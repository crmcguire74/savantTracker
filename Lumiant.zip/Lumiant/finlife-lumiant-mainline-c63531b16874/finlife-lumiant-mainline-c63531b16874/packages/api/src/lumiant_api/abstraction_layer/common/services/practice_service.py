import datetime
import uuid
from typing import Any, Optional

import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from sqlalchemy import and_, func, or_

from lumiant_api.abstraction_layer.common.constants import aws_region, external_domains
from lumiant_api.abstraction_layer.common.database.schema.address import Address as DBAddress
from lumiant_api.abstraction_layer.common.database.schema.client import Client as DBClient
from lumiant_api.abstraction_layer.common.database.schema.contact_details import ContactDetails as DBContactDetails
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset as DBAsset
from lumiant_api.abstraction_layer.common.database.schema.governance.liability import Liability as DBLiability
from lumiant_api.abstraction_layer.common.database.schema.governance.portfolio import Portfolio as DBPortfolio
from lumiant_api.abstraction_layer.common.database.schema.household import Household as DBHousehold
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice as DBPractice
from lumiant_api.abstraction_layer.common.database.schema.practice_billing import PracticeBilling as DBPracticeBilling
from lumiant_api.abstraction_layer.common.database.schema.practice_office import PracticeOffice as DBPracticeOffice
from lumiant_api.abstraction_layer.common.database.schema.staff import Staff as DBStaff
from lumiant_api.abstraction_layer.common.database.schema.tamarac.practice_mapping import (
    TamaracPracticeMapping as DBTamaracPracticeMapping,
)
from lumiant_api.abstraction_layer.common.event_bus.models.operation import Operation
from lumiant_api.abstraction_layer.common.event_bus.models.practice_event import PracticeEvent
from lumiant_core.momentum.apps.api_gateway_restapi.exceptions import InternalServerError
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.models.package import practice_package
from lumiant_api.abstraction_layer.common.models.practice import practice_status
from lumiant_api.abstraction_layer.common.models.practice.practice_status import PracticeStatus
from lumiant_api.abstraction_layer.common.utils.date_utils import DateUtils
from lumiant_api.abstraction_layer.common.utils.domain_utils import DomainUtils
from lumiant_api.abstraction_layer.common.utils.event_bus_utils import EventBusUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class PracticeService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Practice
    -------------------------------------------------------------------------------------------------
    """

    logger = Logger(child=True, service="Practice")
    tracer = Tracer(service="Practice")

    lumiant_rds_session: sqlalchemy.orm.Session
    boto3_session: Boto3Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Boto3Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def get(self, practice_id: int) -> DBPractice | None:
        # pylint: disable=singleton-comparison
        practice = self.lumiant_rds_session.query(DBPractice).filter(DBPractice.practice_id == practice_id).first()

        return practice

    def get_practice_ids_matching_status(self, practice_statuses: list[str]) -> list[int]:
        # pylint: disable=singleton-comparison
        db_practice_ids = (
            self.lumiant_rds_session.query(DBPractice)
            .filter(DBPractice.status.in_(practice_statuses))
            .with_entities(DBPractice.practice_id)
            .all()
        )

        if db_practice_ids is None:
            return []

        practice_ids: list[int] = []
        for db_practice_id in db_practice_ids:
            practice_ids.append(db_practice_id[0])

        return practice_ids

    @tracer.capture_method(capture_response=False)  # type: ignore
    def create_practice(
        self,
        dealer_group_id: int | None,
        name: str,
        abn: str | None,
        afsl: str | None,
        afsl_name: str | None,
        legal_name: str | None,
        status: str | None,
        contract_start: str | datetime.date | None,
        contract_period: int | None,
        ilgn: str | None,
        practice_billing_id: int | None,
        t_c_version: str,
        home_region: str | None,
        home_locale: str | None,
        practice_package_id: int | None = practice_package.STARTER.practice_package_id,
        whitelabel_enabled: bool | None = False,
    ) -> DBPractice:
        name = StringUtils.trim_to_empty(name)
        abn = StringUtils.trim_to_empty(abn).replace(" ", "")
        legal_name = StringUtils.trim_to_empty(legal_name)

        # Conditional ABN rules based on locale/region (AU requires ABN; US forbids it)
        normalized_locale = StringUtils.trim_to_empty(home_locale).lower() if home_locale is not None else ""
        normalized_region = StringUtils.trim_to_empty(home_region).lower() if home_region is not None else ""
        is_au = (aws_region.AP_SOUTHEAST_2 in normalized_region) or ("au" in normalized_locale)
        is_us = (aws_region.US_EAST_1 in normalized_region) or ("us" in normalized_locale)
        if is_au and len(abn) == 0:
            raise InternalServerError("ABN is required for Australian practices")
        abn_to_save: Optional[str] = abn
        if is_us:
            # Ignore ABN for US practices by writing null
            abn_to_save = None

        practice = DBPractice()
        if len(name) > 0:
            practice.name = name
        if abn_to_save is not None and len(abn_to_save) > 0:
            practice.abn = abn_to_save
        if len(abn) > 0:
            practice.legal_name = legal_name
        practice.practice_code = uuid.uuid4()
        practice.created_by = self.auth_metadata.iam_id
        practice.updated_by = self.auth_metadata.iam_id

        if practice_package_id is not None:
            practice.practice_package_id = practice_package_id

        if whitelabel_enabled is not None:
            practice.whitelabel_enabled = whitelabel_enabled

        external_domain = self._get_external_domain(
            practice_billing_id=practice_billing_id, practice_package_id=practice_package_id
        )

        self._set_conditional_values(
            practice=practice,
            dealer_group_id=dealer_group_id,
            afsl=afsl,
            afsl_name=afsl_name,
            status=status,
            contract_start=contract_start,
            contract_period=contract_period,
            ilgn=ilgn,
            practice_billing_id=practice_billing_id,
            external_domain=external_domain,
            t_c_version=t_c_version,
            home_region=home_region,
            home_locale=home_locale,
            upsert_type="insert",
        )

        practice.original_status = status  # type: ignore

        self.lumiant_rds_session.add(practice)
        self.lumiant_rds_session.commit()

        try:
            lumiant_event = PracticeEvent(  # type: ignore
                operation=Operation.CREATED,
                lumiant_object_id=practice.practice_id,  # type: ignore
                practice_id=practice.practice_id,  # type: ignore
                lumiant_object_properties=None,  # type: ignore
            )

            print("Created practice, sending event...")
            EventBusUtils.publish_lumiant_event(
                lumiant_event=lumiant_event,
                account_id=self.auth_metadata.account_id,
                region=self.auth_metadata.region,
                boto3_session=self.boto3_session,
            )
        except Exception as e:
            self.logger.error("Failed to send PracticeEvent - {0}".format(e), exc_info=True)

        return practice

    @tracer.capture_method(capture_response=False)  # type: ignore
    def update_practice(
        self,
        practice_id: int,
        dealer_group_id: int | None,
        name: str | None,
        abn: str | None,
        afsl: str | None,
        afsl_name: str | None,
        legal_name: str | None,
        status: str | None,
        contract_start: str | datetime.date | None,
        contract_period: int | None,
        ilgn: str | None,
        practice_billing_id: int | None,
        t_c_version: str,
        home_region: str | None,
        home_locale: str | None,
    ) -> DBPractice | None:
        practice = self.lumiant_rds_session.query(DBPractice).filter(DBPractice.practice_id == practice_id).first()

        if practice is None:
            print("Could not update Practice as no practice with id [{0}] was found".format(practice_id))
            raise InternalServerError("Could not update Practice")

        practice.updated = datetime.datetime.now(datetime.UTC)
        practice.updated_by = self.auth_metadata.iam_id

        # We want to ensure that we don't set the name or abn to a value that's already in use
        # AFSL can be duplicated as we have existing data where the AFSL is the AFSL of the Dealer Group
        if name is not None:
            name = StringUtils.trim_to_empty(name)

            if len(name) > 0 and name != practice.name:
                self.check_for_duplicate_values(DBPractice.name, name)
                practice.name = name

        if abn is not None:
            abn = StringUtils.trim_to_empty(abn)

            if len(abn) > 0 and abn != practice.abn:
                self.check_for_duplicate_values(DBPractice.abn, abn)
                practice.abn = abn

        if legal_name is not None:
            legal_name = StringUtils.trim_to_empty(legal_name)

            if len(legal_name) > 0 and legal_name != practice.legal_name:
                self.check_for_duplicate_values(DBPractice.legal_name, legal_name)
                practice.legal_name = legal_name

        external_domain = self._get_external_domain(
            practice_billing_id=practice_billing_id, practice_package_id=practice.practice_package_id
        )

        self._set_conditional_values(
            practice=practice,
            dealer_group_id=dealer_group_id,
            afsl=afsl,
            afsl_name=afsl_name,
            status=status,
            contract_start=contract_start,
            contract_period=contract_period,
            ilgn=ilgn,
            practice_billing_id=practice_billing_id,
            external_domain=external_domain,
            t_c_version=t_c_version,
            home_region=home_region,
            home_locale=home_locale,
        )

        self.lumiant_rds_session.commit()

        try:
            lumiant_event = PracticeEvent(  # type: ignore
                operation=Operation.UPDATED,
                lumiant_object_id=practice.practice_id,  # type: ignore
                lumiant_object_properties=None,  # type: ignore
            )

            print("Updated practice, sending event...")
            EventBusUtils.publish_lumiant_event(
                lumiant_event=lumiant_event,
                account_id=self.auth_metadata.account_id,
                region=self.auth_metadata.region,
                boto3_session=self.boto3_session,
            )
        except Exception as e:
            self.logger.error("Failed to send PracticeEvent - {0}".format(e), exc_info=True)

        return practice

    def check_for_duplicate_values(self, column: Any, value: str, upsert_type: str = "update") -> None:
        existing_practice = (
            self.lumiant_rds_session.query(DBPractice).filter(func.lower(column) == value.lower()).first()
        )

        if existing_practice is not None:
            print(
                "Could not {0} Practice as the column [{1}] value [{2}] is duplicated".format(
                    upsert_type, column, value
                )
            )
            column_name = column.prop.key
            column_name = column_name.replace("_", " ")
            column_value = str(value)

            raise InternalServerError(
                "Sorry. There appears to be an existing Practice matching the details you entered. Please provide "
                "another value for Practice {0} -> {1} in the Practice Details section. (PS-1)".format(
                    column_name, column_value
                ),
            )

    def _set_conditional_values(
        self,
        practice: DBPractice,
        dealer_group_id: int | None,
        afsl: str | None,
        afsl_name: str | None,
        status: str | None,
        contract_start: Any | None,
        contract_period: int | None,
        ilgn: str | None,
        practice_billing_id: int | None,
        external_domain: str | None,
        t_c_version: str | None,
        home_region: str | None,
        home_locale: str | None,
        upsert_type: str = "update",
    ) -> None:
        if dealer_group_id is not None:
            practice.dealer_group_id = dealer_group_id

        if afsl is not None:
            practice.afsl = StringUtils.trim_to_empty(afsl).replace(" ", "")

        if afsl_name is not None:
            practice.afsl_name = StringUtils.trim_to_empty(afsl_name)

        if status is not None:
            if PracticeStatus.get_from_status(status) is None:
                print("Could not {0} Practice as the status [{1}] is invalid".format(upsert_type, status))
                raise InternalServerError(
                    "Sorry. We were unable to create your Practice in our system. Please try again. (PS-2)",
                )

            practice.status = status

        if contract_start is not None:
            if isinstance(contract_start, datetime.datetime):
                practice.contract_start = contract_start.date()
            elif isinstance(contract_start, datetime.date):
                practice.contract_start = contract_start
            elif isinstance(contract_start, str):
                try:
                    practice.contract_start = DateUtils.parse_unknown_str_as_date(
                        contract_start, region=self.auth_metadata.region
                    )
                except Exception:
                    pass

        if contract_period is not None:
            practice.contract_period = contract_period

        if ilgn is not None:
            practice.ilgn = StringUtils.trim_to_empty(ilgn)

        if practice_billing_id is not None:
            practice.practice_billing_id = practice_billing_id

        if external_domain is not None:
            practice.external_domain = external_domain

        if t_c_version is not None:
            practice.t_c_version = StringUtils.trim_to_empty(t_c_version)

        if home_region is not None:
            practice.home_region = StringUtils.trim_to_empty(home_region)

        if home_locale is not None:
            practice.home_locale = StringUtils.trim_to_empty(home_locale)

    def _get_practice_country(self, practice_billing_id: int | None) -> str | None:
        if practice_billing_id is None:
            return None

        practice_billing = (
            self.lumiant_rds_session.query(DBPracticeBilling)
            .join(DBAddress, DBAddress.address_id == DBPracticeBilling.billing_address_id)
            .filter(DBPracticeBilling.practice_billing_id == practice_billing_id)
            .first()
        )

        if practice_billing is None:
            return None

        return practice_billing.address.country

    def _get_external_domain(self, practice_billing_id: int | None, practice_package_id: int | None) -> str:
        if practice_package_id is not None and practice_package_id == practice_package.INVPREFS.practice_package_id:
            return external_domains.INVPREFS

        practice_country = self._get_practice_country(practice_billing_id)
        external_domain = DomainUtils.get_domain_for_country_code(  # type: ignore[attr-defined]
            country_code=practice_country, environment=self.auth_metadata.environment
        )

        return external_domain

    def get_practice_id_for_client(self, client: DBClient | None) -> int | None:
        if client is not None and client.household is not None:
            return self.get_practice_id_for_household(household=client.household)

        return None

    def get_practice_id_for_household(self, household: DBHousehold | None) -> int | None:
        if household is not None and household.household_team_members is not None:
            practice: DBPractice
            if isinstance(household.household_team_members, DBHouseholdTeamMember):
                practice = household.household_team_members.practice
            else:
                practice = household.household_team_members[0].practice

            if practice is not None:
                return practice.practice_id

        return None

    def get_practice_from_tamarac_practice_name(self, tamarac_practice_name: str | None) -> int | None:
        if tamarac_practice_name is None:
            return None

        tamarac_mapping: DBPractice | None = (
            self.lumiant_rds_session.query(DBPractice)
            .join(DBTamaracPracticeMapping, DBTamaracPracticeMapping.practice_id == DBPractice.practice_id)
            .filter(DBTamaracPracticeMapping.tamarac_practice_name == tamarac_practice_name)
            .first()
        )

        if tamarac_mapping is None:
            return None

        return tamarac_mapping.practice_id

    def is_practice_from_client_email_trial(
        self,
        email_address: str,
    ) -> bool:
        client_email_practice = (
            self.lumiant_rds_session.query(DBPractice)
            .join(DBHouseholdTeamMember, DBPractice.practice_id == DBHouseholdTeamMember.practice_id)
            .join(DBClient, DBHouseholdTeamMember.household_id == DBClient.household_id)
            .join(DBContactDetails, DBClient.contact_details_id == DBContactDetails.contact_details_id)
            .filter(
                and_(
                    DBContactDetails.email_address == email_address,
                    DBPractice.status == practice_status.STATUS_TRIAL.status,
                )
            )
            .with_entities(DBPractice.practice_id)
            .first()
        )

        return client_email_practice is not None

    def is_practice_from_staff_email_trial(
        self,
        email_address: str,
    ) -> bool:
        staff_email_practice = (
            self.lumiant_rds_session.query(DBPractice)
            .join(DBPracticeOffice, DBPractice.practice_id == DBPracticeOffice.practice_id)
            .join(DBStaff, DBPracticeOffice.practice_office_id == DBStaff.practice_office_id)
            .join(DBContactDetails, DBStaff.contact_details_id == DBContactDetails.contact_details_id)
            .filter(
                and_(
                    DBContactDetails.email_address == email_address,
                    DBPractice.status == practice_status.STATUS_TRIAL.status,
                )
            )
            .with_entities(DBPractice.practice_id)
            .first()
        )

        return staff_email_practice is not None

    # TODO: Leandro - this should be in HouseholdService
    def get_household_ids_list_for_net_worth_timeline(self, practice_id: int) -> list[int]:
        household_ids_list = []
        household_ids_tuple = (
            self.lumiant_rds_session.query(DBHouseholdTeamMember)
            .outerjoin(DBAsset, DBAsset.household_id == DBHouseholdTeamMember.household_id)
            .outerjoin(DBLiability, DBLiability.household_id == DBHouseholdTeamMember.household_id)
            .filter(
                DBHouseholdTeamMember.practice_id == practice_id,
                or_(DBAsset.asset_id.is_not(None), DBLiability.liability_id.is_not(None)),
            )
            .with_entities(DBHouseholdTeamMember.household_id)
            .distinct()
            .all()
        )

        for household_id_tuple in household_ids_tuple:
            if household_id_tuple is not None:
                household_ids_list.append(household_id_tuple[0])

        return household_ids_list

    # TODO: Leandro - this should be in HouseholdService
    def get_household_ids_list_for_account_value_net_investment(self, practice_id: int) -> list[int]:
        household_ids_list = []
        household_ids_tuple = (
            self.lumiant_rds_session.query(DBHouseholdTeamMember)
            .join(DBPortfolio, DBPortfolio.household_id == DBHouseholdTeamMember.household_id)
            .filter(DBHouseholdTeamMember.practice_id == practice_id, DBPortfolio.soft_deleted.is_(False))
            .with_entities(DBHouseholdTeamMember.household_id)
            .distinct()
            .all()
        )

        for household_id_tuple in household_ids_tuple:
            if household_id_tuple is not None:
                household_ids_list.append(household_id_tuple[0])

        return household_ids_list

    def get_for_staff_id_from_practice_office(
        self,
        staff_id: int,
    ) -> DBPractice | None:
        practice = (
            self.lumiant_rds_session.query(DBPractice)
            .join(DBPracticeOffice, DBPracticeOffice.practice_id == DBPractice.practice_id)
            .join(DBStaff, DBStaff.practice_office_id == DBPracticeOffice.practice_office_id)
            .filter(DBStaff.staff_id == staff_id)
            .first()
        )

        return practice
