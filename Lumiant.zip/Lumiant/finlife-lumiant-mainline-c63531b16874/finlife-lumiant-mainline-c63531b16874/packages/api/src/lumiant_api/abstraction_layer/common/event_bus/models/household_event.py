from lumiant_api.abstraction_layer.common.event_bus.models.lumiant_event import LumiantEvent
from pydantic import Field


class HouseholdEvent(LumiantEvent):
    """
    -------------------------------------------------------------------------------------------------
    MODEL: Household Event
    -------------------------------------------------------------------------------------------------
    """

    type: str = Field(
        alias="type",
        description="The type of event that has occurred",
        json_schema_extra={"is_attribute": True},
        default="Household",
    )

    lumiant_object: str = Field(
        alias="lumiantObject",
        description="The lumiant object (if any) that this event pertains to",
        json_schema_extra={"is_attribute": True},
        default="Household",
    )

    lumiant_object_id_column: str = Field(
        alias="lumiantObjectIdColumn",
        description="The ID column name of the lumiant object that this event pertains to",
        json_schema_extra={"is_attribute": True},
        default="household_id",
    )
