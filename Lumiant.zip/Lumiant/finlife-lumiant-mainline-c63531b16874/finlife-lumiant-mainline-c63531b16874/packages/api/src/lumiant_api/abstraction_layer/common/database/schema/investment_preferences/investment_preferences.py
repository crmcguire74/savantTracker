import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, String, DateTime, text, ForeignKey, Boolean, Text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import mapped_column, relationship, Mapped


class InvestmentPreferences(Base):
    __tablename__ = "InvestmentPreferences"

    investment_preferences_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("Client.client_id"), nullable=False, index=True)
    intro_video: Mapped[str | None] = mapped_column(String(255), nullable=True)
    customisation_video: Mapped[str | None] = mapped_column(String(255), nullable=True)
    customisation: Mapped[str | None] = mapped_column(ENUM("Y", "N", "NP", "U"), nullable=True)
    ethical_video: Mapped[str | None] = mapped_column(String(255), nullable=True)
    ethical: Mapped[str | None] = mapped_column(ENUM("Y", "N", "NP", "U"), nullable=True)
    asset_class_video: Mapped[str | None] = mapped_column(String(255), nullable=True)
    allocation_video: Mapped[str | None] = mapped_column(String(255), nullable=True)
    allocation_type: Mapped[str | None] = mapped_column(ENUM("S", "D", "NP", "U"), nullable=True)
    risk_video: Mapped[str | None] = mapped_column(String(255), nullable=True)
    comfortable_with_downturn: Mapped[str | None] = mapped_column(String(255), nullable=True)
    cost_video: Mapped[str | None] = mapped_column(String(255), nullable=True)
    cost_driven: Mapped[str | None] = mapped_column(ENUM("Y", "N"), nullable=True)
    comments: Mapped[str | None] = mapped_column(Text, nullable=True)
    customisation_video_help: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    customisation_video_comments: Mapped[str | None] = mapped_column(Text, nullable=True)
    ethical_video_help: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    ethical_video_comments: Mapped[str | None] = mapped_column(Text, nullable=True)
    asset_class_video_help: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    asset_class_video_comments: Mapped[str | None] = mapped_column(Text, nullable=True)
    allocation_video_help: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    allocation_video_comments: Mapped[str | None] = mapped_column(Text, nullable=True)
    risk_video_help: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    risk_video_comments: Mapped[str | None] = mapped_column(Text, nullable=True)
    risk_diversification: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_market_correction: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_percentage_drop: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_capital_protection: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    risk_access_capital: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_influenced_by_returns: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_increase_to_meet_goal: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_max_downside: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_inflation: Mapped[int | None] = mapped_column(Integer, nullable=True)
    cost_video_help: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    cost_video_comments: Mapped[str | None] = mapped_column(Text, nullable=True)
    asset_class_and_diversification_video_help: Mapped[str | None] = mapped_column(ENUM("Y", "N", "U"), nullable=True)
    asset_class_preferences: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    asset_class_preferences_comments: Mapped[str | None] = mapped_column(String(1023), nullable=True)
    asset_class_risk: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    asset_class_risk_comments: Mapped[str | None] = mapped_column(String(1023), nullable=True)
    ethical_preferences: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    ethical_preferences_comments: Mapped[str | None] = mapped_column(String(1023), nullable=True)
    active_passive_video_help: Mapped[str | None] = mapped_column(ENUM("Y", "N", "U"), nullable=True)
    cost_wealth_priorities: Mapped[str | None] = mapped_column(ENUM("A", "B", "C", "D"), nullable=True)
    risk_volatility_video_help: Mapped[str | None] = mapped_column(ENUM("Y", "N", "U"), nullable=True)
    risk_timelines: Mapped[str | None] = mapped_column(ENUM("Y", "N", "U"), nullable=True)
    risk_experience: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_knowledge: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_past: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_current: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_timeframe: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_variability: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_volatility: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_reaction: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_tolerance: Mapped[int | None] = mapped_column(Integer, nullable=True)
    risk_future: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    deleted_by: Mapped[str | None] = mapped_column(String(50), nullable=True)
    deleted: Mapped[datetime.datetime | None] = mapped_column(DateTime, nullable=True)

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client: Mapped["Client"] = relationship("Client", back_populates="investment_preferences", lazy="select")

    prioritisation: Mapped[list["InvestmentPreferencesRanking"]] = relationship(
        "InvestmentPreferencesRanking", back_populates="investment_preferences", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.investment_preferences.investment_preferences_ranking import (
    InvestmentPreferencesRanking,
)  # pylint: disable=C0413,R0401
