import json
from dataclasses import dataclass

from aws_lambda_powertools import Logger

from lumiant_api.abstraction_layer.common.database.schema.governance.asset_yodlee_mapping import (
    AssetYodleeMapping as DBAssetYodleeMapping,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance_yodlee_mapping import (
    InsuranceYodleeMapping as DBInsuranceYodleeMapping,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.liability_yodlee_mapping import (
    LiabilityYodleeMapping as DBLiabilityYodleeMapping,
)
from lumiant_api.abstraction_layer.common.models.governance.utils.yodlee_mapping_utils import YodleeMappingUtils
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils


@dataclass
class YodleeMapping(object):
    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    providerAccountId: int | None
    additionalStatus: str
    additionalStatusDescription: str
    lastUpdated: str
    isBroken: bool
    createdBy: str
    created: str
    updatedBy: str
    updated: str

    def __init__(self) -> None:
        self.providerAccountId = None
        self.additionalStatus = ""
        self.additionalStatusDescription = ""
        self.lastUpdated = ""
        self.isBroken = False
        self.createdBy = ""
        self.created = ""
        self.updatedBy = ""
        self.updated = ""

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)

    @staticmethod
    def convert_from_db_model(
        db_yodlee_mapping: DBAssetYodleeMapping | DBLiabilityYodleeMapping | DBInsuranceYodleeMapping | None,
    ) -> "YodleeMapping | None":
        if db_yodlee_mapping is None:
            return None

        yodlee_mapping = YodleeMapping()
        yodlee_mapping.providerAccountId = int(db_yodlee_mapping.provider_account_id)  # type: ignore
        yodlee_mapping.additionalStatus = db_yodlee_mapping.additional_status  # type: ignore
        yodlee_mapping.additionalStatusDescription = YodleeMappingUtils.get_status_description(
            status=db_yodlee_mapping.additional_status
        )
        yodlee_mapping.lastUpdated = SerializationUtils.convert_value_to_string(db_yodlee_mapping.last_updated)
        yodlee_mapping.isBroken = YodleeMappingUtils.is_link_broken(status=db_yodlee_mapping.additional_status)
        yodlee_mapping.createdBy = db_yodlee_mapping.created_by
        yodlee_mapping.created = SerializationUtils.convert_value_to_string(db_yodlee_mapping.created)
        yodlee_mapping.updatedBy = db_yodlee_mapping.updated_by
        yodlee_mapping.updated = SerializationUtils.convert_value_to_string(db_yodlee_mapping.updated)

        return yodlee_mapping
