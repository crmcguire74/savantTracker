import datetime

from boto3.session import Session as Boto3Session
from dateutil import parser

import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from lumiant_api.abstraction_layer.common.constants import aws_region
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance_yodlee_mapping import (
    InsuranceYodleeMapping as DBInsuranceYodleeMapping,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.liability_yodlee_mapping import (
    LiabilityYodleeMapping as DBLiabilityYodleeMapping,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.asset_yodlee_mapping import (
    AssetYodleeMapping as DBAssetYodleeMapping,
)
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class YodleeMappingService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Yodlee Mapping object
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(child=True, service="Governance")
    tracer = Tracer(service="Governance")

    lumiant_rds_session: sqlalchemy.orm.Session
    boto3_session: Boto3Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Boto3Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def get_asset_yodlee_mapping(self, asset_id: int) -> DBAssetYodleeMapping | None:
        yodlee_mapping = (
            self.lumiant_rds_session.query(DBAssetYodleeMapping)
            .filter(DBAssetYodleeMapping.asset_id == asset_id)
            .first()
        )

        return yodlee_mapping

    def get_liability_yodlee_mapping(self, liability_id: int) -> DBLiabilityYodleeMapping | None:
        yodlee_mapping = (
            self.lumiant_rds_session.query(DBLiabilityYodleeMapping)
            .filter(DBLiabilityYodleeMapping.liability_id == liability_id)
            .first()
        )

        return yodlee_mapping

    def get_insurance_yodlee_mapping(self, insurance_id: int) -> DBInsuranceYodleeMapping | None:
        yodlee_mapping = (
            self.lumiant_rds_session.query(DBInsuranceYodleeMapping)
            .filter(DBInsuranceYodleeMapping.insurance_id == insurance_id)
            .first()
        )

        return yodlee_mapping

    @tracer.capture_method(capture_response=False)  # type: ignore
    def save(
        self,
        entity_type: str,
        entity_id: int,
        provider_account_id: str,
        additional_status: str,
        last_updated: str | datetime.datetime | None,
        execute_commit: bool = False,
    ) -> DBAssetYodleeMapping | DBLiabilityYodleeMapping | DBInsuranceYodleeMapping | None:
        yodlee_mapping: DBAssetYodleeMapping | DBLiabilityYodleeMapping | DBInsuranceYodleeMapping | None = None
        if entity_type == "A":
            yodlee_mapping = self.get_asset_yodlee_mapping(asset_id=entity_id)
        elif entity_type == "L":
            yodlee_mapping = self.get_liability_yodlee_mapping(liability_id=entity_id)
        elif entity_type == "I":
            yodlee_mapping = self.get_insurance_yodlee_mapping(insurance_id=entity_id)

        if yodlee_mapping is None:
            if entity_type == "A":
                yodlee_mapping = DBAssetYodleeMapping()
                yodlee_mapping.asset_id = entity_id
            elif entity_type == "L":
                yodlee_mapping = DBLiabilityYodleeMapping()
                yodlee_mapping.liability_id = entity_id
            else:
                yodlee_mapping = DBInsuranceYodleeMapping()
                yodlee_mapping.insurance_id = entity_id

            yodlee_mapping.created = datetime.datetime.now(datetime.UTC)
            yodlee_mapping.created_by = self.auth_metadata.iam_id
            self.lumiant_rds_session.add(yodlee_mapping)

        yodlee_mapping.provider_account_id = provider_account_id
        yodlee_mapping.additional_status = additional_status

        if last_updated is not None:
            last_updated_parsed: datetime.datetime | None = None

            if isinstance(last_updated, datetime.datetime):
                last_updated_parsed = last_updated
            elif isinstance(last_updated, str) and len(StringUtils.trim_to_empty(last_updated)) > 0:
                try:
                    last_updated_parsed = parser.parse(
                        last_updated, dayfirst=self.auth_metadata.region != aws_region.US_EAST_1
                    )
                except Exception:
                    # If we couldn't parse the date ignore it - should be coming through as a date not a string!
                    pass

            yodlee_mapping.last_updated = last_updated_parsed

        yodlee_mapping.updated = datetime.datetime.now(datetime.UTC)
        yodlee_mapping.updated_by = self.auth_metadata.iam_id

        if execute_commit:
            self.lumiant_rds_session.commit()
        else:
            self.lumiant_rds_session.flush()

        return yodlee_mapping
