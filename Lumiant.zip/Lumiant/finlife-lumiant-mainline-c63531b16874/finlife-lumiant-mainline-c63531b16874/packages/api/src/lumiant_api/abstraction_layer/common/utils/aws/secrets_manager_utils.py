import json

import botocore.client
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from botocore.exceptions import ClientError

from lumiant_api.abstraction_layer.common.types.singleton import Singleton
from lumiant_api.abstraction_layer.common.utils.region_utils import RegionUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class SecretsManagerUtils(object, metaclass=Singleton):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Secrets Manager - Handy methods for interacting with the AWS Secrets Manager
    -------------------------------------------------------------------------------------------------
    """

    logger = Logger(child=True, service="SharedLayer")
    tracer = Tracer(service="SharedLayer")

    SECRETS_MANAGER_SERVICE_NAME = "secretsmanager"

    boto3_session: Boto3Session
    default_region: str
    client: botocore.client  # type: ignore

    def __init__(self, boto3_session: Boto3Session, default_region: str | None = None) -> None:
        self.boto3_session = boto3_session

        def_region = StringUtils.trim_to_empty(default_region)
        if len(def_region) == 0:
            def_region = RegionUtils.get_current_region()

        self.default_region = def_region
        self.client = self.boto3_session.client(  # type: ignore
            service_name=SecretsManagerUtils.SECRETS_MANAGER_SERVICE_NAME, region_name=default_region
        )

    @tracer.capture_method(capture_response=False)  # type: ignore
    def get_client(self, region: str | None = None) -> botocore.client:  # type: ignore
        if region is None:
            return self.client
        elif region != self.default_region:
            return self.boto3_session.client(  # type: ignore
                service_name=SecretsManagerUtils.SECRETS_MANAGER_SERVICE_NAME, region_name=region
            )
        else:
            return self.client

    def get_secret_arn(self, region: str, secret_name: str) -> str:
        client = self.get_client(region=region)

        try:
            secret_description = client.describe_secret(SecretId=secret_name)  # type: ignore
            secret_arn = secret_description["ARN"]
            return secret_arn
        except ClientError as e:
            if e.response["Error"]["Code"] == "DecryptionFailureException":  # type: ignore
                self.logger.error("Secrets Manager can't decrypt the protected secret text using the provided KMS key.")
            elif e.response["Error"]["Code"] == "InternalServiceErrorException":  # type: ignore
                self.logger.error("Secrets Manager had an internal service error.")
            elif e.response["Error"]["Code"] == "InvalidParameterException":  # type: ignore
                self.logger.error("Invalid parameter provided.")
            elif e.response["Error"]["Code"] == "InvalidRequestException":  # type: ignore
                self.logger.error("Parameter value provided is not valid for the current state.")
            elif e.response["Error"]["Code"] == "ResourceNotFoundException":  # type: ignore
                self.logger.error("Secrets Manager could not be found.")

            return ""

    def get_rds_cluster_secrets(
        self, region: str | None, secret_name: str, routing_via_localhost: bool
    ) -> tuple[str, str, str, str, bool]:
        client = self.get_client(region=region)

        try:
            secret_value_response = client.get_secret_value(SecretId=secret_name)  # type: ignore

            if "SecretString" in secret_value_response:
                lumiant_cluster_secrets_json = json.loads(secret_value_response["SecretString"])
                username: str = lumiant_cluster_secrets_json["username"]
                password: str = lumiant_cluster_secrets_json["password"]
                port: str = lumiant_cluster_secrets_json["port"]
                rds_proxy: str = (
                    lumiant_cluster_secrets_json["rdsProxy"] if "rdsProxy" in lumiant_cluster_secrets_json else ""
                )

                # If we have rds_proxy defined overwrite with localhost tunnelling if unit testing
                if routing_via_localhost and rds_proxy is not None:
                    rds_proxy = "127.0.0.1"
                    port = "13306"

                init_via_rds_proxy = True if len(StringUtils.trim_to_empty(rds_proxy)) > 0 else False
                return username, password, port, rds_proxy, init_via_rds_proxy

            return "", "", "", "", False
        except ClientError as e:
            if e.response["Error"]["Code"] == "DecryptionFailureException":  # type: ignore
                self.logger.error("Secrets Manager can't decrypt the protected secret text using the provided KMS key.")
            elif e.response["Error"]["Code"] == "InternalServiceErrorException":  # type: ignore
                self.logger.error("Secrets Manager had an internal service error.")
            elif e.response["Error"]["Code"] == "InvalidParameterException":  # type: ignore
                self.logger.error("Invalid parameter provided.")
            elif e.response["Error"]["Code"] == "InvalidRequestException":  # type: ignore
                self.logger.error("Parameter value provided is not valid for the current state.")
            elif e.response["Error"]["Code"] == "ResourceNotFoundException":  # type: ignore
                self.logger.error("Secrets Manager could not be found.")

            return "", "", "", "", False
