from enum import Enum


class Operation(Enum):
    """
    -------------------------------------------------------------------------------------------------
    ENUM: Operation
    -------------------------------------------------------------------------------------------------
    """

    NA = 0
    CREATED = 1
    UPDATED = 2
    DELETED = 3
    ENABLED = 4
    DISABLED = 5
    PUSH_TO_EXTERNAL = 6

    @staticmethod
    def get_operation_name(op: int) -> str:
        if op == Operation.NA.value:
            return "NA"
        elif op == Operation.CREATED.value:
            return "CREATED"
        elif op == Operation.UPDATED.value:
            return "UPDATED"
        elif op == Operation.DELETED.value:
            return "DELETED"
        elif op == Operation.ENABLED.value:
            return "ENABLED"
        elif op == Operation.DISABLED.value:
            return "DISABLED"
        elif op == Operation.PUSH_TO_EXTERNAL.value:
            return "PUSH_TO_EXTERNAL"
        else:
            return "UNKNOWN"
