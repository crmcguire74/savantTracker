import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Boolean, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class PracticeHouseholdPackage(Base):
    __tablename__ = "PracticeHouseholdPackage"

    practice_household_package_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    practice_package_id: Mapped[int] = mapped_column(
        ForeignKey("PracticePackage.practice_package_id"), nullable=False, index=True
    )
    household_package_id: Mapped[int] = mapped_column(
        ForeignKey("HouseholdPackage.household_package_id"), nullable=False, index=True
    )
    default_hh_package: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # practice_packages = relationship('PracticePackage', back_populates='practice_household_packages')
    # household_packages = relationship('HouseholdPackage', back_populates='practice_household_packages')

    # One-Way Relationships
    household_package: Mapped[list["HouseholdPackageComponent"]] = relationship("HouseholdPackage", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.packages.household_package_component import (
    HouseholdPackageComponent,
)  # pylint: disable=C0413,R0401
