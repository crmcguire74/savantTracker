import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Boolean, String, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class PowerOf(Base):
    __tablename__ = "PowerOf"

    power_of_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    estate_planning_id: Mapped[int] = mapped_column(
        ForeignKey("EstatePlanning.estate_planning_id"), nullable=False, index=True
    )
    power_of_type: Mapped[str | None] = mapped_column(ENUM("A", "G"))
    poa_type_enduring: Mapped[bool | None] = mapped_column(Boolean)
    poa_type_medical: Mapped[bool | None] = mapped_column(Boolean)
    poa_type_limited: Mapped[bool | None] = mapped_column(Boolean)
    poa_type_care: Mapped[bool | None] = mapped_column(Boolean)
    poa_type_other: Mapped[bool | None] = mapped_column(Boolean)
    first_name: Mapped[str] = mapped_column(String(255), nullable=False)
    middle_name: Mapped[str | None] = mapped_column(String(255))
    last_name: Mapped[str] = mapped_column(String(255), nullable=False)
    is_alternate: Mapped[bool | None] = mapped_column(Boolean)
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    notes: Mapped[str | None] = mapped_column(String(5000))
    client_notes: Mapped[str | None] = mapped_column(String(2500))
    partner_notes: Mapped[str | None] = mapped_column(String(2500))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    estate_planning: Mapped["EstatePlanning"] = relationship(
        "EstatePlanning", back_populates="powers_of", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.governance.estate_planning import EstatePlanning  # pylint: disable=C0413,R0401
