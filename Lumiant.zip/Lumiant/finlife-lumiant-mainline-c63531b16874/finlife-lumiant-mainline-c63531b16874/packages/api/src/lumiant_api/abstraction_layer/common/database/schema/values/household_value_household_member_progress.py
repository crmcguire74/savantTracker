import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class HouseholdValueHouseholdMemberProgress(Base):
    __tablename__ = "HouseholdValueHouseholdMemberProgress"

    household_value_household_member_progress_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_value_id: Mapped[int] = mapped_column(
        ForeignKey("HouseholdValue.household_value_id"), nullable=False, index=True
    )
    description: Mapped[str | None] = mapped_column(String(5000))
    progress: Mapped[int | None] = mapped_column(Integer)
    client_id: Mapped[int | None] = mapped_column(Integer, index=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household_value: Mapped["HouseholdValue"] = relationship(
        "HouseholdValue", back_populates="household_member_progress", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.values.household_value import HouseholdValue  # pylint: disable=C0413,R0401
