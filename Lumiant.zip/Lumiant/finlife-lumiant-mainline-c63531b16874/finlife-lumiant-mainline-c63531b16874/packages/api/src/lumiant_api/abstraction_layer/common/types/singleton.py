from typing import Any


class Singleton(type):
    """
    -------------------------------------------------------------------------------------------------
    Singleton design pattern
    -------------------------------------------------------------------------------------------------
    """

    def __init__(cls, what: str, bases: Any, dict_: dict[str, Any]) -> None:
        super(Singleton, cls).__init__(what, bases, dict_)
        cls.__instance = None

    def __call__(cls, *args: Any, **kwargs: Any) -> Any:
        if cls.__instance is None:
            cls.__instance = super(Singleton, cls).__call__(*args, **kwargs)
        return cls.__instance
