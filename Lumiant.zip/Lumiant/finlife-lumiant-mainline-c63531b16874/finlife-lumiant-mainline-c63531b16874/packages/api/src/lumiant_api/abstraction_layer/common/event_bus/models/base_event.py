import uuid

from pydantic import ConfigDict, BaseModel, Field


class BaseEvent(BaseModel):
    """
    -------------------------------------------------------------------------------------------------
    MODEL: Base Event
    -------------------------------------------------------------------------------------------------
    """

    # Event Identifier
    id: str = Field(
        alias="id",
        description="The unique ID of the event",
        json_schema_extra={"is_attribute": True},
        default=str(uuid.uuid4()),
    )

    # Event Type
    type: str = Field(
        alias="type",
        description="The type of event that has occurred",
        json_schema_extra={"is_attribute": True},
    )

    model_config = ConfigDict(populate_by_name=True)
