import uuid
from typing import Any

from aws_lambda_powertools import Logger
from sqlalchemy import Row, Select, and_, select
from sqlalchemy.orm import Session, aliased

from lumiant_api.abstraction_layer.common.constants import roles
from lumiant_api.abstraction_layer.common.database.schema.client import Client as DBClient
from lumiant_api.abstraction_layer.common.database.schema.household import Household as DBHousehold
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice as DBPractice
from lumiant_api.abstraction_layer.common.database.schema.practice_office import PracticeOffice as DBPracticeOffice
from lumiant_api.abstraction_layer.common.database.schema.staff import Staff as DBStaff
from lumiant_core.momentum.apps.api_gateway_restapi.exceptions import InternalServerError
from lumiant_api.abstraction_layer.common.models.practice import practice_status
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class AuthorisationUtils(object):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Authorisation - Handy methods for performing Lumiant authorisation checks
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    @staticmethod
    def get_staff_id_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        staff_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> int | None:
        # If a Lumiant Elevated user is making this call then they're allowed to access any staff record and this HAS
        # to be specified via the staff_id as the username will be that of the Lumiant Elevated user. Note: we could
        # perform an additional check here to ensure that the staff_id provided exists in the practice_id provided.
        print("A")
        if is_lumiant_elevated_user:
            print("B")
            return staff_id

        # If the user is not a staff member, then they're not allowed access
        if not is_staff:
            print("C")
            return None

        # If the user is a staff member then they can access their own information, OR, if they're a Practice Manager
        # they can access any staff member within their practice
        result_tuple = session.execute(
            select(DBStaff)
            .join(DBPracticeOffice, DBPracticeOffice.practice_office_id == DBStaff.practice_office_id)
            .where(and_(DBPracticeOffice.practice_id == practice_id, DBStaff.iam_id == uuid.UUID(iam_id)))
            .with_only_columns(DBStaff.staff_id, DBStaff.role)
            .limit(1)
        ).first()
        print("D")
        print(result_tuple)
        if result_tuple is None:
            return None

        db_user_staff_id, db_user_staff_role = result_tuple[0], result_tuple[1]
        print(db_user_staff_id)
        print(db_user_staff_role)
        # If we don't have information about the current staff member, we can't continue
        if db_user_staff_id is None:
            print("E")
            return None

        if staff_id is None:
            print("F")
            # A staff member is accessing their own information
            return db_user_staff_id
        else:
            if roles.STAFF_ROLE_PRACTICE_MANAGER not in db_user_staff_role[0]:
                # If you have specified a staff_id but you're not a Practice Manager we want to return None as you don't
                # have access to other staff
                print("G")
                return None
            else:
                # If you are a Practice Manager we need to ensure that the staff member you've selected is within your
                # practice
                db_selected_staff_id: int = session.scalars(
                    select(DBStaff)
                    .join(DBPracticeOffice, DBPracticeOffice.practice_office_id == DBStaff.practice_office_id)
                    .where(and_(DBPracticeOffice.practice_id == practice_id, DBStaff.staff_id == staff_id))
                    .with_only_columns(DBStaff.staff_id)
                    .limit(1)
                ).first()  # type: ignore
                print("H")
                return db_selected_staff_id

    @staticmethod
    def get_client_id_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> int | None:
        try:
            result = AuthorisationUtils._get_client_partner_household_query_based_on_user(
                iam_id=iam_id,
                is_staff=is_staff,
                session=session,
                practice_id=practice_id,
                client_id=client_id,
                household_id=household_id,
                get_client=True,
                get_partner=False,
                get_household=False,
                get_ids_only=True,
                is_lumiant_elevated_user=is_lumiant_elevated_user,
            )

            return result[0] if result is not None and len(result) > 0 else None
        except Exception:
            # Many reasons why this would fail - namely that the user doesn't have access to the specified client
            if is_staff and client_id is None:
                return None

            AuthorisationUtils.logger.error(
                "Failed to retrieve client id [Username - {0}, Client Id - {1}, Is Staff - {2}, "
                "Practice Id - {3}]".format(iam_id, client_id, is_staff, practice_id),
                exc_info=True,
            )
            return None

    @staticmethod
    def get_partner_id_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> int | None:
        try:
            result = AuthorisationUtils._get_client_partner_household_query_based_on_user(
                iam_id=iam_id,
                is_staff=is_staff,
                session=session,
                practice_id=practice_id,
                client_id=client_id,
                household_id=household_id,
                get_client=False,
                get_partner=True,
                get_household=False,
                get_ids_only=True,
                is_lumiant_elevated_user=is_lumiant_elevated_user,
            )

            return result[1] if result is not None and len(result) > 1 else None
        except Exception:
            # Many reasons why this would fail - namely that the user doesn't have access to the specified client
            if is_staff and client_id is None:
                return None

            AuthorisationUtils.logger.error(
                "Failed to retrieve partner id [Username - {0}, Client Id - {1}, Is Staff - {2}, "
                "Practice Id - {3}]".format(iam_id, client_id, is_staff, practice_id),
                exc_info=True,
            )
            return None

    @staticmethod
    def get_household_id_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> int | None:
        try:
            result = AuthorisationUtils._get_client_partner_household_query_based_on_user(
                iam_id=iam_id,
                is_staff=is_staff,
                session=session,
                practice_id=practice_id,
                client_id=client_id,
                household_id=household_id,
                get_client=False,
                get_partner=False,
                get_household=True,
                get_ids_only=True,
                is_lumiant_elevated_user=is_lumiant_elevated_user,
            )

            return result[1] if result is not None and len(result) > 1 else None
        except Exception:
            # Many reasons why this would fail - namely that the user doesn't have access to the specified client
            if is_staff and client_id is None:
                return None

            AuthorisationUtils.logger.error(
                "Failed to retrieve household id [Username - {0}, Client Id - {1}, Is Staff - {2}, "
                "Practice Id - {3}]".format(iam_id, client_id, is_staff, practice_id),
                exc_info=True,
            )
            return None

    @staticmethod
    def get_client_partner_ids_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> tuple[int | None, int | None]:
        try:
            result = AuthorisationUtils._get_client_partner_household_query_based_on_user(
                iam_id=iam_id,
                is_staff=is_staff,
                session=session,
                practice_id=practice_id,
                client_id=client_id,
                household_id=household_id,
                get_client=True,
                get_partner=True,
                get_household=False,
                get_ids_only=True,
                is_lumiant_elevated_user=is_lumiant_elevated_user,
            )

            return (result[0], result[1]) if result is not None and len(result) > 1 else (None, None)
        except Exception:
            # Many reasons why this would fail - namely that the user doesn't have access to the specified client
            if is_staff and client_id is None:
                return None, None

            AuthorisationUtils.logger.error(
                "Failed to retrieve client and partner ids [Username - {0}, Client Id - {1}, Is Staff - {2}, "
                "Practice Id - {3}]".format(iam_id, client_id, is_staff, practice_id),
                exc_info=True,
            )
            return None, None

    @staticmethod
    def get_client_partner_household_ids_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> tuple[int | None, int | None, int | None]:
        try:
            result = AuthorisationUtils._get_client_partner_household_query_based_on_user(
                iam_id=iam_id,
                is_staff=is_staff,
                session=session,
                practice_id=practice_id,
                client_id=client_id,
                household_id=household_id,
                get_client=True,
                get_partner=True,
                get_household=True,
                get_ids_only=True,
                is_lumiant_elevated_user=is_lumiant_elevated_user,
            )

            return (result[0], result[1], result[2]) if result is not None and len(result) > 2 else (None, None, None)
        except Exception:
            # Many reasons why this would fail - namely that the user doesn't have access to the specified client
            if is_staff and client_id is None:
                return None, None, None

            AuthorisationUtils.logger.error(
                "Failed to retrieve client, partner and household ids [Username - {0}, Client Id - {1}, Is Staff - {2}"
                ", Practice Id - {3}]".format(iam_id, client_id, is_staff, practice_id),
                exc_info=True,
            )
            return None, None, None

    @staticmethod
    def get_client_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> DBClient | None:
        try:
            result = AuthorisationUtils._get_client_partner_household_query_based_on_user(
                iam_id=iam_id,
                is_staff=is_staff,
                session=session,
                practice_id=practice_id,
                client_id=client_id,
                household_id=household_id,
                get_client=True,
                get_partner=False,
                get_household=False,
                is_lumiant_elevated_user=is_lumiant_elevated_user,
            )

            return result[0] if result is not None and len(result) > 0 else None
        except Exception:
            # Many reasons why this would fail - namely that the user doesn't have access to the specified client
            if is_staff and client_id is None:
                return None

            AuthorisationUtils.logger.error(
                "Failed to retrieve client [Username - {0}, Client Id - {1}, Is Staff - {2}, Practice Id - {3}]".format(
                    iam_id, client_id, is_staff, practice_id
                ),
                exc_info=True,
            )
            return None

    @staticmethod
    def get_partner_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> DBClient | None:
        try:
            result = AuthorisationUtils._get_client_partner_household_query_based_on_user(
                iam_id=iam_id,
                is_staff=is_staff,
                session=session,
                practice_id=practice_id,
                client_id=client_id,
                household_id=household_id,
                get_client=False,
                get_partner=True,
                get_household=False,
                is_lumiant_elevated_user=is_lumiant_elevated_user,
            )

            return result[1] if result is not None and len(result) > 1 else None
        except Exception:
            # Many reasons why this would fail - namely that the user doesn't have access to the specified client
            if is_staff and client_id is None:
                return None

            AuthorisationUtils.logger.error(
                "Failed to retrieve partner [Username - {0}, Client Id - {1}, Is Staff - {2}, "
                "Practice Id - {3}]".format(iam_id, client_id, is_staff, practice_id),
                exc_info=True,
            )
            return None

    @staticmethod
    def get_household_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> DBHousehold | None:
        try:
            result = AuthorisationUtils._get_client_partner_household_query_based_on_user(
                iam_id=iam_id,
                is_staff=is_staff,
                session=session,
                practice_id=practice_id,
                client_id=client_id,
                household_id=household_id,
                get_client=False,
                get_partner=False,
                get_household=True,
                is_lumiant_elevated_user=is_lumiant_elevated_user,
            )

            return result[1] if result is not None and len(result) > 1 else None
        except Exception:
            # Many reasons why this would fail - namely that the user doesn't have access to the specified client
            if is_staff and client_id is None:
                return None

            AuthorisationUtils.logger.error(
                "Failed to retrieve household [Username - {0}, Client Id - {1}, Is Staff - {2}, "
                "Practice Id - {3}]".format(iam_id, client_id, is_staff, practice_id),
                exc_info=True,
            )
            return None

    @staticmethod
    def get_client_partner_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> tuple[DBClient | None, DBClient | None]:
        try:
            result = AuthorisationUtils._get_client_partner_household_query_based_on_user(
                iam_id=iam_id,
                is_staff=is_staff,
                session=session,
                practice_id=practice_id,
                client_id=client_id,
                household_id=household_id,
                get_client=True,
                get_partner=True,
                get_household=False,
                is_lumiant_elevated_user=is_lumiant_elevated_user,
            )

            return (result[0], result[1]) if result is not None and len(result) > 1 else (None, None)
        except Exception:
            # Many reasons why this would fail - namely that the user doesn't have access to the specified client
            if is_staff and client_id is None:
                return None, None

            AuthorisationUtils.logger.error(
                "Failed to retrieve client and partner [Username - {0}, Client Id - {1}, Is Staff - {2}, "
                "Practice Id - {3}]".format(iam_id, client_id, is_staff, practice_id),
                exc_info=True,
            )
            return None, None

    @staticmethod
    def get_client_partner_household_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> tuple[DBClient | None, DBClient | None, DBHousehold | None]:
        try:
            result = AuthorisationUtils._get_client_partner_household_query_based_on_user(
                iam_id=iam_id,
                is_staff=is_staff,
                session=session,
                practice_id=practice_id,
                client_id=client_id,
                household_id=household_id,
                get_client=True,
                get_partner=True,
                get_household=True,
                is_lumiant_elevated_user=is_lumiant_elevated_user,
            )

            return (result[0], result[1], result[2]) if result is not None and len(result) > 2 else (None, None, None)
        except Exception:
            # Many reasons why this would fail - namely that the user doesn't have access to the specified client
            if is_staff and client_id is None:
                return None, None, None

            AuthorisationUtils.logger.error(
                "Failed to retrieve client, partner and household [Username - {0}, Client Id - {1}, Is Staff - {2},"
                " Practice Id - {3}]".format(iam_id, client_id, is_staff, practice_id),
                exc_info=True,
            )
            return None, None, None

    @staticmethod
    def get_client_household_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> tuple[DBClient | None, DBHousehold | None]:
        try:
            result = AuthorisationUtils._get_client_partner_household_query_based_on_user(
                iam_id=iam_id,
                is_staff=is_staff,
                session=session,
                practice_id=practice_id,
                client_id=client_id,
                household_id=household_id,
                get_client=True,
                get_partner=False,
                get_household=True,
                is_lumiant_elevated_user=is_lumiant_elevated_user,
            )

            return (result[0], result[1]) if result is not None and len(result) > 1 else (None, None)
        except Exception:
            # Many reasons why this would fail - namely that the user doesn't have access to the specified client
            if is_staff and client_id is None:
                return None, None

            AuthorisationUtils.logger.error(
                "Failed to retrieve client and household [Username - {0}, Client Id - {1}, Is Staff - {2},"
                " Practice Id - {3}]".format(iam_id, client_id, is_staff, practice_id),
                exc_info=True,
            )
            return None, None

    @staticmethod
    def _get_client_partner_household_query_based_on_user(
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        session: Session,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_id: int | None = None,
        household_id: int | None = None,
        get_client: bool = True,
        get_partner: bool = True,
        get_household: bool = True,
        get_ids_only: bool = False,
        is_lumiant_elevated_user: bool | None = False,
    ) -> Row[Any]:
        client_data: DBClient = aliased(DBClient)  # type: ignore
        partner_data: DBClient = aliased(DBClient)  # type: ignore

        # Step 1. Get the Base Query
        query = AuthorisationUtils._get_base_client_partner_household_query(
            client_data=client_data, partner_data=partner_data
        )

        # Step 2. Apply the specific filters for iam_id, is_staff, client_id and household_id (as specified)
        filtered_query = AuthorisationUtils._apply_security_filters_to_client_partner_household_query(
            query=query,
            iam_id=iam_id,
            is_staff=is_staff,
            practice_id=practice_id,
            client_id=client_id,
            household_id=household_id,
            client_data=client_data,
            is_lumiant_elevated_user=is_lumiant_elevated_user,
        )

        # Step 3. Filter the query to the required elements
        final_query = AuthorisationUtils._apply_entities_to_client_partner_household_query(
            filtered_query=filtered_query,
            client_data=client_data,
            partner_data=partner_data,
            get_client=get_client,
            get_partner=get_partner,
            get_household=get_household,
            get_ids_only=get_ids_only,
        )

        # Step 4. Run the query
        result = session.execute(final_query.distinct().limit(1)).first()

        return result  # type: ignore

    @staticmethod
    def _get_base_client_partner_household_query(client_data: DBClient, partner_data: DBClient) -> Select:
        query = (
            select(DBHousehold)
            .join(
                client_data,  # type: ignore
                and_(client_data.household_id == DBHousehold.household_id, client_data.deleted.is_(None)),  # type: ignore
            )
            .outerjoin(
                partner_data,  # type: ignore
                and_(
                    partner_data.household_id == DBHousehold.household_id,  # type: ignore
                    partner_data.client_id != client_data.client_id,  # type: ignore
                    partner_data.deleted.is_(None),  # type: ignore
                ),
            )
            .join(DBHouseholdTeamMember, DBHouseholdTeamMember.household_id == DBHousehold.household_id)
            .join(DBPractice, DBPractice.practice_id == DBHouseholdTeamMember.practice_id)
        )

        return query

    @staticmethod
    def _apply_security_filters_to_client_partner_household_query(
        query: Select,
        # Retrieve this via: LambdaEventUtils.get_username_from_event(event)
        iam_id: str,
        # Retrieve this via: LambdaEventUtils.is_staff()
        is_staff: bool,
        # Retrieve this via: LambdaEventUtils.get_practice_id()
        practice_id: int,
        client_data: DBClient,
        client_id: int | None = None,
        household_id: int | None = None,
        is_lumiant_elevated_user: bool | None = False,
    ) -> Select:
        # If the user is a Staff member, then they are allowed to specify a client_id but only as long as that
        # client is in the same practice as them.
        #
        # If the user is a Client, then we ignore any specified client_id and determine it via their iam_id
        #
        # Once we have a valid client_id, we can then determine their partner's client_id and household_id
        if is_staff or is_lumiant_elevated_user:
            # The access for Lumiant Integration is broader than Staff as it can be scoped outside of the Practice
            if not is_lumiant_elevated_user and client_id is None and household_id is None:
                raise InternalServerError("Cannot authenticate as this call requires either a Client or Household id")  # type: ignore[call-arg]

            filtered_query = query

            if is_staff:
                # pylint: disable=singleton-comparison
                filtered_query = filtered_query.join(DBStaff, DBStaff.iam_id == uuid.UUID(iam_id)).where(
                    and_(
                        (DBHouseholdTeamMember.staff_id == DBStaff.staff_id)
                        | (DBHouseholdTeamMember.practice_office_id == DBStaff.practice_office_id)
                        | and_(
                            (DBHouseholdTeamMember.staff_id.is_(None)),
                            (DBHouseholdTeamMember.practice_office_id.is_(None)),
                            (DBHouseholdTeamMember.practice_id == practice_id),
                        ).self_group(),
                        DBPractice.practice_id == practice_id,
                    )
                )

            elif is_lumiant_elevated_user and client_id is None and household_id is None:
                # The pathway here for a Lumiant elevated user should *always* specify the Practice Id of the practice
                # they are trying to access however we know that's not necessarily the case today - API functions will
                # need to be reviewed where `practiceId` is not provided (or not handled) as a parameter
                filtered_query = filtered_query.where(DBPractice.practice_id == practice_id)

            if client_id is not None:
                filtered_query = filtered_query.where(client_data.client_id == client_id)  # type: ignore

            if household_id is not None:
                filtered_query = filtered_query.where(DBHousehold.household_id == household_id)
        else:
            # If the username is blank, it means that this has been run in an unauthenticated context.
            # As a result, the iam_id that requires to be checked won't yet be available (as the user
            # hasn't yet been created in Cognito if they're following the correct flow). In that scenario,
            # we will assume that the client_id, if provided, can be trusted.
            #
            # ============================================================================================
            #                                       !! IMPORTANT !!
            # ============================================================================================
            #
            # It is CRITICAL that the client_id is validated in that unauthenticated scenario. This is
            # typically done using `DynamoDBUtils.validate_invite_code()`.
            iam_id = StringUtils.trim_to_empty(iam_id)
            if len(iam_id) > 0 or client_id is None:
                # This requires a username - so if none is available, we need to bail
                if len(iam_id) == 0:
                    raise InternalServerError("No client details available for authentication")

                # pylint: disable=singleton-comparison
                filtered_query = query.where(
                    and_(
                        client_data.iam_id == uuid.UUID(iam_id),  # type: ignore
                        client_data.is_active.is_(True),  # type: ignore
                        DBPractice.practice_id == practice_id,
                    )
                )
            else:
                # pylint: disable=singleton-comparison
                filtered_query = query.where(
                    and_(
                        client_data.client_id == client_id,  # type: ignore
                        client_data.is_active.is_(True),  # type: ignore
                        DBPractice.practice_id == practice_id,
                    )
                )

            # And include the household check in all circumstances if it's been specified
            if household_id is not None:
                filtered_query = filtered_query.where(DBHousehold.household_id == household_id)

        # Ensure that the Practice isn't disabled or abandoned - note: we will want to allow this for LumiantAdmin!
        filtered_query = filtered_query.where(
            and_(
                DBPractice.status.not_in(
                    [practice_status.STATUS_DISABLED.status, practice_status.STATUS_ABANDONED.status]
                )
            )
        )

        return filtered_query

    @staticmethod
    def _apply_entities_to_client_partner_household_query(
        filtered_query: Select,
        client_data: DBClient,
        partner_data: DBClient,
        get_client: bool = True,
        get_partner: bool = True,
        get_household: bool = True,
        get_ids_only: bool = False,
    ) -> Select:
        entities = []

        # There is an error whereby if the client is not being retrieved, the `with_entities()` line at the end
        # rewrites the query causing it to break. As a result, we'll always include something from the client
        # to avoid that error
        if get_client:
            entities.append(client_data.client_id.label("client_id") if get_ids_only else client_data)  # type: ignore
        else:
            entities.append(client_data.client_id.label("client_id"))  # type: ignore

        if get_partner:
            entities.append(partner_data.client_id.label("partner_id") if get_ids_only else partner_data)  # type: ignore
        if get_household:
            entities.append(client_data.household_id.label("household_id") if get_ids_only else DBHousehold)  # type: ignore

        return filtered_query.with_only_columns(*entities)
