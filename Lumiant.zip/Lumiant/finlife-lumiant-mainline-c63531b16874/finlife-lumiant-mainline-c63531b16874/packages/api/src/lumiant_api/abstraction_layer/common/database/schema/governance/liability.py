import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Date, String, Numeric, Boolean, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Liability(Base):
    __tablename__ = "Liability"

    liability_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    client_id: Mapped[int | None] = mapped_column(ForeignKey("Client.client_id"), index=True)
    client_id_pa: Mapped[int | None] = mapped_column(Integer)
    client_id_pa_date: Mapped[datetime.date | None] = mapped_column(Date)
    client_id_approval_status: Mapped[str | None] = mapped_column(String(50), nullable=True)
    legal_entity_id: Mapped[int | None] = mapped_column(ForeignKey("LegalEntity.legal_entity_id"), index=True)
    legal_entity_id_pa: Mapped[int | None] = mapped_column(Integer)
    legal_entity_id_pa_date: Mapped[datetime.date | None] = mapped_column(Date)
    legal_entity_id_approval_status: Mapped[str | None] = mapped_column(String(50), nullable=True)
    asset_id: Mapped[int | None] = mapped_column(ForeignKey("Asset.asset_id"), index=True)
    liability_type: Mapped[str] = mapped_column(ENUM("C", "L", "T", "O"), nullable=False)
    loan_type: Mapped[str | None] = mapped_column(ENUM("H", "I", "V", "E", "M", "A", "P", "O", "T"))
    description: Mapped[str | None] = mapped_column(String(200))
    account_number: Mapped[str | None] = mapped_column(String(50))
    provider_name: Mapped[str | None] = mapped_column(String(100))
    lender: Mapped[str | None] = mapped_column(String(100))
    max_limit: Mapped[float | None] = mapped_column(Numeric(15, 2))
    original_amount: Mapped[float | None] = mapped_column(Numeric(15, 2))
    owing: Mapped[float | None] = mapped_column(Numeric(15, 2))
    owing_pa: Mapped[float | None] = mapped_column(Numeric(15, 2))
    owing_pa_date: Mapped[datetime.date | None] = mapped_column(Date)
    owing_approval_status: Mapped[str | None] = mapped_column(String(50), nullable=True)
    rate: Mapped[float | None] = mapped_column(Numeric(5, 4))
    rate_pa: Mapped[float | None] = mapped_column(Numeric(5, 4))
    rate_pa_date: Mapped[datetime.date | None] = mapped_column(Date)
    rate_approval_status: Mapped[str | None] = mapped_column(String(50), nullable=True)
    interest_rate_type: Mapped[str | None] = mapped_column(String(50))
    repayment: Mapped[float | None] = mapped_column(Numeric(15, 2))
    repayment_pa: Mapped[float | None] = mapped_column(Numeric(15, 2))
    repayment_pa_date: Mapped[datetime.date | None] = mapped_column(Date)
    repayment_approval_status: Mapped[str | None] = mapped_column(String(50), nullable=True)
    repayment_frequency: Mapped[str | None] = mapped_column(
        ENUM("D", "O", "W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A")
    )
    repayment_frequency_pa: Mapped[str | None] = mapped_column(
        ENUM("D", "O", "W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A")
    )
    repayment_frequency_pa_date: Mapped[datetime.date | None] = mapped_column(Date)
    repayment_frequency_approval_status: Mapped[str | None] = mapped_column(String(50), nullable=True)
    monthly_payment: Mapped[float | None] = mapped_column(Numeric(15, 2))
    notes: Mapped[str | None] = mapped_column(String(5000))
    client_notes: Mapped[str | None] = mapped_column(String(2500))
    partner_notes: Mapped[str | None] = mapped_column(String(2500))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    display_name: Mapped[str | None] = mapped_column(String(100))
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    external_load_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    for_approval: Mapped[bool] = mapped_column(Boolean, default=0, nullable=False)
    approval_status: Mapped[str | None] = mapped_column(String(255), nullable=True)
    approval_change_date: Mapped[datetime.date | None] = mapped_column(Date)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="liabilities", lazy="select")
    client: Mapped["Client"] = relationship("Client", back_populates="liabilities", lazy="select")
    legal_entity: Mapped["LegalEntity"] = relationship("LegalEntity", back_populates="liabilities", lazy="select")
    asset: Mapped["Asset"] = relationship("Asset", back_populates="liabilities", lazy="select")

    liability_yodlee_mapping: Mapped["LiabilityYodleeMapping"] = relationship(
        "LiabilityYodleeMapping", back_populates="liability", uselist=False, lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.legal_entity import LegalEntity  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.liability_yodlee_mapping import (
    LiabilityYodleeMapping,
)  # pylint: disable=C0413,R0401
