import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Numeric, Date, Boolean, String, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class InsuranceCoverage(Base):
    __tablename__ = "InsuranceCoverage"

    insurance_coverage_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    insurance_id: Mapped[int] = mapped_column(ForeignKey("Insurance.insurance_id"), nullable=False, index=True)
    life_insurance_type: Mapped[str | None] = mapped_column(
        ENUM("LT", "LO", "TO", "IP", "TC", "BE", "AR", "SB", "DI", "HE", "LC", "UM", "PC", "OI")
    )
    general_insurance_type: Mapped[str | None] = mapped_column(ENUM("H", "V", "L", "P", "A", "O"))
    life_insurance_sub_type: Mapped[str | None] = mapped_column(ENUM("TL", "WL", "UL", "VL", "VUL"))
    disability_sub_type: Mapped[str | None] = mapped_column(ENUM("P", "EP"))
    long_term_care_sub_type: Mapped[str | None] = mapped_column(ENUM("T", "LTC", "H"))
    other_insurance_sub_type: Mapped[str | None] = mapped_column(ENUM("P", "ES"))
    cover: Mapped[float | None] = mapped_column(Numeric(15, 2))
    cover_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    cover_per_annum: Mapped[float | None] = mapped_column(Numeric(15, 2))
    ip_cover_type: Mapped[str | None] = mapped_column(ENUM("A", "I"))
    ar_sub_type: Mapped[str | None] = mapped_column(
        ENUM("AC", "CC", "CO", "DE", "ED", "FC", "FB", "FU", "FD", "FI", "FL", "GI", "NC", "OT", "WP")
    )
    payout_period: Mapped[str | None] = mapped_column(ENUM("LS", "1Y", "2Y", "5Y", "PE", "65"))
    payout_period_end: Mapped[datetime.date | None] = mapped_column(Date)
    payout_wait_period: Mapped[int | None] = mapped_column(Integer)  # 0 - None, 30, 60, 90, 365, 730
    inside_super: Mapped[bool | None] = mapped_column(Boolean)
    end_year: Mapped[int | None] = mapped_column(Integer)
    death_benefit: Mapped[float | None] = mapped_column(Numeric(15, 2))
    beneficiary_relation: Mapped[str | None] = mapped_column(String(255))
    chronic_care_rider: Mapped[bool | None] = mapped_column(Boolean)
    other_beneficiary: Mapped[str | None] = mapped_column(String(255))
    long_or_short: Mapped[str | None] = mapped_column(ENUM("L", "S"))
    monthly_benefit_amount: Mapped[float | None] = mapped_column(Numeric(15, 2))
    total_benefits: Mapped[float | None] = mapped_column(Numeric(15, 2))
    payout_type: Mapped[str | None] = mapped_column(ENUM("AE", "I"))
    payout_period_text: Mapped[str | None] = mapped_column(String(255))
    elimination_period: Mapped[int | None] = mapped_column(Integer)
    healthcare_source: Mapped[str | None] = mapped_column(ENUM("ES", "E"))
    premium_tax_credit: Mapped[bool | None] = mapped_column(Boolean)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    insurance: Mapped["Insurance"] = relationship("Insurance", back_populates="coverages", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance import Insurance  # pylint: disable=C0413,R0401
