from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class BoolUtils(object):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Bool
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    def __init__(self) -> None:
        pass

    @staticmethod
    def parse(bool_or_str_input: bool | str | None) -> bool:
        if bool_or_str_input is None:
            return False

        if isinstance(bool_or_str_input, bool):
            return bool_or_str_input

        value: str = StringUtils.trim_to_empty(bool_or_str_input).lower()

        return value in ["t", "true", "y", "yes", "1", "on"]
