import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Boolean, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class TaxDetails(Base):
    __tablename__ = "TaxDetails"

    tax_details_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("Client.client_id"), nullable=False, index=True)
    tfn: Mapped[str | None] = mapped_column(String(9))
    country_code_tax: Mapped[str | None] = mapped_column(String(2))
    state_code_tax: Mapped[str | None] = mapped_column(String(5))
    family_tax_benefit: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    notes: Mapped[str | None] = mapped_column(String(5000))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client: Mapped["Client"] = relationship("Client", back_populates="tax_details", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
