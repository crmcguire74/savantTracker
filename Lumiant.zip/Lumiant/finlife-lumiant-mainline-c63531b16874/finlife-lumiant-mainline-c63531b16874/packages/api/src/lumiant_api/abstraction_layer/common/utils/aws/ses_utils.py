import os
from email.mime.application import MIMEApplication
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import botocore.client
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from botocore.exceptions import ClientError

from lumiant_api.abstraction_layer.common.constants import environments
from lumiant_api.abstraction_layer.common.constants.emails import NON_PROD_EMAIL_RECIPIENT
from lumiant_api.abstraction_layer.common.types.singleton import Singleton
from lumiant_api.abstraction_layer.common.utils.region_utils import RegionUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class SimpleEmailServiceUtils(object, metaclass=Singleton):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Simple Email Service - Handy methods for interacting with the AWS SES
    -------------------------------------------------------------------------------------------------
    """

    logger = Logger(child=True, service="SharedLayer")
    tracer = Tracer(service="SharedLayer")

    SIMPLE_EMAIL_SERVICE_NAME = "ses"
    DEFAULT_CHARSET = "UTF-8"

    boto3_session: Boto3Session
    default_region: str
    client: botocore.client  # type: ignore

    def __init__(self, boto3_session: Boto3Session, default_region: str | None = None) -> None:
        self.boto3_session = boto3_session

        def_region = StringUtils.trim_to_empty(default_region)
        if len(def_region) == 0:
            def_region = RegionUtils.get_current_region()

        self.default_region = def_region
        self.client = self.boto3_session.client(
            service_name=SimpleEmailServiceUtils.SIMPLE_EMAIL_SERVICE_NAME, region_name=default_region
        )

    @tracer.capture_method(capture_response=False)  # type: ignore
    def get_client(self, region: str | None) -> botocore.client:  # type: ignore
        if region is not None and region != self.default_region:
            return self.boto3_session.client(
                service_name=SimpleEmailServiceUtils.SIMPLE_EMAIL_SERVICE_NAME, region_name=region
            )
        else:
            return self.client

    @staticmethod
    def _check_email_address(email_address: str, environment: str, practice_id: int | None = None) -> str:
        # Emails should not be sent out in non-production environments. The one exception at this moment is Savant QA
        if environment in [environments.ENVIRONMENT_PROD, environments.ENVIRONMENT_PROD_US]:
            return email_address
        elif environment == environments.ENVIRONMENT_DEV and (practice_id is not None and practice_id == 48190):
            if email_address == "alex_medlicott@investblue.com.au":
                return email_address
            if email_address == "adrian@lumiant.io":
                return email_address
            if email_address == "adrian.jy.chung@gmail.com":
                return email_address
            else:
                return "{0}@lumiant.io".format(NON_PROD_EMAIL_RECIPIENT)
        else:
            return "{0}@lumiant.io".format(NON_PROD_EMAIL_RECIPIENT)

    def send_email(
        self,
        environment: str,
        region: str,
        sender: str,
        recipients: list[str],
        subject: str,
        body_text: str,
        body_html: str,
        reply_to: str | None,
        from_name: str,
        attachments: list[str] | None = None,
        embedded_images: list[tuple[str, str, str]] | None = None,
        cc_recipients: list[str] | None = None,
        bcc_recipients: list[str] | None = None,
        practice_id: int | None = None,
    ) -> bool:
        client = self.get_client(region=region)

        try:
            checked_recipients: list[str] = []
            checked_cc_recipients: list[str] = []
            checked_bcc_recipients: list[str] = []

            for recipient in recipients:
                recipient = SimpleEmailServiceUtils._check_email_address(
                    email_address=recipient, environment=environment, practice_id=practice_id
                )

                if recipient not in checked_recipients:
                    checked_recipients.append(recipient)

            if cc_recipients is not None:
                for recipient in cc_recipients:
                    recipient = SimpleEmailServiceUtils._check_email_address(
                        email_address=recipient, environment=environment, practice_id=practice_id
                    )

                    if recipient not in checked_cc_recipients and recipient not in checked_recipients:
                        checked_cc_recipients.append(recipient)

            if bcc_recipients is not None:
                for recipient in bcc_recipients:
                    recipient = SimpleEmailServiceUtils._check_email_address(
                        email_address=recipient, environment=environment, practice_id=practice_id
                    )

                    if (
                        recipient not in checked_bcc_recipients
                        and recipient not in checked_cc_recipients
                        and recipient not in checked_recipients
                    ):
                        checked_bcc_recipients.append(recipient)

            print("SES Send Email [{0}] => Sending email(s) to {1}".format(environment, checked_recipients))

            try:
                encoded_from_name = StringUtils.encode_to_ascii(from_name)
            except Exception:
                encoded_from_name = ""

            msg = self._create_multipart_message(
                sender=sender,
                recipients=checked_recipients,
                cc_recipients=checked_cc_recipients,
                bcc_recipients=checked_bcc_recipients,
                title=subject,
                text=body_text,
                html=body_html,
                reply_to=reply_to,
                from_name=encoded_from_name,
                attachments=attachments,
                embedded_images=embedded_images,
            )

            response = client.send_raw_email(  # type: ignore
                Source=sender,
                Destinations=checked_recipients + checked_cc_recipients + checked_bcc_recipients,
                RawMessage={"Data": msg.as_string()},
            )

            print("SES Send Email [{0}] => Response {1}".format(environment, response))

            return True
        except ClientError as e:
            if e.response["Error"]["Code"] == "InternalServiceErrorException":  # type: ignore
                self.logger.error("SES had an internal service error.")
            elif e.response["Error"]["Code"] == "InvalidParameterException":  # type: ignore
                self.logger.error("Invalid parameter provided.")
            elif e.response["Error"]["Code"] == "InvalidRequestException":  # type: ignore
                self.logger.error("Parameter value provided is not valid for the current state.")
            elif e.response["Error"]["Code"] == "ResourceNotFoundException":  # type: ignore
                self.logger.error("SES could not be found.")
            else:
                self.logger.error("General SES error {0}".format(e), exc_info=True)

            return False

    def _create_multipart_message(
        self,
        sender: str,
        recipients: list[str],
        cc_recipients: list[str],
        bcc_recipients: list[str],
        title: str,
        text: str,
        html: str,
        reply_to: str | None,
        from_name: str,
        attachments: list[str] | None,
        embedded_images: list[tuple[str, str, str]] | None = None,
    ) -> MIMEMultipart:
        msg = MIMEMultipart("related")
        msg["Subject"] = title
        msg["From"] = "{} <{}>".format(from_name, sender)
        msg["To"] = ", ".join(recipients)

        if len(cc_recipients) > 0:
            msg["Cc"] = ", ".join(cc_recipients)

        if len(bcc_recipients) > 0:
            msg["Bcc"] = ", ".join(bcc_recipients)

        if reply_to is not None:
            msg["Reply-To"] = reply_to

        msg_selection = MIMEMultipart("alternative")
        msg.attach(msg_selection)

        text_content = MIMEText(text, "plain")
        msg_selection.attach(text_content)

        html_content = MIMEText(html, "html")
        msg_selection.attach(html_content)

        # Add attachments
        for attachment in attachments or []:
            with open(attachment, "rb") as f:
                attachment_part = MIMEApplication(f.read())
                attachment_part.add_header("Content-Disposition", "attachment", filename=os.path.basename(attachment))
                msg.attach(attachment_part)

        # Add embedded images
        for embedded_image in embedded_images or []:
            with open(embedded_image[0], "rb") as f:
                image = MIMEImage(f.read(), embedded_image[2])
                image.add_header("Content-ID", f"<{embedded_image[1]}>")
                image.add_header("Content-Disposition", "inline", filename=f"<{embedded_image[1]}.{embedded_image[2]}>")
                msg.attach(image)

        return msg
