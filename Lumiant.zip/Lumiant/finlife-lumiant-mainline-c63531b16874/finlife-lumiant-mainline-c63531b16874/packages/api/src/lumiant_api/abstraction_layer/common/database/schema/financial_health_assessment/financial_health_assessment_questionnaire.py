import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class FHAQuestionnaire(Base):
    __tablename__ = "FHAQuestionnaire"

    fha_questionnaire_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    financial_health_assessment_id: Mapped[int] = mapped_column(
        ForeignKey("FinancialHealthAssessment.financial_health_assessment_id"), nullable=False, index=True
    )
    question_id: Mapped[int] = mapped_column(Integer, nullable=False)
    string_response: Mapped[str | None] = mapped_column(String(5000))
    int_response: Mapped[int | None] = mapped_column(Integer)
    section: Mapped[int | None] = mapped_column(Integer)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    financial_health_assessment: Mapped["FinancialHealthAssessment"] = relationship(
        "FinancialHealthAssessment", back_populates="responses", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.financial_health_assessment.financial_health_assessment import (
    FinancialHealthAssessment,
)  # pylint: disable=C0413,R0401
