import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from lumiant_api.abstraction_layer.common.database.schema.base import Base


class PracticeStrategyCategory(Base):
    __tablename__ = "PracticeStrategyCategory"

    practice_strategy_category_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    practice_id: Mapped[int] = mapped_column(ForeignKey("Practice.practice_id"), nullable=False, index=True)
    category_name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(String(5000))
    rank: Mapped[int | None] = mapped_column(Integer, default=0)
    mui_icon_name: Mapped[str | None] = mapped_column(String(255))
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)

    # Two-Way Relationship
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    practice: Mapped["Practice"] = relationship("Practice", back_populates="practice_strategy_category", lazy="select")

    practice_strategies: Mapped[list["PracticeStrategy"]] = relationship(
        "PracticeStrategy", back_populates="practice_strategy_category", lazy="select"
    )
    household_strategy_categories: Mapped[list["HouseholdStrategyCategory"]] = relationship(
        "HouseholdStrategyCategory", back_populates="practice_strategy_category", lazy="select"
    )
    household_strategies: Mapped[list["HouseholdStrategy"]] = relationship(
        "HouseholdStrategy", back_populates="practice_strategy_category", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy import (
    HouseholdStrategy,  # pylint: disable=C0413,R0401
)
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy_category import (
    HouseholdStrategyCategory,  # pylint: disable=C0413,R0401
)
from lumiant_api.abstraction_layer.common.database.schema.strategies.practice_strategy import (
    PracticeStrategy,  # pylint: disable=C0413,R0401
)
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice  # pylint: disable=C0413,R0401
