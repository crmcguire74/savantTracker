import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Numeric, Boolean, Date, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Insurance(Base):
    __tablename__ = "Insurance"

    insurance_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    client_id: Mapped[int | None] = mapped_column(ForeignKey("Client.client_id"), index=True)
    legal_entity_id: Mapped[int | None] = mapped_column(ForeignKey("LegalEntity.legal_entity_id"), index=True)
    asset_id: Mapped[int | None] = mapped_column(ForeignKey("Asset.asset_id"), index=True)
    beneficiary_client_id: Mapped[int | None] = mapped_column(Integer)
    beneficiary_legal_entity_id: Mapped[int | None] = mapped_column(Integer)
    beneficiary_household_member_id: Mapped[int | None] = mapped_column(Integer)
    insurance_type: Mapped[str] = mapped_column(ENUM("L", "G"), nullable=False)
    life_insurance_type: Mapped[str | None] = mapped_column(
        ENUM("LT", "LO", "TO", "IP", "TC", "BE", "AR", "SB", "DI", "HE", "LC", "UM", "PC")
    )
    general_insurance_type: Mapped[str | None] = mapped_column(ENUM("H", "V", "L", "P", "A", "O"))
    insurer: Mapped[str | None] = mapped_column(String(100))
    description: Mapped[str | None] = mapped_column(String(200))
    excess: Mapped[float | None] = mapped_column(Numeric(15, 2))
    cash_value: Mapped[float | None] = mapped_column(Numeric(15, 2))
    cover: Mapped[float | None] = mapped_column(Numeric(15, 2))
    cover_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    inside_super: Mapped[bool | None] = mapped_column(Boolean)
    ip_cover_type: Mapped[str | None] = mapped_column(ENUM("A", "I"))
    ar_sub_type: Mapped[str | None] = mapped_column(
        ENUM("AC", "CC", "CO", "DE", "ED", "FC", "FB", "FU", "FD", "FI", "FL", "GI", "NC", "OT", "WP")
    )
    premium: Mapped[float | None] = mapped_column(Numeric(15, 2))
    frequency: Mapped[str | None] = mapped_column(ENUM("D", "O", "W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"))
    policy_number: Mapped[str | None] = mapped_column(String(50))
    # 'A': Active, 'I': Inactive, 'O': Other
    policy_status: Mapped[str | None] = mapped_column(ENUM("A", "I", "O"))
    policy_to_date: Mapped[datetime.date | None] = mapped_column(Date)
    premium_increase_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    payout_period: Mapped[str | None] = mapped_column(ENUM("LS", "1Y", "2Y", "5Y", "PE"))
    payout_period_end: Mapped[datetime.date | None] = mapped_column(Date)
    payout_wait_period: Mapped[int | None] = mapped_column(Integer)  # 0 - None, 30, 60, 90, 365, 730
    end_year: Mapped[int | None] = mapped_column(Integer)
    notes: Mapped[str | None] = mapped_column(String(5000))
    client_notes: Mapped[str | None] = mapped_column(String(2500))
    partner_notes: Mapped[str | None] = mapped_column(String(2500))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    display_name: Mapped[str | None] = mapped_column(String(100))
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    external_load_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="insurances", lazy="select")
    client: Mapped["Client"] = relationship("Client", back_populates="insurances", lazy="select")
    legal_entity: Mapped["LegalEntity"] = relationship("LegalEntity", back_populates="insurance", lazy="select")
    asset: Mapped["Asset"] = relationship("Asset", back_populates="insurance", lazy="select")

    coverages: Mapped[list["InsuranceCoverage"]] = relationship(
        "InsuranceCoverage", back_populates="insurance", lazy="select"
    )

    insurance_yodlee_mapping: Mapped["InsuranceYodleeMapping"] = relationship(
        "InsuranceYodleeMapping", back_populates="insurance", uselist=False, lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance_coverage import InsuranceCoverage  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance_yodlee_mapping import (
    InsuranceYodleeMapping,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.legal_entity import LegalEntity  # pylint: disable=C0413,R0401
