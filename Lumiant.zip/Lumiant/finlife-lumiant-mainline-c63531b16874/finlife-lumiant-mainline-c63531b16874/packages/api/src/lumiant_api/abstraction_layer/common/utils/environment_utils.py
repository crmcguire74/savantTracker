import os

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.constants import environments


class EnvironmentUtils(object):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Environment - Handy methods for accessing OS Environment variables
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    def __init__(self) -> None:
        pass

    @staticmethod
    def get_environment() -> str:
        if "ENV" in os.environ:
            return os.environ["ENV"]
        else:
            return "test"

    @staticmethod
    def get_region() -> str:
        if "REGION" in os.environ:
            return os.environ["REGION"]
        else:
            return ""

    @staticmethod
    def is_aws_prod_environment(specified_environment: str | None = None) -> bool:
        env = EnvironmentUtils.get_environment() if specified_environment is None else specified_environment
        return env in [environments.ENVIRONMENT_PROD, environments.ENVIRONMENT_PROD_US]

    @staticmethod
    def is_aws_prod_au_environment(specified_environment: str | None = None) -> bool:
        env = EnvironmentUtils.get_environment() if specified_environment is None else specified_environment
        return env == environments.ENVIRONMENT_PROD

    @staticmethod
    def is_aws_prod_us_environment(specified_environment: str | None = None) -> bool:
        env = EnvironmentUtils.get_environment() if specified_environment is None else specified_environment
        return env == environments.ENVIRONMENT_PROD_US
