import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Boolean, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class HouseholdStrategyCategory(Base):
    __tablename__ = "HouseholdStrategyCategory"

    household_strategy_category_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    practice_strategy_category_id: Mapped[int | None] = mapped_column(
        ForeignKey("PracticeStrategyCategory.practice_strategy_category_id"), nullable=True, index=True
    )
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    status: Mapped[int | None] = mapped_column(Integer, nullable=True, default=0)
    status_migrated: Mapped[bool | None] = mapped_column(Integer, nullable=True, default=False)
    rank: Mapped[int | None] = mapped_column(Integer, nullable=True, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)

    # Two-Way Relationship
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship(
        "Household", back_populates="household_strategy_categories", lazy="select"
    )
    practice_strategy_category: Mapped["PracticeStrategyCategory"] = relationship(
        "PracticeStrategyCategory", back_populates="household_strategy_categories", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.practice_strategy_category import (
    PracticeStrategyCategory,
)  # pylint: disable=C0413,R0401
