import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class HouseholdValues(Base):
    __tablename__ = "HouseholdValues"

    household_values_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    # Delete this column it shouldn't be here!
    client_values_id: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(ENUM("O", "C"), nullable=False)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    deleted_by: Mapped[str | None] = mapped_column(String(50), nullable=True)
    deleted: Mapped[datetime.datetime | None] = mapped_column(DateTime, nullable=True)

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="household_values", lazy="select")

    values: Mapped[list["HouseholdValue"]] = relationship(
        "HouseholdValue", back_populates="household_values", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.values.household_value import HouseholdValue  # pylint: disable=C0413,R0401
