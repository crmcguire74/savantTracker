import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, Boolean, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class PracticeStrategy(Base):
    __tablename__ = "PracticeStrategy"

    practice_strategy_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    practice_strategy_category_id: Mapped[int] = mapped_column(
        ForeignKey("PracticeStrategyCategory.practice_strategy_category_id"), nullable=False, index=True
    )
    strategy_name: Mapped[str] = mapped_column(String(1000), nullable=False)
    details: Mapped[str | None] = mapped_column(String(10000))
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)

    # Two-Way Relationship
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    practice_strategy_category: Mapped["PracticeStrategyCategory"] = relationship(
        "PracticeStrategyCategory", back_populates="practice_strategies", lazy="select"
    )

    household_strategies: Mapped[list["HouseholdStrategy"]] = relationship(
        "HouseholdStrategy", back_populates="practice_strategy", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy import HouseholdStrategy  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.practice_strategy_category import (
    PracticeStrategyCategory,
)  # pylint: disable=C0413,R0401
