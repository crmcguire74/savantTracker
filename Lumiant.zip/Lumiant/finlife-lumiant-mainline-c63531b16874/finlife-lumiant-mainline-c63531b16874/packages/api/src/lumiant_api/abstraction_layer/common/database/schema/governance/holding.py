import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Numeric, Date, Boolean, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Holding(Base):
    __tablename__ = "Holding"

    holding_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("Portfolio.portfolio_id"), nullable=False, index=True)
    security_id: Mapped[int | None] = mapped_column(ForeignKey("md_security.security_id"), nullable=True, index=True)
    ticker: Mapped[str | None] = mapped_column(String(30), nullable=True)
    description: Mapped[str | None] = mapped_column(String(200))
    quantity: Mapped[float | None] = mapped_column(Numeric(20, 8), nullable=True)
    purchase_price: Mapped[float | None] = mapped_column(Numeric(15, 2))
    purchase_date: Mapped[datetime.date | None] = mapped_column(Date)
    average_price: Mapped[float | None] = mapped_column(Numeric(20, 8))
    total_cost: Mapped[float | None] = mapped_column(Numeric(15, 2))
    market_price: Mapped[float | None] = mapped_column(Numeric(20, 8))
    market_price_date: Mapped[datetime.date | None] = mapped_column(Date)
    maturity_date: Mapped[datetime.date | None] = mapped_column(Date)
    interest_rate: Mapped[float | None] = mapped_column(Numeric(5, 4))
    payment_frequency: Mapped[str | None] = mapped_column(
        ENUM("D", "O", "W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A", "AT")
    )
    currency_code: Mapped[str | None] = mapped_column(String(3), nullable=True)
    override_asset_tree_id: Mapped[int | None] = mapped_column(Integer)
    override_security_group_id: Mapped[int | None] = mapped_column(Integer)
    override_security_type_id: Mapped[int | None] = mapped_column(Integer)
    override_security_style: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    external_load_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    portfolio: Mapped["Portfolio"] = relationship("Portfolio", back_populates="holdings", lazy="select")
    security: Mapped["MDSecurity"] = relationship("MDSecurity", back_populates="holding", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.governance.portfolio import Portfolio  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.market_data.security import MDSecurity  # pylint: disable=C0413,R0401
