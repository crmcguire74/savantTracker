import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Numeric, Integer, String, DateTime, text, ForeignKey
from sqlalchemy.orm import mapped_column, relationship, Mapped


class MoneyGuideProData(Base):
    __tablename__ = "MoneyGuideProData"

    money_guide_pro_data_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("Client.client_id"), nullable=False, index=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    practice_id: Mapped[int] = mapped_column(ForeignKey("Practice.practice_id"), nullable=False, index=True)
    target_low: Mapped[float | None] = mapped_column(Numeric(15, 2), nullable=True)
    target_high: Mapped[float | None] = mapped_column(Numeric(15, 2), nullable=True)
    number_of_trials: Mapped[float | None] = mapped_column(Numeric(15, 2), nullable=True)
    number_of_successful_trials: Mapped[float | None] = mapped_column(Numeric(15, 2), nullable=True)
    probability_of_success: Mapped[float | None] = mapped_column(Numeric(15, 2), nullable=True)
    probability_of_success_formatted: Mapped[str | None] = mapped_column(String(50), nullable=True)
    confidence_zone_result: Mapped[str | None] = mapped_column(String(50), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client: Mapped["Client"] = relationship(
        "Client", back_populates="money_guide_pro_data_client_mapping", lazy="select"
    )
    household: Mapped["Household"] = relationship(
        "Household", back_populates="money_guide_pro_data_household_mapping", lazy="select"
    )
    practice: Mapped["Practice"] = relationship(
        "Practice", back_populates="money_guide_pro_data_practice_mapping", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice  # pylint: disable=C0413,R0401
