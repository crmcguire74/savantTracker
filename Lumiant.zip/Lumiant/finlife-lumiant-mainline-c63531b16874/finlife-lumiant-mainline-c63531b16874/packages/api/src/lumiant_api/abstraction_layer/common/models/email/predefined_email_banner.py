# pylint: disable=line-too-long
import json
import os
from pathlib import Path

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils


class PredefinedEmailBanner(object):
    """
    -------------------------------------------------------------------------------------------------
    Predefined Email Banner
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    email_banner_id: int
    email_banner_filename: str
    email_banner_local_path: str

    def __init__(self, email_banner_id: int, email_banner_filename: str) -> None:
        self.email_banner_id = email_banner_id
        self.email_banner_filename = email_banner_filename
        self.email_banner_local_path = os.path.join(
            os.path.dirname(Path(__file__).absolute()), "../../templates/email/{0}".format(email_banner_filename)
        )

    @staticmethod
    def get_all_predefined_email_banners() -> set["PredefinedEmailBanner"]:
        return {
            EMAIL_BANNER_REGISTER_CLIENT,
            EMAIL_BANNER_INVITE_REGISTRATION,
            EMAIL_BANNER_INVITE_LIFE,
            EMAIL_BANNER_INVESTMENT_PREFERENCES,
            EMAIL_BANNER_CREATE_LIFEBOOK,
            EMAIL_BANNER_SET_PASSWORD,
            EMAIL_BANNER_TASKS,
            EMAIL_BANNER_INDIVIDUAL_VALUES,
        }

    @staticmethod
    def get_from_id(email_banner_id: int) -> "PredefinedEmailBanner | None":
        return EMAIL_BANNERS_BY_ID.get(email_banner_id, None)

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)


EMAIL_BANNER_REGISTER_CLIENT = PredefinedEmailBanner(email_banner_id=1, email_banner_filename="register-client.png")
EMAIL_BANNER_INVITE_REGISTRATION = PredefinedEmailBanner(email_banner_id=2, email_banner_filename="invite-register.png")
EMAIL_BANNER_INVITE_LIFE = PredefinedEmailBanner(email_banner_id=3, email_banner_filename="invite-your-life.png")
EMAIL_BANNER_INVESTMENT_PREFERENCES = PredefinedEmailBanner(
    email_banner_id=4, email_banner_filename="invite-investment-preferences.png"
)
EMAIL_BANNER_CREATE_LIFEBOOK = PredefinedEmailBanner(email_banner_id=5, email_banner_filename="invite-your-life.png")
EMAIL_BANNER_SET_PASSWORD = PredefinedEmailBanner(email_banner_id=6, email_banner_filename="set-password.png")
EMAIL_BANNER_TASKS = PredefinedEmailBanner(email_banner_id=7, email_banner_filename="tasks.png")
EMAIL_BANNER_INDIVIDUAL_VALUES = PredefinedEmailBanner(email_banner_id=8, email_banner_filename="individual-values.png")

EMAIL_BANNERS_BY_ID: dict[int, PredefinedEmailBanner] = {
    EMAIL_BANNER_REGISTER_CLIENT.email_banner_id: EMAIL_BANNER_REGISTER_CLIENT,
    EMAIL_BANNER_INVITE_REGISTRATION.email_banner_id: EMAIL_BANNER_INVITE_REGISTRATION,
    EMAIL_BANNER_INVITE_LIFE.email_banner_id: EMAIL_BANNER_INVITE_LIFE,
    EMAIL_BANNER_INVESTMENT_PREFERENCES.email_banner_id: EMAIL_BANNER_INVESTMENT_PREFERENCES,
    EMAIL_BANNER_CREATE_LIFEBOOK.email_banner_id: EMAIL_BANNER_CREATE_LIFEBOOK,
    EMAIL_BANNER_SET_PASSWORD.email_banner_id: EMAIL_BANNER_SET_PASSWORD,
    EMAIL_BANNER_TASKS.email_banner_id: EMAIL_BANNER_TASKS,
    EMAIL_BANNER_INDIVIDUAL_VALUES.email_banner_id: EMAIL_BANNER_INDIVIDUAL_VALUES,
}
