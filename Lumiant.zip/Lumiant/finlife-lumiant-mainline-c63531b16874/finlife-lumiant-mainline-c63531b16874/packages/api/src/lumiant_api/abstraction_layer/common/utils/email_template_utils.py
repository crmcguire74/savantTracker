import html
import os
import tempfile
import uuid
from pathlib import Path
from typing import Any

from boto3.session import Session as Boto3Session

import chevron
from aws_lambda_powertools import Logger
from bs4 import BeautifulSoup
from lumiant_api.abstraction_layer.common.constants import aws_region, external_domains
from lumiant_api.abstraction_layer.common.constants.emails import LUMIANT_PRACTICE_ID_PROD_AU_US
from lumiant_api.abstraction_layer.common.database.schema.staff import Staff as DBStaff
from lumiant_api.abstraction_layer.common.database.schema.practice_logo import PracticeLogo as DBPracticeLogo
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice as DBPractice
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.models.email import predefined_email_banner
from lumiant_api.abstraction_layer.common.models.email.predefined_email_banner import PredefinedEmailBanner
from lumiant_api.abstraction_layer.common.services.practice_service import PracticeService
from lumiant_api.abstraction_layer.common.utils.aws.ses_utils import SimpleEmailServiceUtils
from lumiant_api.abstraction_layer.common.utils.domain_utils import DomainUtils
from lumiant_api.abstraction_layer.common.utils.email_address_utils import EmailAddressUtils
from lumiant_api.abstraction_layer.common.utils.aws.s3_utils import S3Utils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils
from lumiant_api.abstraction_layer.common.constants import environments
from sqlalchemy.orm import Session


class EmailTemplateUtils(object):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Email Template Utils - Handy methods for maintaining email templating
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    @staticmethod
    def format_and_send_email(
        boto3_session: Boto3Session,
        environment: str,
        region: str,
        sender: str,
        recipients: list[str],
        subject: str,
        body_text: str,
        body_html: str,
        reply_to: str | None,
        from_name: str,
        # Left = Local Path or Uri, Right = True if Local Path
        practice_logo: tuple[str, bool] | None,
        # Left = Predefined Banner Local Path or Uri, Right = True if Predefined Banner Local Path
        banner: tuple[str, bool] | None = None,
        footnote: str | None = None,
        attachments: list[str] | None = None,
        include_powered_by_logo: bool = True,
        cc_recipients: list[str] | None = None,
        bcc_recipients: list[str] | None = None,
        practice_id: int | None = None,
    ) -> bool:
        # Images to be attached (cid)
        images: list[tuple[str, str, str]] = []

        # Practice Logo can be provided (typically via the method below to retrieve it from S3) using a local path
        # (i.e. second Tuple value is True) or as a URI if the second Tuple value is False
        practice_logo_html = ""
        if practice_logo is not None and len(practice_logo[0]) > 0:
            practice_logo_html = """
                <img style="border: 0; display: block; margin: 0 auto; max-height: 112px !important;"
                     id="practice-logo-image" src="{0}" align="left" alt="Logo" border="0">
            """.format("cid:practice-logo-image" if practice_logo[1] else practice_logo[0])

            if practice_logo[1]:
                images.append((practice_logo[0], "practice-logo-image", "png"))

        banner_logo_html = ""
        if banner is not None and len(banner[0]) > 0:
            banner_logo_html = """
                <img style="border-style: none; display: block; border-color: #dddddd; margin: 0; max-width: 100%;
                    height: auto;" width="600" height="269" id="banner-placeholder" src="{0}" alt="Banner">
            """.format("cid:banner-image" if banner[1] else banner[0])

            if banner[1]:
                images.append((banner[0], "banner-image", "png"))

        powered_by_logo_html = ""
        if include_powered_by_logo:
            powered_by_logo_html = """
                <img style="border-style: none; display: block; margin: 0; height: 20px;" width="96" height="20"
                     id="powered-by-logo-image" src="cid:powered-by-image" alt="Powered By Lumiant" />
            """
            if (
                environment == environments.ENVIRONMENT_PROD
                and region == aws_region.AP_SOUTHEAST_2
                and practice_id == 395
            ):
                powered_by_logo_html = """
                    <img style="border-style: none; display: block; margin: 0; height: 20px;" width="31" height="20"
                         id="powered-by-logo-image" src="cid:powered-by-image" alt="Powered By Lumiant" />
                """
                images.append(
                    (
                        os.path.join(os.path.dirname(Path(__file__).absolute()), "../templates/email/apc-logo.png"),
                        "powered-by-image",
                        "png",
                    )
                )
            else:
                images.append(
                    (
                        os.path.join(os.path.dirname(Path(__file__).absolute()), "../templates/email/powered-by.png"),
                        "powered-by-image",
                        "png",
                    )
                )

        template_params = {
            "practice_logo": None
            if environment == environments.ENVIRONMENT_PROD
            and region == aws_region.AP_SOUTHEAST_2
            and practice_id == 395
            else practice_logo_html,
            "banner_logo": banner_logo_html,
            "title": subject,
            "main_content": body_html,
            "note": footnote,
            "powered_by_logo": powered_by_logo_html,
        }

        html_template_path = os.path.join(
            os.path.dirname(Path(__file__).absolute()), "../templates/email/notification_external.html"
        )
        with open(html_template_path, "r", encoding="utf-8") as html_template:
            body_html = chevron.render(html_template.read(), template_params)
        body_html = html.unescape(body_html)

        # Loop over and replace buttons
        soup = BeautifulSoup(body_html, "html.parser")
        button_links = soup.select("a")
        for button_link in button_links:
            body_html = body_html.replace(
                str(button_link),
                EmailTemplateUtils.create_responsive_button_html(str(button_link.get("href", "")), button_link.text),
            )

        ses_utils = SimpleEmailServiceUtils(boto3_session=boto3_session)
        return ses_utils.send_email(
            environment=environment,
            region=region,
            body_html=body_html,
            body_text=body_text,
            from_name=from_name,
            reply_to=reply_to,
            subject=subject,
            sender=sender,
            recipients=recipients,
            attachments=attachments,
            embedded_images=images,
            cc_recipients=cc_recipients,
            bcc_recipients=bcc_recipients,
            practice_id=practice_id,
        )

    @staticmethod
    def get_practice_email_logo_local_path(
        boto3_session: Boto3Session, practice_logos: list[DBPracticeLogo] | None, environment: str, region: str
    ) -> str:
        svg_practice_logo: DBPracticeLogo | None = None
        logo_local_path_and_filename: str = ""

        if practice_logos is not None:
            for practice_logo in practice_logos:
                if practice_logo.type == "E":
                    svg_practice_logo = practice_logo

        if svg_practice_logo is not None:
            logo_s3_path_and_filename = "practice-data/{0}/logos/{1}-{2}".format(
                svg_practice_logo.practice.practice_id, svg_practice_logo.type, svg_practice_logo.s3_path
            )

            s3_utils: S3Utils = S3Utils(boto3_session=boto3_session)
            bucket_name = s3_utils.get_lumiant_data_full_bucket_name(environment=environment, region=region)
            logo_local_path_and_filename = "{0}/{1}-{2}-{3}".format(
                tempfile.gettempdir(),
                svg_practice_logo.practice.practice_id,
                svg_practice_logo.type,
                svg_practice_logo.s3_path,
            )

            s3_utils.download_s3_object_to_local_filesystem(
                bucket_name=bucket_name,
                path_and_filename=logo_s3_path_and_filename,
                local_path_and_filename=logo_local_path_and_filename,
            )

        return logo_local_path_and_filename

    @staticmethod
    def get_default_footnote() -> str:
        return (
            "Need help? visit the <a href='https://finlife.atlassian.net/servicedesk/customer/portals'>"
            "Lumiant Help Hub</a>."
        )

    # This kind of hackery was required so that I didn't need to distribute all this logic amongst the text for email
    # content so instead I self-contained it here. The button doesn't seem to work in Outlook which is why we have
    # this piece of ugliness self-contained here.
    @staticmethod
    def create_responsive_button_html(url: str, label: str) -> str:
        return """
        <table>
            <tr>
            <td style="padding-left: 0px; padding-right: 0px; padding-top: 0px;padding-bottom: 0px;">
                <a href="{0}" style="background: #333; border: 9px solid #333; text-decoration: none; padding: 3px 25px; color: #fff; border-radius: 4px; display:inline-block; margin: 15px 0 19px; mso-padding-alt: 0; text-underline-color:#333">
                    <!--[if mso]><i style="letter-spacing: 15px;mso-font-width:-100%;mso-text-raise:30pt" hidden>&nbsp;</i><![endif]-->
                    <span style="mso-text-raise:15pt;">{1}</span>
                    <!--[if mso]><i style="letter-spacing: 15px;mso-font-width:-100%" hidden>&nbsp;</i><![endif]-->
                </a>
            </td>
            </tr>
        </table>
        """.format(url, label)

    @staticmethod
    def send_register_staff_email(
        boto3_session: Boto3Session,
        body_html: str,
        body_text: str,
        email_address: str,
        practice_manager_first_name: str,
        practice_manager_last_name: str,
        practice_manager_email_address: str,
        region: str,
        environment: str,
        practice: DBPractice,
    ) -> bool:
        practice_logo_local_path = EmailTemplateUtils.get_practice_email_logo_local_path(
            boto3_session=boto3_session, practice_logos=practice.practice_logos, environment=environment, region=region
        )

        (sender, sender_name, reply_to) = EmailAddressUtils.get_email_sender_name_and_reply_to_for_practice(
            practice=practice,
            region=region,
            staff_first_name=practice_manager_first_name,
            staff_last_name=practice_manager_last_name,
            reply_to=practice_manager_email_address,
        )

        # TODO: Check if the practice has a config override for the images - initially though, we will provide
        #       a hack for APC
        banner = predefined_email_banner.EMAIL_BANNER_SET_PASSWORD.email_banner_local_path

        if (
            environment == environments.ENVIRONMENT_PROD
            and region == aws_region.AP_SOUTHEAST_2
            and practice.practice_id == 395
        ):
            banner = PredefinedEmailBanner(
                email_banner_id=0, email_banner_filename="invite-your-life-apc.jpg"
            ).email_banner_local_path

        result = EmailTemplateUtils.format_and_send_email(
            boto3_session=boto3_session,
            environment=environment,
            region=region,
            sender=sender,
            recipients=[email_address],
            subject="Welcome to Lumiant",
            body_text=body_text,
            body_html=body_html,
            reply_to=reply_to,
            from_name=sender_name,
            practice_logo=(practice_logo_local_path, True),
            banner=(banner, True),
            footnote=EmailTemplateUtils.get_default_footnote(),
            practice_id=practice.practice_id,
        )

        return result

    @staticmethod
    def render_register_staff_email(
        first_name: str,
        email_address: str,
        temporary_password: str,
        practice_manager_first_name: str,
        practice_manager_last_name: str,
        environment: str,
        practice_code: str,
        practice_home_region: str,
    ) -> tuple[str, str]:
        domain = DomainUtils.get_domain_for_practice(practice=None, region=practice_home_region)
        www_domain = DomainUtils.get_app_domain_for_environment(domain=domain, environment=environment)

        practice_region = "US" if practice_home_region is not None and "us" in practice_home_region else "AU"

        if len(StringUtils.trim_to_empty(practice_code)) > 0:
            base_url = "https://{0}/sign-in?practiceCode={1}&practiceRegion={2}".format(
                www_domain, practice_code, practice_region
            )
        else:
            base_url = "https://{0}/sign-in?practiceRegion={1}".format(www_domain, practice_region)

        template_params = {
            "staff_first_name": first_name,
            "login_url": base_url,
            "login": email_address,
            "temporary_password": temporary_password,
            "practice_manager_name": "{0} {1}".format(practice_manager_first_name, practice_manager_last_name),
        }

        return EmailTemplateUtils._render_email(
            template_params=template_params,
            html_mustache_template="../templates/register_staff/register_staff_html.mustache",
            text_mustache_template="../templates/register_staff/register_staff_text.mustache",
        )

    @staticmethod
    def render_register_sign_up_practice_email(
        first_name: str,
        email_address: str,
        temporary_password: str,
        practice_manager_first_name: str,
        practice_manager_last_name: str,
        environment: str,
        practice_code: str,
        package_name: str,
        practice_home_region: str,
    ) -> tuple[str, str]:
        domain = DomainUtils.get_domain_for_practice(practice=None, region=practice_home_region)
        www_domain = DomainUtils.get_app_domain_for_environment(domain=domain, environment=environment)

        practice_region = "US" if practice_home_region is not None and "us" in practice_home_region else "AU"

        if len(StringUtils.trim_to_empty(practice_code)) > 0:
            base_url = "https://{0}/sign-in?practiceCode={1}&practiceRegion={2}".format(
                www_domain, practice_code, practice_region
            )
        else:
            base_url = "https://{0}/sign-in?practiceRegion={1}".format(www_domain, practice_region)

        template_params = {
            "staff_first_name": first_name,
            "login_url": base_url,
            "login": email_address,
            "temporary_password": temporary_password,
            "practice_manager_name": "{0} {1}".format(practice_manager_first_name, practice_manager_last_name),
            "package_name": StringUtils.trim_to_empty(package_name),
        }

        return EmailTemplateUtils._render_email(
            template_params=template_params,
            html_mustache_template="../templates/register_staff/register_sign_up_practice_html.mustache",
            text_mustache_template="../templates/register_staff/register_sign_up_practice_text.mustache",
        )

    @staticmethod
    def _render_email(
        template_params: dict[str, Any], html_mustache_template: str, text_mustache_template: str
    ) -> tuple[str, str]:
        html_template_path = os.path.join(os.path.dirname(Path(__file__).absolute()), html_mustache_template)

        with open(html_template_path, "r", encoding="utf-8") as html_template:
            body_html = chevron.render(html_template.read(), template_params)

        text_template_path = os.path.join(os.path.dirname(Path(__file__).absolute()), text_mustache_template)

        with open(text_template_path, "r", encoding="utf-8") as text_template:
            body_text = chevron.render(text_template.read(), template_params)

        return body_html, body_text

    @staticmethod
    def include_powered_by_logo(domain: str) -> bool:
        """
        :param domain:
        :return: True if the email template should include the Powered By Lumiant logo, False otherwise
        """

        return StringUtils.trim_to_empty(domain) != external_domains.INVPREFS

    @staticmethod
    def convert_email_signature_to_html(email_signature: str | None) -> str:
        """
        We support both special tags, e.g. '[LOGO]' and formatting characters, e.g. '\n' both of which need to be
        converted into html equivalents.
        """
        if email_signature is None:
            return ""

        #
        if "[LOGO]" in email_signature:
            email_signature = email_signature.replace(
                "[LOGO]",
                '<img src="cid:practice-logo-image" alt="practice logo" style="max-width:150px; max-height:80px">',
            )

        if email_signature is not None:
            email_signature = email_signature.replace("\n", "<br/>")

        return email_signature

    @staticmethod
    def send_temporary_password_to_staff(
        lumiant_rds_session: Session,
        auth_metadata: LambdaAuthorisationMetadata,
        boto3_session: Boto3Session,
        staff: DBStaff | None,
        temporary_password: str | None,
    ) -> bool:
        result: bool = False

        staff_first_name = ""
        staff_email = ""

        if staff is not None:
            staff_first_name = staff.first_name
            staff_email = staff.contact_details.email_address
        else:
            print("ERROR - Failed to email temporary password to staff as Staff object does not exist.")

        practice_service = PracticeService(
            lumiant_rds_session=lumiant_rds_session, boto3_session=boto3_session, auth_metadata=auth_metadata
        )

        # Practice Lumiant
        practice_lumiant = practice_service.get(practice_id=LUMIANT_PRACTICE_ID_PROD_AU_US)

        if (
            practice_lumiant is not None
            and practice_lumiant.name is not None
            and practice_lumiant.practice_logos is not None
        ):
            if staff is not None and staff.staff_id is not None:
                practice = practice_service.get_for_staff_id_from_practice_office(staff_id=staff.staff_id)
                if practice is not None and practice.home_region is not None:
                    domain = DomainUtils.get_domain_for_practice(practice=practice, region=practice.home_region)
                    practice_region = (
                        "US" if practice.home_region is not None and "us" in practice.home_region else "AU"
                    )
                    www_domain = DomainUtils.get_app_domain_for_environment(
                        domain=domain, environment=auth_metadata.environment
                    )

                    if len(StringUtils.trim_to_empty(str(practice.practice_code))) > 0:
                        login_url = "https://{0}/sign-in?practiceCode={1}&practiceRegion={2}".format(
                            www_domain, uuid.UUID(str(practice.practice_code)), practice_region
                        )
                    else:
                        login_url = "https://{0}/sign-in?practiceRegion={1}".format(www_domain, practice_region)

                    template_params = {
                        "staff_first_name": staff_first_name,
                        "login_url": login_url,
                        "staff_email_address": staff_email,
                        "temporary_password": temporary_password,
                        "practice_name": "{0} Team".format(practice_lumiant.name),
                    }

                    body_html, body_text = EmailTemplateUtils._render_email_temporary_password_notification(
                        template_params,
                        html_mustache_template="../templates/email/issue_new_staff_temporary_password_html.mustache",
                        text_mustache_template="../templates/email/issue_new_staff_temporary_password_text.mustache",
                    )

                    practice_logo_local_path = EmailTemplateUtils.get_practice_email_logo_local_path(
                        boto3_session=boto3_session,
                        practice_logos=practice_lumiant.practice_logos,
                        environment=auth_metadata.environment,
                        region=auth_metadata.region,
                    )

                    banner = predefined_email_banner.EMAIL_BANNER_INVITE_LIFE.email_banner_local_path

                    result = EmailTemplateUtils.format_and_send_email(
                        boto3_session=boto3_session,
                        environment=auth_metadata.environment,
                        region=auth_metadata.region,
                        sender="no-reply@lumiant.io",
                        recipients=[staff_email],
                        subject="Your Lumiant Login Temporary Password",
                        body_text=body_text,
                        body_html=body_html,
                        reply_to="no-reply@lumiant.io",
                        from_name="Lumiant admin",
                        practice_logo=(practice_logo_local_path, True),
                        banner=(banner, True),
                        footnote=EmailTemplateUtils.get_default_footnote(),
                        practice_id=auth_metadata.practice_id,
                    )
                else:
                    print(
                        "ERROR - Failed to send temporary_password to staff as as Practice object or "
                        "Practice.home_region does not exist"
                    )
            else:
                print(
                    "ERROR - Failed to send temporary_password to staff as Staff object or Staff.staff_id does not "
                    "exist"
                )
        else:
            print("ERROR - Could not find Practice Lumiant")

        return result

    @staticmethod
    def _render_email_temporary_password_notification(
        template_params: dict, html_mustache_template: str, text_mustache_template: str
    ) -> tuple[str, str]:
        html_template_path: str = os.path.join(os.path.dirname(Path(__file__).absolute()), html_mustache_template)
        if len(html_template_path) == 0:
            print("ERROR - Failed to email new staff temporary password as html template path is incorrect")

        with open(html_template_path, "r", encoding="utf-8") as html_template:
            body_html = chevron.render(html_template.read(), template_params)

        text_template_path: str = os.path.join(os.path.dirname(Path(__file__).absolute()), text_mustache_template)
        if len(html_template_path) == 0:
            print("ERROR - Failed to email new staff temporary password as text template path is incorrect")

        with open(text_template_path, "r", encoding="utf-8") as text_template:
            body_text = chevron.render(text_template.read(), template_params)

        return body_html, body_text
