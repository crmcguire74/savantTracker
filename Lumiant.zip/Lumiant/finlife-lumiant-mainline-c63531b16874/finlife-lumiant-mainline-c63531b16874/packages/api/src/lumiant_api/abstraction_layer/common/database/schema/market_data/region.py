import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, String, ForeignKey, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class MDRegion(Base):
    __tablename__ = "md_region"

    region_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    alt_name: Mapped[str] = mapped_column(String(255), nullable=False)
    parent_region_id: Mapped[int | None] = mapped_column(ForeignKey("md_region.region_id"), nullable=True, index=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    parent_region: Mapped["MDRegion"] = relationship("MDRegion", remote_side=[region_id])
