import json

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.constants import aws_region
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils


class Country(object):
    """
    -------------------------------------------------------------------------------------------------
    Country
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    country_code: str
    name: str
    region: str
    locale: str

    def __init__(self, country_code: str, name: str, region: str, locale: str) -> None:
        self.country_code = country_code
        self.name = name
        self.region = region
        self.locale = locale

    @staticmethod
    def get_from_country_code(country_code: str) -> "Country | None":
        return COUNTRIES_BY_CODE.get(country_code, None)

    @staticmethod
    def get_from_region(region: str) -> "Country | None":
        # There's an issue here whereby the AU.region and NZ.region are the same but they refer to different countries
        # In order to ensure this behaves in a consistent manner, we will handle this manually
        if region == aws_region.AP_SOUTHEAST_2:
            return AU
        else:
            return COUNTRIES_BY_REGION.get(region, None)

    @staticmethod
    def get_from_locale(locale: str) -> "Country | None":
        return COUNTRIES_BY_LOCALE.get(locale, None)

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)


US = Country("US", "United States", aws_region.US_EAST_1, "en-US")
AU = Country("AU", "Australia", aws_region.AP_SOUTHEAST_2, "en-AU")
NZ = Country("NZ", "New Zealand", aws_region.AP_SOUTHEAST_2, "en-NZ")

COUNTRIES_BY_CODE: dict[str, Country] = {US.country_code: US, AU.country_code: AU, NZ.country_code: NZ}

COUNTRIES_BY_REGION: dict[str, "Country"] = {US.region: US, AU.region: AU, NZ.region: NZ}

COUNTRIES_BY_LOCALE: dict[str, "Country"] = {US.locale: US, AU.locale: AU, NZ.locale: NZ}
