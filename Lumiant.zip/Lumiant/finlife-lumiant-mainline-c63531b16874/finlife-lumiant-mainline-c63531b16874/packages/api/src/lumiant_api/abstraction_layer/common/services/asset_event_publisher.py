from dataclasses import asdict

import sqlalchemy.orm
from aws_lambda_powertools import Logger
from boto3.session import Session as Boto3Session

from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset as DBAsset
from lumiant_api.abstraction_layer.common.event_bus.models.governance.asset_event import AssetEvent
from lumiant_api.abstraction_layer.common.event_bus.models.operation import Operation
from lumiant_api.abstraction_layer.common.models import integration_type
from lumiant_api.abstraction_layer.assets.models.asset import Asset
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.services.practice_integration_service import PracticeIntegrationService
from lumiant_api.abstraction_layer.common.utils.event_bus_utils import EventBusUtils
from lumiant_api.abstraction_layer.practice.utils.practice_integration_details_utils import (
    PracticeIntegrationDetailsUtils,
)


def publish_asset_event(
    asset: DBAsset,
    is_create: bool,
    lumiant_rds_session: sqlalchemy.orm.Session,
    boto3_session: Boto3Session,
    auth_metadata: LambdaAuthorisationMetadata,
    logger: Logger,
) -> None:
    """Publish an AssetEvent to the event bus after save."""
    try:
        asset_model = Asset.convert_from_db_model(
            db_asset=asset, lumiant_rds_session=lumiant_rds_session, auth_metadata=auth_metadata
        )
        if asset_model is None:
            return

        type_and_operation = _resolve_xplan_operation(
            lumiant_rds_session=lumiant_rds_session,
            boto3_session=boto3_session,
            auth_metadata=auth_metadata,
            external_system=asset.external_system,
        )

        lumiant_event = AssetEvent(  # type: ignore
            operation=Operation.CREATED if is_create else Operation.UPDATED,
            practice_id=auth_metadata.practice_id,  # type: ignore
            lumiant_object_id=asset.asset_id,  # type: ignore
            lumiant_object_properties=asdict(asset_model),  # type: ignore
            household_id=asset.household_id,  # type: ignore
            type_and_operation=type_and_operation,  # type: ignore
        )

        EventBusUtils.publish_lumiant_event(
            lumiant_event=lumiant_event,
            account_id=auth_metadata.account_id,
            region=auth_metadata.region,
            boto3_session=boto3_session,
        )
    except Exception as e:
        logger.error("Failed to send AssetEvent - {0}".format(e), exc_info=True)


def _resolve_xplan_operation(
    lumiant_rds_session: sqlalchemy.orm.Session,
    boto3_session: Boto3Session,
    auth_metadata: LambdaAuthorisationMetadata,
    external_system: str | None,
) -> str | None:
    """Return the type_and_operation string if XPLAN sync is enabled, else None."""
    practice_integration_service = PracticeIntegrationService(
        lumiant_rds_session=lumiant_rds_session,
        boto3_session=boto3_session,
        auth_metadata=auth_metadata,
    )
    practice_integration = practice_integration_service.get_for_practice_and_type(
        practice_id=auth_metadata.practice_id, integration_type=integration_type.XPLAN.code
    )

    if (
        practice_integration is not None
        and practice_integration.enabled
        and practice_integration.integration_details is not None
        and external_system in [None, integration_type.XPLAN.code]
    ):
        practice_integration_details_utils = PracticeIntegrationDetailsUtils(practice_integration)
        if practice_integration_details_utils.sync_governance_to_xplan_enabled():
            return "Asset-{0}".format(Operation.get_operation_name(Operation.PUSH_TO_EXTERNAL.value))

    return None
