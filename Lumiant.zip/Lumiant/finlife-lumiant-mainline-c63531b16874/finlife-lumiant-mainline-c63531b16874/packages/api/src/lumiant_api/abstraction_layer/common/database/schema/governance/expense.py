import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Numeric, Boolean, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Expense(Base):
    __tablename__ = "Expense"

    expense_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    client_id: Mapped[int | None] = mapped_column(ForeignKey("Client.client_id"), index=True)
    legal_entity_id: Mapped[int | None] = mapped_column(ForeignKey("LegalEntity.legal_entity_id"), index=True)
    asset_id: Mapped[int | None] = mapped_column(ForeignKey("Asset.asset_id"), index=True)
    household_member_id: Mapped[int | None] = mapped_column(
        ForeignKey("HouseholdMember.household_member_id"), index=True
    )
    expense_type: Mapped[str] = mapped_column(ENUM("L", "E", "S", "M"), nullable=False)
    expense_sub_type: Mapped[str | None] = mapped_column(ENUM("P", "G", "I", "V", "A", "R", "C", "N", "E", "U", "O"))
    savings_plan_type: Mapped[str | None] = mapped_column(ENUM("C", "O", "I", "S", "T"))
    description: Mapped[str | None] = mapped_column(String(200))
    amount: Mapped[float | None] = mapped_column(Numeric(15, 2))
    amount_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    discretionary_amount: Mapped[float | None] = mapped_column(Numeric(15, 2))
    frequency: Mapped[str | None] = mapped_column(ENUM("W", "F", "T", "M", "B", "Q", "S", "A"))
    end_year: Mapped[int | None] = mapped_column(Integer)
    stop_allowance: Mapped[str | None] = mapped_column(ENUM("E", "Y"))
    stop_allowance_age: Mapped[int | None] = mapped_column(Integer)
    fee_increase_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    changes_expected: Mapped[bool | None] = mapped_column(Boolean)
    time_frame: Mapped[str | None] = mapped_column(ENUM("O", "E", "R", "F", "V", "X", "S", "G", "N", "T", "L", "W"))
    notes: Mapped[str | None] = mapped_column(String(5000))
    client_notes: Mapped[str | None] = mapped_column(String(2500))
    partner_notes: Mapped[str | None] = mapped_column(String(2500))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    external_load_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="expenses", lazy="select")
    client: Mapped["Client"] = relationship("Client", back_populates="expenses", lazy="select")
    legal_entity: Mapped["LegalEntity"] = relationship("LegalEntity", back_populates="expenses", lazy="select")
    asset: Mapped["Asset"] = relationship("Asset", back_populates="expense", lazy="select")
    household_member: Mapped["HouseholdMember"] = relationship(
        "HouseholdMember", back_populates="expense", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.household_member import HouseholdMember  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.legal_entity import LegalEntity  # pylint: disable=C0413,R0401
