import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from sqlalchemy import and_

from lumiant_api.abstraction_layer.common.database.schema.governance.insurance import Insurance as DBInsurance
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance_coverage import (
    InsuranceCoverage as DBInsuranceCoverage,
)
from lumiant_api.abstraction_layer.common.models.request.governance.insurance.save_insurance_coverage_request import (
    SaveInsuranceCoverageRequest,
)
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)


class InsuranceCoverageService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Insurance
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(child=True, service="Governance")
    tracer = Tracer(service="Governance")

    lumiant_rds_session: sqlalchemy.orm.Session
    boto3_session: Boto3Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Boto3Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def get(self, insurance_coverage_id: int) -> DBInsuranceCoverage | None:
        # pylint: disable=singleton-comparison
        insurance_coverage = (
            self.lumiant_rds_session.query(DBInsuranceCoverage)
            .filter(and_(DBInsuranceCoverage.insurance_coverage_id == insurance_coverage_id))
            .first()
        )

        return insurance_coverage

    def get_for_household(self, household_id: int) -> list[DBInsuranceCoverage] | None:
        # pylint: disable=singleton-comparison
        insurance_coverages = (
            self.lumiant_rds_session.query(DBInsuranceCoverage)
            .join(DBInsurance, DBInsurance.insurance_id == DBInsuranceCoverage.insurance_id)
            .filter(and_(DBInsurance.household_id == household_id))
            .all()
        )

        return insurance_coverages

    def delete(self, insurance_coverage_id: int, execute_commit: bool = True) -> bool:
        return self.delete_insurance_coverage(
            insurance_coverage=self.get(insurance_coverage_id=insurance_coverage_id), execute_commit=execute_commit
        )

    def delete_insurance_coverage(
        self, insurance_coverage: DBInsuranceCoverage | None, execute_commit: bool = True
    ) -> bool:
        if insurance_coverage is not None:
            self.lumiant_rds_session.delete(insurance_coverage)

            if execute_commit:
                self.lumiant_rds_session.commit()
            else:
                self.lumiant_rds_session.flush()
            return True
        else:
            return False

    def save_insurance_coverages(
        self,
        insurance: DBInsurance,
        coverages: list[SaveInsuranceCoverageRequest],
        auth_metadata: LambdaAuthorisationMetadata,
        backend_upsert: bool,
    ) -> None:
        current_coverages = set()
        old_coverages = set(
            [x.insurance_coverage_id for x in insurance.coverages] if insurance.coverages is not None else []
        )

        for coverage in coverages:
            coverage_to_upsert: DBInsuranceCoverage | None = None
            if coverage.insurance_coverage_id is not None:
                # Search for the InsuranceCoverage by insurance_coverage_id
                if len(insurance.coverages) > 0:
                    coverage_to_upsert = next(
                        (x for x in insurance.coverages if x.insurance_coverage_id == coverage.insurance_coverage_id),
                        None,
                    )

            if coverage_to_upsert is None:
                # insurance_coverage_id not found or insurance.coverages list is empty. Search by type
                if len(insurance.coverages) > 0:
                    for db_coverage in insurance.coverages:
                        if (
                            insurance.insurance_type == "L"
                            and db_coverage.life_insurance_type == coverage.life_insurance_type
                        ):
                            if coverage.life_insurance_type == "LO":  # Life Only
                                if db_coverage.life_insurance_sub_type == coverage.life_insurance_sub_type:
                                    coverage_to_upsert = db_coverage
                                    break
                            elif coverage.life_insurance_type == "DI":  # Disability
                                if db_coverage.disability_sub_type == coverage.disability_sub_type:
                                    coverage_to_upsert = db_coverage
                                    break
                            elif coverage.life_insurance_type == "LC":  # Long Term Care
                                if db_coverage.long_term_care_sub_type == coverage.long_term_care_sub_type:
                                    coverage_to_upsert = db_coverage
                                    break
                            elif coverage.life_insurance_type == "OI":  # Other Insurance
                                if db_coverage.other_insurance_sub_type == coverage.other_insurance_sub_type:
                                    coverage_to_upsert = db_coverage
                                    break
                            else:
                                coverage_to_upsert = db_coverage
                                break

                        elif (
                            insurance.insurance_type == "G"
                            and db_coverage.general_insurance_type == coverage.general_insurance_type
                        ):
                            coverage_to_upsert = db_coverage
                            break

            if coverage_to_upsert is None:
                # InsuranceCoverage not found by id neither by type OR it's a new insurance. Do the insert
                coverage_to_upsert = DBInsuranceCoverage()
                coverage_to_upsert.insurance_id = insurance.insurance_id
                coverage_to_upsert.created_by = auth_metadata.iam_id
                self.lumiant_rds_session.add(coverage_to_upsert)
                insurance.coverages.append(coverage_to_upsert)

            coverage_to_upsert.life_insurance_type = coverage.life_insurance_type
            coverage_to_upsert.general_insurance_type = coverage.general_insurance_type
            coverage_to_upsert.life_insurance_sub_type = coverage.life_insurance_sub_type
            coverage_to_upsert.disability_sub_type = coverage.disability_sub_type
            coverage_to_upsert.long_term_care_sub_type = coverage.long_term_care_sub_type
            coverage_to_upsert.other_insurance_sub_type = coverage.other_insurance_sub_type
            coverage_to_upsert.ip_cover_type = coverage.ip_cover_type
            coverage_to_upsert.ar_sub_type = coverage.ar_sub_type
            coverage_to_upsert.payout_period = coverage.payout_period
            coverage_to_upsert.payout_period_end = coverage.payout_period_end  # type: ignore
            coverage_to_upsert.payout_wait_period = coverage.payout_wait_period
            coverage_to_upsert.cover = coverage.cover
            coverage_to_upsert.cover_bps = coverage.cover_bps
            coverage_to_upsert.cover_per_annum = coverage.cover_per_annum
            coverage_to_upsert.inside_super = coverage.inside_super
            coverage_to_upsert.end_year = coverage.end_year
            coverage_to_upsert.death_benefit = coverage.death_benefit
            coverage_to_upsert.beneficiary_relation = (
                coverage.beneficiary_relation[:255] if coverage.beneficiary_relation is not None else None
            )
            coverage_to_upsert.chronic_care_rider = coverage.chronic_care_rider
            coverage_to_upsert.other_beneficiary = (
                coverage.other_beneficiary[:255] if coverage.other_beneficiary is not None else None
            )
            coverage_to_upsert.long_or_short = coverage.long_or_short
            coverage_to_upsert.monthly_benefit_amount = coverage.monthly_benefit_amount
            coverage_to_upsert.total_benefits = coverage.total_benefits
            coverage_to_upsert.payout_type = coverage.payout_type
            coverage_to_upsert.payout_period_text = (
                coverage.payout_period_text[:255] if coverage.payout_period_text is not None else None
            )
            coverage_to_upsert.elimination_period = coverage.elimination_period
            coverage_to_upsert.healthcare_source = coverage.healthcare_source
            coverage_to_upsert.premium_tax_credit = coverage.premium_tax_credit
            coverage_to_upsert.updated_by = auth_metadata.iam_id

            self.lumiant_rds_session.flush()
            current_coverages.add(coverage_to_upsert.insurance_coverage_id)

        # we remove discontinued only from the syncs (which should send all the coverages in the list)
        if backend_upsert:
            # Remove discontinued coverages
            insurance_coverages_to_delete = list(old_coverages.difference(current_coverages))

            for insurance_coverage_to_delete in insurance_coverages_to_delete:
                coverage_to_delete = next(
                    (x for x in insurance.coverages if x.insurance_coverage_id == insurance_coverage_to_delete), None
                )

                if coverage_to_delete is not None:
                    self.lumiant_rds_session.delete(coverage_to_delete)

            insurance.coverages = [x for x in insurance.coverages if x.insurance_coverage_id in current_coverages]

        self.lumiant_rds_session.flush()
