import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Numeric, Boolean, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class HouseholdPackageComponent(Base):
    __tablename__ = "HouseholdPackageComponent"

    household_package_component_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_package_id: Mapped[int] = mapped_column(
        ForeignKey("HouseholdPackage.household_package_id"), nullable=False, index=True
    )
    component_id: Mapped[int] = mapped_column(ForeignKey("Component.component_id"), nullable=False, index=True)
    price: Mapped[float | None] = mapped_column(Numeric(12, 4), nullable=True)
    num_included: Mapped[int | None] = mapped_column(Integer, nullable=True)
    treat_included_as_min: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # One-Way Relationships
    component: Mapped["Component"] = relationship("Component", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.packages.component import Component  # pylint: disable=C0413,R0401
