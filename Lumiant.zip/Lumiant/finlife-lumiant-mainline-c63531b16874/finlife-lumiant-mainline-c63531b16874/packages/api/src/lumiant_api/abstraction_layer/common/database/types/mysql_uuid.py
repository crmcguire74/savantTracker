import uuid

from sqlalchemy import types, util
from sqlalchemy.dialects.mysql.base import MSBinary
from sqlalchemy.engine import Dialect


class MySQLUUID(types.TypeDecorator):
    """
    -------------------------------------------------------------------------------------------------
    Custom Type to convert between a UUID (36 character string) and a BINARY(16) field as stored in
    the database. This also supports, and we encourage the use of, the `swap_flag` introduced to
    move the more highly changing elements of the UUID further down to aid with indexing.
    -------------------------------------------------------------------------------------------------
    """

    impl = MSBinary
    python_type = uuid.UUID  # type: ignore
    swap_flag: bool = False
    cache_ok: bool = True

    def __init__(self, swap_flag: bool = False) -> None:
        self.swap_flag = swap_flag
        self.impl.length = 16  # type: ignore
        types.TypeDecorator.__init__(self, length=self.impl.length)  # type: ignore

    def __repr__(self) -> str:
        return util.generic_repr(self)

    def process_bind_param(self, value: uuid.UUID | None, dialect: Dialect | None = None) -> bytes | None:
        if value and isinstance(value, uuid.UUID):
            return MySQLUUID.convert_uuid_to_binary(value, self.swap_flag)
        elif value and not isinstance(value, uuid.UUID):
            raise ValueError("value {0} is not a valid uuid.UUID".format(value))
        else:
            return None

    def process_result_value(self, value: bytes | None, dialect: Dialect | None = None) -> uuid.UUID | None:
        return MySQLUUID.convert_binary_to_uuid(value=value, swap_flag=self.swap_flag)

    def process_literal_param(self, value: bytes | None, dialect: Dialect | None = None) -> str | None:
        return None

    def is_mutable(self) -> bool:
        return False

    @staticmethod
    def convert_uuid_to_binary(value: uuid.UUID, swap_flag: bool = False) -> bytes:
        if not swap_flag:
            return value.bytes
        else:
            uuid_str = str(value)
            swapped_uuid = "{0}{1}-{2}-{3}-{4}-{5}".format(
                uuid_str[14:18], uuid_str[9:13], uuid_str[0:4], uuid_str[4:8], uuid_str[19:23], uuid_str[24:]
            )

            return uuid.UUID(swapped_uuid).bytes

    @staticmethod
    def convert_binary_to_uuid(value: bytes | None, swap_flag: bool = False) -> uuid.UUID | None:
        if value:
            uuid_value = uuid.UUID(bytes=value)

            if not swap_flag:
                return uuid_value
            else:
                uuid_str = str(uuid_value).replace("-", "")
                return uuid.UUID(
                    "{0}-{1}-{2}-{3}-{4}".format(
                        uuid_str[8:16], uuid_str[4:8], uuid_str[0:4], uuid_str[16:20], uuid_str[20:]
                    )
                )
        else:
            return None
