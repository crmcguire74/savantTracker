class IntegrationType:
    code: str

    def __init__(self, code: str) -> None:
        self.code = code


XPLAN = IntegrationType("XP")
