import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Numeric, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class HouseholdWellnessHistory(Base):
    __tablename__ = "HouseholdWellnessHistory"

    household_wellness_history_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    wellness_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    life_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    values_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    goals_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    tasks_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    kaa_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    components: Mapped[str | None] = mapped_column(String(8), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="wellness_history", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
