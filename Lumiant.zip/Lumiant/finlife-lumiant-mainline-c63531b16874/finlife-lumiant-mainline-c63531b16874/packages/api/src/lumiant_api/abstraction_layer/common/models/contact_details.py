import json
from dataclasses import dataclass

from aws_lambda_powertools import Logger

from lumiant_api.abstraction_layer.common.database.schema.contact_details import ContactDetails as DBContactDetails
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils


@dataclass
class ContactDetails(object):
    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    contactDetailsId: int
    emailAddress: str
    mobileNumber: str
    faxNumber: str
    phoneNumber: str
    createdBy: str
    created: str
    updatedBy: str
    updated: str

    def __init__(self) -> None:
        self.contactDetailsId = 0
        self.emailAddress = ""
        self.mobileNumber = ""
        self.faxNumber = ""
        self.phoneNumber = ""
        self.createdBy = ""
        self.created = ""
        self.updatedBy = ""
        self.updated = ""

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)

    @staticmethod
    def convert_from_db_model(db_contact_details: DBContactDetails | None) -> "ContactDetails | None":
        if db_contact_details is None:
            return None

        contact_details = ContactDetails()
        contact_details.contactDetailsId = db_contact_details.contact_details_id
        contact_details.emailAddress = db_contact_details.email_address
        contact_details.mobileNumber = db_contact_details.mobile_number  # type: ignore
        contact_details.faxNumber = db_contact_details.fax_number  # type: ignore
        contact_details.phoneNumber = db_contact_details.phone_number  # type: ignore
        contact_details.createdBy = db_contact_details.created_by
        contact_details.created = SerializationUtils.convert_value_to_string(db_contact_details.created)
        contact_details.updatedBy = db_contact_details.updated_by
        contact_details.updated = SerializationUtils.convert_value_to_string(db_contact_details.updated)

        return contact_details
