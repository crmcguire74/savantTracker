import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Boolean, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class TaxPlanning(Base):
    __tablename__ = "TaxPlanning"

    tax_planning_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    client_id: Mapped[int | None] = mapped_column(ForeignKey("Client.client_id"), index=True)
    legal_entity_id: Mapped[int | None] = mapped_column(ForeignKey("LegalEntity.legal_entity_id"), index=True)
    significant_changes_impact: Mapped[bool | None] = mapped_column(Boolean)
    description: Mapped[str | None] = mapped_column(String(255))
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="tax_plannings", lazy="select")
    client: Mapped["Client"] = relationship("Client", back_populates="tax_plannings", lazy="select")
    legal_entity: Mapped["LegalEntity"] = relationship("LegalEntity", back_populates="tax_plannings", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.legal_entity import LegalEntity  # pylint: disable=C0413,R0401
