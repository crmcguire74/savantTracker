import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Date, DateTime, text, Boolean
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Trustee(Base):
    __tablename__ = "Trustee"

    trustee_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    legal_entity_id: Mapped[int] = mapped_column(ForeignKey("LegalEntity.legal_entity_id"), nullable=False, index=True)
    trustee_type: Mapped[str] = mapped_column(ENUM("I", "C"), nullable=False)
    first_name: Mapped[str | None] = mapped_column(String(255))
    middle_name: Mapped[str | None] = mapped_column(String(255))
    last_name: Mapped[str | None] = mapped_column(String(255))
    company_name: Mapped[str | None] = mapped_column(String(255))
    date_appointed: Mapped[datetime.date | None] = mapped_column(Date)
    notes: Mapped[str | None] = mapped_column(String(5000))
    client_notes: Mapped[str | None] = mapped_column(String(2500))
    partner_notes: Mapped[str | None] = mapped_column(String(2500))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    legal_entity: Mapped["LegalEntity"] = relationship("LegalEntity", back_populates="trustees", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.governance.legal_entity import LegalEntity  # pylint: disable=C0413,R0401
