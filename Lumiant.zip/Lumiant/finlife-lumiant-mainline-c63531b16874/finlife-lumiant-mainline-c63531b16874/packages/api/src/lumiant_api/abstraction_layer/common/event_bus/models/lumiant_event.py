from typing import Any

from lumiant_api.abstraction_layer.common.event_bus.models.base_event import BaseEvent
from lumiant_api.abstraction_layer.common.event_bus.models.operation import Operation
from pydantic import ConfigDict, Field


class LumiantEvent(BaseEvent):
    """
    -------------------------------------------------------------------------------------------------
    MODEL: Lumiant Event
    -------------------------------------------------------------------------------------------------
    """

    # Event Details
    operation: Operation = Field(
        alias="operation",
        description="The type of operation that was performed",
        json_schema_extra={"is_attribute": True},
        default=Operation.NA,
    )
    practice_id: int = Field(
        alias="practiceId",
        description="The practice ID that this event pertains to",
        json_schema_extra={"is_attribute": True},
    )

    type_and_operation: str | None = Field(
        alias="typeAndOperation",
        description="This field is used for the filter policy between SQS and SNS",
        json_schema_extra={"is_attribute": True},
        default=None,
    )

    # Lumiant Object Details
    lumiant_object: str | None = Field(
        alias="lumiantObject",
        description="The lumiant object (if any) that this event pertains to",
        json_schema_extra={"is_attribute": True},
        default=None,
    )
    lumiant_object_id_column: str | None = Field(
        alias="lumiantObjectIdColumn",
        description="The ID column name of the lumiant object that this event pertains to",
        json_schema_extra={"is_attribute": False},
        default=None,
    )
    lumiant_object_id: int | None = Field(
        alias="lumiantObjectId",
        description="The ID of the lumiant object that this event pertains to",
        json_schema_extra={"is_attribute": True},
        default=None,
    )
    lumiant_object_properties: dict[str, Any] | None = Field(
        alias="lumiantObjectProperties",
        description="The properties of the lumiant object that this event pertains to",
        json_schema_extra={"is_attribute": False},
        default=None,
    )

    model_config = ConfigDict(populate_by_name=True)
