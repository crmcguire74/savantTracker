import datetime

import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from sqlalchemy import and_

from lumiant_api.abstraction_layer.common.database.schema.governance.insurance import Insurance as DBInsurance
from lumiant_api.abstraction_layer.common.models.request.governance.insurance.save_insurance_coverage_request import (
    SaveInsuranceCoverageRequest,
)
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.services.insurance_coverage_service import InsuranceCoverageService
from lumiant_api.abstraction_layer.common.services.yodlee_mapping_service import YodleeMappingService
from lumiant_api.abstraction_layer.common.utils.authorisation_utils import AuthorisationUtils
from lumiant_api.abstraction_layer.common.utils.date_utils import DateUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class InsuranceService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Insurance
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(child=True, service="Governance")
    tracer = Tracer(service="Governance")

    lumiant_rds_session: sqlalchemy.orm.Session
    boto3_session: Boto3Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Boto3Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def validate_user_access(
        self,
        practice_id: int,
        insurance_id: int | None = None,
        household_id: int | None = None,
        client_id: int | None = None,
    ) -> tuple[bool, int | None]:
        """
        This method is here in the service as it's common for all Insurance API's to validate that the user has access
        to the specified insurance via the household.

        Note: There should only ever be one of insurance_id or household specified, the former to retrieve a specific
              record and the latter to retrieve all the records for a household. So we use the first non-null value
              starting with the more specific insurance_id.

          - If a client calls the API, this checks that the insurance belongs to their household
          - If a staff member calls the API, this checks that the household is within their practice
          - If a Lumiant elevated user calls the API, they can provide the practice id in order to access any household
            in the specified practice.
        """

        household_id_to_check: int | None = None

        if insurance_id is not None:
            # Retrieve the associated household_id
            household_id_tuple = (
                self.lumiant_rds_session.query(DBInsurance)
                .filter(DBInsurance.insurance_id == insurance_id)
                .with_entities(DBInsurance.household_id)
                .first()
            )

            if household_id_tuple is None:
                print("Could not access the required Insurance as Household could not be found")
                return False, None

            household_id_to_check = household_id_tuple[0]
        elif household_id is not None:
            household_id_to_check = household_id

        if (
            self.auth_metadata.is_staff() or self.auth_metadata.is_lumiant_elevated_user()
        ) and household_id_to_check is None:
            # If they're both null then we have no way to determine if the user has access to the specified data
            print("Could not access the required Insurance as neither the Insurance nor Household were specified")
            return False, None

        # Validate that the current user has access to that household
        matched_household_id = AuthorisationUtils.get_household_id_based_on_user(
            iam_id=self.auth_metadata.iam_id,
            is_staff=self.auth_metadata.is_staff(),
            session=self.lumiant_rds_session,
            practice_id=practice_id,
            household_id=household_id_to_check,
            client_id=client_id,
            is_lumiant_elevated_user=self.auth_metadata.is_lumiant_elevated_user(),
        )

        if matched_household_id is None or (household_id is not None and household_id != matched_household_id):
            print("Could not access the required Insurance as the user does not have access to it")
            return False, None

        return True, matched_household_id

    def get(self, insurance_id: int) -> DBInsurance | None:
        # pylint: disable=singleton-comparison
        insurance = (
            self.lumiant_rds_session.query(DBInsurance)
            .filter(and_(DBInsurance.insurance_id == insurance_id, DBInsurance.soft_deleted.is_not(True)))
            .first()
        )

        return insurance

    def get_for_external_id(
        self,
        household_id: int,
        client_id: int | None,
        external_id: str,
        external_system: str,
        life_insurance_type: str | None = None,
        general_insurance_type: str | None = None,
    ) -> DBInsurance | None:
        # pylint: disable=singleton-comparison
        if life_insurance_type is None and general_insurance_type is None:
            insurance = (
                self.lumiant_rds_session.query(DBInsurance)
                .filter(
                    and_(
                        DBInsurance.household_id == household_id,
                        DBInsurance.external_id == external_id,
                        DBInsurance.external_system == external_system,
                        DBInsurance.soft_deleted.is_not(True),
                    )
                )
                .first()
            )

        elif life_insurance_type is None:
            # pylint: disable=singleton-comparison
            insurance = (
                self.lumiant_rds_session.query(DBInsurance)
                .filter(
                    and_(
                        DBInsurance.household_id == household_id,
                        DBInsurance.client_id == client_id,
                        DBInsurance.external_id == external_id,
                        DBInsurance.external_system == external_system,
                        DBInsurance.insurance_type == "G",
                        DBInsurance.general_insurance_type == general_insurance_type,
                        DBInsurance.soft_deleted.is_not(True),
                    )
                )
                .first()
            )

        else:
            # pylint: disable=singleton-comparison
            insurance = (
                self.lumiant_rds_session.query(DBInsurance)
                .filter(
                    and_(
                        DBInsurance.household_id == household_id,
                        DBInsurance.client_id == client_id,
                        DBInsurance.external_id == external_id,
                        DBInsurance.external_system == external_system,
                        DBInsurance.insurance_type == "L",
                        DBInsurance.life_insurance_type == life_insurance_type,
                        DBInsurance.soft_deleted.is_not(True),
                    )
                )
                .first()
            )

        return insurance

    def get_for_household(self, household_id: int | None) -> list[DBInsurance] | None:
        if household_id is None:
            return []

        insurances = (
            self.lumiant_rds_session.query(DBInsurance)
            .filter(and_(DBInsurance.household_id == household_id, DBInsurance.soft_deleted.is_not(True)))
            .all()
        )

        return insurances

    @tracer.capture_method(capture_response=False)  # type: ignore
    def save(
        self,
        insurance_id: int | None,
        household_id: int,
        client_id: int | None,
        legal_entity_id: int | None,
        asset_id: int | None,
        beneficiary_client_id: int | None,
        beneficiary_legal_entity_id: int | None,
        beneficiary_household_member_id: int | None,
        insurance_type: str,
        life_insurance_type: str | None,
        general_insurance_type: str | None,
        insurer: str | None,
        description: str | None,
        excess: float | None,
        cash_value: float | None,
        cover: float | None,
        cover_bps: float | None,
        inside_super: bool | None,
        ip_cover_type: str | None,
        ar_sub_type: str | None,
        premium: float | None,
        frequency: str | None,
        policy_number: str | None,
        policy_status: str | None,
        policy_to_date: str | datetime.date | None,
        premium_increase_bps: float | None,
        payout_period: str | None,
        payout_period_end: str | datetime.date | None,
        payout_wait_period: int | None,
        end_year: int | None,
        notes: str | None,
        client_notes: str | None,
        partner_notes: str | None,
        confidential_notes: str | None,
        display_name: str | None,
        external_load_id: str | None = None,
        soft_deleted: bool | None = False,
        backend_upsert: bool = False,
        external_id: str | None = None,
        external_system: str | None = None,
        provider_account_id_yodlee: str | None = None,
        additional_status_yodlee: str | None = None,
        last_updated_yodlee: str | datetime.datetime | None = None,
        coverages: list[SaveInsuranceCoverageRequest] | None = None,
    ) -> DBInsurance | None:
        insurance: DBInsurance | None = None

        if insurance_id is not None:
            # Household should not be set in this instance, only during creation
            insurance = self.get(insurance_id=insurance_id)

            if insurance is None:
                print("Could not update Insurance with id [{0}] as it could not be found".format(insurance_id))
                return None
        else:
            if external_system is not None and external_id is not None:
                # Life and General Insurance can have a single external id which is then broken into our individual
                # categories
                insurance = self.get_for_external_id(
                    client_id=client_id,
                    household_id=household_id,
                    external_id=external_id,
                    external_system=external_system,
                    life_insurance_type=life_insurance_type,
                    general_insurance_type=general_insurance_type,
                )

            if insurance is None:
                insurance = DBInsurance()
                insurance.household_id = household_id
                insurance.soft_deleted = False
                insurance.created = datetime.datetime.now(datetime.UTC)
                insurance.created_by = self.auth_metadata.iam_id
                self.lumiant_rds_session.add(insurance)

        insurance.client_id = client_id
        insurance.legal_entity_id = legal_entity_id
        insurance.asset_id = asset_id
        insurance.beneficiary_client_id = beneficiary_client_id
        insurance.beneficiary_legal_entity_id = beneficiary_legal_entity_id
        insurance.beneficiary_household_member_id = beneficiary_household_member_id
        insurance.insurance_type = insurance_type
        insurance.life_insurance_type = life_insurance_type
        insurance.general_insurance_type = general_insurance_type
        insurance.insurer = StringUtils.trim_to_empty(insurer)
        insurance.description = StringUtils.trim_to_empty(description)
        insurance.excess = excess
        insurance.cash_value = cash_value
        insurance.cover = cover
        insurance.cover_bps = cover_bps
        insurance.inside_super = inside_super
        insurance.ip_cover_type = ip_cover_type
        insurance.ar_sub_type = ar_sub_type
        insurance.premium = premium
        insurance.frequency = frequency
        insurance.policy_number = StringUtils.trim_to_empty(policy_number)
        insurance.policy_status = StringUtils.trim_to_none(policy_status)

        if policy_to_date is not None:
            if isinstance(policy_to_date, datetime.date):
                insurance.policy_to_date = DateUtils.validate_date(policy_to_date)
            elif isinstance(policy_to_date, str):
                try:
                    insurance.policy_to_date = DateUtils.validate_date(
                        DateUtils.parse_unknown_str_as_date(policy_to_date, region=self.auth_metadata.region)
                    )
                except Exception:
                    # If we couldn't parse the date ignore it - should be coming through as a date not a string!
                    pass
        else:
            insurance.policy_to_date = None

        insurance.premium_increase_bps = premium_increase_bps
        insurance.payout_period = payout_period

        if payout_period_end is not None:
            if isinstance(payout_period_end, datetime.date):
                insurance.payout_period_end = DateUtils.validate_date(payout_period_end)
            elif isinstance(payout_period_end, str):
                try:
                    insurance.payout_period_end = DateUtils.validate_date(
                        DateUtils.parse_unknown_str_as_date(payout_period_end, region=self.auth_metadata.region)
                    )
                except Exception:
                    # If we couldn't parse the date ignore it - should be coming through as a date not a string!
                    pass
        else:
            insurance.payout_period_end = None

        insurance.payout_wait_period = payout_wait_period
        insurance.end_year = end_year
        if notes is not None:
            insurance.notes = StringUtils.trim_to_empty(notes)
        if client_notes is not None:
            insurance.client_notes = StringUtils.trim_to_empty(client_notes)
        if partner_notes is not None:
            insurance.partner_notes = StringUtils.trim_to_empty(partner_notes)
        if confidential_notes is not None and (
            self.auth_metadata.is_staff()
            or self.auth_metadata.is_lumiant_elevated_user()
            or self.auth_metadata.is_api_read_write_user()
        ):
            insurance.confidential_notes = StringUtils.trim_to_empty(confidential_notes)

        # Only update this field when sent. External feeds won't provide it to avoid overriding the client's change.
        if display_name is not None:
            insurance.display_name = StringUtils.trim_to_empty(display_name)

        if external_id is not None:
            insurance.external_id = StringUtils.trim_to_empty(external_id)
        if external_system is not None:
            insurance.external_system = StringUtils.trim_to_empty(external_system)

        insurance.updated = datetime.datetime.now(datetime.UTC)
        insurance.updated_by = self.auth_metadata.iam_id

        self.lumiant_rds_session.flush()

        if coverages is not None:
            insurance_coverage_service = InsuranceCoverageService(
                lumiant_rds_session=self.lumiant_rds_session,
                boto3_session=self.boto3_session,
                auth_metadata=self.auth_metadata,
            )
            insurance_coverage_service.save_insurance_coverages(
                insurance=insurance,
                coverages=coverages,
                auth_metadata=self.auth_metadata,
                backend_upsert=backend_upsert,
            )

        # only backend can update the following
        if backend_upsert:
            if any([provider_account_id_yodlee, additional_status_yodlee, last_updated_yodlee]):
                yodlee_mapping_service = YodleeMappingService(
                    lumiant_rds_session=self.lumiant_rds_session,
                    boto3_session=self.boto3_session,
                    auth_metadata=self.auth_metadata,
                )
                insurance_yodlee_mapping = yodlee_mapping_service.save(
                    entity_type="I",
                    entity_id=insurance.insurance_id,
                    provider_account_id=provider_account_id_yodlee,  # type: ignore
                    additional_status=additional_status_yodlee,  # type: ignore
                    last_updated=last_updated_yodlee,
                )
                insurance.insurance_yodlee_mapping = insurance_yodlee_mapping  # type: ignore

            insurance.external_load_id = external_load_id
            insurance.soft_deleted = soft_deleted

        self.lumiant_rds_session.commit()

        return insurance

    def delete(self, insurance_id: int, execute_commit: bool = True) -> bool:
        return self.delete_insurance(insurance=self.get(insurance_id=insurance_id), execute_commit=execute_commit)

    def delete_insurance(self, insurance: DBInsurance | None, execute_commit: bool = True) -> bool:
        if insurance is not None:
            for db_insurance_coverage in insurance.coverages:
                self.lumiant_rds_session.delete(db_insurance_coverage)

            if insurance.insurance_yodlee_mapping is not None:
                self.lumiant_rds_session.delete(insurance.insurance_yodlee_mapping)

            self.lumiant_rds_session.delete(insurance)

            if execute_commit:
                self.lumiant_rds_session.commit()
            else:
                self.lumiant_rds_session.flush()
            return True
        else:
            return False

    def soft_delete(self, insurance: DBInsurance | None, execute_commit: bool = True) -> bool:
        if insurance is not None:
            insurance.soft_deleted = True
            insurance.updated = datetime.datetime.now(datetime.UTC)
            insurance.updated_by = self.auth_metadata.iam_id

            if execute_commit:
                self.lumiant_rds_session.commit()
            else:
                self.lumiant_rds_session.flush()
            return True
        else:
            return False
