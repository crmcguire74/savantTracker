import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from lumiant_api.abstraction_layer.common.database.schema.client import Client as DBClient
from lumiant_api.abstraction_layer.common.database.schema.goals.goal import Goal as DBGoal
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset as DBAsset
from lumiant_api.abstraction_layer.common.database.schema.governance.business_planning import (
    BusinessPlanning as DBBusinessPlanning,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.charitable_planning import (
    CharitablePlanning as DBCharitablePlanning,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.education_planning import (
    EducationPlanning as DBEducationPlanning,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.estate_planning import (
    EstatePlanning as DBEstatePlanning,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.income import Income as DBIncome
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance import Insurance as DBInsurance
from lumiant_api.abstraction_layer.common.database.schema.governance.legal_entity import LegalEntity as DBLegalEntity
from lumiant_api.abstraction_layer.common.database.schema.governance.liability import Liability as DBLiability
from lumiant_api.abstraction_layer.common.database.schema.governance.professional_contact import (
    ProfessionalContact as DBProfessionalContact,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.super_beneficiary import (
    SuperBeneficiary as DBSuperBeneficiary,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.tax_planning import TaxPlanning as DBTaxPlanning
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.trustee import Trustee as DBTrustee
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice as DBPractice
from lumiant_api.abstraction_layer.common.database.schema.practice_office import PracticeOffice as DBPracticeOffice
from lumiant_api.abstraction_layer.common.database.schema.staff import Staff as DBStaff
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy import (
    HouseholdStrategy as DBHouseholdStrategy,
)
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy_category import (
    HouseholdStrategyCategory as DBHouseholdKeyAdviceArea,
)
from lumiant_api.abstraction_layer.common.database.schema.strategies.practice_strategy import (
    PracticeStrategy as DBPracticeStrategy,
)
from lumiant_api.abstraction_layer.common.database.schema.strategies.practice_strategy_category import (
    PracticeStrategyCategory as DBPracticeKeyAdviceArea,
)
from lumiant_api.abstraction_layer.common.database.schema.tasks.task import Task as DBTask
from lumiant_api.abstraction_layer.common.database.schema.governance.living_discretionary_expense import (
    LivingDiscretionaryExpense as DBLivingDiscretionaryExpense,
)
from lumiant_core.momentum.apps.api_gateway_restapi.exceptions import NotFoundException
from sqlalchemy import and_, exists


class IdValidationService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: ID Validation Service
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(child=True, service="IdValidationService")
    tracer = Tracer(service="IdValidationService")

    lumiant_rds_session: sqlalchemy.orm.Session
    boto3_session: Boto3Session

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Boto3Session,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session

    # ===========================================================================================
    # ID VALIDATION METHODS - Return 404 for both non-existent and unauthorized resources
    # This prevents information disclosure (security best practice)
    # ===========================================================================================

    def validate_household_id(self, household_id: int, practice_id: int) -> None:
        """
        Validate household_id exists and belongs to the practice.
        Raises NotFoundException (404) if household doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if household exists AND is in the practice (combined check for security)
            household_in_practice = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBHouseholdTeamMember.household_id == household_id,
                        DBHouseholdTeamMember.practice_id == practice_id,
                    )
                )
            ).scalar()
            if not household_in_practice:
                raise NotFoundException(message="Household not found")

    def validate_client_id(self, client_id: int, practice_id: int, household_id: int | None = None) -> None:
        """
        Validate client_id exists and belongs to the practice (and optionally household).
        Raises NotFoundException (404) if client doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # If household_id is provided, check client is in that household
            if household_id is not None:
                client_in_household = self.lumiant_rds_session.query(
                    exists().where(
                        and_(
                            DBClient.client_id == client_id,
                            DBClient.household_id == household_id,
                        )
                    )
                ).scalar()
                if not client_in_household:
                    raise NotFoundException(message="Client not found")
            else:
                # Otherwise, check client is in the practice via household
                client_in_practice = self.lumiant_rds_session.query(
                    exists().where(
                        and_(
                            DBClient.client_id == client_id,
                            DBClient.household_id == DBHouseholdTeamMember.household_id,
                            DBHouseholdTeamMember.practice_id == practice_id,
                        )
                    )
                ).scalar()

                if not client_in_practice:
                    raise NotFoundException(message="Client not found")

    def validate_goal_id(self, goal_id: int, household_id: int) -> None:
        """
        Validate goal_id exists and belongs to the household.
        Raises NotFoundException (404) if goal doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if goal exists AND is in the household (combined check for security)
            goal_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBGoal.goal_id == goal_id,
                        DBGoal.household_id == household_id,
                        DBGoal.deleted.is_(None),
                    )
                )
            ).scalar()

            if not goal_in_household:
                raise NotFoundException(message="Goal not found")

    def validate_financial_asset_id(self, financial_asset_id: int, household_id: int) -> None:
        """
        Validate financial_asset_id exists and belongs to the household.
        Raises NotFoundException (404) if asset doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if asset exists AND is in the household (combined check for security)
            # Note: Asset has household_id directly, no need to join through LegalEntity
            # Asset types: I = Investment, P = Investment Property, U = Annuity
            asset_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBAsset.asset_id == financial_asset_id,
                        DBAsset.asset_type.in_(["I", "P", "U"]),
                        DBAsset.household_id == household_id,
                        DBAsset.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not asset_in_household:
                raise NotFoundException(message="Financial asset not found")

    def validate_non_financial_asset_id(self, non_financial_asset_id: int, household_id: int) -> None:
        """
        Validate non_financial_asset_id exists and belongs to the household.
        Raises NotFoundException (404) if asset doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if asset exists AND is in the household (combined check for security)
            # Note: Asset has household_id directly, no need to join through LegalEntity
            # Asset types: H = Home, V = Vehicle, O = Other
            asset_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBAsset.asset_id == non_financial_asset_id,
                        DBAsset.asset_type.in_(["H", "V", "O"]),
                        DBAsset.household_id == household_id,
                        DBAsset.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not asset_in_household:
                raise NotFoundException(message="Non-financial asset not found")

    def validate_superannuation_id(self, superannuation_id: int, household_id: int) -> None:
        """
        Validate superannuation_id exists and belongs to the household.
        Raises NotFoundException (404) if superannuation doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if superannuation exists AND is in the household (combined check for security)
            # Note: Asset has household_id directly, no need to join through LegalEntity
            # Asset types: S = Super, N = Pension
            super_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBAsset.asset_id == superannuation_id,
                        DBAsset.asset_type.in_(["S"]),
                        DBAsset.household_id == household_id,
                        DBAsset.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not super_in_household:
                raise NotFoundException(message="Superannuation not found")

    def validate_income_id(self, income_id: int, household_id: int) -> None:
        """
        Validate income_id exists and belongs to the household.
        Raises NotFoundException (404) if income doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            income_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBIncome.income_id == income_id,
                        DBIncome.household_id == household_id,
                        DBIncome.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not income_in_household:
                raise NotFoundException(message="Income not found")

    def validate_education_planning_id(self, education_planning_id: int, household_id: int) -> None:
        """
        Validate education_planning_id exists and belongs to the household.
        Raises NotFoundException (404) if education planning doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            education_planning_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBEducationPlanning.education_planning_id == education_planning_id,
                        DBEducationPlanning.household_id == household_id,
                        DBEducationPlanning.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not education_planning_in_household:
                raise NotFoundException(message="Education planning not found")

    def validate_charitable_planning_id(self, charitable_planning_id: int, household_id: int) -> None:
        """
        Validate charitable_planning_id exists and belongs to the household.
        Raises NotFoundException (404) if charitable planning doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            charitable_planning_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBCharitablePlanning.charitable_planning_id == charitable_planning_id,
                        DBCharitablePlanning.household_id == household_id,
                        DBCharitablePlanning.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not charitable_planning_in_household:
                raise NotFoundException(message="Charitable planning not found")

    def validate_professional_contact_id(self, professional_contact_id: int, household_id: int) -> None:
        """
        Validate professional_contact_id exists and belongs to the household.
        Raises NotFoundException (404) if contact doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            contact_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBProfessionalContact.professional_contact_id == professional_contact_id,
                        DBProfessionalContact.household_id == household_id,
                        DBProfessionalContact.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not contact_in_household:
                raise NotFoundException(message="Professional contact not found")

    def validate_super_beneficiary_id(self, super_beneficiary_id: int, superannuation_id: int) -> None:
        """
        Validate super_beneficiary_id exists and belongs to the superannuation.
        Raises NotFoundException (404) if beneficiary doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if beneficiary exists AND belongs to this superannuation (combined check for security)
            beneficiary_for_super = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBSuperBeneficiary.super_beneficiary_id == super_beneficiary_id,
                        DBSuperBeneficiary.asset_id == superannuation_id,
                        DBSuperBeneficiary.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not beneficiary_for_super:
                raise NotFoundException(message="Super beneficiary not found")

    def validate_liability_id(self, liability_id: int, household_id: int) -> None:
        """
        Validate liability_id exists and belongs to the household.
        Raises NotFoundException (404) if liability doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if liability exists AND is in the household (combined check for security)
            # Note: Liability has household_id directly, no need to join through LegalEntity
            liability_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBLiability.liability_id == liability_id,
                        DBLiability.household_id == household_id,
                        DBLiability.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not liability_in_household:
                raise NotFoundException(message="Liability not found")

    def validate_insurance_id(self, insurance_id: int, household_id: int) -> None:
        """
        Validate insurance_id exists and belongs to the household.
        Raises NotFoundException (404) if insurance doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if insurance exists AND is in the household (combined check for security)
            # Note: Insurance has household_id directly, no need to join through LegalEntity
            insurance_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBInsurance.insurance_id == insurance_id,
                        DBInsurance.household_id == household_id,
                        DBInsurance.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not insurance_in_household:
                raise NotFoundException(message="Insurance not found")

    def validate_legal_entity_id(self, legal_entity_id: int, household_id: int) -> None:
        """
        Validate legal_entity_id exists and belongs to the household.
        Raises NotFoundException (404) if legal entity doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if legal entity exists AND is in the household (combined check for security)
            legal_entity_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBLegalEntity.legal_entity_id == legal_entity_id,
                        DBLegalEntity.household_id == household_id,
                        DBLegalEntity.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not legal_entity_in_household:
                raise NotFoundException(message="Legal entity not found")

    def validate_trustee_id(self, trustee_id: int, legal_entity_id: int) -> None:
        """
        Validate trustee_id exists and belongs to the legal_entity_id.
        Raises NotFoundException (404) if trustee doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if trustee exists AND belongs to the legal entity (combined check for security)
            trustee_in_legal_entity = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBTrustee.trustee_id == trustee_id,
                        DBTrustee.legal_entity_id == legal_entity_id,
                        DBTrustee.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not trustee_in_legal_entity:
                raise NotFoundException(message="Trustee not found")

    def validate_estate_planning_id(
        self, estate_planning_id: int, practice_id: int, household_id: int, client_id: int
    ) -> None:
        """
        Validate estate_planning_id exists and belongs to the practice, household, and client.
        Raises NotFoundException (404) if estate planning doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if estate planning exists AND is in the household AND practice AND belongs to client (combined check for security)
            estate_planning_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBEstatePlanning.estate_planning_id == estate_planning_id,
                        DBEstatePlanning.household_id == household_id,
                        DBEstatePlanning.client_id == client_id,
                        DBHouseholdTeamMember.household_id == DBEstatePlanning.household_id,
                        DBEstatePlanning.client_id == client_id,
                        DBHouseholdTeamMember.practice_id == practice_id,
                    )
                )
            ).scalar()

            if not estate_planning_in_household:
                raise NotFoundException(message="Estate Planning not found")

    def validate_household_strategy_id(self, household_strategy_id: int, household_id: int) -> None:
        """
        Validate household_strategy_id exists, is not soft deleted, and belongs to the household.
        Raises NotFoundException (404) if strategy doesn't exist, is soft deleted, or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if strategy exists AND is in the household AND is not soft deleted (combined check for security)
            strategy_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBHouseholdStrategy.household_strategy_id == household_strategy_id,
                        DBHouseholdStrategy.household_id == household_id,
                        DBHouseholdStrategy.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not strategy_in_household:
                raise NotFoundException(message="Household strategy not found")

    def validate_household_key_advice_area_id(self, household_key_advice_area_id: int, household_id: int) -> None:
        """
        Validate household_key_advice_area_id exists, is not soft deleted, and belongs to the household.
        Raises NotFoundException (404) if key advice area doesn't exist, is soft deleted, or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if key advice area exists AND is in the household AND is not soft deleted (combined check for security)
            kaa_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBHouseholdKeyAdviceArea.household_strategy_category_id == household_key_advice_area_id,
                        DBHouseholdKeyAdviceArea.household_id == household_id,
                        DBHouseholdKeyAdviceArea.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not kaa_in_household:
                raise NotFoundException(message="Household key advice area not found")

    def validate_practice_office_id(self, practice_office_id: int, practice_id: int) -> None:
        """
        Validate practice_office_id exists and belongs to the practice.
        Raises NotFoundException (404) if office doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if office exists AND is in the practice (combined check for security)
            office_in_practice = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBPracticeOffice.practice_office_id == practice_office_id,
                        DBPracticeOffice.practice_id == practice_id,
                    )
                )
            ).scalar()
            if not office_in_practice:
                raise NotFoundException(message="Practice office not found")

    def validate_staff_id(self, staff_id: int, practice_id: int) -> None:
        """
        Validate staff_id exists, is active, and belongs to the practice.
        Raises NotFoundException (404) if staff doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if staff exists AND is in the practice (combined check for security)
            staff_in_practice = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBStaff.staff_id == staff_id,
                        DBStaff.is_active,
                        DBPracticeOffice.practice_office_id == DBStaff.practice_office_id,
                        DBPracticeOffice.practice_id == practice_id,
                    )
                )
            ).scalar()
            if not staff_in_practice:
                raise NotFoundException(message="Staff not found")

    def validate_practice_strategy_id(self, practice_strategy_id: int, practice_id: int) -> None:
        """
        Validate practice_strategy_id exists, is not soft deleted, and belongs to the practice.
        Raises NotFoundException (404) if strategy doesn't exist, is soft deleted, or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if strategy exists AND is in the practice AND is not soft deleted (combined check for security)
            # Note: PracticeStrategy doesn't have practice_id directly, need to join through PracticeStrategyCategory
            strategy_in_practice = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBPracticeStrategy.practice_strategy_id == practice_strategy_id,
                        DBPracticeStrategy.practice_strategy_category_id
                        == DBPracticeKeyAdviceArea.practice_strategy_category_id,
                        DBPracticeKeyAdviceArea.practice_id == practice_id,
                        DBPracticeStrategy.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not strategy_in_practice:
                raise NotFoundException(message="Practice strategy not found")

    def validate_practice_key_advice_area_id(self, practice_key_advice_area_id: int, practice_id: int) -> None:
        """
        Validate practice_key_advice_area_id exists, is not soft deleted, and belongs to the practice.
        Raises NotFoundException (404) if key advice area doesn't exist, is soft deleted, or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if key advice area exists AND is in the practice AND is not soft deleted (combined check for security)
            kaa_in_practice = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBPracticeKeyAdviceArea.practice_strategy_category_id == practice_key_advice_area_id,
                        DBPracticeKeyAdviceArea.practice_id == practice_id,
                        DBPracticeKeyAdviceArea.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not kaa_in_practice:
                raise NotFoundException(message="Practice key advice area not found")

    def validate_task_id(
        self, task_id: int, household_id: int, client_id: int | None = None, include_deleted: bool = False
    ) -> None:
        """
        Validate task_id exists, is not deleted, and optionally belongs to household or client.
        Raises NotFoundException (404) if task doesn't exist, is deleted, or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Build conditions for task validation
            conditions = [
                DBTask.task_id == task_id,
                DBTask.household_id == household_id,  # Task is not soft deleted
            ]

            # Add client validation if provided
            if client_id is not None:
                conditions.append(DBTask.client_id == client_id)
            if not include_deleted:
                conditions.append(DBTask.deleted.is_(None))
            # Check if task exists with all conditions
            task_exists = self.lumiant_rds_session.query(exists().where(and_(*conditions))).scalar()

            if not task_exists:
                raise NotFoundException(message="Task not found")

    def validate_practice_id(self, practice_id: int) -> None:
        """
        Validate practice_id exists.
        Raises NotFoundException if practice doesn't exist.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if practice exists at all
            practice_exists = self.lumiant_rds_session.query(
                exists().where(DBPractice.practice_id == practice_id)
            ).scalar()

            if not practice_exists:
                raise NotFoundException(message="Practice not found")

    def validate_business_planning_id(self, business_planning_id: int, household_id: int) -> None:
        """
        Validate business_planning_id exists and belongs to the household.
        Raises NotFoundException (404) if business planning doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            business_planning_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBBusinessPlanning.business_planning_id == business_planning_id,
                        DBBusinessPlanning.household_id == household_id,
                        DBBusinessPlanning.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not business_planning_in_household:
                raise NotFoundException(message="Business planning not found")

    def validate_tax_planning_id(self, tax_planning_id: int, household_id: int) -> None:
        """
        Validate tax_planning_id exists and belongs to the household.
        Raises NotFoundException (404) if tax planning doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            # Check if tax planning exists AND is in the household (combined check for security)
            # Note: practice scoping is already enforced by ensure_household_authorization() in the operation
            tax_planning_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBTaxPlanning.tax_planning_id == tax_planning_id,
                        DBTaxPlanning.household_id == household_id,
                        DBTaxPlanning.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not tax_planning_in_household:
                raise NotFoundException(message="Tax planning not found")

    def validate_living_discretionary_expense_id(self, living_discretionary_expense_id: int, household_id: int) -> None:
        """
        Validate living_discretionary_expense_id exists and belongs to the household.
        Raises NotFoundException (404) if expense doesn't exist or not authorized.
        Returns 404 for both cases to prevent information disclosure.
        """
        with self.lumiant_rds_session.no_autoflush:
            expense_in_household = self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBLivingDiscretionaryExpense.living_discretionary_expense_id == living_discretionary_expense_id,
                        DBLivingDiscretionaryExpense.household_id == household_id,
                        DBLivingDiscretionaryExpense.soft_deleted.is_not(True),
                    )
                )
            ).scalar()

            if not expense_in_household:
                raise NotFoundException(message="Living discretionary expense not found")
