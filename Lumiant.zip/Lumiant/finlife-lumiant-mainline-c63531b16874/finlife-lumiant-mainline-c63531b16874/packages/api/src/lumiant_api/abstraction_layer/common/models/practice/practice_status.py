import json

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils


class PracticeStatus(object):
    """
    -------------------------------------------------------------------------------------------------
    Practice Status
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    status: str
    sequence_order: int
    description: str
    salesforce_type: str

    def __init__(self, status: str, sequence_order: int, description: str, salesforce_status: str) -> None:
        self.status = status
        self.sequence_order = sequence_order
        self.description = description
        self.salesforce_type = salesforce_status

    @staticmethod
    def get_from_status(status: str) -> "PracticeStatus | None":
        if status == STATUS_LUMIANT.status:
            return STATUS_LUMIANT
        elif status == STATUS_LUMIANT_DEMO.status:
            return STATUS_LUMIANT_DEMO
        elif status == STATUS_ABANDONED.status:
            return STATUS_ABANDONED
        elif status == STATUS_DISABLED.status:
            return STATUS_DISABLED
        elif status == STATUS_TRIAL.status:
            return STATUS_TRIAL
        elif status == STATUS_IPL.status:
            return STATUS_IPL
        elif status == STATUS_CUSTOMER.status:
            return STATUS_CUSTOMER
        else:
            return None

    @staticmethod
    def get_from_salesforce_type(salesforce_type: str) -> "PracticeStatus | None":
        if salesforce_type == STATUS_LUMIANT.salesforce_type:
            return STATUS_LUMIANT
        elif salesforce_type == STATUS_LUMIANT_DEMO.salesforce_type:
            return STATUS_LUMIANT_DEMO
        elif salesforce_type == STATUS_ABANDONED.salesforce_type:
            return STATUS_ABANDONED
        elif salesforce_type == STATUS_DISABLED.salesforce_type:
            return STATUS_DISABLED
        elif salesforce_type == STATUS_TRIAL.salesforce_type:
            return STATUS_TRIAL
        elif salesforce_type == STATUS_IPL.salesforce_type:
            return STATUS_IPL
        elif salesforce_type == STATUS_CUSTOMER.salesforce_type:
            return STATUS_CUSTOMER
        else:
            return None

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)


STATUS_LUMIANT = PracticeStatus("I", 1300, "Internal Practice", "LUMIANT")
STATUS_LUMIANT_DEMO = PracticeStatus("S", 1200, "Demo / Test Practice", "LUMIANT_DEMO")
STATUS_ABANDONED = PracticeStatus("L", 1100, "Abandoned", "ABANDONED")
STATUS_DISABLED = PracticeStatus("X", 1000, "Disabled", "DISABLED")

STATUS_TRIAL = PracticeStatus("T", 300, "Trial", "TRIAL")
STATUS_IPL = PracticeStatus("C", 200, "IPL", "IPL")
STATUS_CUSTOMER = PracticeStatus("O", 100, "Onboarded", "CUSTOMER")
