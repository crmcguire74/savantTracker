import random
import secrets
from typing import Any

import botocore.client
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from botocore.exceptions import ClientError

from lumiant_core.momentum.apps.api_gateway_restapi.exceptions import (
    InternalServerError,
    InvalidParameterDetails,
    InvalidParameterException,
)
from lumiant_api.abstraction_layer.common.types.singleton import Singleton
from lumiant_api.abstraction_layer.common.utils.mobile_utils import MobileUtils
from lumiant_api.abstraction_layer.common.utils.region_utils import RegionUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class CognitoUtils(object, metaclass=Singleton):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Cognito - Handy methods for interacting with the AWS Cognito IDP
    -------------------------------------------------------------------------------------------------
    """

    logger = Logger(child=True, service="SharedLayer")
    tracer = Tracer(service="SharedLayer")

    COGNITO_SERVICE_NAME = "cognito-idp"
    PRACTICE_ID_ATTRIBUTE = "custom:practice_id"
    PRACTICE_OFFICE_ID_ATTRIBUTE = "custom:practice_office_id"
    STAFF_ID_ATTRIBUTE = "custom:staff_id"
    CLIENT_ID_ATTRIBUTE = "custom:client_id"
    MIGRATED_ATTRIBUTE = "custom:migrated"
    AUTH0_MIGRATED_ATTRIBUTE = "custom:auth0_migrated"
    SSO_PROVISIONED_ATTRIBUTE = "custom:sso_provisioned"
    SUB_ATTRIBUTE = "sub"

    boto3_session: Boto3Session
    default_region: str
    client: botocore.client  # type: ignore

    def __init__(self, boto3_session: Boto3Session, default_region: str | None = None) -> None:
        self.boto3_session = boto3_session

        def_region = StringUtils.trim_to_empty(default_region)
        if len(def_region) == 0:
            def_region = RegionUtils.get_current_region()

        self.default_region = def_region
        self.client = self.boto3_session.client(  # type: ignore
            service_name=CognitoUtils.COGNITO_SERVICE_NAME, region_name=default_region
        )

    @tracer.capture_method(capture_response=False)  # type: ignore
    def get_client(self, region: str | None) -> botocore.client:  # type: ignore
        if region is not None and region != self.default_region:
            return self.boto3_session.client(
                service_name=CognitoUtils.COGNITO_SERVICE_NAME,  # type: ignore
                region_name=region,  # type: ignore
            )
        else:
            return self.client

    @staticmethod
    def get_attribute_for_user(attribute: str, user: dict[str, Any] | None) -> str:
        if user is None:
            return ""

        try:
            if "UserAttributes" in user:
                attribute_dict = next((item for item in user["UserAttributes"] if item["Name"] == attribute), None)

                return StringUtils.trim_to_empty(attribute_dict["Value"]) if attribute_dict is not None else ""
            elif "Attributes" in user:
                attribute_dict = next((item for item in user["Attributes"] if item["Name"] == attribute), None)

                return StringUtils.trim_to_empty(attribute_dict["Value"]) if attribute_dict is not None else ""
            else:
                return ""
        except Exception:
            return ""

    def get_default_user_pool(self, region: str | None = None) -> str:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            response = client.list_user_pools(MaxResults=10)  # type: ignore

            # Do a basic test just in case there are multiple user pools in place (there shouldn't be)
            if len(response["UserPools"]) > 1:
                print("There is more than 1 user pool defined - please check")

                for pool in response["UserPools"]:
                    if pool["Name"].startswith("lumiantweb"):
                        return pool["Id"]

            # Else default it
            return response["UserPools"][0]["Id"]
        except ClientError as e:
            if e.response["Error"]["Code"] == "InvalidParameterException":  # type: ignore
                self.logger.error("Invalid pool id and/or user provided.")
            elif e.response["Error"]["Code"] == "TooManyRequestsException":  # type: ignore
                self.logger.error("Too many requests.")
            elif e.response["Error"]["Code"] == "NotAuthorizedException":  # type: ignore
                self.logger.error("Not authorised.")
            elif e.response["Error"]["Code"] == "InternalErrorException":  # type: ignore
                self.logger.error("Cognito had an internal service error.")
            else:
                self.logger.error("Failed to determine the default user pool", exc_info=True)

            return ""

    def get_user_by_pool_id_and_username(
        self,
        user_pool_id: str,
        # This should be the Cognito Username == 'sub' as available in auth_metadata (LambdaAuthorisationMetadata)
        iam_username: str,
        region: str | None = None,
        skip_to_lower: bool | None = True,
    ) -> dict[str, Any] | None:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            try:
                return client.admin_get_user(  # type: ignore
                    UserPoolId=user_pool_id, Username=iam_username.lower() if not skip_to_lower else iam_username
                )
            except ClientError as e:
                if iam_username == iam_username.lower():
                    raise e
                else:
                    return client.admin_get_user(UserPoolId=user_pool_id, Username=iam_username)  # type: ignore
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":  # type: ignore
                self.logger.error("Cognito could not be found.")
            elif e.response["Error"]["Code"] == "InvalidParameterException":  # type: ignore
                self.logger.error("Invalid pool id and/or user provided.")
            elif e.response["Error"]["Code"] == "TooManyRequestsException":  # type: ignore
                self.logger.error("Too many requests.")
            elif e.response["Error"]["Code"] == "NotAuthorizedException":  # type: ignore
                self.logger.error("Not authorised.")
            elif e.response["Error"]["Code"] == "UserNotFoundException":  # type: ignore
                self.logger.error("User could not be found.")
            elif e.response["Error"]["Code"] == "InternalErrorException":  # type: ignore
                self.logger.error("Cognito had an internal service error.")

            return None

    def get_user_by_pool_id_and_email_address(
        self, user_pool_id: str, email_address: str, region: str | None = None, skip_to_lower: bool | None = False
    ) -> dict[str, Any] | None:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            response = client.list_users(  # type: ignore
                UserPoolId=user_pool_id,
                AttributesToGet=["email"],
                Limit=1,
                Filter='email = "{0}"'.format(email_address.lower() if not skip_to_lower else email_address),
            )

            if response is None or "Users" not in response or len(response["Users"]) < 1:
                return None
            else:
                return client.admin_get_user(UserPoolId=user_pool_id, Username=response["Users"][0]["Username"])  # type: ignore
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":  # type: ignore
                self.logger.error("Cognito could not be found.")
            elif e.response["Error"]["Code"] == "InvalidParameterException":  # type: ignore
                self.logger.error("Invalid pool id and/or user provided.")
            elif e.response["Error"]["Code"] == "TooManyRequestsException":  # type: ignore
                self.logger.error("Too many requests.")
            elif e.response["Error"]["Code"] == "NotAuthorizedException":  # type: ignore
                self.logger.error("Not authorised.")
            elif e.response["Error"]["Code"] == "UserNotFoundException":  # type: ignore
                self.logger.error("User could not be found.")
            elif e.response["Error"]["Code"] == "InternalErrorException":  # type: ignore
                self.logger.error("Cognito had an internal service error.")

            return None

    def get_user_groups_by_pool_id_and_username(
        self,
        user_pool_id: str,
        # This should be the Cognito Username == 'sub' as available in auth_metadata (LambdaAuthorisationMetadata)
        iam_username: str,
        region: str | None = None,
        skip_to_lower: bool | None = False,
    ) -> list[str]:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            cognito_groups = client.admin_list_groups_for_user(  # type: ignore
                UserPoolId=user_pool_id, Username=iam_username.lower() if not skip_to_lower else iam_username
            )

            groups = []
            for group in cognito_groups["Groups"]:
                groups.append(group["GroupName"])

            return groups
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":  # type: ignore
                self.logger.error("Cognito could not be found.")
            elif e.response["Error"]["Code"] == "InvalidParameterException":  # type: ignore
                self.logger.error("Invalid pool id and/or user provided.")
            elif e.response["Error"]["Code"] == "TooManyRequestsException":  # type: ignore
                self.logger.error("Too many requests.")
            elif e.response["Error"]["Code"] == "NotAuthorizedException":  # type: ignore
                self.logger.error("Not authorised.")
            elif e.response["Error"]["Code"] == "UserNotFoundException":  # type: ignore
                self.logger.error("User could not be found.")
            elif e.response["Error"]["Code"] == "InternalErrorException":  # type: ignore
                self.logger.error("Cognito had an internal service error.")

            return []

    def create_new_user(
        self,
        user_pool_id: str,
        # Note: This email address is used as the Username for the current Cognito User Pool and there is a check
        #       to ensure that the Username provided below IS an email. We will want to change this so that we
        #       can support aliases that aren't email addresses for those users that share or do not have their
        #       own email address.
        email_address: str,
        first_name: str,
        last_name: str,
        mobile_number: str,
        practice_id: int,
        practice_office_id: int | None = None,
        staff_id: int | None = None,
        client_id: int | None = None,
        migrated: bool | None = False,
        region: str | None = None,
        created_via_retool: bool = False,
    ) -> tuple[dict[str, Any] | None, str]:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            mobile_number = MobileUtils.validate_mobile_number(mobile_number)

            # Generate a temporary password - ensuring that it will pass the policy
            temporary_password = self._generate_temporary_password()

            user_attributes = [
                {"Name": "name", "Value": "{0} {1}".format(first_name, last_name)},
                {"Name": "email", "Value": email_address.lower()},
                {"Name": "phone_number", "Value": mobile_number},
                {"Name": "given_name", "Value": first_name},
                {"Name": "family_name", "Value": last_name},
                {"Name": CognitoUtils.PRACTICE_ID_ATTRIBUTE, "Value": str(practice_id)},
                {
                    "Name": CognitoUtils.PRACTICE_OFFICE_ID_ATTRIBUTE,
                    "Value": str(practice_office_id if practice_office_id is not None else 0),
                },
                {"Name": CognitoUtils.STAFF_ID_ATTRIBUTE, "Value": str(staff_id if staff_id is not None else 0)},
                {"Name": CognitoUtils.CLIENT_ID_ATTRIBUTE, "Value": str(client_id if client_id is not None else 0)},
                {"Name": CognitoUtils.MIGRATED_ATTRIBUTE, "Value": "true" if migrated else "false"},
                {"Name": "email_verified", "Value": "false"},
            ]

            if len(StringUtils.trim_to_empty(mobile_number)) > 0:
                user_attributes.append({"Name": "phone_number_verified", "Value": "false"})

            user = client.admin_create_user(  # type: ignore
                UserPoolId=user_pool_id,
                Username=email_address.lower(),
                UserAttributes=user_attributes,
                TemporaryPassword=temporary_password,
                ForceAliasCreation=False,
                # See https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/cognito-idp.html
                MessageAction="SUPPRESS",
                DesiredDeliveryMediums=["EMAIL"],
            )

            if not created_via_retool:
                verified_user_attributes = [{"Name": "email_verified", "Value": "true"}]

                if len(StringUtils.trim_to_empty(mobile_number)) > 0:
                    verified_user_attributes.append({"Name": "phone_number_verified", "Value": "true"})

                client.admin_update_user_attributes(  # type: ignore
                    UserPoolId=user_pool_id, Username=email_address.lower(), UserAttributes=verified_user_attributes
                )

            return user, temporary_password
        except ClientError as e:
            if e.response["Error"]["Code"] == "InvalidParameterException":  # type: ignore
                if "Invalid phone number" in e.response["Error"]["Message"]:  # type: ignore
                    self.logger.error("Failed to create user - invalid phone number format", exc_info=True)
                    raise InvalidParameterException(
                        parameters=[
                            InvalidParameterDetails(
                                error_type="invalid_format",
                                parameter="phone_number",
                                reason="Invalid phone number format",
                            )
                        ],
                        message="Failed to create user - invalid phone number format",
                    ) from e
                else:
                    self.logger.error("Failed to create user.", exc_info=True)
                    raise InternalServerError("Failed to create user.") from e
            else:
                self.logger.error("Failed to create user.", exc_info=True)
                raise InternalServerError("Failed to create user.") from e
        except Exception as e:
            self.logger.error("Failed to create user.", exc_info=True)
            raise InternalServerError("Failed to create user.") from e

    def update_user_email(
        self,
        user_pool_id: str,
        # This should be the Cognito Username == 'sub' as available in auth_metadata (LambdaAuthorisationMetadata)
        iam_username: str,
        new_email_address: str,
        region: str | None = None,
        skip_to_lower: bool | None = False,
    ) -> bool:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            client.admin_update_user_attributes(  # type: ignore
                UserPoolId=user_pool_id,
                Username=iam_username.lower() if not skip_to_lower else iam_username,
                UserAttributes=[
                    {"Name": "email", "Value": new_email_address},
                    {"Name": "email_verified", "Value": "true"},
                ],
            )

            return True
        except ClientError:
            self.logger.error("Failed to update user email", exc_info=True)
            return False

    def _generate_temporary_password(self) -> str:
        # Remove some of the ambiguous characters before beginning
        ascii_lowercase = "abcdefghjkmnpqrstuvwxyz"
        ascii_uppercase = "ABCDEFGHJKMNPQRSTUVWXYZ"
        digits = "23456789"
        punctuation = r"""!#$%&()*+/<=>?@[\]^_{}~"""

        # Generate a temporary password - ensuring that it will pass the policy
        temporary_password: str = (
            "".join(secrets.choice(ascii_lowercase) for _ in range(2))
            + "".join(secrets.choice(ascii_uppercase) for _ in range(2))
            + "".join(secrets.choice(digits) for _ in range(2))
            + "".join(secrets.choice(punctuation) for _ in range(2))
        )

        temporary_password = "".join(random.sample(temporary_password, len(temporary_password)))

        return temporary_password

    def delete_user(
        self,
        user_pool_id: str,
        # This should be the Cognito Username == 'sub' as available in auth_metadata (LambdaAuthorisationMetadata)
        iam_username: str,
        region: str | None = None,
        skip_to_lower: bool | None = False,
    ) -> bool:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            client.admin_delete_user(  # type: ignore
                UserPoolId=user_pool_id,
                Username=iam_username.lower() if not skip_to_lower else iam_username,
            )

            return True
        except ClientError:
            self.logger.error("Failed to delete user.", exc_info=True)
            return False

    def add_user_to_group(
        self,
        user_pool_id: str,
        # This should be the Cognito Username == 'sub' as available in auth_metadata (LambdaAuthorisationMetadata)
        iam_username: str,
        group_name: str,
        region: str | None = None,
        skip_to_lower: bool | None = False,
    ) -> bool:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            client.admin_add_user_to_group(  # type: ignore
                UserPoolId=user_pool_id,
                Username=iam_username.lower() if not skip_to_lower else iam_username,
                GroupName=group_name,
            )

            return True
        except ClientError:
            self.logger.error("Failed to add user to group.", exc_info=True)
            return False

    def remove_user_from_group(
        self,
        user_pool_id: str,
        # This should be the Cognito Username == 'sub' as available in auth_metadata (LambdaAuthorisationMetadata)
        iam_username: str,
        group_name: str,
        region: str | None = None,
        skip_to_lower: bool | None = False,
    ) -> bool:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            client.admin_remove_user_from_group(  # type: ignore
                UserPoolId=user_pool_id,
                Username=iam_username.lower() if not skip_to_lower else iam_username,
                GroupName=group_name,
            )

            return True
        except ClientError:
            self.logger.error("Failed to remove user from group.", exc_info=True)
            return False

    def does_user_exist(
        self,
        user_pool_id: str,
        # With our current Cognito User Pool configuration the Username == Email Address but it can also be accessed
        # via the 'sub' and when looking in Cognito the default view shows the 'sub' == Username. However once an
        # email address is changed, you can no longer use the original email address if it was the one that was used
        # when the user was originally created as that is forever locked in as an alias for the Username! So when
        # checking for duplicates, we have to check the Username and also the UserAttributes.
        iam_username_or_email: str,
        region: str | None = None,
        skip_to_lower: bool | None = False,
    ) -> bool:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            # First check for a user whose Username == sub or email address provided
            try:
                client.admin_get_user(  # type: ignore
                    UserPoolId=user_pool_id,
                    Username=iam_username_or_email.lower() if not skip_to_lower else iam_username_or_email,
                )

                return True
            except Exception:
                pass

            # Secondly, check if an email is provided then it too is unique
            if "@" in iam_username_or_email:
                response = client.list_users(  # type: ignore
                    UserPoolId=user_pool_id,
                    AttributesToGet=["email"],
                    Limit=1,
                    Filter='email = "{0}"'.format(iam_username_or_email.lower()),
                )

                return "Users" in response and len(response["Users"]) > 0
            else:
                return False
        except self.client.exceptions.UserNotFoundException:  # type: ignore
            print("User does not exist")
            return False
        except ClientError:
            self.logger.error("Could not determine if user exists.", exc_info=True)
            return False

    def set_staff_id(
        self,
        user_pool_id: str,
        # This should be the Cognito Username == 'sub' as available in auth_metadata (LambdaAuthorisationMetadata)
        iam_username: str,
        staff_id: int,
        region: str | None = None,
        skip_to_lower: bool | None = False,
    ) -> bool:
        return self.set_user_attribute(
            user_pool_id=user_pool_id,
            iam_username=iam_username,
            attribute_name=CognitoUtils.STAFF_ID_ATTRIBUTE,
            attribute_value=str(staff_id),
            region=region,
            skip_to_lower=skip_to_lower,
        )

    def set_user_attribute(
        self,
        user_pool_id: str,
        # This should be the Cognito Username == 'sub' as available in auth_metadata (LambdaAuthorisationMetadata)
        iam_username: str,
        attribute_name: str,
        attribute_value: str,
        region: str | None = None,
        skip_to_lower: bool | None = False,
    ) -> bool:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            client.admin_update_user_attributes(  # type: ignore
                UserPoolId=user_pool_id,
                Username=iam_username.lower() if not skip_to_lower else iam_username,
                UserAttributes=[{"Name": attribute_name, "Value": attribute_value}],
            )

            return True
        except ClientError:
            self.logger.error("Failed to set user attribute.")
            return False

    def admin_enable_user(
        self,
        user_pool_id: str,
        # This should be the Cognito Username == 'sub' as available in auth_metadata (LambdaAuthorisationMetadata)
        iam_username: str,
        region: str | None = None,
        skip_to_lower: bool | None = False,
    ) -> bool:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            client.admin_enable_user(  # type: ignore
                UserPoolId=user_pool_id, Username=iam_username.lower() if not skip_to_lower else iam_username
            )

            return True
        except ClientError:
            self.logger.error("Failed to enable this user on Cognito.", exc_info=True)
            return False

    def admin_disable_user(
        self,
        user_pool_id: str,
        # This should be the Cognito Username == 'sub' as available in auth_metadata (LambdaAuthorisationMetadata)
        iam_username: str,
        region: str | None = None,
        skip_to_lower: bool | None = False,
    ) -> bool:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            client.admin_disable_user(  # type: ignore
                UserPoolId=user_pool_id, Username=iam_username.lower() if not skip_to_lower else iam_username
            )

            return True
        except ClientError:
            self.logger.error("Failed to disable this user on Cognito.", exc_info=True)
            return False

    def admin_user_global_sign_out(
        self,
        user_pool_id: str,
        # This should be the Cognito Username == 'sub' as available in auth_metadata (LambdaAuthorisationMetadata)
        iam_username: str,
        region: str | None = None,
        skip_to_lower: bool | None = False,
    ) -> bool:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            client.admin_user_global_sign_out(  # type: ignore
                UserPoolId=user_pool_id, Username=iam_username.lower() if not skip_to_lower else iam_username
            )

            return True
        except ClientError:
            self.logger.error("Failed to disable this user on Cognito.", exc_info=True)
            return False
