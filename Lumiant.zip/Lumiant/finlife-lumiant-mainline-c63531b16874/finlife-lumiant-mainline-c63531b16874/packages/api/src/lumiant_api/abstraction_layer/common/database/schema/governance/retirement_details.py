import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Numeric, String, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class RetirementDetails(Base):
    __tablename__ = "RetirementDetails"

    retirement_details_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("Client.client_id"), nullable=False, index=True)
    retirement_age: Mapped[int | None] = mapped_column(Integer)
    required_income: Mapped[float | None] = mapped_column(Numeric(12, 2))
    retirement_lifestyle: Mapped[str | None] = mapped_column(ENUM("B", "C", "L"))
    notes: Mapped[str | None] = mapped_column(String(5000))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client: Mapped["Client"] = relationship("Client", back_populates="retirement_details", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
