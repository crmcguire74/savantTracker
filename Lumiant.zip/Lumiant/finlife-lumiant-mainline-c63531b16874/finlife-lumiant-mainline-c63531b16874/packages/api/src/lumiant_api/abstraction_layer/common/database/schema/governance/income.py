import datetime
from typing import Any

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Numeric, Boolean, Date, DateTime, text
from sqlalchemy.dialects.mysql import ENUM, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Income(Base):
    __tablename__ = "Income"

    income_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    client_id: Mapped[int | None] = mapped_column(ForeignKey("Client.client_id"), index=True)
    legal_entity_id: Mapped[int | None] = mapped_column(ForeignKey("LegalEntity.legal_entity_id"), index=True)
    asset_id: Mapped[int | None] = mapped_column(ForeignKey("Asset.asset_id"), index=True)
    income_type: Mapped[str] = mapped_column(ENUM("S", "I", "P", "C"), nullable=False)
    employer: Mapped[str | None] = mapped_column(String(100))
    job_title: Mapped[str | None] = mapped_column(String(100))
    salary: Mapped[float | None] = mapped_column(Numeric(15, 2))
    super_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    salary_sacrifice: Mapped[float | None] = mapped_column(Numeric(15, 2))
    income: Mapped[float | None] = mapped_column(Numeric(15, 2))
    frequency: Mapped[str | None] = mapped_column(ENUM("W", "F", "T", "M", "B", "Q", "S", "A"))
    income_sub_type: Mapped[str | None] = mapped_column(
        ENUM("GA", "GD", "GC", "GP", "GG", "GI", "GT", "GV", "GO", "DP", "DA", "DS", "DI", "DT")
    )
    description: Mapped[str | None] = mapped_column(String(200))
    assessed: Mapped[bool | None] = mapped_column(Boolean)
    tax_status: Mapped[str | None] = mapped_column(ENUM("T", "N"))
    rate_change_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    bonus: Mapped[float | None] = mapped_column(Numeric(15, 2))
    bonus_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    commission: Mapped[float | None] = mapped_column(Numeric(15, 2))
    commission_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    start_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    end_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    planned_changes: Mapped[bool | None] = mapped_column(Boolean)
    planned_changes_description: Mapped[str | None] = mapped_column(String(255))
    eligible_social_benefits: Mapped[bool | None] = mapped_column(Boolean)
    type_of_concession: Mapped[str | None] = mapped_column(String(100))
    gifted_assets: Mapped[bool | None] = mapped_column(Boolean)
    gifted_assets_list: Mapped[dict[str, Any] | None] = mapped_column(JSON)
    crn: Mapped[str | None] = mapped_column(String(100))
    is_receiving_payments: Mapped[bool | None] = mapped_column(Boolean)
    payment_type: Mapped[str | None] = mapped_column(String(100))
    benefit_amount: Mapped[float | None] = mapped_column(Numeric(15, 2))
    retirement_benefit_amount: Mapped[float | None] = mapped_column(Numeric(15, 2))
    notes: Mapped[str | None] = mapped_column(String(5000))
    client_notes: Mapped[str | None] = mapped_column(String(2000))
    partner_notes: Mapped[str | None] = mapped_column(String(2000))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="income", lazy="select")
    client: Mapped["Client"] = relationship("Client", back_populates="income", lazy="select")
    legal_entity: Mapped["LegalEntity"] = relationship("LegalEntity", back_populates="income", lazy="select")
    asset: Mapped["Asset"] = relationship("Asset", back_populates="income", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.legal_entity import LegalEntity  # pylint: disable=C0413,R0401
