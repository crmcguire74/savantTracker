import json
from dataclasses import dataclass

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.database.schema.module_state import ModuleState as DBModuleState
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils


@dataclass
class ModuleState(object):
    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    moduleStateId: int | None
    clientId: int | None
    previouslyCompleted: bool
    module: str
    moduleState: str
    sentDate: str
    sentReminders: int
    startedDate: str
    startedReminders: int
    finishedDate: str
    expiredDate: str
    numberOfStaffVaultUploads: int
    numberOfClientVaultUploads: int
    numberOfStaffVaultFileMoves: int
    numberOfClientVaultFileMoves: int
    numberOfStaffVaultFileRenames: int
    numberOfClientVaultFileRenames: int
    updatedBy: str
    updated: str

    def __init__(self) -> None:
        self.moduleStateId = None
        self.clientId = None
        self.previouslyCompleted = False
        self.module = ""
        self.moduleState = ""
        self.sentDate = ""
        self.sentReminders = 0
        self.startedDate = ""
        self.startedReminders = 0
        self.finishedDate = ""
        self.expiredDate = ""
        self.updatedBy = ""
        self.updated = ""
        self.numberOfStaffVaultUploads = 0
        self.numberOfClientVaultUploads = 0
        self.numberOfStaffVaultFileMoves = 0
        self.numberOfClientVaultFileMoves = 0
        self.numberOfStaffVaultFileRenames = 0
        self.numberOfClientVaultFileRenames = 0

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)

    @staticmethod
    def convert_from_db_model(db_module_state: DBModuleState | None) -> "ModuleState | None":
        if db_module_state is None:
            return None

        module_state = ModuleState()
        module_state.moduleStateId = db_module_state.module_state_id
        module_state.clientId = db_module_state.client_id
        module_state.previouslyCompleted = db_module_state.previously_completed
        module_state.module = db_module_state.module
        module_state.moduleState = db_module_state.module_state
        module_state.sentDate = SerializationUtils.convert_value_to_string(db_module_state.sent_date)
        module_state.sentReminders = db_module_state.sent_reminders
        module_state.startedDate = SerializationUtils.convert_value_to_string(db_module_state.started_date)
        module_state.startedReminders = db_module_state.started_reminders
        module_state.finishedDate = SerializationUtils.convert_value_to_string(db_module_state.finished_date)
        module_state.expiredDate = SerializationUtils.convert_value_to_string(db_module_state.expired_date)
        module_state.updatedBy = db_module_state.updated_by
        module_state.updated = SerializationUtils.convert_value_to_string(db_module_state.updated)
        module_state.numberOfStaffVaultUploads = db_module_state.number_of_staff_vault_uploads
        module_state.numberOfClientVaultUploads = db_module_state.number_of_client_vault_uploads
        module_state.numberOfStaffVaultFileMoves = db_module_state.number_of_staff_vault_file_moves
        module_state.numberOfClientVaultFileMoves = db_module_state.number_of_client_vault_file_moves
        module_state.numberOfStaffVaultFileRenames = db_module_state.number_of_staff_vault_file_renames
        module_state.numberOfClientVaultFileRenames = db_module_state.number_of_client_vault_file_renames

        return module_state
