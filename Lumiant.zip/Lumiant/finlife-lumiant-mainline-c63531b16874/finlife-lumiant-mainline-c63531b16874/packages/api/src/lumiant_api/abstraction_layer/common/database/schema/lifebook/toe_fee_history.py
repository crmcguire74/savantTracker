import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Numeric, Integer, ForeignKey, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class ToeFeeHistory(Base):
    __tablename__ = "ToeFeeHistory"

    toe_fee_history_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    toe_file_name: Mapped[str] = mapped_column(String(100), nullable=False)
    initial_fee: Mapped[float | None] = mapped_column(Numeric(20, 8), nullable=True)
    deposit_payable: Mapped[float | None] = mapped_column(Numeric(20, 8), nullable=True)
    all_assets_under_management: Mapped[float | None] = mapped_column(Numeric(20, 8), nullable=True)
    minimum_annual_fee: Mapped[float | None] = mapped_column(Numeric(20, 8), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="toe_fee_history", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
