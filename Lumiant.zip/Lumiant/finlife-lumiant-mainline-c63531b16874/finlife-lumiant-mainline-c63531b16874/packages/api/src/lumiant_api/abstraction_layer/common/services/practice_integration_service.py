import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from sqlalchemy import and_

from lumiant_api.abstraction_layer.common.database.schema.integrations.practice_integration import (
    PracticeIntegration as DBPracticeIntegration,
)
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)


class PracticeIntegrationService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Practice Integration
    -------------------------------------------------------------------------------------------------
    """

    logger = Logger(child=True, service="Practice")
    tracer = Tracer(service="Practice")

    lumiant_rds_session: sqlalchemy.orm.Session
    boto3_session: Boto3Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Boto3Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def get_for_practice_and_type(
        self, practice_id: int, integration_type: str, only_enabled: bool = False
    ) -> DBPracticeIntegration | None:
        if only_enabled:
            integration = (
                self.lumiant_rds_session.query(DBPracticeIntegration)
                .filter(
                    and_(
                        DBPracticeIntegration.practice_id == practice_id,
                        DBPracticeIntegration.integration_type == integration_type,
                        DBPracticeIntegration.enabled.is_(True),
                    )
                )
                .first()
            )
        else:
            integration = (
                self.lumiant_rds_session.query(DBPracticeIntegration)
                .filter(
                    and_(
                        DBPracticeIntegration.practice_id == practice_id,
                        DBPracticeIntegration.integration_type == integration_type,
                    )
                )
                .first()
            )

        return integration
