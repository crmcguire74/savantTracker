import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Date, Boolean, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class HouseholdMember(Base):
    __tablename__ = "HouseholdMember"

    household_member_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    relation: Mapped[str] = mapped_column(String(40), nullable=False)
    first_name: Mapped[str] = mapped_column(String(255), nullable=False)
    middle_name: Mapped[str | None] = mapped_column(String(255))
    last_name: Mapped[str] = mapped_column(String(255), nullable=False)
    dob: Mapped[datetime.date | None] = mapped_column(Date)
    sex: Mapped[str | None] = mapped_column(ENUM("M", "F", "O", "U"))
    living_at_home: Mapped[bool | None] = mapped_column(Boolean)
    financially_dependent: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    financially_dependent_until: Mapped[int | None] = mapped_column(Integer)
    notes: Mapped[str | None] = mapped_column(String(5000))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="household_members", lazy="select")

    expense: Mapped[list["Household"]] = relationship("Expense", back_populates="household_member", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
