import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Boolean, String, Date, Numeric, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class EmploymentDetails(Base):
    __tablename__ = "EmploymentDetails"

    employment_details_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("Client.client_id"), nullable=False, index=True)
    degree_qualified: Mapped[bool | None] = mapped_column(Boolean)
    qualifications: Mapped[str | None] = mapped_column(String(255))
    recent_retrenched: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    employment_status: Mapped[str | None] = mapped_column(
        ENUM("F", "P", "A", "S", "C", "H", "N", "R", "U", "O", "E", "T")
    )
    planned_changes: Mapped[bool | None] = mapped_column(Boolean)
    planned_changes_description: Mapped[str | None] = mapped_column(String(255))
    business_structure: Mapped[str | None] = mapped_column(String(255))
    employed_by_own_company: Mapped[bool | None] = mapped_column(Boolean)
    occupation: Mapped[str | None] = mapped_column(String(80))
    start_date: Mapped[datetime.date | None] = mapped_column(Date)
    employer: Mapped[str | None] = mapped_column(String(80))
    secondary_occupation: Mapped[str | None] = mapped_column(String(80))
    secondary_occupation_start_date: Mapped[datetime.date | None] = mapped_column(Date)
    secondary_occupation_employer: Mapped[str | None] = mapped_column(String(80))
    employment_hours_per_week: Mapped[float | None] = mapped_column(Numeric(3, 1))
    unused_annual_leave: Mapped[float | None] = mapped_column(Numeric(3, 1))
    unused_sick_leave: Mapped[float | None] = mapped_column(Numeric(3, 1))
    unused_long_service_leave: Mapped[float | None] = mapped_column(Numeric(3, 1))
    worked_overseas: Mapped[bool | None] = mapped_column(Boolean)
    worked_overseas_details: Mapped[str | None] = mapped_column(String(255))
    salary_sacrifice_available: Mapped[bool | None] = mapped_column(Boolean)
    notes: Mapped[str | None] = mapped_column(String(5000))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client: Mapped["Client"] = relationship("Client", back_populates="employment_details", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
