import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class HouseholdValue(Base):
    __tablename__ = "HouseholdValue"

    household_value_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_values_id: Mapped[int] = mapped_column(
        ForeignKey("HouseholdValues.household_values_id"), nullable=False, index=True
    )
    # Delete this column it shouldn't be here!
    client_id: Mapped[int | None] = mapped_column(Integer)
    card_id: Mapped[int | None] = mapped_column(Integer)
    value_rank: Mapped[int | None] = mapped_column(Integer)
    notes: Mapped[str | None] = mapped_column(String(5000))
    progress: Mapped[int | None] = mapped_column(Integer)
    description: Mapped[str | None] = mapped_column(String(5000))
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household_values: Mapped["HouseholdValues"] = relationship(
        "HouseholdValues", back_populates="values", lazy="select"
    )

    # TODO: This should be removed and it should use 'card_id' instead of 'household_value_id' like HouseholdValueGoal
    next_steps: Mapped[list["HouseholdValueNextStep"]] = relationship(
        "HouseholdValueNextStep", back_populates="household_value", lazy="select"
    )
    household_member_progress: Mapped[list["HouseholdValueHouseholdMemberProgress"]] = relationship(
        "HouseholdValueHouseholdMemberProgress", back_populates="household_value", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.values.household_values import HouseholdValues  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.values.household_value_household_member_progress import (
    HouseholdValueHouseholdMemberProgress,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.values.household_value_next_step import HouseholdValueNextStep  # pylint: disable=C0413,R0401
