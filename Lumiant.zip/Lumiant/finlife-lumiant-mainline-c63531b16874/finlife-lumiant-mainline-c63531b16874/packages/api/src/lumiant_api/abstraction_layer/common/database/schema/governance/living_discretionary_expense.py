import datetime
from sqlalchemy.dialects.mysql import ENUM
from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Numeric, String, DateTime, text, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship


class LivingDiscretionaryExpense(Base):
    __tablename__ = "LivingDiscretionaryExpense"

    living_discretionary_expense_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)

    alimony: Mapped[float | None] = mapped_column(Numeric(15, 2))
    alimony_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    child_maintenance: Mapped[float | None] = mapped_column(Numeric(15, 2))
    child_maintenance_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    child_care: Mapped[float | None] = mapped_column(Numeric(15, 2))
    child_care_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    child: Mapped[float | None] = mapped_column(Numeric(15, 2))
    child_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    care: Mapped[float | None] = mapped_column(Numeric(15, 2))
    care_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    education: Mapped[float | None] = mapped_column(Numeric(15, 2))
    education_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    rent: Mapped[float | None] = mapped_column(Numeric(15, 2))
    rent_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    association_fees: Mapped[float | None] = mapped_column(Numeric(15, 2))
    association_fees_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    rates: Mapped[float | None] = mapped_column(Numeric(15, 2))
    rates_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    water: Mapped[float | None] = mapped_column(Numeric(15, 2))
    water_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    gardening: Mapped[float | None] = mapped_column(Numeric(15, 2))
    gardening_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    home_improvement: Mapped[float | None] = mapped_column(Numeric(15, 2))
    home_improvement_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    repairs: Mapped[float | None] = mapped_column(Numeric(15, 2))
    repairs_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    electricity: Mapped[float | None] = mapped_column(Numeric(15, 2))
    electricity_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    gas: Mapped[float | None] = mapped_column(Numeric(15, 2))
    gas_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    groceries: Mapped[float | None] = mapped_column(Numeric(15, 2))
    groceries_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    home_phone: Mapped[float | None] = mapped_column(Numeric(15, 2))
    home_phone_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    cable: Mapped[float | None] = mapped_column(Numeric(15, 2))
    cable_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    broadband: Mapped[float | None] = mapped_column(Numeric(15, 2))
    broadband_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    mobile: Mapped[float | None] = mapped_column(Numeric(15, 2))
    mobile_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    cleaning: Mapped[float | None] = mapped_column(Numeric(15, 2))
    cleaning_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    personal_care: Mapped[float | None] = mapped_column(Numeric(15, 2))
    personal_care_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    pet_care: Mapped[float | None] = mapped_column(Numeric(15, 2))
    pet_care_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    appliances: Mapped[float | None] = mapped_column(Numeric(15, 2))
    appliances_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    home_other: Mapped[float | None] = mapped_column(Numeric(15, 2))
    home_other_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    clothing: Mapped[float | None] = mapped_column(Numeric(15, 2))
    clothing_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    footwear: Mapped[float | None] = mapped_column(Numeric(15, 2))
    footwear_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    healthcare: Mapped[float | None] = mapped_column(Numeric(15, 2))
    healthcare_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    dental: Mapped[float | None] = mapped_column(Numeric(15, 2))
    dental_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    healthcare_other: Mapped[float | None] = mapped_column(Numeric(15, 2))
    healthcare_other_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    car_transport: Mapped[float | None] = mapped_column(Numeric(15, 2))
    car_transport_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    public_transport: Mapped[float | None] = mapped_column(Numeric(15, 2))
    public_transport_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    living_other: Mapped[float | None] = mapped_column(Numeric(15, 2))
    living_other_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    memberships: Mapped[float | None] = mapped_column(Numeric(15, 2))
    memberships_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    streaming: Mapped[float | None] = mapped_column(Numeric(15, 2))
    streaming_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    alcohol: Mapped[float | None] = mapped_column(Numeric(15, 2))
    alcohol_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    tobacco: Mapped[float | None] = mapped_column(Numeric(15, 2))
    tobacco_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    entertainment: Mapped[float | None] = mapped_column(Numeric(15, 2))
    entertainment_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    hobbies: Mapped[float | None] = mapped_column(Numeric(15, 2))
    hobbies_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    vacations: Mapped[float | None] = mapped_column(Numeric(15, 2))
    vacations_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    take_away: Mapped[float | None] = mapped_column(Numeric(15, 2))
    take_away_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    gifts: Mapped[float | None] = mapped_column(Numeric(15, 2))
    gifts_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    donations: Mapped[float | None] = mapped_column(Numeric(15, 2))
    donations_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    discretionary_other: Mapped[float | None] = mapped_column(Numeric(15, 2))
    discretionary_other_frequency: Mapped[str | None] = mapped_column(
        ENUM("W", "F", "T", "M", "I", "L", "E", "B", "Q", "S", "A"), default="W"
    )

    notes: Mapped[str | None] = mapped_column(String(5000))
    client_notes: Mapped[str | None] = mapped_column(String(2500))
    partner_notes: Mapped[str | None] = mapped_column(String(2500))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship(
        "Household", back_populates="living_discretionary_expenses", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
