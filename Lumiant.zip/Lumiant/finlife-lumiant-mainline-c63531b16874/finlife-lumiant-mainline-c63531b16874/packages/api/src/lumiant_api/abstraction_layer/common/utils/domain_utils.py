from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.constants import aws_region, external_domains, environments
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice as DBPractice
from lumiant_api.abstraction_layer.common.utils.environment_utils import EnvironmentUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class DomainUtils(object):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Domain
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    def __init__(self) -> None:
        pass

    @staticmethod
    def get_domain_for_practice(practice: DBPractice | None, region: str | None = None) -> str:
        """
        :param practice: Typically should be lumiant_rds_session.query(DBPractice)...
        :param region: Typically should be auth_metadata.region
        :return: default domain to use
        """

        if practice is not None:
            # Override the domain if explicitly defined
            if len(StringUtils.trim_to_empty(practice.external_domain)) > 0:
                return StringUtils.trim_to_empty(practice.external_domain)
            else:
                practice_home_region = StringUtils.trim_to_empty(practice.home_region)

                if len(practice_home_region) > 0:
                    return (
                        external_domains.INTERNATIONAL
                        if practice_home_region != aws_region.AP_SOUTHEAST_2
                        else external_domains.LUMIANT
                    )

        # Determine the region if not provided
        if region is None:
            region = EnvironmentUtils.get_region()

        region = StringUtils.trim_to_empty(region)

        if len(region) > 0:
            return external_domains.INTERNATIONAL if region != aws_region.AP_SOUTHEAST_2 else external_domains.LUMIANT
        else:
            return external_domains.LUMIANT

    @staticmethod
    def get_app_domain_for_environment(domain: str, environment: str) -> str:
        """
        :param domain: Output from get_domain_for_practice() above
        :param environment: Typically should be auth_metadata.environment
        :return: www domain to use
        """

        domain = StringUtils.trim_to_empty(domain)
        environment = StringUtils.trim_to_empty(environment)

        # WWW Domain wise, we don't want to use the environment directly
        if environment == environments.ENVIRONMENT_QA_US:
            environment = environments.ENVIRONMENT_QA
        if environment == environments.ENVIRONMENT_STAGING_US:
            environment = environments.ENVIRONMENT_STAGING
        if environment == environments.ENVIRONMENT_PROD_US:
            environment = environments.ENVIRONMENT_PROD

        is_prod = EnvironmentUtils.is_aws_prod_environment(environment)

        if external_domains.INVPREFS == domain and is_prod:
            return domain

        return "app{0}.{1}".format("" if is_prod else "-" + environment, domain)
