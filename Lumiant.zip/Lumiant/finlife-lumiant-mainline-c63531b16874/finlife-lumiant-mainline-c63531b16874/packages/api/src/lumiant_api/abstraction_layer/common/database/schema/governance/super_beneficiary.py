import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Boolean, String, Date, Numeric, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class SuperBeneficiary(Base):
    __tablename__ = "SuperBeneficiary"

    super_beneficiary_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    legal_entity_id: Mapped[int | None] = mapped_column(
        ForeignKey("LegalEntity.legal_entity_id"), nullable=True, index=True
    )
    asset_id: Mapped[int | None] = mapped_column(ForeignKey("Asset.asset_id"), nullable=True, index=True)
    is_primary: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    name: Mapped[str | None] = mapped_column(String(200))
    relation: Mapped[str | None] = mapped_column(ENUM("M", "P", "C", "O"))
    nominated: Mapped[bool | None] = mapped_column(Boolean)
    beneficiary_type: Mapped[str | None] = mapped_column(ENUM("N", "B", "P", "L", "R"))
    ends: Mapped[datetime.date | None] = mapped_column(Date)
    amount: Mapped[float | None] = mapped_column(Numeric(15, 2))
    percent: Mapped[float | None] = mapped_column(Numeric(5, 4))
    estate: Mapped[str | None] = mapped_column(ENUM("D", "P", "R"))
    estate_amount: Mapped[float | None] = mapped_column(Numeric(15, 2))
    estate_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    notes: Mapped[str | None] = mapped_column(String(5000))
    client_notes: Mapped[str | None] = mapped_column(String(2500))
    partner_notes: Mapped[str | None] = mapped_column(String(2500))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    external_id: Mapped[str | None] = mapped_column(String(20), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    legal_entity: Mapped["LegalEntity"] = relationship(
        "LegalEntity", back_populates="super_beneficiaries", lazy="select"
    )
    asset: Mapped["Asset"] = relationship("Asset", back_populates="super_beneficiaries", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.legal_entity import LegalEntity  # pylint: disable=C0413,R0401
