import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Boolean, Date, Numeric, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class EstatePlanning(Base):
    __tablename__ = "EstatePlanning"

    estate_planning_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    client_id: Mapped[int | None] = mapped_column(ForeignKey("Client.client_id"), index=True)
    solicitor_name: Mapped[str | None] = mapped_column(String(255))
    will_in_place: Mapped[bool | None] = mapped_column(Boolean)
    is_will_current: Mapped[bool | None] = mapped_column(Boolean)
    will_date: Mapped[datetime.date | None] = mapped_column(Date)
    will_location: Mapped[str | None] = mapped_column(String(200))
    will_provisions: Mapped[str | None] = mapped_column(ENUM("A", "T", "G"))
    healthcare_directive: Mapped[bool | None] = mapped_column(Boolean)
    healthcare_directive_details: Mapped[str | None] = mapped_column(String(2000))
    funeral_arrangement: Mapped[str | None] = mapped_column(ENUM("P", "B", "N"))
    funeral_details: Mapped[str | None] = mapped_column(String(200))
    prepaid_funeral: Mapped[bool | None] = mapped_column(Boolean)
    funeral_expense_value: Mapped[float | None] = mapped_column(Numeric(15, 2))
    purchase_date: Mapped[datetime.date | None] = mapped_column(Date)
    account_number: Mapped[str | None] = mapped_column(String(50))
    product_provider: Mapped[str | None] = mapped_column(String(100))
    super_beneficiaries_nominated: Mapped[bool | None] = mapped_column(Boolean)
    beneficiaries_nominated: Mapped[bool | None] = mapped_column(Boolean)
    poa_granted: Mapped[bool | None] = mapped_column(Boolean)
    pog_granted: Mapped[bool | None] = mapped_column(Boolean)
    apoa_granted: Mapped[bool | None] = mapped_column(Boolean)
    letter_of_wishes: Mapped[bool | None] = mapped_column(Boolean)
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    notes: Mapped[str | None] = mapped_column(String(5000))
    client_notes: Mapped[str | None] = mapped_column(String(1500))
    partner_notes: Mapped[str | None] = mapped_column(String(1500))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="estate_planning", lazy="select")
    client: Mapped["Client"] = relationship("Client", back_populates="estate_planning", lazy="select")

    beneficiaries: Mapped[list["Beneficiary"]] = relationship(
        "Beneficiary", back_populates="estate_planning", lazy="select"
    )
    executors: Mapped[list["Executor"]] = relationship("Executor", back_populates="estate_planning", lazy="select")
    powers_of: Mapped[list["PowerOf"]] = relationship("PowerOf", back_populates="estate_planning", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.beneficiary import Beneficiary  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.executor import Executor  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.power_of import PowerOf  # pylint: disable=C0413,R0401
