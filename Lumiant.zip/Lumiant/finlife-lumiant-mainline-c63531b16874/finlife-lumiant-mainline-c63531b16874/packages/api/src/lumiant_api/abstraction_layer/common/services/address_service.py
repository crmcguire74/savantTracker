import datetime

import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from lumiant_api.abstraction_layer.common.database.schema.address import Address as DBAddress
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils
from lumiant_core.momentum.apps.api_gateway_restapi.exceptions import InternalServerError


class AddressService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Address
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(child=True, service="Address")
    tracer = Tracer(service="Address")

    lumiant_rds_session: sqlalchemy.orm.Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.auth_metadata = auth_metadata

    def get_address(self, address_id: int) -> DBAddress | None:
        """Get an address by ID."""
        return self.lumiant_rds_session.query(DBAddress).filter(DBAddress.address_id == address_id).first()

    def create_address(
        self,
        constructed_address: str | None = None,
        address_line_1: str | None = None,
        address_line_2: str | None = None,
        suburb: str | None = None,
        post_code: str | None = None,
        state: str | None = None,
        country: str | None = None,
    ) -> int:
        """Create a new address record and return its ID. Does not commit — caller must commit or flush."""
        address = DBAddress()
        address.created_by = self.auth_metadata.iam_id
        address.updated_by = self.auth_metadata.iam_id
        self._set_address_fields(
            constructed_address=constructed_address,
            address=address,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            suburb=suburb,
            post_code=post_code,
            state=state,
            country=country,
        )
        self.lumiant_rds_session.add(address)
        self.lumiant_rds_session.flush()
        return address.address_id

    def update_address(
        self,
        address_id: int,
        constructed_address: str | None = None,
        address_line_1: str | None = None,
        address_line_2: str | None = None,
        suburb: str | None = None,
        post_code: str | None = None,
        state: str | None = None,
        country: str | None = None,
    ) -> None:
        """Update an existing address record. Does not commit — caller must commit or flush."""
        address = self.get_address(address_id=address_id)
        if address is None:
            raise InternalServerError("Could not update Address")

        address.updated = datetime.datetime.now(datetime.UTC)
        address.updated_by = self.auth_metadata.iam_id
        self._set_address_fields(
            address=address,
            constructed_address=constructed_address,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            suburb=suburb,
            post_code=post_code,
            state=state,
            country=country,
        )
        self.lumiant_rds_session.flush()

    @staticmethod
    def _set_address_fields(
        address: DBAddress,
        address_line_1: str | None,
        address_line_2: str | None,
        suburb: str | None,
        post_code: str | None,
        state: str | None,
        country: str | None,
        constructed_address: str | None = None,
    ) -> None:
        if constructed_address is not None:
            address.constructed_address = StringUtils.trim_to_empty(constructed_address)[:255]
        if address_line_1 is not None:
            address.address_line_1 = StringUtils.trim_to_empty(address_line_1)[:255]
        if address_line_2 is not None:
            address.address_line_2 = StringUtils.trim_to_empty(address_line_2)[:255]
        if suburb is not None:
            address.suburb = StringUtils.trim_to_empty(suburb)[:100]
        if post_code is not None:
            address.post_code = StringUtils.trim_to_empty(post_code)[:5]
        if state is not None:
            address.state = StringUtils.trim_to_empty(state)[:3]
        if country is not None:
            address.country = StringUtils.trim_to_empty(country)[:2]

        # Mandatory fields
        if address.address_line_1 is None:
            address.address_line_1 = ""
        if address.suburb is None:
            address.suburb = ""
        if address.post_code is None:
            address.post_code = ""
        if address.state is None:
            address.state = ""
        if address.country is None:
            address.country = ""
