import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Numeric, DateTime, text, Boolean
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class LegalEntity(Base):
    __tablename__ = "LegalEntity"

    legal_entity_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    legal_entity_type: Mapped[str] = mapped_column(ENUM("C", "S", "T", "E"), nullable=False)
    company_type: Mapped[str | None] = mapped_column(ENUM("T", "N", "I", "O"))
    trustee_type: Mapped[str | None] = mapped_column(ENUM("I", "C"))
    trust_type: Mapped[str | None] = mapped_column(ENUM("D", "U", "H", "C", "T", "S", "F", "E", "O"))
    name: Mapped[str | None] = mapped_column(String(250))
    purpose: Mapped[str | None] = mapped_column(String(1000))
    abn: Mapped[str | None] = mapped_column(String(13))
    tfn: Mapped[str | None] = mapped_column(String(9))
    value: Mapped[float | None] = mapped_column(Numeric(15, 2))
    growth_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    growth_dollar: Mapped[float | None] = mapped_column(Numeric(15, 2))
    client_share: Mapped[float | None] = mapped_column(Numeric(5, 4))
    partner_share: Mapped[float | None] = mapped_column(Numeric(5, 4))
    client_super_phase: Mapped[str | None] = mapped_column(ENUM("A", "T", "P"))
    partner_super_phase: Mapped[str | None] = mapped_column(ENUM("A", "T", "P"))
    notes: Mapped[str | None] = mapped_column(String(5000))
    client_notes: Mapped[str | None] = mapped_column(String(2000))
    partner_notes: Mapped[str | None] = mapped_column(String(2000))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="legal_entities", lazy="select")

    trustees: Mapped[list["Trustee"]] = relationship("Trustee", back_populates="legal_entity", lazy="select")
    trust_beneficiaries: Mapped[list["TrustBeneficiary"]] = relationship(
        "TrustBeneficiary", back_populates="legal_entity", lazy="select"
    )
    super_beneficiaries: Mapped[list["SuperBeneficiary"]] = relationship(
        "SuperBeneficiary", back_populates="legal_entity", lazy="select"
    )
    directors: Mapped[list["Director"]] = relationship("Director", back_populates="legal_entity", lazy="select")
    assets: Mapped[list["Asset"]] = relationship("Asset", back_populates="legal_entity", lazy="select")
    liabilities: Mapped[list["Liability"]] = relationship("Liability", back_populates="legal_entity", lazy="select")
    income: Mapped[list["Income"]] = relationship("Income", back_populates="legal_entity", lazy="select")
    expenses: Mapped[list["Expense"]] = relationship("Expense", back_populates="legal_entity", lazy="select")
    insurance: Mapped[list["Insurance"]] = relationship("Insurance", back_populates="legal_entity", lazy="select")
    tax_plannings: Mapped[list["TaxPlanning"]] = relationship(
        "TaxPlanning", back_populates="legal_entity", lazy="select"
    )
    education_plannings: Mapped[list["EducationPlanning"]] = relationship(
        "EducationPlanning", back_populates="legal_entity", lazy="select"
    )
    business_plannings: Mapped[list["BusinessPlanning"]] = relationship(
        "BusinessPlanning", back_populates="legal_entity", lazy="select"
    )
    charitable_plannings: Mapped[list["CharitablePlanning"]] = relationship(
        "CharitablePlanning", back_populates="legal_entity", lazy="select"
    )
    portfolios: Mapped[list["Portfolio"]] = relationship("Portfolio", back_populates="legal_entity", lazy="select")

    risk_profile: Mapped["RiskProfile"] = relationship(
        "RiskProfile", back_populates="legal_entity", uselist=False, lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.super_beneficiary import SuperBeneficiary  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.business_planning import BusinessPlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.charitable_planning import CharitablePlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.director import Director  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.education_planning import EducationPlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.expense import Expense  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.income import Income  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance import Insurance  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.liability import Liability  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.portfolio import Portfolio  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.risk_profile import RiskProfile  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.tax_planning import TaxPlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.trustee import Trustee  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.trust_beneficiary import TrustBeneficiary  # pylint: disable=C0413,R0401
