import datetime

import lumiant_api.abstraction_layer.common.constants.aws_region
from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.utils.date_utils import DateUtils


class BillingUtils(object):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Billing - Handy methods for maintaining billing
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    TRIGGER_NA: str = "N"
    TRIGGER_INVITED: str = "I"
    TRIGGER_VALUES: str = "V"
    TRIGGER_LIFEBOOK: str = "L"
    TRIGGER_INVESTMENT_PREFERENCES: str = "P"
    TRIGGER_TASKS: str = "T"
    TRIGGER_REGISTRATION: str = "R"
    TRIGGER_GOALS: str = "G"
    TRIGGER_DISCOUNT_OFFER: str = "D"

    @staticmethod
    def get_client_billable_start_date(
        region: str = lumiant_api.abstraction_layer.common.constants.aws_region.AP_SOUTHEAST_2,
    ) -> datetime.date:
        return DateUtils.get_current_date_in_region_tz(
            region=region
            if region is not None
            else lumiant_api.abstraction_layer.common.constants.aws_region.AP_SOUTHEAST_2
        )

    @staticmethod
    def get_client_billable_end_date(
        region: str = lumiant_api.abstraction_layer.common.constants.aws_region.AP_SOUTHEAST_2,
    ) -> datetime.date:
        date = DateUtils.get_current_datetime_in_region_tz(
            region=region
            if region is not None
            else lumiant_api.abstraction_layer.common.constants.aws_region.AP_SOUTHEAST_2
        )

        return (date.replace(day=1) + datetime.timedelta(days=32)).replace(
            day=15, hour=0, minute=0, second=0, microsecond=0
        )
