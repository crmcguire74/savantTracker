import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Date, Boolean, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Goal(Base):
    __tablename__ = "Goal"

    goal_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    client_id: Mapped[int | None] = mapped_column(ForeignKey("Client.client_id"), nullable=True, index=True)
    title: Mapped[str | None] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(String(3500))
    success_looks_like: Mapped[str | None] = mapped_column(String(1500))
    target_date: Mapped[datetime.date | None] = mapped_column(Date)
    target_date_pa: Mapped[datetime.date | None] = mapped_column(Date)
    target_date_pa_date: Mapped[datetime.date | None] = mapped_column(Date)
    target_date_approval_status: Mapped[str | None] = mapped_column(String(50))
    completed_date: Mapped[datetime.date | None] = mapped_column(Date)
    rank: Mapped[int | None] = mapped_column(Integer)
    estimated_cost: Mapped[int | None] = mapped_column(Integer)
    estimated_cost_pa: Mapped[int | None] = mapped_column(Integer)
    estimated_cost_pa_date: Mapped[datetime.date | None] = mapped_column(Date)
    estimated_cost_approval_status: Mapped[str | None] = mapped_column(String(50))
    confidence: Mapped[int | None] = mapped_column(Integer)
    progress: Mapped[int | None] = mapped_column(Integer)
    importance: Mapped[int | None] = mapped_column(Integer)
    category: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[int | None] = mapped_column(Integer)
    status_pa: Mapped[int | None] = mapped_column(Integer)
    status_pa_date: Mapped[datetime.date | None] = mapped_column(Date)
    status_approval_status: Mapped[str | None] = mapped_column(String(50))
    recurrence_type: Mapped[str] = mapped_column(ENUM("N", "M", "Q", "S", "A"), default="N", nullable=False)
    recurrence_type_pa: Mapped[str | None] = mapped_column(ENUM("N", "M", "Q", "S", "A"), nullable=True)
    recurrence_type_pa_date: Mapped[datetime.date | None] = mapped_column(Date)
    recurrence_type_approval_status: Mapped[str | None] = mapped_column(String(50))
    recurrence_interval: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    recurrence_interval_pa: Mapped[int | None] = mapped_column(Integer, nullable=True)
    recurrence_interval_pa_date: Mapped[datetime.date | None] = mapped_column(Date)
    recurrence_interval_approval_status: Mapped[str | None] = mapped_column(String(50))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    source_of_truth: Mapped[str] = mapped_column(String(50), nullable=False, default="L")
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    secondary_external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    tertiary_external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    for_approval: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    approval_status: Mapped[str | None] = mapped_column(String(255), nullable=True)
    approval_change_date: Mapped[datetime.date | None] = mapped_column(Date)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    deleted_by: Mapped[str | None] = mapped_column(String(50), nullable=True)
    deleted: Mapped[datetime.datetime | None] = mapped_column(DateTime, nullable=True)

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="goals", lazy="select")
    client: Mapped["Client"] = relationship("Client", back_populates="goals", lazy="select")

    household_value_goals: Mapped[list["HouseholdValueGoal"]] = relationship(
        "HouseholdValueGoal", back_populates="goal", lazy="select"
    )
    client_value_goals: Mapped[list["ClientValueGoal"]] = relationship(
        "ClientValueGoal", back_populates="goal", lazy="select"
    )
    life_goals: Mapped[list["LifeGoal"]] = relationship("LifeGoal", back_populates="goal", lazy="select")
    client_strategy_goals: Mapped[list["ClientStrategyGoal"]] = relationship(
        "ClientStrategyGoal", back_populates="goal", lazy="select"
    )
    household_strategy_goals: Mapped[list["HouseholdStrategyGoal"]] = relationship(
        "HouseholdStrategyGoal", back_populates="goal", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.life.life_goal import LifeGoal  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.client_strategy_goal import ClientStrategyGoal  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy_goal import (
    HouseholdStrategyGoal,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.values.client_value_goal import ClientValueGoal  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.values.household_value_goal import HouseholdValueGoal  # pylint: disable=C0413,R0401
