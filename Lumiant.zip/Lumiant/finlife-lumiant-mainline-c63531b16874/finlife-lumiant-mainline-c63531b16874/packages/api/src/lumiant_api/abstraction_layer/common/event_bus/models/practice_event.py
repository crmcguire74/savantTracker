from lumiant_api.abstraction_layer.common.event_bus.models.lumiant_event import LumiantEvent
from pydantic import Field


class PracticeEvent(LumiantEvent):
    """
    -------------------------------------------------------------------------------------------------
    MODEL: Practice Event
    -------------------------------------------------------------------------------------------------
    """

    type: str = Field(
        alias="type",
        description="The type of event that has occurred",
        json_schema_extra={"is_attribute": True},
        # const=True,
        default="Practice",
    )

    lumiant_object: str = Field(
        alias="lumiantObject",
        description="The lumiant object (if any) that this event pertains to",
        json_schema_extra={"is_attribute": True},
        # const=True,
        default="Practice",
    )

    lumiant_object_id_column: str = Field(
        alias="lumiantObjectIdColumn",
        description="The ID column name of the lumiant object that this event pertains to",
        json_schema_extra={"is_attribute": True},
        # const=True,
        default="practice_id",
    )
