import json
from dataclasses import dataclass

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils


@dataclass
class HouseholdStaffAccess(object):
    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    practiceOfficeId: int | None
    practiceOfficeName: str | None
    staffId: int | None
    staffTitle: str | None
    staffFirstName: str | None
    staffMiddleName: str | None
    staffLastName: str | None
    role: str

    def __init__(self) -> None:
        self.practiceOfficeId = None
        self.practiceOfficeName = None
        self.staffId = None
        self.staffTitle = None
        self.staffFirstName = None
        self.staffMiddleName = None
        self.staffLastName = None
        self.role = ""

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)

    @staticmethod
    def convert_from_db_model(db_hh_team_member: DBHouseholdTeamMember | None) -> "HouseholdStaffAccess | None":
        if db_hh_team_member is None:
            return None

        hh_staff_access = HouseholdStaffAccess()
        hh_staff_access.practiceOfficeId = db_hh_team_member.practice_office_id
        hh_staff_access.practiceOfficeName = (
            db_hh_team_member.practice_office.name if db_hh_team_member.practice_office is not None else None
        )
        hh_staff_access.staffId = db_hh_team_member.staff_id
        hh_staff_access.staffTitle = db_hh_team_member.staff.title if db_hh_team_member.staff is not None else None
        hh_staff_access.staffFirstName = (
            db_hh_team_member.staff.first_name if db_hh_team_member.staff is not None else None
        )
        hh_staff_access.staffMiddleName = (
            db_hh_team_member.staff.middle_name if db_hh_team_member.staff is not None else None
        )
        hh_staff_access.staffLastName = (
            db_hh_team_member.staff.last_name if db_hh_team_member.staff is not None else None
        )
        hh_staff_access.role = db_hh_team_member.role

        return hh_staff_access
