import datetime
from typing import Any

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Boolean, DateTime, text
from sqlalchemy.dialects.mysql import ENUM, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship


class HealthDetails(Base):
    __tablename__ = "HealthDetails"

    health_details_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("Client.client_id"), nullable=False, index=True)
    health_status: Mapped[str | None] = mapped_column(ENUM("E", "G", "F", "P"))
    medical_history_issues: Mapped[str | None] = mapped_column(String(5000))
    is_smoker: Mapped[bool | None] = mapped_column(Boolean)
    smoke_per_day: Mapped[int | None] = mapped_column(Integer)
    use_nicotine: Mapped[bool | None] = mapped_column(Boolean)
    nicotine_per_day: Mapped[int | None] = mapped_column(Integer)
    use_medication: Mapped[bool | None] = mapped_column(Boolean)
    medication_details: Mapped[str | None] = mapped_column(String(255))
    medical_condition: Mapped[bool | None] = mapped_column(Boolean)
    medical_condition_details: Mapped[str | None] = mapped_column(String(255))
    major_illness: Mapped[bool | None] = mapped_column(Boolean)
    major_illness_details: Mapped[str | None] = mapped_column(String(255))
    private_health: Mapped[bool | None] = mapped_column(Boolean)
    private_health_details: Mapped[str | None] = mapped_column(String(255))
    sports_interests_list: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    # length set to 50 because it was giving an error row too long for above one.
    sports_interests: Mapped[str | None] = mapped_column(String(50))
    sports_interests_frequency: Mapped[str | None] = mapped_column(ENUM("D", "W", "M", "B", "Q", "S", "A", "O"))
    notes: Mapped[str | None] = mapped_column(String(5000))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client: Mapped["Client"] = relationship("Client", back_populates="health_details", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
