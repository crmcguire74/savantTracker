import json

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils
from lumiant_api.abstraction_layer.common.utils.user_group_utils import UserGroupUtils


class LambdaAuthorisationMetadata(object):
    """
    -------------------------------------------------------------------------------------------------
    Lambda Authorisation Metadata
    Metadata that is collected and processed inside the Authorisation service which may be of use
    in other parts of the application.
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    username: str
    user_groups: list[str]
    practice_id: int
    region: str
    environment: str
    user_pool_id: str
    account_id: str
    sub: str

    def __init__(
        self,
        username: str,
        user_groups: list[str],
        practice_id: int,
        region: str,
        environment: str,
        user_pool_id: str,
        acc_id: str,
        sub: str,
    ) -> None:
        self.username = StringUtils.trim_to_empty(username)
        self.user_groups = user_groups
        self.practice_id = practice_id
        self.region = StringUtils.trim_to_empty(region)
        self.environment = StringUtils.trim_to_empty(environment)
        self.user_pool_id = StringUtils.trim_to_empty(user_pool_id)
        self.account_id = StringUtils.trim_to_empty(acc_id)
        self.sub = StringUtils.trim_to_empty(sub)

    # ---------------------------------------------------------------------------------------------
    # Empty
    # ---------------------------------------------------------------------------------------------
    @staticmethod
    def default() -> "LambdaAuthorisationMetadata":
        return LambdaAuthorisationMetadata(
            username="",
            user_groups=[],
            practice_id=-1,
            region="",
            environment="",
            user_pool_id="",
            acc_id="",
            sub="",
        )

    # ---------------------------------------------------------------------------------------------
    # SSO Handling
    # ---------------------------------------------------------------------------------------------
    @property
    def iam_id(self) -> str:
        if self.sub and self.sub != self.username:
            return self.sub
        else:
            # for backwards-compatibility (`sub` not populated)
            return self.username

    # ---------------------------------------------------------------------------------------------
    # Authorised / Unauthorised
    # ---------------------------------------------------------------------------------------------
    def is_authorised(self) -> bool:
        return len(self.username) > 0

    def is_unauthorised(self) -> bool:
        return not self.is_authorised()

    # ---------------------------------------------------------------------------------------------
    # Role
    # ---------------------------------------------------------------------------------------------
    def is_public(self) -> bool:
        return UserGroupUtils.is_public(self.user_groups)

    def is_client(self) -> bool:
        # It is possible (due to old data mostly) that an individual is both a client and staff.
        # This is discouraged and will be addressed as part of the changes to support shared email addresses
        # but in the mean time we're going to be explicit about the user not being a staff member.
        return UserGroupUtils.is_client(self.user_groups)

    def is_staff(self) -> bool:
        return UserGroupUtils.is_staff(self.user_groups)

    def is_practice_manager(self) -> bool:
        return UserGroupUtils.is_practice_manager(self.user_groups)

    def is_professional(self) -> bool:
        return UserGroupUtils.is_professional(self.user_groups)

    def is_paraplanner(self) -> bool:
        return UserGroupUtils.is_paraplanner(self.user_groups)

    def is_support(self) -> bool:
        return UserGroupUtils.is_support(self.user_groups)

    def is_lumiant_elevated_user(self) -> bool:
        return UserGroupUtils.is_lumiant_elevated_user(self.user_groups)

    def is_lumiant_reporting(self) -> bool:
        return UserGroupUtils.is_lumiant_reporting(self.user_groups)

    def is_lumiant_integration(self) -> bool:
        return UserGroupUtils.is_lumiant_integration(self.user_groups)

    def is_lumiant_admin(self) -> bool:
        return UserGroupUtils.is_lumiant_admin(self.user_groups)

    def is_lumiant_support(self) -> bool:
        return UserGroupUtils.is_lumiant_support(self.user_groups)

    def is_api_read_write_user(self) -> bool:
        return UserGroupUtils.is_api_read_write_user(self.user_groups)

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)
