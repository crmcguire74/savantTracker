import json
from dataclasses import dataclass

from aws_lambda_powertools import Logger
from boto3.session import Session as Boto3Session
from sqlalchemy.orm import Session

from lumiant_api.abstraction_layer.common.database.schema.client import Client as DBClient
from lumiant_api.abstraction_layer.common.models.address import Address
from lumiant_api.abstraction_layer.common.models.contact_details import ContactDetails
from lumiant_api.abstraction_layer.common.models.governance.module_state import ModuleState
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.utils.billing_utils import BillingUtils
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


@dataclass
class Client(object):
    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    clientId: int
    householdId: int
    iamId: str | None
    wealthIds: list[str] | None
    type: str
    title: str | None
    firstName: str
    middleName: str | None
    lastName: str
    preferredName: str | None
    dob: str | None
    lastLogin: str
    lastUserAgent: str
    registered: bool
    active: bool
    billableStart: str | None
    billableTrigger: str
    address: Address | None
    contactDetails: ContactDetails
    moduleStates: list[ModuleState]
    wellnessScore: float | None
    sex: str
    relationshipStatus: str
    countryCodeBirth: str
    countryCodeResidency: str
    countryCodeCitizenship: str
    notes: str

    # NOTE: These are optional and not always returned!
    goalCount: int | None
    taskCount: int | None

    externalId: str | None
    externalSystem: str | None
    externalId2: str | None
    externalSystem2: str | None

    createdBy: str
    created: str
    updatedBy: str
    updated: str

    def __init__(self) -> None:
        self.clientId = 0
        self.householdId = 0
        self.iamId = ""
        self.wealthIds = []
        self.type = ""
        self.title = ""
        self.firstName = ""
        self.middleName = ""
        self.lastName = ""
        self.preferredName = ""
        self.dob = ""
        self.lastLogin = ""
        self.lastUserAgent = ""
        self.registered = False
        self.active = True
        self.billableStart = ""
        self.billableTrigger = BillingUtils.TRIGGER_NA
        self.address = None
        self.contactDetails = ContactDetails()
        self.moduleStates = []
        self.wellnessScore = None
        self.sex = ""
        self.relationshipStatus = ""
        self.countryCodeBirth = ""
        self.countryCodeResidency = ""
        self.countryCodeCitizenship = ""
        self.notes = ""

        self.goalCount = None
        self.taskCount = None

        self.externalId = None
        self.externalSystem = None
        self.externalId2 = None
        self.externalSystem2 = None

        self.createdBy = ""
        self.created = ""
        self.updatedBy = ""
        self.updated = ""

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)

    @staticmethod
    def convert_from_db_model(
        db_client: DBClient | None,
        auth_metadata: LambdaAuthorisationMetadata,
        lumiant_rds_session: Session,
        boto3_session: Boto3Session,
        client_goal_count: int | None = None,
        client_task_count: int | None = None,
        include_module_states: bool = True,
    ) -> "Client | None":
        if db_client is None:
            return None

        client = Client()
        client.clientId = db_client.client_id
        client.householdId = db_client.household_id

        if auth_metadata.is_lumiant_elevated_user():
            client.iamId = str(db_client.iam_id)

        client.wealthIds = []
        if db_client.client_wealth_ids is not None:
            for client_wealth_id in db_client.client_wealth_ids:
                client.wealthIds.append(client_wealth_id.ilcn)  # type: ignore

        client.type = db_client.type
        client.title = StringUtils.trim_to_empty(db_client.title)
        client.firstName = db_client.first_name
        client.middleName = db_client.middle_name
        client.lastName = db_client.last_name
        client.preferredName = db_client.preferred_name
        client.dob = SerializationUtils.convert_value_to_string(db_client.dob)
        client.lastLogin = SerializationUtils.convert_value_to_string(db_client.last_login)
        client.lastUserAgent = db_client.last_user_agent  # type: ignore
        client.registered = False if db_client.iam_id is None else True
        client.active = db_client.is_active
        client.billableStart = SerializationUtils.convert_value_to_string(db_client.billable_start)
        client.billableTrigger = db_client.billable_trigger
        client.address = None if db_client.address is None else Address.convert_from_db_model(db_client.address)

        # Contact Details is mandatory
        contact_details = ContactDetails.convert_from_db_model(db_client.contact_details)
        client.contactDetails = contact_details if contact_details is not None else ContactDetails()

        if include_module_states:
            if db_client.module_state is not None:
                for client_module_state in db_client.module_state:
                    module_state = ModuleState.convert_from_db_model(client_module_state)
                    if module_state is not None:
                        client.moduleStates.append(module_state)

        client.wellnessScore = (
            float(db_client.wellness.wellness_score)
            if db_client.wellness is not None and db_client.wellness.wellness_score is not None
            else None
        )

        # TODO: Leandro - we need to put in a proper fix if this is an edge case that needs to be catered for
        #       We now have WellbeingScore events so it can be done off that if necessary but best to avoid it all
        #       in the first place.
        # if client.wellnessScore is not None \
        #         and db_client.wellness is not None \
        #         and db_client.wellness.components is not None \
        #         and len(db_client.wellness.components) == 1 \
        #         and ('G' in db_client.wellness.components
        #              or 'T' in db_client.wellness.components
        #              or 'K' in db_client.wellness.components):
        #     if WellnessScoreUtils.add_null_score_entry(
        #         components=db_client.wellness.components,
        #         household_id=db_client.household_id,
        #         lumiant_rds_session=lumiant_rds_session,
        #         auth_metadata=auth_metadata,
        #         boto3_session=boto3_session
        #     ):
        #         client.wellnessScore = None

        client.sex = db_client.sex  # type: ignore
        client.relationshipStatus = db_client.relationship_status  # type: ignore
        client.countryCodeBirth = db_client.country_code_birth  # type: ignore
        client.countryCodeResidency = db_client.country_code_residency  # type: ignore
        client.countryCodeCitizenship = db_client.country_code_citizenship  # type: ignore

        client.notes = db_client.notes  # type: ignore

        client.goalCount = None if client_goal_count is None else client_goal_count
        client.taskCount = None if client_task_count is None else client_task_count

        client.externalId = db_client.external_id
        client.externalSystem = db_client.external_system
        client.externalId2 = db_client.external_id_2
        client.externalSystem2 = db_client.external_system_2

        client.createdBy = db_client.created_by
        client.created = SerializationUtils.convert_value_to_string(db_client.created)
        client.updatedBy = db_client.updated_by
        client.updated = SerializationUtils.convert_value_to_string(db_client.updated)

        return client
