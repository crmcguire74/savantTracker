import json
from dataclasses import dataclass

from aws_lambda_powertools import Logger

from lumiant_api.abstraction_layer.common.database.schema.address import Address as DBAddress
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils


@dataclass
class Address(object):
    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    addressId: int
    addressLine1: str
    addressLine2: str
    suburb: str
    postCode: str
    state: str
    country: str
    createdBy: str
    created: str
    updatedBy: str
    updated: str

    def __init__(self) -> None:
        self.addressId = 0
        self.addressLine1 = ""
        self.addressLine2 = ""
        self.suburb = ""
        self.postCode = ""
        self.state = ""
        self.country = ""
        self.createdBy = ""
        self.created = ""
        self.updatedBy = ""
        self.updated = ""

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)

    @staticmethod
    def convert_from_db_model(db_address: DBAddress | None) -> "Address | None":
        if db_address is None:
            return None

        address = Address()
        address.addressId = db_address.address_id
        address.addressLine1 = db_address.address_line_1
        address.addressLine2 = db_address.address_line_2  # type: ignore
        address.suburb = db_address.suburb
        address.postCode = db_address.post_code
        address.state = db_address.state
        address.country = db_address.country
        address.createdBy = db_address.created_by
        address.created = SerializationUtils.convert_value_to_string(db_address.created)
        address.updatedBy = db_address.updated_by
        address.updated = SerializationUtils.convert_value_to_string(db_address.updated)

        return address
