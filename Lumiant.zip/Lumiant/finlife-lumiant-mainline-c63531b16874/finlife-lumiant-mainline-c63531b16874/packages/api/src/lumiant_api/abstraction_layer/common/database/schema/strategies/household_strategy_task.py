import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from lumiant_api.abstraction_layer.common.database.schema.base import Base


class HouseholdStrategyTask(Base):
    __tablename__ = "HouseholdStrategyTask"

    household_strategy_task_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_strategy_id: Mapped[int] = mapped_column(
        ForeignKey("HouseholdStrategy.household_strategy_id"), nullable=False, index=True
    )
    task_id: Mapped[int] = mapped_column(ForeignKey("Task.task_id"), nullable=False, index=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationship
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household_strategy: Mapped["HouseholdStrategy"] = relationship(
        "HouseholdStrategy", back_populates="household_strategy_tasks", lazy="select"
    )
    task: Mapped["Task"] = relationship("Task", back_populates="household_strategy_tasks", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy import HouseholdStrategy
from lumiant_api.abstraction_layer.common.database.schema.tasks.task import Task
