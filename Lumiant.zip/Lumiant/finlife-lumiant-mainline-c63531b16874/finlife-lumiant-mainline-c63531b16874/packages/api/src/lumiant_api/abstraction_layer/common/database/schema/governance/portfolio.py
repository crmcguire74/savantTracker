import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Numeric, Boolean, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Portfolio(Base):
    __tablename__ = "Portfolio"

    portfolio_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    client_id: Mapped[int | None] = mapped_column(ForeignKey("Client.client_id"), index=True)
    legal_entity_id: Mapped[int | None] = mapped_column(ForeignKey("LegalEntity.legal_entity_id"), index=True)
    name: Mapped[str | None] = mapped_column(String(255))
    type: Mapped[str | None] = mapped_column(ENUM("I", "S"))  # I = Investments, S = Superannuation
    account_number: Mapped[str | None] = mapped_column(String(50))
    risk_score: Mapped[float | None] = mapped_column(Numeric(15, 2), nullable=True)
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    external_load_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="portfolios", lazy="select")
    client: Mapped["Client"] = relationship("Client", back_populates="portfolios", lazy="select")
    legal_entity: Mapped["LegalEntity"] = relationship("LegalEntity", back_populates="portfolios", lazy="select")

    holdings: Mapped[list["Holding"]] = relationship("Holding", back_populates="portfolio", lazy="select")
    portfolio_performance: Mapped[list["PortfolioPerformance"]] = relationship(
        "PortfolioPerformance", back_populates="portfolio", lazy="select"
    )
    riskalyze_portfolio_mapping: Mapped[list["RiskalyzePortfolioMapping"]] = relationship(
        "RiskalyzePortfolioMapping", back_populates="portfolio", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.holding import Holding  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.legal_entity import LegalEntity  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.portfolio_performance import PortfolioPerformance  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.riskalyze.riskalyze_portfolio_mapping import (
    RiskalyzePortfolioMapping,
)  # pylint: disable=C0413,R0401
