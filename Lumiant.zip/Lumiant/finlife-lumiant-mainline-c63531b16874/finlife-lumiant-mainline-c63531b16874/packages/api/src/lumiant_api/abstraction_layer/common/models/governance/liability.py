import json
from dataclasses import dataclass

from aws_lambda_powertools import Logger

from lumiant_api.abstraction_layer.common.database.schema.governance.liability import Liability as DBLiability
from lumiant_api.abstraction_layer.common.models.governance.yodlee_mapping import YodleeMapping
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


@dataclass
class Liability(object):
    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    liabilityId: int
    householdId: int
    clientId: int | None
    clientFirstName: str | None
    clientLastName: str | None
    clientPreferredName: str | None
    clientIdPA: int | None
    clientIdPADate: str | None
    clientIdApprovalStatus: str | None
    legalEntityId: int | None
    legalEntityName: str | None
    legalEntityIdPA: int | None
    legalEntityIdPADate: str | None
    legalEntityIdApprovalStatus: str | None
    assetId: int | None
    liabilityType: str
    loanType: str | None
    description: str | None
    accountNumber: str | None
    providerName: str | None
    lender: str | None
    maxLimit: float | None
    originalAmount: float | None
    owing: float | None
    owingPA: float | None
    owingPADate: str | None
    owingApprovalStatus: str | None
    rate: float | None
    ratePA: float | None
    ratePADate: str | None
    rateApprovalStatus: str | None
    interestRateType: str | None
    repayment: float | None
    repaymentPA: float | None
    repaymentPADate: str | None
    repaymentApprovalStatus: str | None
    repaymentFrequency: str | None
    repaymentFrequencyPA: str | None
    repaymentFrequencyPADate: str | None
    repaymentFrequencyApprovalStatus: str | None
    monthlyPayment: float | None
    notes: str | None
    clientNotes: str | None
    partnerNotes: str | None
    confidentialNotes: str | None
    displayName: str | None
    externalId: str
    externalSystem: str
    liabilityYodleeMapping: YodleeMapping | None
    createdBy: str
    created: str
    updatedBy: str
    updated: str

    def __init__(self) -> None:
        self.liabilityId = 0
        self.householdId = 0
        self.clientId = None
        self.clientFirstName = None
        self.clientLastName = None
        self.clientPreferredName = None
        self.clientIdPA = None
        self.clientIdPADate = None
        self.clientIdApprovalStatus = None
        self.legalEntityId = None
        self.legalEntityName = None
        self.legalEntityIdPA = None
        self.legalEntityIdPADate = None
        self.legalEntityIdApprovalStatus = None
        self.assetId = None
        self.liabilityType = ""
        self.loanType = None
        self.description = None
        self.accountNumber = None
        self.providerName = None
        self.lender = None
        self.maxLimit = None
        self.originalAmount = None
        self.owing = None
        self.owingPA = None
        self.owingPADate = None
        self.owingApprovalStatus = None
        self.rate = None
        self.ratePA = None
        self.ratePADate = None
        self.rateApprovalStatus = None
        self.interestRateType = None
        self.repayment = None
        self.repaymentPA = None
        self.repaymentPADate = None
        self.repaymentApprovalStatus = None
        self.repaymentFrequency = None
        self.repaymentFrequencyPA = None
        self.repaymentFrequencyPADate = None
        self.repaymentFrequencyApprovalStatus = None
        self.monthlyPayment = None
        self.notes = None
        self.clientNotes = None
        self.partnerNotes = None
        self.confidentialNotes = None
        self.displayName = None
        self.externalId = ""
        self.externalSystem = ""
        self.liabilityYodleeMapping = None
        self.createdBy = ""
        self.created = ""
        self.updatedBy = ""
        self.updated = ""

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)

    @staticmethod
    def convert_from_db_model(
        db_liability: DBLiability | None, auth_metadata: LambdaAuthorisationMetadata
    ) -> "Liability | None":
        if db_liability is None:
            return None

        liability = Liability()
        liability.liabilityId = db_liability.liability_id
        liability.householdId = db_liability.household_id
        liability.clientId = db_liability.client_id
        if liability.clientId is not None:
            liability.clientFirstName = db_liability.client.first_name
            liability.clientLastName = db_liability.client.last_name
            liability.clientPreferredName = db_liability.client.preferred_name
        liability.clientIdPA = db_liability.client_id_pa
        liability.clientIdPADate = SerializationUtils.convert_value_to_string(db_liability.client_id_pa_date)
        liability.clientIdApprovalStatus = db_liability.client_id_approval_status
        liability.legalEntityId = db_liability.legal_entity_id
        if liability.legalEntityId is not None:
            liability.legalEntityName = db_liability.legal_entity.name
        liability.legalEntityIdPA = db_liability.legal_entity_id_pa
        liability.legalEntityIdPADate = SerializationUtils.convert_value_to_string(db_liability.legal_entity_id_pa_date)
        liability.legalEntityIdApprovalStatus = db_liability.legal_entity_id_approval_status
        liability.assetId = db_liability.asset_id
        liability.liabilityType = StringUtils.trim_to_empty(db_liability.liability_type)
        liability.loanType = StringUtils.trim_to_empty(db_liability.loan_type)
        liability.description = db_liability.description
        liability.accountNumber = db_liability.account_number
        liability.providerName = db_liability.provider_name
        liability.lender = db_liability.lender
        liability.maxLimit = db_liability.max_limit
        liability.originalAmount = db_liability.original_amount
        liability.owing = db_liability.owing
        liability.owingPA = db_liability.owing_pa
        liability.owingPADate = SerializationUtils.convert_value_to_string(db_liability.owing_pa_date)
        liability.owingApprovalStatus = db_liability.owing_approval_status
        liability.rate = db_liability.rate
        liability.ratePA = db_liability.rate_pa
        liability.ratePADate = SerializationUtils.convert_value_to_string(db_liability.rate_pa_date)
        liability.rateApprovalStatus = db_liability.rate_approval_status
        liability.interestRateType = db_liability.interest_rate_type
        liability.repayment = db_liability.repayment
        liability.repaymentPA = db_liability.repayment_pa
        liability.repaymentPADate = SerializationUtils.convert_value_to_string(db_liability.repayment_pa_date)
        liability.repaymentApprovalStatus = db_liability.repayment_approval_status
        liability.repaymentFrequency = db_liability.repayment_frequency
        liability.repaymentFrequencyPA = db_liability.repayment_frequency_pa
        liability.repaymentFrequencyPADate = SerializationUtils.convert_value_to_string(
            db_liability.repayment_frequency_approval_status
        )
        liability.repaymentFrequencyApprovalStatus = db_liability.repayment_frequency_approval_status

        if db_liability.repayment_frequency == "M":
            liability.monthlyPayment = db_liability.repayment

        liability.notes = db_liability.notes
        liability.clientNotes = db_liability.client_notes
        liability.partnerNotes = db_liability.partner_notes
        liability.confidentialNotes = (
            db_liability.confidential_notes
            if auth_metadata.is_staff() or auth_metadata.is_lumiant_elevated_user()
            else ""
        )
        liability.displayName = db_liability.display_name
        liability.externalId = db_liability.external_id  # type: ignore
        liability.externalSystem = db_liability.external_system  # type: ignore

        liability.liabilityYodleeMapping = (
            YodleeMapping.convert_from_db_model(db_liability.liability_yodlee_mapping)
            if db_liability.liability_yodlee_mapping is not None
            else None
        )

        liability.createdBy = db_liability.created_by
        liability.created = SerializationUtils.convert_value_to_string(db_liability.created)
        liability.updatedBy = db_liability.updated_by
        liability.updated = SerializationUtils.convert_value_to_string(db_liability.updated)

        return liability
