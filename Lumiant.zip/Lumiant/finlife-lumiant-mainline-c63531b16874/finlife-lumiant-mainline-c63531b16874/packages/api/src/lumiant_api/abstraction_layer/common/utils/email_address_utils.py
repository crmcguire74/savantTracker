from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.constants import aws_region, emails, external_domains
from lumiant_api.abstraction_layer.common.database.schema.staff import Staff as DBStaff
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice as DBPractice
from lumiant_api.abstraction_layer.common.utils.environment_utils import EnvironmentUtils
from lumiant_api.abstraction_layer.practice.utils.practice_config_utils import PracticeConfigUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class EmailAddressUtils(object):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Email Address
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    def __init__(self) -> None:
        pass

    @staticmethod
    def get_email_domain_for_practice(practice: DBPractice | None, region: str | None = None) -> str:
        """
        :param practice: Typically should be lumiant_rds_session.query(DBPractice)...
        :param region: Typically should be auth_metadata.region
        :return: email domain to use
        """

        # This is different to DomainUtils as we don't have a 1:1 email address to domain mapping
        # Technically we could simplify this by emailing everything from lumiant.io
        if practice is not None:
            practice_home_region = StringUtils.trim_to_empty(practice.home_region)

            if len(practice_home_region) > 0:
                return (
                    external_domains.INTERNATIONAL
                    if practice_home_region != aws_region.AP_SOUTHEAST_2
                    else external_domains.LUMIANT
                )

        # Determine the region if not provided
        if region is None:
            region = EnvironmentUtils.get_region()

        region = StringUtils.trim_to_empty(region)

        if len(region) > 0:
            return external_domains.INTERNATIONAL if region != aws_region.AP_SOUTHEAST_2 else external_domains.LUMIANT
        else:
            return external_domains.LUMIANT

    @staticmethod
    def get_email_sender_name_and_reply_to_for_practice(
        practice: DBPractice | None = None,
        region: str | None = None,
        staff: DBStaff | None = None,
        staff_first_name: str | None = None,
        staff_last_name: str | None = None,
        reply_to: str | None = None,
    ) -> tuple[str, str, str | None]:
        """
        This should be three separate methods but they're always used together...

        :param practice: Typically should be lumiant_rds_session.query(DBPractice)...
        :param region: Typically should be auth_metadata.region
        :param staff: Typically should be lumiant_rds_session.query(DBStaff)...
        :param staff_first_name: Only used if staff is None
        :param staff_last_name: Only used if staff is None
        :param reply_to: Only needs to be provided if it differs from staff.contact_details.email_address
        :return: sender email address, sender name and reply to email address to use
        """

        sender = ""
        sender_name = ""
        final_reply_to = None

        if practice is not None:
            practice_config_utils = PracticeConfigUtils(practice.practice_config)
            sender = StringUtils.trim_to_empty(practice_config_utils.get_notification_email_sender())
            sender_name = StringUtils.trim_to_empty(practice_config_utils.get_notification_email_sender_name())
            final_reply_to = sender

        if len(sender) == 0:
            domain = EmailAddressUtils.get_email_domain_for_practice(practice=practice, region=region)
            sender = "{0}@{1}".format(emails.NO_REPLY_EMAIL_SENDER, domain)

            if staff is not None:
                staff_first_name = StringUtils.trim_to_empty(staff.first_name)
                staff_last_name = StringUtils.trim_to_empty(staff.last_name)

                if (
                    staff.contact_details is not None
                    and len(StringUtils.trim_to_empty(staff.contact_details.email_address)) > 0
                ):
                    final_reply_to = staff.contact_details.email_address
                else:
                    final_reply_to = reply_to
            else:
                final_reply_to = reply_to

            sender_name = "{} {}".format(
                StringUtils.trim_to_empty(staff_first_name), StringUtils.trim_to_empty(staff_last_name)
            )

        return sender, sender_name, final_reply_to
