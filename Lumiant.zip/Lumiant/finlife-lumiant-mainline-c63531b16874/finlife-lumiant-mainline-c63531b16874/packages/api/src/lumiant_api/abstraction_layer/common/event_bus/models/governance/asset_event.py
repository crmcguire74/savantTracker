from lumiant_api.abstraction_layer.common.event_bus.models.lumiant_event import LumiantEvent
from pydantic import Field


class AssetEvent(LumiantEvent):
    """
    -------------------------------------------------------------------------------------------------
    MODEL: Asset Event
    -------------------------------------------------------------------------------------------------
    """

    type: str = Field(
        alias="type",
        description="The type of event that has occurred",
        json_schema_extra={"is_attribute": True},
        default="Asset",
    )

    lumiant_object: str = Field(
        alias="lumiantObject",
        description="The lumiant object (if any) that this event pertains to",
        json_schema_extra={"is_attribute": True},
        default="Asset",
    )

    lumiant_object_id_column: str = Field(
        alias="lumiantObjectIdColumn",
        description="The ID column name of the lumiant object that this event pertains to",
        json_schema_extra={"is_attribute": True},
        default="asset_id",
    )

    household_id: int | None = Field(
        alias="householdId",
        description="The ID of the household to which this Asset belongs",
        json_schema_extra={"is_attribute": True},
        default=None,
    )

    client_id: int | None = Field(
        alias="clientId",
        description="The ID of the client to which this Asset belongs, if any, as a null means it is for both",
        json_schema_extra={"is_attribute": True},
        default=None,
    )
