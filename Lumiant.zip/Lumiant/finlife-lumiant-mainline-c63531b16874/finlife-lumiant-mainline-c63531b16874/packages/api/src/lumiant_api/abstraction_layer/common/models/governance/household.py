import json
from dataclasses import dataclass
from typing import TYPE_CHECKING

from boto3.session import Session as Boto3Session

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.database.schema.client import Client as DBClient
from lumiant_api.abstraction_layer.common.database.schema.household import Household as DBHousehold
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.common.models import country

if TYPE_CHECKING:
    from lumiant_api.abstraction_layer.common.database.schema.practice import Practice as DBPractice
from lumiant_api.abstraction_layer.common.models.governance.client import Client
from lumiant_api.abstraction_layer.common.models.governance.household_staff_access import HouseholdStaffAccess
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from sqlalchemy.orm import Session


@dataclass
class Household(object):
    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    householdId: int
    name: str
    isTest: bool
    householdPackageCode: str | None
    practiceSegmentationId: int | None
    practiceSegmentationName: str | None
    countryCode: str | None
    createdBy: str
    created: str
    updatedBy: str
    updated: str

    # NOTE: These are optional as they're outside the Household table
    clients: list[Client] | None  # Only used by listHouseholds
    wellnessScore: float | None  # This is ok to include all the time
    # TODO: Remove this - it should be an entirely separate API!
    householdStaffAccess: list[HouseholdStaffAccess] | None  # This could be retrieved as needed

    def __init__(self) -> None:
        self.householdId = 0
        self.name = ""
        self.clients = None
        self.isTest = False
        self.householdPackageCode = None
        self.practiceSegmentationId = None
        self.practiceSegmentationName = None
        self.countryCode = country.AU.country_code
        self.wellnessScore = None
        self.householdStaffAccess = None
        self.createdBy = ""
        self.created = ""
        self.updatedBy = ""
        self.updated = ""

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)

    @staticmethod
    def convert_from_db_model(
        db_household: DBHousehold | None,
        auth_metadata: LambdaAuthorisationMetadata,
        lumiant_rds_session: Session,
        boto3_session: Boto3Session,
        uses_household_packages: bool | None = None,
        include_clients: bool = True,
        include_staff_access: bool = True,
    ) -> "Household | None":
        if db_household is None:
            return None

        household = Household._convert_from_db_model(
            db_household=db_household,
            uses_household_packages=uses_household_packages,
            lumiant_rds_session=lumiant_rds_session,
            boto3_session=boto3_session,
            auth_metadata=auth_metadata,
        )

        if household is None:
            return None

        if include_clients:
            if db_household.clients is not None:
                household.clients = []
                for db_client in db_household.clients:
                    if not db_client.deleted:
                        client = Client.convert_from_db_model(
                            db_client=db_client,
                            auth_metadata=auth_metadata,
                            lumiant_rds_session=lumiant_rds_session,
                            boto3_session=boto3_session,
                        )

                        if client is not None:
                            household.clients.append(client)

        if include_staff_access:
            if db_household.household_team_members is not None:
                household.householdStaffAccess = []
                for hh_team_member in db_household.household_team_members:
                    hh_staff_access = HouseholdStaffAccess.convert_from_db_model(db_hh_team_member=hh_team_member)
                    if hh_staff_access is not None:
                        household.householdStaffAccess.append(hh_staff_access)

        return household

    @staticmethod
    def convert_from_db_model_with_clients(
        db_household: DBHousehold | None,
        auth_metadata: LambdaAuthorisationMetadata,
        lumiant_rds_session: Session,
        boto3_session: Boto3Session,
        uses_household_packages: bool | None,
        db_client: DBClient | None,
        client_goal_count: int | None,
        client_task_count: int | None,
        db_partner: DBClient | None,
        partner_goal_count: int | None,
        partner_task_count: int | None,
        household_goal_count: int | None,
    ) -> "Household | None":
        if db_household is None:
            return None

        household = Household._convert_from_db_model(
            db_household=db_household,
            uses_household_packages=uses_household_packages,
            lumiant_rds_session=lumiant_rds_session,
            boto3_session=boto3_session,
            auth_metadata=auth_metadata,
        )

        if household is None:
            return None

        client: Client | None = None
        partner: Client | None = None

        if db_client is not None:
            client = Client.convert_from_db_model(
                db_client=db_client,
                auth_metadata=auth_metadata,
                client_goal_count=client_goal_count,
                client_task_count=client_task_count,
                lumiant_rds_session=lumiant_rds_session,
                boto3_session=boto3_session,
            )

            if client is not None:
                if household_goal_count is not None:
                    if client.goalCount is None:
                        client.goalCount = household_goal_count
                    else:
                        client.goalCount += household_goal_count

        if db_partner is not None:
            partner = Client.convert_from_db_model(
                db_client=db_partner,
                auth_metadata=auth_metadata,
                lumiant_rds_session=lumiant_rds_session,
                boto3_session=boto3_session,
                client_goal_count=partner_goal_count,
                client_task_count=partner_task_count,
            )

            if partner is not None:
                if household_goal_count is not None:
                    if partner.goalCount is None:
                        partner.goalCount = household_goal_count
                    else:
                        partner.goalCount += household_goal_count

        if client is not None or partner is not None:
            household.clients = []

            if client is not None:
                household.clients.append(client)

            if partner is not None:
                household.clients.append(partner)

        # if db_household.household_team_members is not None:
        #     household.householdStaffAccess = []
        #     for hh_team_member in db_household.household_team_members:
        #         hh_staff_access = HouseholdStaffAccess.convert_from_db_model(db_hh_team_member=hh_team_member)
        #         if hh_staff_access is not None:
        #             household.householdStaffAccess.append(hh_staff_access)

        return household

    @staticmethod
    def _convert_from_db_model(
        db_household: DBHousehold | None,
        uses_household_packages: bool | None,
        lumiant_rds_session: Session,
        boto3_session: Boto3Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> "Household | None":
        if db_household is None:
            return None

        # Check what package the practice is on to know what household package to use
        if uses_household_packages is None and db_household.household_team_members is not None:
            practice: DBPractice
            if isinstance(db_household.household_team_members, DBHouseholdTeamMember):
                practice = db_household.household_team_members.practice
            else:
                practice = db_household.household_team_members[0].practice

            if practice is not None:
                practice_package = practice.practice_package

                if practice_package is not None:
                    uses_household_packages = practice_package.uses_household_packages

        household = Household()
        household.householdId = db_household.household_id
        household.name = db_household.name
        household.isTest = db_household.is_test

        if uses_household_packages is not None and not uses_household_packages:
            household.householdPackageCode = None
        else:
            household.householdPackageCode = (
                db_household.household_package.code if db_household.household_package is not None else None
            )

        household.practiceSegmentationId = db_household.practice_segmentation_id
        household.practiceSegmentationName = (
            db_household.practice_segmentation.segment_name if db_household.practice_segmentation is not None else None
        )

        household.countryCode = (
            db_household.country_code if db_household.country_code is not None else country.AU.country_code
        )

        household.wellnessScore = (
            float(db_household.wellness.wellness_score)
            if db_household.wellness is not None and db_household.wellness.wellness_score is not None
            else None
        )

        # TODO: Leandro - we need to put in a proper fix if this is an edge case that needs to be catered for
        #       We now have WellbeingScore events so it can be done off that if necessary but best to avoid it all
        #       in the first place.
        # if household.wellnessScore is not None \
        #         and db_household.wellness is not None \
        #         and db_household.wellness.components is not None \
        #         and len(db_household.wellness.components) == 1 \
        #         and ('G' in db_household.wellness.components
        #              or 'T' in db_household.wellness.components
        #              or 'K' in db_household.wellness.components):
        #     if WellnessScoreUtils.add_null_score_entry(
        #         components=db_household.wellness.components,
        #         household_id=db_household.household_id,
        #         lumiant_rds_session=lumiant_rds_session,
        #         auth_metadata=auth_metadata,
        #         boto3_session=boto3_session
        #     ):
        #         household.wellnessScore = None

        household.createdBy = db_household.created_by
        household.created = SerializationUtils.convert_value_to_string(db_household.created)
        household.updatedBy = db_household.updated_by
        household.updated = SerializationUtils.convert_value_to_string(db_household.updated)

        return household
