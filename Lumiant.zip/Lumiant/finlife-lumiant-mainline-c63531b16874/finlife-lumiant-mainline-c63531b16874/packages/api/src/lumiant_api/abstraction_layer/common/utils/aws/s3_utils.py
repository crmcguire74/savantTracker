import os

import botocore.client
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from botocore.exceptions import ClientError

from lumiant_api.abstraction_layer.common.constants import aws_region, environments
from lumiant_api.abstraction_layer.common.types.singleton import Singleton
from lumiant_api.abstraction_layer.common.utils.region_utils import RegionUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils

LUMIANT_DATA_S3_PREFIX = "lumiant-data"


class S3Utils(object, metaclass=Singleton):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: S3 - Handy methods for interacting with the AWS Simple Storage Service
    -------------------------------------------------------------------------------------------------
    """

    logger = Logger(child=True, service="SharedLayer")
    tracer = Tracer(service="SharedLayer")

    S3_SERVICE_NAME = "s3"

    boto3_session: Boto3Session
    default_region: str
    client: botocore.client  # type: ignore

    def __init__(self, boto3_session: Boto3Session, default_region: str | None = None) -> None:
        self.boto3_session = boto3_session

        def_region = StringUtils.trim_to_empty(default_region)
        if len(def_region) == 0:
            def_region = RegionUtils.get_current_region()

        self.default_region = def_region
        self.client = self.boto3_session.client(  # type: ignore
            service_name=S3Utils.S3_SERVICE_NAME, region_name=default_region
        )

    @tracer.capture_method(capture_response=False)  # type: ignore
    def get_client(self, region: str | None = None) -> botocore.client:  # type: ignore
        if region is not None and region != self.default_region:
            return self.boto3_session.client(service_name=S3Utils.S3_SERVICE_NAME, region_name=region)  # type: ignore
        else:
            return self.client

    @tracer.capture_method(capture_response=False)  # type: ignore
    def get_lumiant_data_full_bucket_name(self, environment: str, region: str) -> str:
        if environment == environments.ENVIRONMENT_PROD:
            return "{0}{1}-{2}".format(
                LUMIANT_DATA_S3_PREFIX,
                "234717" if region == aws_region.US_EAST_1 else "111925",
                environment,
            )
        elif environment == environments.ENVIRONMENT_PROD_US:
            return "{0}{1}-{2}".format(
                LUMIANT_DATA_S3_PREFIX,
                "234717" if region == aws_region.US_EAST_1 else "111925",
                environment,
            )
        elif environment == environments.ENVIRONMENT_STAGING:
            return "{0}{1}-{2}".format(
                LUMIANT_DATA_S3_PREFIX,
                "224059" if region == aws_region.US_EAST_1 else "223502",
                environment,
            )
        elif environment == environments.ENVIRONMENT_STAGING_US:
            return "{0}{1}-{2}".format(
                LUMIANT_DATA_S3_PREFIX,
                "224059" if region == aws_region.US_EAST_1 else "223502",
                environment,
            )
        elif environment == environments.ENVIRONMENT_QA:
            return "{0}{1}-{2}".format(
                LUMIANT_DATA_S3_PREFIX,
                "231923" if region == aws_region.US_EAST_1 else "235323",
                environment,
            )
        elif environment == environments.ENVIRONMENT_QA_US:
            return "{0}{1}-{2}".format(
                LUMIANT_DATA_S3_PREFIX,
                "231923" if region == aws_region.US_EAST_1 else "235323",
                environment,
            )
        else:
            return "{0}225323-dev".format(LUMIANT_DATA_S3_PREFIX)

    def download_s3_object_to_local_filesystem(
        self, bucket_name: str, path_and_filename: str, local_path_and_filename: str, region: str | None = None
    ) -> bool:
        try:
            if region is not None and region != self.default_region:
                client = self.get_client(region=region)
            else:
                client = self.client

            if not os.path.exists(os.path.dirname(local_path_and_filename)):
                os.makedirs(os.path.dirname(local_path_and_filename))

            with open(local_path_and_filename, "wb") as target_file:
                client.download_fileobj(bucket_name, path_and_filename, target_file)  # type: ignore

            return True
        except ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchKey":  # type: ignore
                print("Could not retrieve file [{0}] from S3 bucket [{1}]".format(path_and_filename, bucket_name))
            else:
                self.logger.error(
                    "Could not retrieve file [{0}] from S3 bucket [{1}]".format(path_and_filename, bucket_name),
                    exc_info=True,
                )

            return False
        except Exception:
            self.logger.error(
                "Could not retrieve file [{0}] from S3 bucket [{1}].".format(path_and_filename, bucket_name),
                exc_info=True,
            )
            return False
