import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, Boolean, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class PracticeIntegration(Base):
    __tablename__ = "PracticeIntegration"

    practice_integration_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    practice_id: Mapped[int] = mapped_column(ForeignKey("Practice.practice_id"), nullable=False, index=True)
    integration_type: Mapped[str] = mapped_column(
        ENUM("IL", "CD", "MG", "RT", "RA", "SF", "TM", "BX", "XP", "PR"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    secrets_manager_secret_name: Mapped[str | None] = mapped_column(String(512))
    last_synced: Mapped[datetime.datetime | None] = mapped_column(DateTime, nullable=True)
    description: Mapped[str | None] = mapped_column(String(15000))
    integration_details: Mapped[str | None] = mapped_column(String)  # Save integration details as JSON
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    practice: Mapped["Practice"] = relationship("Practice", back_populates="practice_integrations", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice  # pylint: disable=C0413,R0401
