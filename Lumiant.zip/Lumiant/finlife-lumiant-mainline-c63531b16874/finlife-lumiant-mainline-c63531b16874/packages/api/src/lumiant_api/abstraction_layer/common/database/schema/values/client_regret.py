import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class ClientRegret(Base):
    __tablename__ = "ClientRegret"

    client_regret_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_values_id: Mapped[int] = mapped_column(
        ForeignKey("ClientValues.client_values_id"), nullable=False, index=True
    )
    regret: Mapped[str | None] = mapped_column(String(5000))
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client_values: Mapped["ClientValues"] = relationship("ClientValues", back_populates="regrets", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.values.client_values import ClientValues  # pylint: disable=C0413,R0401
