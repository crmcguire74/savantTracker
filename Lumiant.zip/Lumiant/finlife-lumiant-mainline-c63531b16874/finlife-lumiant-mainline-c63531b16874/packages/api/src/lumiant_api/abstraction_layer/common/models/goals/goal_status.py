import json
from typing import Any

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils


class GoalStatus(object):
    """
    -------------------------------------------------------------------------------------------------
    Goal Status
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    goal_status_id: int
    goal_status: str

    def __init__(self, goal_status_id: int, goal_status: str) -> None:
        self.goal_status_id = goal_status_id
        self.goal_status = goal_status

    def convert_from_model(self) -> dict[str, Any]:
        return {"goalStatusId": self.goal_status_id, "goalStatus": self.goal_status}

    @staticmethod
    def get_from_id(goal_status_id: int) -> "GoalStatus | None":
        return GOAL_STATUS_BY_ID.get(goal_status_id, None)

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)


TODO = GoalStatus(1, "To Do")
DOING = GoalStatus(2, "Doing")
DONE = GoalStatus(3, "Done")
DELETED = GoalStatus(100, "Deleted")

GOAL_STATUS_BY_ID: dict[int, Any] = {
    TODO.goal_status_id: TODO,
    DOING.goal_status_id: DOING,
    DONE.goal_status_id: DONE,
    DELETED.goal_status_id: DELETED,
}

GOAL_STATUS_EX_DELETED_BY_ID: dict[int, Any] = {
    TODO.goal_status_id: TODO,
    DOING.goal_status_id: DOING,
    DONE.goal_status_id: DONE,
}
