import datetime

from dateutil import parser
from dateutil.relativedelta import relativedelta

import pytz
from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.constants import aws_region
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class DateUtils(object):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Date
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    def __init__(self) -> None:
        pass

    @staticmethod
    def get_timezone_in_region(region: str = aws_region.AP_SOUTHEAST_2) -> datetime.tzinfo:
        # We ONLY need to support the regions into which we deploy the platform. At this stage that is limited to:
        # ap-southeast-2 (default)
        # us-east-1
        if StringUtils.trim_to_empty(region).lower() == aws_region.US_EAST_1:
            return pytz.timezone("US/Eastern")
        else:
            return pytz.timezone("Australia/Sydney")

    @staticmethod
    def get_current_date_in_region_tz(region: str = aws_region.AP_SOUTHEAST_2) -> datetime.date:
        utc_time = datetime.datetime.now(datetime.UTC)
        tz = DateUtils.get_timezone_in_region(region=region)
        localized_date = utc_time.astimezone(tz).date()
        return localized_date

    @staticmethod
    def get_current_datetime_in_region_tz(region: str = aws_region.AP_SOUTHEAST_2) -> datetime.datetime:
        utc_time = datetime.datetime.now(datetime.UTC)
        tz = DateUtils.get_timezone_in_region(region=region)
        localized_datetime = utc_time.astimezone(tz)
        return localized_datetime

    @staticmethod
    def convert_datetime_to_region_tz(
        date_time: datetime.datetime, region: str = aws_region.AP_SOUTHEAST_2
    ) -> datetime.datetime:
        # We ONLY need to support the regions into which we deploy the platform. At this stage that is limited to:
        # ap-southeast-2 (default)
        # us-east-1
        if date_time.tzinfo is None:
            date_time = pytz.utc.localize(date_time)

        return date_time.astimezone(DateUtils.get_timezone_in_region(region=region))

    @staticmethod
    def validate_date_of_birth(dob: datetime.date | None) -> datetime.date | None:
        if dob is None:
            return None

        current_date = datetime.date.today()

        # Try and handle dates < 100, i.e. 2 digit years
        if dob.year < 100:
            return DateUtils._validate_date_of_birth_using_2_digit_year(date=dob, current_date=current_date)

        # Try and handle dates < 1000, i.e. 3 digit years (these should be incredibly rare as it means that they're
        # either completely wrong or had the millenium removed!
        if dob.year < 1000:
            return DateUtils._validate_date_of_birth_using_3_digit_year(date=dob, current_date=current_date)

        # Additional check to ensure that the fixed date > 1900-1-1 and < today
        # - ignore the century and just rely on the 2 digit year
        if dob < datetime.date(1900, 1, 1) or dob > current_date:
            return DateUtils._validate_date_of_birth_using_2_digit_year(date=dob, current_date=current_date)
        else:
            return dob

    @staticmethod
    def _validate_date_of_birth_using_2_digit_year(date: datetime.date, current_date: datetime.date) -> datetime.date:
        current_decade = int(current_date.year / 100)
        dob_2_digit_year = date.year % 100

        fixed_date = datetime.date(current_decade * 100 + dob_2_digit_year, date.month, date.day)
        if fixed_date > current_date:
            fixed_date = datetime.date((current_decade - 1) * 100 + dob_2_digit_year, date.month, date.day)

        return fixed_date

    @staticmethod
    def _validate_date_of_birth_using_3_digit_year(date: datetime.date, current_date: datetime.date) -> datetime.date:
        current_millenium = int(current_date.year / 1000)
        dob_3_digit_year = date.year % 1000

        fixed_date = datetime.date(current_millenium * 1000 + dob_3_digit_year, date.month, date.day)
        if fixed_date > current_date:
            fixed_date = datetime.date((current_millenium - 1) * 1000 + dob_3_digit_year, date.month, date.day)

        # Additional check to ensure that the fixed date > 1900-1-1
        # - ignore the century and just rely on the 2 digit year
        if fixed_date < datetime.date(1900, 1, 1):
            return DateUtils._validate_date_of_birth_using_2_digit_year(date=date, current_date=current_date)
        else:
            return fixed_date

    @staticmethod
    def validate_date(date: datetime.date | None) -> datetime.date | None:
        if date is None:
            return None

        current_date = datetime.date.today()

        # Try and handle dates < 100, i.e. 2 digit years
        if date.year < 100:
            return DateUtils._validate_date_using_2_digit_year(date=date, current_date=current_date)

        # Try and handle dates < 1000, i.e. 3 digit years (these should be incredibly rare as it means that they're
        # either completely wrong or had the millenium removed!
        if date.year < 1000:
            return DateUtils._validate_date_using_3_digit_year(date=date, current_date=current_date)

        return date

    @staticmethod
    def _validate_date_using_2_digit_year(date: datetime.date, current_date: datetime.date) -> datetime.date:
        current_decade = int(current_date.year / 100)
        date_2_digit_year = date.year % 100

        fixed_date = datetime.date(current_decade * 100 + date_2_digit_year, date.month, date.day)
        return fixed_date

    @staticmethod
    def _validate_date_using_3_digit_year(date: datetime.date, current_date: datetime.date) -> datetime.date:
        current_millenium = int(current_date.year / 1000)
        date_3_digit_year = date.year % 1000

        fixed_date_future = datetime.date(current_millenium * 1000 + date_3_digit_year, date.month, date.day)
        fixed_date_past = datetime.date((current_millenium - 1) * 1000 + date_3_digit_year, date.month, date.day)

        # If we are more than 100 years out (both ends), then ignore the hundreds and revert back to tens
        if fixed_date_future > (current_date + relativedelta(years=100)):
            if fixed_date_past < datetime.date(1900, 1, 1):
                return DateUtils._validate_date_using_2_digit_year(date=date, current_date=current_date)
            else:
                return fixed_date_past
        else:
            return fixed_date_future

    @staticmethod
    def parse_unknown_str_as_date(date_str: str, region: str = aws_region.AP_SOUTHEAST_2) -> datetime.date | None:
        date_str = StringUtils.trim_to_empty(date_str).replace("/", "-")
        if len(date_str) == 0:
            return None

        try:
            return datetime.datetime.strptime(
                date_str, "%d-%m-%Y" if region == aws_region.AP_SOUTHEAST_2 else "%m-%d-%Y"
            ).date()
        except Exception:
            try:
                return datetime.datetime.strptime(
                    date_str, "%d-%m-%y" if region == aws_region.AP_SOUTHEAST_2 else "%m-%d-%y"
                ).date()
            except Exception:
                try:
                    return datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
                except Exception:
                    try:
                        return datetime.datetime.strptime(date_str, "%y-%m-%d").date()
                    except Exception:
                        return parser.parse(date_str, dayfirst=region != aws_region.US_EAST_1).date()
