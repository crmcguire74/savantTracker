from typing import Any

import botocore.client
from boto3.session import Session as Boto3Session
from botocore.exceptions import ClientError

from aws_lambda_powertools import Logger, Tracer
from lumiant_api.abstraction_layer.common.types.singleton import Singleton
from lumiant_api.abstraction_layer.common.utils.region_utils import RegionUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class SimpleNotificationServiceUtils(object, metaclass=Singleton):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Simple Notification Service - Handy methods for interacting with the AWS SNS
    -------------------------------------------------------------------------------------------------
    """

    logger = Logger(child=True, service="SharedLayer")
    tracer = Tracer(service="SharedLayer")

    SIMPLE_NOTIFICATION_SERVICE_NAME = "sns"
    DEFAULT_CHARSET = "UTF-8"

    boto3_session: Boto3Session
    default_region: str
    client: botocore.client  # type: ignore

    def __init__(self, boto3_session: Boto3Session, default_region: str | None = None) -> None:
        self.boto3_session = boto3_session

        def_region = StringUtils.trim_to_empty(default_region)
        if len(def_region) == 0:
            def_region = RegionUtils.get_current_region()

        self.default_region = def_region
        self.client = self.boto3_session.client(
            service_name=SimpleNotificationServiceUtils.SIMPLE_NOTIFICATION_SERVICE_NAME,
            region_name=default_region,
        )

    @tracer.capture_method(capture_response=False)  # type: ignore
    def get_client(self, region: str | None) -> botocore.client:  # type: ignore
        if region is not None and region != self.default_region:
            return self.boto3_session.client(
                service_name=SimpleNotificationServiceUtils.SIMPLE_NOTIFICATION_SERVICE_NAME,
                region_name=region,
            )
        else:
            return self.client

    def get_topic_arn(self, topic_name: str, account_id: str, region: str) -> str:
        return "arn:aws:sns:{0}:{1}:{2}".format(region, account_id, topic_name)

    def publish_event(
        self,
        event_body: str,
        event_attributes: dict[str, Any],
        topic_name: str,
        account_id: str,
        region: str,
    ) -> dict[str, Any] | None:
        try:
            client = self.get_client(region=region)
            response = client.publish(  # type: ignore[attr-defined]
                TopicArn=self.get_topic_arn(topic_name=topic_name, account_id=account_id, region=region),
                Message=event_body,
                MessageAttributes=event_attributes,
            )

            return response
        except ClientError as e:
            self.logger.error("SNS error {0}".format(e), exc_info=True)
            return None
