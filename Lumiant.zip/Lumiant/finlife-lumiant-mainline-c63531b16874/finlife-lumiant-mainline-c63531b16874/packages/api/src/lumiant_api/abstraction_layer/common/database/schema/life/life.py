import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Numeric, String, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Life(Base):
    __tablename__ = "Life"

    life_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("Client.client_id"), nullable=False, index=True)
    status: Mapped[str] = mapped_column(ENUM("O", "C"), nullable=False)
    overall_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    emotional_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    environmental_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    spiritual_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    social_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    education_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    occupational_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    physical_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    financial_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    deleted_by: Mapped[str | None] = mapped_column(String(50), nullable=True)
    deleted: Mapped[datetime.datetime | None] = mapped_column(DateTime, nullable=True)

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client: Mapped["Client"] = relationship("Client", back_populates="lives", lazy="select")

    responses: Mapped[list["LifeQuestionnaire"]] = relationship(
        "LifeQuestionnaire", back_populates="life", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.life.life_questionnaire import LifeQuestionnaire  # pylint: disable=C0413,R0401
