import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class MDAssetTree(Base):
    __tablename__ = "md_asset_tree"

    asset_tree_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    inv_group_id: Mapped[int] = mapped_column(
        ForeignKey("md_investment_group.inv_group_id"), nullable=False, index=True
    )
    region_id: Mapped[int] = mapped_column(ForeignKey("md_region.region_id"), nullable=False, index=True)
    asset_class_id: Mapped[int] = mapped_column(ForeignKey("md_asset_class.asset_class_id"), nullable=False, index=True)
    sector_id: Mapped[int] = mapped_column(ForeignKey("md_sector.sector_id"), nullable=False, index=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    inv_group: Mapped["MDInvestmentGroup"] = relationship("MDInvestmentGroup")
    region: Mapped["MDRegion"] = relationship("MDRegion")
    asset_class: Mapped["MDAssetClass"] = relationship("MDAssetClass")
    sector: Mapped["MDSector"] = relationship("MDSector")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.market_data.investment_group import MDInvestmentGroup  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.market_data.region import MDRegion  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.market_data.asset_class import MDAssetClass  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.market_data.sector import MDSector  # pylint: disable=C0413,R0401
