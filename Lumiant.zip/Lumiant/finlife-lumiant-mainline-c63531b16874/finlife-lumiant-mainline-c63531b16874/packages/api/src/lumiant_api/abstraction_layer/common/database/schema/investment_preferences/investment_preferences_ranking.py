import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class InvestmentPreferencesRanking(Base):
    __tablename__ = "InvestmentPreferencesRanking"

    investment_preferences_ranking_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    investment_preferences_id: Mapped[int] = mapped_column(
        ForeignKey("InvestmentPreferences.investment_preferences_id"), nullable=False, index=True
    )
    option_id: Mapped[int] = mapped_column(Integer, nullable=False)
    rank: Mapped[int | None] = mapped_column(Integer)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    investment_preferences: Mapped["InvestmentPreferences"] = relationship(
        "InvestmentPreferences", back_populates="prioritisation", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.investment_preferences.investment_preferences import (
    InvestmentPreferences,
)  # pylint: disable=C0413,R0401
