import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, String, DateTime, text, ForeignKey, Date, Boolean
from sqlalchemy.orm import mapped_column, relationship, Mapped


class Task(Base):
    __tablename__ = "Task"

    task_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int | None] = mapped_column(ForeignKey("Household.household_id"), nullable=True, index=True)
    client_id: Mapped[int | None] = mapped_column(ForeignKey("Client.client_id"), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(1500), nullable=False)
    order: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str | None] = mapped_column(String(5000), nullable=True)
    due_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    completed_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(50), nullable=False)
    is_internal: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    source_of_truth: Mapped[str] = mapped_column(String(50), nullable=False, default="L")
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    deleted_by: Mapped[str | None] = mapped_column(String(50), nullable=True)
    deleted: Mapped[datetime.datetime | None] = mapped_column(DateTime, nullable=True)

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="tasks", lazy="select")
    client: Mapped["Client"] = relationship("Client", back_populates="tasks", lazy="select")

    household_strategy_tasks: Mapped[list["HouseholdStrategyTask"]] = relationship(
        "HouseholdStrategyTask", back_populates="task", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy_task import (
    HouseholdStrategyTask,
)  # pylint: disable=C0413,R0401
