import datetime

import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from lumiant_core.momentum.apps.api_gateway_restapi.exceptions import ForbiddenException
from sqlalchemy import and_, or_

from lumiant_api.abstraction_layer.common.constants import practice, roles
from lumiant_api.abstraction_layer.common.database.schema.packages.component import Component as DBComponent
from lumiant_api.abstraction_layer.common.database.schema.packages.practice_package import (
    PracticePackage as DBPracticePackage,
)
from lumiant_api.abstraction_layer.common.database.schema.packages.practice_package_component import (
    PracticePackageComponent as DBPracticePackageComponent,
)
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice as DBPractice
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.utils.environment_utils import EnvironmentUtils


class LambdaAuthorisationService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Lambda Authorisation - Role Based and Component Access Control
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(child=True, service="SharedLayer")
    tracer = Tracer(service="SharedLayer")

    def __init__(self) -> None:
        pass

    @tracer.capture_method(capture_response=False)  # type: ignore
    def validate_rbac(
        self,
        auth_metadata: LambdaAuthorisationMetadata,
        roles_to_check: list[str],
        role_check_all: bool = False,
    ) -> None:
        if len(roles_to_check) > 0:
            if role_check_all:
                if not all(x in auth_metadata.user_groups for x in roles_to_check):
                    print(
                        "User is not in all the right Cognito group(s) to run this function. Roles to check [{0}] - "
                        "User Groups [{1}]".format(roles_to_check, auth_metadata.user_groups)
                    )
                    raise ForbiddenException()
            else:
                if not any(x in auth_metadata.user_groups for x in roles_to_check):
                    print(
                        "User is not in the right Cognito group to run this function. Roles to check [{0}] - User "
                        "Groups [{1}]".format(roles_to_check, auth_metadata.user_groups)
                    )
                    raise ForbiddenException()

        if any(x in roles.COGNITO_LUMIANT_ROLES for x in auth_metadata.user_groups):
            practice_ids_to_check = [practice.LUMIANT_PRACTICE_ID]

            if EnvironmentUtils.is_aws_prod_au_environment(specified_environment=auth_metadata.environment):
                practice_ids_to_check.append(practice.LUMIANT_ADVISER_DEMO_PRACTICE_ID)
                practice_ids_to_check.append(practice.LUMIANT_DEMO_PRACTICE_ID)
                practice_ids_to_check.append(practice.LUMIANT_OPERATIONS_AU)
            elif EnvironmentUtils.is_aws_prod_us_environment(specified_environment=auth_metadata.environment):
                practice_ids_to_check.append(practice.LUMIANT_ADVISER_DEMO_US_PRACTICE_ID)
                practice_ids_to_check.append(practice.LUMIANT_OPERATIONS_US)

            if auth_metadata.practice_id not in practice_ids_to_check:
                self.logger.error(
                    "Non Lumiant user has been assigned an internal Lumiant role. User Groups [{0}]".format(
                        auth_metadata.user_groups
                    )
                )
                raise ForbiddenException()

    @tracer.capture_method(capture_response=False)  # type: ignore
    def validate_component_access(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        component_to_check: str,
        practice_id: int,
        household_id: int | None = None,
        client_id: int | None = None,
        is_lumiant_elevated_user: bool = False,
    ) -> None:
        if len(component_to_check) == 0 or is_lumiant_elevated_user:
            return

        now = datetime.datetime.today()

        found = (
            lumiant_rds_session.query(DBPractice)
            .join(DBPracticePackage, DBPracticePackage.practice_package_id == DBPractice.practice_package_id)
            .join(
                DBPracticePackageComponent,
                DBPracticePackageComponent.practice_package_id == DBPracticePackage.practice_package_id,
            )
            .join(DBComponent, DBComponent.component_id == DBPracticePackageComponent.component_id)
            .filter(
                and_(
                    DBPractice.practice_id == practice_id,
                    DBComponent.code == component_to_check,
                    or_(DBPracticePackage.start_date.is_(None), DBPracticePackage.start_date <= now),
                    or_(DBPracticePackage.end_date.is_(None), DBPracticePackage.end_date > now),
                    or_(DBComponent.start_date.is_(None), DBComponent.start_date <= now),
                    or_(DBComponent.end_date.is_(None), DBComponent.end_date > now),
                )
            )
            .with_entities(DBComponent.code)
            .first()
        )

        if found is None:
            print(
                "Practice/Household does not have access to the required component. Practice Id [{0}], Household Id "
                "[{1}], Client Id [{2}], Component [{3}]".format(
                    practice_id, household_id, client_id, component_to_check
                )
            )

            raise ForbiddenException()
