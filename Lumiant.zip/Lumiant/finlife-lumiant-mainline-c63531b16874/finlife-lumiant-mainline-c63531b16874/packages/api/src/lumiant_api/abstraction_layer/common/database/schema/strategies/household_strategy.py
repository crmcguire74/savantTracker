import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Date, Numeric, DateTime, Boolean, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class HouseholdStrategy(Base):
    __tablename__ = "HouseholdStrategy"

    household_strategy_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    practice_strategy_category_id: Mapped[int] = mapped_column(
        ForeignKey("PracticeStrategyCategory.practice_strategy_category_id"), nullable=False, index=True
    )
    practice_strategy_id: Mapped[int | None] = mapped_column(
        ForeignKey("PracticeStrategy.practice_strategy_id"), nullable=True, index=True
    )
    strategy_name: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    details: Mapped[str | None] = mapped_column(String(10000), nullable=True)
    progress: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    start_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    end_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    target_amount: Mapped[float | None] = mapped_column(Numeric(15, 2), nullable=True)
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)

    # Two-Way Relationship
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="household_strategies", lazy="select")
    practice_strategy_category: Mapped["PracticeStrategyCategory"] = relationship(
        "PracticeStrategyCategory", back_populates="household_strategies", lazy="select"
    )
    practice_strategy: Mapped["PracticeStrategy"] = relationship(
        "PracticeStrategy", back_populates="household_strategies", lazy="select"
    )

    household_strategy_goals: Mapped[list["HouseholdStrategyGoal"]] = relationship(
        "HouseholdStrategyGoal", back_populates="household_strategy", lazy="select"
    )
    household_strategy_tasks: Mapped[list["HouseholdStrategyTask"]] = relationship(
        "HouseholdStrategyTask", back_populates="household_strategy", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.practice_strategy import PracticeStrategy  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy_goal import (
    HouseholdStrategyGoal,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy_task import (
    HouseholdStrategyTask,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.practice_strategy_category import (
    PracticeStrategyCategory,
)  # pylint: disable=C0413,R0401
