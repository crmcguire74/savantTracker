import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Index, Integer, String, ForeignKey, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class MDSecurity(Base):
    __tablename__ = "md_security"
    __table_args__ = (
        Index("ix_md_security_code", "code"),
        Index("ix_md_security_ms_code", "ms_code"),
        Index("ix_md_security_ticker", "ticker", "exchange"),
    )

    security_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(30), nullable=False)
    ms_code: Mapped[str] = mapped_column(String(30), nullable=False)
    ms_non_fund_code: Mapped[str] = mapped_column(String(100), nullable=False)
    ticker: Mapped[str] = mapped_column(String(30), nullable=False)
    exchange: Mapped[str | None] = mapped_column(String(20), nullable=True)
    isin: Mapped[str | None] = mapped_column(String(12))
    sedol: Mapped[str | None] = mapped_column(String(12))
    cusip: Mapped[str | None] = mapped_column(String(12))
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    asset_tree_id: Mapped[int] = mapped_column(ForeignKey("md_asset_tree.asset_tree_id"), nullable=False, index=True)
    security_group_id: Mapped[int] = mapped_column(
        ForeignKey("md_security_group.security_group_id"), nullable=False, index=True
    )
    security_type_id: Mapped[int] = mapped_column(
        ForeignKey("md_security_type.security_type_id"), nullable=False, index=True
    )
    ms_industry_class_id: Mapped[int | None] = mapped_column(
        ForeignKey("ms_industry_class.ms_industry_class_id"), nullable=True, index=True
    )
    description: Mapped[str | None] = mapped_column(String(2000), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    asset_tree: Mapped["MDAssetTree"] = relationship("MDAssetTree")
    security_group: Mapped["MDSecurityGroup"] = relationship("MDSecurityGroup")
    security_type: Mapped["MDSecurityType"] = relationship("MDSecurityType")

    holding: Mapped[list["Holding"]] = relationship("Holding", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.market_data.asset_tree import MDAssetTree  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.market_data.security_group import MDSecurityGroup  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.market_data.security_type import MDSecurityType  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.holding import Holding  # pylint: disable=C0413,R0401
