import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class InsuranceYodleeMapping(Base):
    __tablename__ = "InsuranceYodleeMapping"

    insurance_yodlee_mapping_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    insurance_id: Mapped[int] = mapped_column(ForeignKey("Insurance.insurance_id"), nullable=False, index=True)
    provider_account_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    additional_status: Mapped[str | None] = mapped_column(String(100), nullable=True)
    last_updated: Mapped[datetime.datetime | None] = mapped_column(DateTime)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    insurance: Mapped["Insurance"] = relationship("Insurance", back_populates="insurance_yodlee_mapping", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance import Insurance  # pylint: disable=C0413,R0401
