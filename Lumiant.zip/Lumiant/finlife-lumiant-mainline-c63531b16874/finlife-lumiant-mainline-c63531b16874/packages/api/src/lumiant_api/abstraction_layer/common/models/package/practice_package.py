# pylint: disable=line-too-long
import json

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils


class PracticePackage(object):
    """
    -------------------------------------------------------------------------------------------------
    Practice Package - Local copy of the data in the PracticePackage table
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    practice_package_id: int
    code: str
    name: str
    description: str
    uses_household_packages: bool

    def __init__(
        self, practice_package_id: int, code: str, name: str, description: str, uses_household_packages: bool
    ) -> None:
        self.practice_package_id = practice_package_id
        self.code = code
        self.name = name
        self.description = description
        self.uses_household_packages = uses_household_packages

    @staticmethod
    def get_from_code(code: str) -> "PracticePackage | None":
        return PRACTICE_PACKAGE_BY_CODE.get(code, None)

    @staticmethod
    def get_from_code_publicly_accessible(code: str) -> "PracticePackage | None":
        return PRACTICE_PACKAGE_PUBLICLY_ACCESSIBLE_BY_CODE.get(code, None)

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)


STARTER = PracticePackage(2, "STARTER", "Starter", "Starter", False)
PRO = PracticePackage(3, "PRO", "Professional", "Professional", False)
ENTERPRISE = PracticePackage(4, "ENTERPRISE", "Enterprise", "Enterprise", False)

INVPREFS = PracticePackage(5, "INVPREFS", "Investment Preferences", "Investment Preferences", False)

LUMIANT = PracticePackage(6, "LUMIANT", "Lumiant", "Internal Lumiant Package", False)

# No Longer Used
# PAYG = PracticePackage(1, 'PAYG', 'Pay As You Go', 'Introduction to the Lumiant client experience with the ability to individually upgrade households.', True)
# PAYGIP = PracticePackage(7, 'PAYGIP', 'Pay As You Go', 'Introduction to the Lumiant client experience with the ability to individually upgrade households.', True)

PRACTICE_PACKAGE_BY_CODE: dict[str, PracticePackage] = {
    STARTER.code: STARTER,
    PRO.code: PRO,
    ENTERPRISE.code: ENTERPRISE,
    INVPREFS.code: INVPREFS,
    LUMIANT.code: LUMIANT,
}

PRACTICE_PACKAGE_PUBLICLY_ACCESSIBLE_BY_CODE: dict[str, PracticePackage] = {STARTER.code: STARTER, PRO.code: PRO}
