import botocore.client
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session

from lumiant_api.abstraction_layer.common.types.singleton import Singleton
from lumiant_api.abstraction_layer.common.utils.region_utils import RegionUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class RDSUtils(object, metaclass=Singleton):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: RDS - Handy methods for interacting with the AWS RDS via the Data API
    -------------------------------------------------------------------------------------------------
    """

    logger = Logger(child=True, service="SharedLayer")
    tracer = Tracer(service="SharedLayer")

    RDS_SERVICE_NAME = "rds-data"

    boto3_session: Boto3Session
    default_region: str
    client: botocore.client  # type: ignore

    def __init__(self, boto3_session: Boto3Session, default_region: str | None = None) -> None:
        self.boto3_session = boto3_session

        def_region = StringUtils.trim_to_empty(default_region)
        if len(def_region) == 0:
            def_region = RegionUtils.get_current_region()

        self.default_region = def_region
        self.client = self.boto3_session.client(service_name=RDSUtils.RDS_SERVICE_NAME, region_name=default_region)

    @tracer.capture_method(capture_response=False)  # type: ignore
    def get_client(self, region: str | None) -> botocore.client:  # type: ignore
        if region is not None and region != self.default_region:
            return self.boto3_session.client(service_name=RDSUtils.RDS_SERVICE_NAME, region_name=region)
        else:
            return self.client
