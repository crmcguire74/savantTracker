import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, Numeric, Boolean, Date, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Asset(Base):
    __tablename__ = "Asset"

    asset_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    client_id: Mapped[int | None] = mapped_column(ForeignKey("Client.client_id"), index=True)
    legal_entity_id: Mapped[int | None] = mapped_column(ForeignKey("LegalEntity.legal_entity_id"), index=True)
    beneficiary_client_id: Mapped[int | None] = mapped_column(Integer)
    beneficiary_legal_entity_id: Mapped[int | None] = mapped_column(Integer)
    other_beneficiary: Mapped[str | None] = mapped_column(String(100))
    relationship_asset: Mapped[str | None] = mapped_column(String(100))
    asset_type: Mapped[str] = mapped_column(ENUM("S", "N", "H", "P", "G", "I", "C", "V", "A", "U", "O"), nullable=False)
    super_type: Mapped[str | None] = mapped_column(
        ENUM("A", "D", "P", "E", "F", "G", "H", "I", "J", "K", "L", "M", "U")
    )
    pension_type: Mapped[str | None] = mapped_column(ENUM("A", "T", "R"))
    annuity_type: Mapped[str | None] = mapped_column(ENUM("L", "G", "D", "I"))
    description: Mapped[str | None] = mapped_column(String(200))
    account_number: Mapped[str | None] = mapped_column(String(50))
    provider_name: Mapped[str | None] = mapped_column(String(100))
    member_number: Mapped[str | None] = mapped_column(String(50))
    balance: Mapped[float | None] = mapped_column(Numeric(20, 8))
    defined_benefit_salary: Mapped[float | None] = mapped_column(Numeric(15, 2))
    defined_benefit_multiple: Mapped[float | None] = mapped_column(Numeric(5, 2))
    employee_contribution: Mapped[float | None] = mapped_column(Numeric(12, 2))
    employee_contribution_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    employee_contribution_type: Mapped[str | None] = mapped_column(ENUM("P", "X"))
    employee_contribution_cap: Mapped[float | None] = mapped_column(Numeric(12, 2))
    employee_contribution_cap_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    employer_contribution: Mapped[float | None] = mapped_column(Numeric(12, 2))
    employer_contribution_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    employer_contribution_cap: Mapped[float | None] = mapped_column(Numeric(12, 2))
    employer_contribution_cap_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    makes_personal_contribution: Mapped[bool | None] = mapped_column(Boolean)
    annual_contribution: Mapped[float | None] = mapped_column(Numeric(12, 2))
    inherited_ira_type: Mapped[str | None] = mapped_column(String(100))
    deceased_owner_date_of_birth: Mapped[datetime.date | None] = mapped_column(Date)
    deceased_owner_date_of_death: Mapped[datetime.date | None] = mapped_column(Date)
    rmd_taken_this_year: Mapped[bool | None] = mapped_column(Boolean)
    previous_year_balance: Mapped[float | None] = mapped_column(Numeric(12, 2))
    annuity_term_date: Mapped[datetime.date | None] = mapped_column(Date)
    death_benefit: Mapped[float | None] = mapped_column(Numeric(12, 2))
    surrender_value: Mapped[float | None] = mapped_column(Numeric(12, 2))
    centrelink_value: Mapped[float | None] = mapped_column(Numeric(12, 2))
    is_used_loan_security: Mapped[bool | None] = mapped_column(Boolean)
    loan_secured_amount: Mapped[float | None] = mapped_column(Numeric(12, 2))
    made_personal_contrib_past_3y: Mapped[bool | None] = mapped_column(Boolean)
    tax_free_component: Mapped[float | None] = mapped_column(Numeric(12, 2))
    preservation_component: Mapped[float | None] = mapped_column(Numeric(12, 2))
    makes_personal_super_contribution: Mapped[bool | None] = mapped_column(Boolean)
    is_salary_sacrifice: Mapped[bool | None] = mapped_column(Boolean)
    super_contribution_amount: Mapped[float | None] = mapped_column(Numeric(12, 2))
    super_contribution_frequency: Mapped[str | None] = mapped_column(ENUM("W", "F", "M", "B", "Q", "H", "A"))
    employer_pays_higher_than_minimum_super: Mapped[bool | None] = mapped_column(Boolean)
    higher_than_minimum_super_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    pre_retirement_ref_model: Mapped[int | None] = mapped_column(Integer)
    post_retirement_ref_model: Mapped[int | None] = mapped_column(Integer)
    fees_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    fees_dollar: Mapped[float | None] = mapped_column(Numeric(15, 2))
    address_id: Mapped[int | None] = mapped_column(ForeignKey("Address.address_id"), index=True)
    own_or_rent: Mapped[str | None] = mapped_column(ENUM("O", "R", "F"))
    is_primary_home: Mapped[bool | None] = mapped_column(Boolean)
    purchase_price: Mapped[float | None] = mapped_column(Numeric(15, 2))
    purchase_date: Mapped[datetime.date | None] = mapped_column(Date)
    growth_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    current_value: Mapped[float | None] = mapped_column(Numeric(15, 2))
    property_type: Mapped[str | None] = mapped_column(ENUM("H", "U"))
    rent: Mapped[float | None] = mapped_column(Numeric(15, 2))
    saving_investment_type: Mapped[str | None] = mapped_column(
        ENUM("C", "B", "D", "T", "I", "O", "K", "M", "R", "E", "H", "W", "V", "U", "S", "A", "X")
    )
    asset_use: Mapped[str | None] = mapped_column(ENUM("N", "E"))
    assessed: Mapped[bool | None] = mapped_column(Boolean)
    make: Mapped[str | None] = mapped_column(String(50))
    model: Mapped[str | None] = mapped_column(String(50))
    last_valued: Mapped[datetime.date | None] = mapped_column(Date)
    super_phase: Mapped[str | None] = mapped_column(ENUM("A", "T", "P"))
    term: Mapped[int | None] = mapped_column(Integer)
    maturity_date: Mapped[datetime.date | None] = mapped_column(Date)
    commuted_amount: Mapped[float | None] = mapped_column(Numeric(15, 2))
    residual_value: Mapped[float | None] = mapped_column(Numeric(15, 2))
    asset_exemption_bps: Mapped[float | None] = mapped_column(Numeric(5, 4))
    notes: Mapped[str | None] = mapped_column(String(5000))
    client_notes: Mapped[str | None] = mapped_column(String(2500))
    partner_notes: Mapped[str | None] = mapped_column(String(2500))
    confidential_notes: Mapped[str | None] = mapped_column(String(5000))
    display_name: Mapped[str | None] = mapped_column(String(100))
    display_ownership: Mapped[int | None] = mapped_column(Integer)
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    external_load_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    soft_deleted: Mapped[bool | None] = mapped_column(Boolean, default=0)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="assets", lazy="select")
    client: Mapped["Client"] = relationship("Client", back_populates="assets", lazy="select")
    legal_entity: Mapped["LegalEntity"] = relationship("LegalEntity", back_populates="assets", lazy="select")
    address: Mapped["Address"] = relationship("Address", back_populates="asset", lazy="select")

    liabilities: Mapped[list["Liability"]] = relationship("Liability", back_populates="asset", lazy="select")
    income: Mapped[list["Income"]] = relationship("Income", back_populates="asset", lazy="select")
    expense: Mapped[list["Expense"]] = relationship("Expense", back_populates="asset", lazy="select")
    super_beneficiaries: Mapped[list["SuperBeneficiary"]] = relationship(
        "SuperBeneficiary", back_populates="asset", lazy="select"
    )
    insurance: Mapped[list["Insurance"]] = relationship("Insurance", back_populates="asset", lazy="select")

    asset_yodlee_mapping: Mapped["AssetYodleeMapping"] = relationship(
        "AssetYodleeMapping", back_populates="asset", uselist=False, lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.address import Address  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.asset_yodlee_mapping import AssetYodleeMapping  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.expense import Expense  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.income import Income  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance import Insurance  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.legal_entity import LegalEntity  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.liability import Liability  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.super_beneficiary import SuperBeneficiary  # pylint: disable=C0413,R0401
