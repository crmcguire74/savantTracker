from pydantic import BaseModel, Field


class SaveInsuranceCoverageRequest(BaseModel):
    """
    -------------------------------------------------------------------------------------------------
    REQUEST: Save Insurance Coverage

    Note: we can map json fields (camelCase) to python fields (snake_case) - and completely change
          the field names altogether but given that we're trying to represent the request here we
          will leave it as provided.
    -------------------------------------------------------------------------------------------------
    """

    insurance_coverage_id: int | None = Field(alias="insuranceCoverageId", default=None)
    insurance_id: int | None = Field(alias="insuranceId", default=None)
    life_insurance_type: str | None = Field(alias="lifeInsuranceType", default=None)
    general_insurance_type: str | None = Field(alias="generalInsuranceType", default=None)
    life_insurance_sub_type: str | None = Field(alias="lifeInsuranceSubType", default=None)
    disability_sub_type: str | None = Field(alias="disabilitySubType", default=None)
    long_term_care_sub_type: str | None = Field(alias="longTermCareSubType", default=None)
    other_insurance_sub_type: str | None = Field(alias="otherInsuranceSubType", default=None)
    cover: float | None = Field(alias="cover", default=None)
    cover_bps: float | None = Field(alias="coverBps", default=None)
    cover_per_annum: float | None = Field(alias="coverPerAnnum", default=None)
    ip_cover_type: str | None = Field(alias="ipCoverType", default=None)
    ar_sub_type: str | None = Field(alias="arSubType", default=None)
    payout_period: str | None = Field(alias="payoutPeriod", default=None)
    payout_period_end: str | None = Field(alias="payoutPeriodEnd", default=None)
    payout_wait_period: int | None = Field(alias="payoutWaitPeriod", default=None)
    inside_super: bool | None = Field(alias="insideSuper", default=None)
    end_year: int | None = Field(alias="endYear", default=None)
    death_benefit: float | None = Field(alias="deathBenefit", default=None)
    beneficiary_relation: str | None = Field(alias="beneficiaryRelation", default=None)
    chronic_care_rider: bool | None = Field(alias="chronicCareRider", default=None)
    other_beneficiary: str | None = Field(alias="otherBeneficiary", default=None)
    long_or_short: str | None = Field(alias="longOrShort", default=None)
    monthly_benefit_amount: float | None = Field(alias="monthlyBenefitAmount", default=None)
    total_benefits: float | None = Field(alias="totalBenefits", default=None)
    payout_type: str | None = Field(alias="payoutType", default=None)
    payout_period_text: str | None = Field(alias="payoutPeriodText", default=None)
    elimination_period: int | None = Field(alias="eliminationPeriod", default=None)
    healthcare_source: str | None = Field(alias="healthcareSource", default=None)
    premium_tax_credit: bool | None = Field(alias="premiumTaxCredit", default=None)
