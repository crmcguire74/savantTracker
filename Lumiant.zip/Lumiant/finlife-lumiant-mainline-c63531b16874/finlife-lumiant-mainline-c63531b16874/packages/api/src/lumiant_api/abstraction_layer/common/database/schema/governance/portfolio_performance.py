import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Numeric, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class PortfolioPerformance(Base):
    __tablename__ = "PortfolioPerformance"

    portfolio_performance_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("Portfolio.portfolio_id"), nullable=False, index=True)
    begin_market_val_mtd: Mapped[float | None] = mapped_column(Numeric(20, 8))
    begin_market_val_ytd: Mapped[float | None] = mapped_column(Numeric(20, 8))
    begin_market_val_1y: Mapped[float | None] = mapped_column(Numeric(20, 8))
    begin_market_val_3y: Mapped[float | None] = mapped_column(Numeric(20, 8))
    begin_market_val_5y: Mapped[float | None] = mapped_column(Numeric(20, 8))
    begin_market_val_incept: Mapped[float | None] = mapped_column(Numeric(20, 8))
    net_contrib_withdraw_mtd: Mapped[float | None] = mapped_column(Numeric(20, 8))
    net_contrib_withdraw_ytd: Mapped[float | None] = mapped_column(Numeric(20, 8))
    net_contrib_withdraw_1y: Mapped[float | None] = mapped_column(Numeric(20, 8))
    net_contrib_withdraw_3y: Mapped[float | None] = mapped_column(Numeric(20, 8))
    net_contrib_withdraw_5y: Mapped[float | None] = mapped_column(Numeric(20, 8))
    net_contrib_withdraw_incept: Mapped[float | None] = mapped_column(Numeric(20, 8))
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    portfolio: Mapped["Portfolio"] = relationship("Portfolio", back_populates="portfolio_performance", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.governance.portfolio import Portfolio  # pylint: disable=C0413,R0401
