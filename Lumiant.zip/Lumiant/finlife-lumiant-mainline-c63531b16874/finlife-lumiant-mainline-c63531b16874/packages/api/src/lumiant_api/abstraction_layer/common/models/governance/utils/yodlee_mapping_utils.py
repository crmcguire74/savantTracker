from aws_lambda_powertools import Logger

SUCCESSFUL_STATUSES = [
    "LOGIN_IN_PROGRESS",
    "DATA_RETRIEVAL_IN_PROGRESS",
    "ACCT_SUMMARY_RECEIVED",
    "AVAILABLE_DATA_RETRIEVED",
    "MIGRATION_IN_PROGRESS",
]

# info from https://developer.envestnet.com/resources/yodlee/data-model/docs/accounts#Dataset_Additional_Statuses
STATUSES_DESCRIPTION = {
    "LOGIN_IN_PROGRESS": "Login to provider site is in progress.",
    "DATA_RETRIEVAL_IN_PROGRESS": "Data aggregation is in progress.",
    "ACCT_SUMMARY_RECEIVED": "Basic account data is retrieved.",
    "AVAILABLE_DATA_RETRIEVED": "All the data available at the provider site is retrieved for the provided dataset.",
    "PARTIAL_DATA_RETRIEVED": "Partial data is retrieved for the dataset.",
    "DATA_RETRIEVAL_FAILED": "Failed to retrieve the data due to unexpected issues.",
    "DATA_NOT_AVAILABLE": "The requested data or document is not available at the provider site.",
    "ACCOUNT_LOCKED": "The account is locked at the provider site. The user has exceeded the maximum number of "
    "incorrect login attempts resulting in the account getting locked.",
    "ADDL_AUTHENTICATION_REQUIRED": "Additional MFA information is needed at the provider site, or to download the "
    "document, additional verification is required.",
    "BETA_SITE_DEV_IN_PROGRESS": "The site for which the data is requested is in the development or beta stage.",
    "CREDENTIALS_UPDATE_NEEDED": "Unable to log in to the provider site due to outdated credentials. The site may be "
    "prompting the user to change or verify the credentials. ",
    "INCORRECT_CREDENTIALS": "Unable to log in to the provider site due to incorrect credentials. The credentials that "
    "the user has provided are incorrect.",
    "PROPERTY_VALUE_NOT_AVAILABLE": "The property value is not available.",
    "INVALID_ADDL_INFO_PROVIDED": "The user has provided incorrect MFA information, or the MFA information provided "
    "has expired.",
    "REQUEST_TIME_OUT": "The request has timed out due to technical reasons.",
    "SITE_BLOCKING_ERROR": "The Yodlee IP is blocked by the provider site.",
    "UNEXPECTED_SITE_ERROR": "All errors indicating issues at the provider site, such as the site being down for "
    "maintenance.",
    "SITE_NOT_SUPPORTED": "The site does not support the requested data or support is not available to complete the"
    " requested action",
    "SITE_UNAVAILABLE": "The provider site is unavailable due to maintenance.",
    "TECH_ERROR": "Indicates there is a technical error.",
    "USER_ACTION_NEEDED_AT_SITE": "Please login at the provider site and complete outstanding actions such as accepting"
    " Terms and Conditions.",
    "SITE_SESSION_INVALIDATED": "The provider has terminated the connection.",
    "NEW_AUTHENTICATION_REQUIRED": "The site has requested for OAuth authentication.",
    "DATASET_NOT_SUPPORTED": "The requested datasets are not supported.",
    "ENROLLMENT_REQUIRED_FOR_DATASET": "The dataset cannot be retrieved as the user has not enrolled for it.",
    "CONSENT_REQUIRED": "Consent is required as the account information is migrated from the credential-based provider "
    "to the Open Banking provider site.",
    "CONSENT_EXPIRED": "The consent provided by the user to access the account information through Open Banking has "
    "expired.",
    "CONSENT_REVOKED": "The user has revoked the consent to access the account information through Open Banking.",
    "INCORRECT_OAUTH_TOKEN": "Failed to log in to the Open Banking provider site due to an incorrect token.",
    "MIGRATION_IN_PROGRESS": "The account information is being migrated from the credential-based provider to the Open "
    "Banking provider site.",
}


class YodleeMappingUtils(object):
    """
    -------------------------------------------------------------------------------------------------
    UTILITIES: Yodlee Mapping - Handy methods for dealing with Yodlee Mapping
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    @staticmethod
    def is_link_broken(status: str | None) -> bool:
        if status is None:
            return False

        return status not in SUCCESSFUL_STATUSES

    @staticmethod
    def get_status_description(status: str | None) -> str:
        if status is None:
            return ""

        return STATUSES_DESCRIPTION[status] if status in STATUSES_DESCRIPTION.keys() else ""
