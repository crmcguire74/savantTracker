import datetime
from typing import Any

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, String, Boolean, Date, DateTime, text
from sqlalchemy.dialects.mysql import JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship


class PracticePackage(Base):
    __tablename__ = "PracticePackage"

    practice_package_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(10), nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str] = mapped_column(String(1500), nullable=False)
    uses_household_packages: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    enabled_feature_flags: Mapped[dict[str, Any] | None] = mapped_column(JSON)
    disabled_feature_flags: Mapped[dict[str, Any] | None] = mapped_column(JSON)
    start_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    end_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # practice_household_packages = relationship('PracticeHouseholdPackage', back_populates='practice_packages')

    # One-Way Relationships
    components: Mapped[list["PracticePackageComponent"]] = relationship("PracticePackageComponent", lazy="select")
    practice_household_packages: Mapped[list["PracticeHouseholdPackage"]] = relationship(
        "PracticeHouseholdPackage", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.packages.practice_package_component import (
    PracticePackageComponent,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.packages.practice_household_package import (
    PracticeHouseholdPackage,
)  # pylint: disable=C0413,R0401
