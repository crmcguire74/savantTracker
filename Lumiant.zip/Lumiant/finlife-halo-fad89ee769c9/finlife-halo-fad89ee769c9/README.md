```
  _              _          _
 | |  _  _ _ __ (_)__ _ _ _| |_
 | |_| || | '  \| / _` | ' \  _|
 |____\_,_|_|_|_|_\__,_|_||_\__|
```

# HALO Documentation

## 1. Prerequisites

* Homebrew - [Homebrew](https://brew.sh/) recommended
* Git Command Line - [GitKraken](https://www.gitkraken.com/) required
* Git UI - [GitKraken](https://www.gitkraken.com/) optional
* Git LFS - [Git LFS](https://git-lfs.com/) required
* Node - [NodeJS](https://nodejs.org/en/) required
* Yarn - [Yarn](https://yarnpkg.com/) required
* IDE - VSCode or WebStorm (or any other IDEA IDE with JS addons)

### 1.1 Homebrew
Start by installing Homebrew:
```
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### 1.2 Git Command Line
Then install git:
```
brew install git
```

### 1.3 Git UI (optional)
Download and install [GitKraken](https://www.gitkraken.com/download)

### 1.4 Git-LFS
Then install git-lfs:
```
brew install git-lfs
git-lfs install
```

### 1.5 Node
Install the required version of Node:
```
brew install node@18
echo 'export PATH="/opt/homebrew/opt/node@18/bin:$PATH"' >> ~/.zshrc
```

### 1.6 Yarn
Install Yarn:
`brew install yarn`

## 2. Local Development

Both `Python 2` and an older version of `node` are required to compile `gyp` and `node-sass`!
Specifically for `node-sass` to compile successfully v14.15.x of `node` is needed - we'll address this by removing sass
but it's needed for backward compatibility at the moment.

The easiest way to update your local environment temporarily to do this is by using `pyenv` and `nvm`, i.e.

```
brew install pyenv
pyenv install 2.7.18
pyenv install 3.11.7
pyenv global 3.11.7 2.7.18      (or 'pyenv shell 3.11.7 2.7.18' for just the current shell)
export PATH="$(pyenv root)/shims:${PATH}"

brew install nvm
nvm install 20.11.0
nvm use 20.11.0
export PATH=~/.nvm/versions/node/v20.11.0/bin:${PATH}
```

You should then be able to run `yarn install` successfully to install all the required dependencies.

## 3. Deployment

Run `yarn build` and then copy the contents of the `/build` directory into the HAGO
(https://bitbucket.org/finlife/halo-backend) repository into it's `/static/halo` directory.


## 4. Test suite


front end testing is done primarily through cypress. it aims to test various aspects of the frontend which include:
- End-to-end testing 
- component testing


### 4.1 Test suite - opening the app
to get started with cypress testing suite run `yarn cypress open`. After a moment the cypress launchpad will launch.
This will launch a chrome window where e2e testing can run.





