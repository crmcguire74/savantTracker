import { createTheme } from '@material-ui/core/styles';

const gen_dark = {
  50: '#333749',
  100: '#333749',
  200: '#333749',
  300: '#333749',
  400: '#333749',
  500: '#333749',
  600: '#333749',
  700: '#333749',
  800: '#333749',
  900: '#333749',
  A100: '#333749',
  A200: '#333749',
  A400: '#333749',
  A700: '#333749',
  contrastDefaultColor: 'light',
}

const gen_txt_white = {
  default: '#333749',
  primary: '#333749',
  secondary: '#9D63AB', //purple
  disabled: 'orange',
  hint: 'black',
  icon: 'red',
  divider: 'green',
  lightDivider: 'purple',
}

const getContrastText = (color) => {
  if (color === "#333749") {
    return 'white'
  } else {
    return 'black'
  }
}

export const base_theme = createTheme(
  {
    typography: {
      useNextVariants: true,
    },
  }
);

export const gen_theme = createTheme(
  {
    typography: {
      useNextVariants: true,
    },
    palette: {
      primary: gen_dark,
      // accent: gen_purple,
      input: {
        bottomLine: '#333749'
      },
      action: {
        active: '#333749'
      },
      text: gen_txt_white,
      getContrastText: getContrastText,
    },
    overrides: {
      MuiMobileStepper: {
        dotActive: {
          backgroundColor: '#26B9A7',
        },
      },
      MuiModal: {
        root: {
          zIndex: '9999999', //this was needed for complete advisors
        }
      },
      MuiTypography: {
        root: {
          color: '#333749',
          fontFamily: 'Avenir',
          fontSize: '1.0965vw',
          fontWeight: '500',
          letterSpacing: '0.13688vw',
          lineHeight: '1.0965vw',
          // textAlign: 'center',
          // marginTop: '-1.02797vw',
          [base_theme.breakpoints.up(1315)]: {
            fontSize: '16px',
            lineHeight: '16px',
            letterSpacing: '2px',
          },
          [base_theme.breakpoints.down(667)]: {
            fontSize: '16px',
            lineHeight: '16px',
            letterSpacing: '2px',
          },
        },
        body: {
          color: '#333749',
          fontFamily: 'Avenir',
        },
      },
      MuiInput: {
        input: {
          color: '#333749',
          fontFamily: 'Avenir',
          fontSize: '1.0965vw',
          fontWeight: '500',
          letterSpacing: '0.13688vw',
          lineHeight: '1.0965vw',
          // textAlign: 'center',
          // marginTop: '-1.02797vw',
          [base_theme.breakpoints.up(1315)]: {
            fontSize: '16px',
            lineHeight: '16px',
            letterSpacing: '2px',
          },
          [base_theme.breakpoints.down(667)]: {
            fontSize: '16px',
            lineHeight: '16px',
            letterSpacing: '2px',
          }
        },
        formControl: {
          [base_theme.breakpoints.up(1315)]: {
            marginTop: '16px',
          },
          [base_theme.breakpoints.between(668, 1314)]: {
            marginTop: '1.0965vw !important',
          },
          [base_theme.breakpoints.down(667)]: {
            marginTop: '0px',
          }
        },
        underline: {
          '&:before': {
            height: '0.13688vw',
          },
          [base_theme.breakpoints.up(1315)]: {
            '&:before': {
              height: '2px',
            },
          },
          [base_theme.breakpoints.down(667)]: {
            '&:before': {
              height: '2px',
            },
          },
        },
      },
      MuiInputLabel: {
        root: {
          color: '#333749',
          fontFamily: 'Avenir',
          fontSize: '1.0965vw',
          fontWeight: '500',
          letterSpacing: '0.13688vw',
          lineHeight: '1.0965vw',
          textAlign: 'center',
          // marginTop: '-1.02797vw',
          [base_theme.breakpoints.up(1315)]: {
            fontSize: '16px',
            lineHeight: '16px',
            letterSpacing: '2px',
          },
          [base_theme.breakpoints.down(667)]: {
            fontSize: '16px',
            lineHeight: '16px',
            letterSpacing: '2px',
          }
        },
        formControl: {
          zIndex: '99', //this was needed for complete advisors
          pointerEvents: 'none',
          transform: 'translate(0, 1.75vw) scale(1)',
          [base_theme.breakpoints.up(1315)]: {
            transform: 'translate(0, 25px) scale(1)',
          },
          [base_theme.breakpoints.down(667)]: {
            transform: 'translate(0, 10px) scale(1)',
          },
        },
        shrink: {
          [base_theme.breakpoints.down(667)]: {
            transform: 'translate(0, -1.5px) scale(0.75)',
          },
        }
      },
      MuiRadio: {
        "&$checked": {
          color: '#9D63AB',
        }
      },
      MuiIconButton: {
        icon: {
          width: '2em',
          height: '2em',
        },
      },

      MuiCheckbox: {
        "&$checked": {
          color: '#9D63AB',
        }
      },
      MuiMenuItem: {
        root: {
          color: '#333749',
          fontFamily: 'Avenir',
          fontSize: '1.0965vw',
          fontWeight: '500',
          letterSpacing: '0.13688vw',
          lineHeight: '1.0965vw',
          textAlign: 'center',
          // marginTop: '-1.02797vw',
          [base_theme.breakpoints.up(1315)]: {
            fontSize: '16px',
            lineHeight: '16px',
            letterSpacing: '2px',
          },
          [base_theme.breakpoints.down(667)]: {
            fontSize: '16px',
            lineHeight: '16px',
            letterSpacing: '2px',
          }
        },
        "&$selected": {
          backgroundColor: '#333749'
        },
      },
      MuiListItem: {
        root: {
          color: '#333749',
          fontFamily: 'Avenir',
          fontSize: '1.0965vw',
          fontWeight: '500',
          letterSpacing: '0.13688vw',
          lineHeight: '1.0965vw',
          textAlign: 'center',
          // marginTop: '-1.02797vw',
          [base_theme.breakpoints.up(1315)]: {
            fontSize: '16px',
            lineHeight: '16px',
            letterSpacing: '2px',
          },
          [base_theme.breakpoints.down(667)]: {
            fontSize: '16px',
            lineHeight: '16px',
            letterSpacing: '2px',
          }
        },
        button: {
          fontFamily: 'Avenir',
          // backgroundColor: '#333749',
          // '&:hover': {
          // backgroundColor: '#333749'
          // }
        },
        default: {
          fontFamily: 'Avenir',
          // backgroundColor: '#333749'
        },
      },
    },
  });