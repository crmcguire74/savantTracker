import { createStore, combineReducers, applyMiddleware, compose } from 'redux'
import halo_reducer from './reducers/halo'
import logic from './logic/logic'
import thunk from 'redux-thunk'
import { createLogicMiddleware } from 'redux-logic';
import { createLogger } from 'redux-logger'
import { responsiveStoreEnhancer, responsiveStateReducer as browser } from 'redux-responsive'

const deps = { // optional injected dependencies for logic
               // anything you need to have available in your logic
  A_SECRET_KEY: 'dsfjsdkfjsdlfjls'
};

export default function configureStore(preloadedState) {
  const middleware = [createLogicMiddleware(logic, deps), thunk]
  if (process.env.NODE_ENV !== 'production') {
    middleware.push(createLogger())
  }
  // Add the reducer to your store on the `routing` key
  const store = createStore(
    combineReducers({halo_reducer, browser}),
    preloadedState,
    compose(
      responsiveStoreEnhancer,
      applyMiddleware(...middleware)
    )
  )

  return store
}