import IconSelect from './IconSelect'
import { set_value_buttons } from '../assessments/helpers'
import { STATIC_ROOT } from '../api-config'

export default {
  component: IconSelect,
  props: {
    value: 'Lorem ipsum',
    disabled: true,
    slide: {
      number: '4m',
      next: 5,
      back: 4,
      step: 3,
      type: 'iconselect',
      header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
      misc: {
        icon: {image: `${STATIC_ROOT}/images/icn_dumbell.svg`, clickable: false, active: true},
        title: "WHY IT MATTERS",
        body: "While BMI is a metric that provides a good baseline for understanding your body makeup and how it relates to your health, it isn't everything. BMI can be misleading if you are of above average muscular build and providing this information produces a more accurate longevity outlook."
      },
      question: {
        large: "Pick the option that matches closest to your body shape.",
        small: "BMI doesn't tell the whole story, your muscle mass has an affect on your longevity, too. To help us understand your muscular structure, we need a bit more information about your body shape."
      },
      inline: true,
      buttons: [{label: "Slim", store: 'musclemass', value: 0, action: 'setvaluenext', active: false},
        {label: "Athletic", store: 'musclemass', value: 1, action: 'setvaluenext', active: false},
        {label: "Muscular", store: 'musclemass', value: 2, action: 'setvaluenext', active: false},
        {label: "Oval", store: 'musclemass', value: 0, action: 'setvaluenext', active: false}],
      populate:
        (slide, store) => {
          var new_slide = Object.assign({}, slide)
          if (store.halo.gender === "female") {
            new_slide.buttons[3] = {label: "Oval", store: 'musclemass', value: 0, action: 'setvaluenext', active: false}
          }
          return new_slide
        },
      validate:
        (store) => {
          if (!store.halo_reducer.halo.hasOwnProperty("musclemass")) {
            return "Please select an option that best reflects your body type."
          }
        },
      set_value:
        (slide, store, value) => {
          return set_value_buttons(slide, value)
        },
    },
    version: 20,
  },
};