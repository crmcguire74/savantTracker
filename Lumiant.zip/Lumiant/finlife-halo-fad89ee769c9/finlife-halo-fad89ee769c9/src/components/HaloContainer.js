import React, { useEffect, useCallback } from 'react'
import { useDispatch, useMappedState } from 'redux-react-hook';
import Dialog from '@material-ui/core/Dialog/Dialog';
import CalcModal from './CalcModal';
import PropTypes from 'prop-types'
import {
  fetchAdvisor,
  close_halo,
  open_closedialog,
  fetchGetDetails
} from '../actions/hactions'
import HaloButton from './HaloButton';

const HaloContainer = ({element}) => {
  //Get dispatch
  const dispatch = useDispatch();
  //When container mounts fetchAdvisor info
  useEffect(() => {
    dispatch(fetchGetDetails())
    dispatch(fetchAdvisor())
  }, [])
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => {
      var isFinal = "final" in state.halo_reducer && state.halo_reducer.final != null
      return {
        open: state.halo_reducer.open,
        advisor: state.halo_reducer.advisor,
        isFinal: isFinal,
      }
    },
    []);
  const {
    open,
    advisor,
    isFinal
  } = useMappedState(mapState);


  const onClose = useCallback(
    (version, redirect, isFinal) => {
      if (version > 18) {
        dispatch(
          open_closedialog({
            message: "Are you sure you want to exit?",
            onConfirm: () => {
              (redirect !== "" && redirect != null && isFinal) ? window.location.replace(redirect) : dispatch(close_halo)
            },
          })
        )
      } else {
        dispatch(close_halo)
      }
    },
    [isFinal],
  );

  var autoOpen = false;

  var url = window.location.href
  if (element.classList.contains("halo-open") || (url.indexOf("halo-open") >= 0)) {
    autoOpen = true;
  }

  return (
    <div>
      <HaloButton advisor={advisor}/>
      <Dialog onClose={() => onClose(advisor.version, "redirect" in advisor ? advisor.redirect : "", isFinal)}
              open={open || autoOpen} children={<CalcModal/>}/>
    </div>
  )
}

HaloContainer.propTypes = {
  element: PropTypes.object,
}

export default HaloContainer