import React, { useCallback } from 'react'
import { useDispatch, useMappedState } from 'redux-react-hook';
import PropTypes from 'prop-types';
import Downshift from 'downshift';
import TextField from '@material-ui/core/TextField';
import Paper from '@material-ui/core/Paper';
import MenuItem from '@material-ui/core/MenuItem';
import { withStyles } from '@material-ui/core/styles';
import { set_value } from '../actions/hactions';
import { EN_AU, EN_GB, EN_NZ } from '../constants/locales';
import { STATE_SUGGESTIONS_AU, STATE_SUGGESTIONS_NZ, STATE_SUGGESTIONS_US } from '../constants/states';

function renderInput(inputProps) {
  const {classes, autoFocus, value, ref, ...other} = inputProps;

  return (
    <TextField
      autoFocus={autoFocus}
      className={classes.textField}
      value={value}
      inputRef={ref}
      InputProps={{
        classes: {
          input: classes.input,
        },
        ...other,
      }}
    />
  );
}

function renderSuggestion(params) {
  const {suggestion, index, itemProps, theme, highlightedIndex, selectedItem} = params;
  const isHighlighted = highlightedIndex === index;
  const isSelected = selectedItem === suggestion.label;

  return (
    <MenuItem
      {...itemProps}
      key={suggestion.value}
      selected={isHighlighted}
      component="div"
      style={{
        fontWeight: isSelected
          ? theme.typography.fontWeightMedium
          : theme.typography.fontWeightRegular,
      }}
    >
      {suggestion.value}
    </MenuItem>
  );
}

function renderSuggestionsContainer(options) {
  const {cContainerProps, children} = options;

  return (
    <Paper
      {...cContainerProps}
      square
      elevation={8}
      style={{
        position: 'relative',
        zIndex: 10000,
        maxHeight: '10rem',
        overflowY: 'auto'
      }}
    >
      {children}
    </Paper>
  );
}

function placeHolderCountry(locale) {
  switch (locale) {
    case EN_AU:
    case EN_GB:
    case EN_NZ:
      return "enter a state"
    default:
      return "enter a US state"
  }
}

function getSuggestions(inputValue, locale) {
  let count = 0;
  let stateSuggestions = STATE_SUGGESTIONS_US;

  if (locale === EN_AU) {
    stateSuggestions = STATE_SUGGESTIONS_AU;
  } else if (locale === EN_NZ) {
    stateSuggestions = STATE_SUGGESTIONS_NZ;
  }

  return stateSuggestions.filter(suggestion => {
    const userInputParser = inputValue.toLowerCase()
    const stateParser = suggestion.label.toLowerCase()

    // TODO: this filter logic will need to be tested to ensure it's reliable
    let keep =  (!inputValue || stateParser.startsWith(userInputParser) && count < 3)
    if (keep) {
      count += 1;
    }
    return keep;
  });
}

const styles = theme => ({
  container: {
    [theme.breakpoints.up(668)]: {
      width: '20vw',
      marginRight: '1.37063vw !important',
      height: '3.90114vw !important',
    },
    [theme.breakpoints.down(667)]: {
      width: '50%',
      marginRight: 'auto',
      marginLeft: 'auto',
      marginBottom: '3vw',
    },
  },
  textField: {
    width: '100%',
    textAlign: 'left',
  },
});

// not sure if this is best practice but will see if
const HaloDownshift = ({classes, theme, locale}) => {
  const placeholderCountry = placeHolderCountry(locale)
  const dispatch = useDispatch();
  const input_change = useCallback(
    (value, select) => (dispatch(set_value('select', select.store, value))),
    [],
  )
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => ({
      select: state.halo_reducer.slide.select,
    }),
    []);
  const {
    select,
  } = useMappedState(mapState);
  return (
    <Downshift
      onChange={(value) => {
        input_change(value, select)
      }}
      render={({
                 getInputProps,
                 getItemProps,
                 isOpen,
                 inputValue,
                 selectedItem,
                 highlightedIndex,
               }) => (
        /*TODO: create a helper method that will need */
        <div className={classes.container}>
          {renderInput(
            getInputProps({
              classes,
              placeholder: placeholderCountry,
              id: 'enter_a_us_state',
            }),
          )}
          {isOpen
            ? renderSuggestionsContainer({
              children: getSuggestions(inputValue, locale).map((suggestion, index) =>
                renderSuggestion({
                  suggestion,
                  index,
                  theme,
                  itemProps: getItemProps({item: suggestion.label}),
                  highlightedIndex,
                  selectedItem,
                }),
              ),
            })
            : null}
        </div>
      )}
    />
  );
}

HaloDownshift.propTypes = {
  classes: PropTypes.object.isRequired,
  theme: PropTypes.object.isRequired,
};

export default withStyles(styles, {withTheme: true})(HaloDownshift)
