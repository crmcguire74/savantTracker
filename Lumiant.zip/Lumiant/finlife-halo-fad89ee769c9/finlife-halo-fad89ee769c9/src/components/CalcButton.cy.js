import React from 'react'
import CalcButton from './CalcButton'

describe('<CalcButton />', () => {
  it('renders', () => {
    // see: https://on.cypress.io/mounting-react
    cy.mount(<CalcButton />)
  })
})