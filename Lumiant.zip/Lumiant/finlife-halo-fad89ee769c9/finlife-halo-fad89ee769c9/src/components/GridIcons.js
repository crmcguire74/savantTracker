import React, { useCallback } from 'react'
import { useDispatch } from 'redux-react-hook';
import PropTypes from 'prop-types'
import { set_value } from '../actions/hactions'
import './IconSelect.css';
import { STATIC_ROOT } from '../api-config'

const GridIcons = ({icons}) => {
  const dispatch = useDispatch();
  const icon_click = useCallback(
    (value, id, index, store) => {
      if (this.icons[index].clickable) {
        dispatch(set_value('select', store, value))
      }
    },
    [],
  )
  if (icons.length === 2) {
    return (
      <div className='gGIcons'>
        <div className='gGIconContainer' onClick={() => {
          this.props.icon_click(icons[0].value, 'icon0', 0, icons[0].store)
        }}>
          <figure className='gGFigure'>
            <img className='gGFigureImg' id={`icon_${icons[0].caption.toLowerCase()}`} alt={icons[0].action}
                 src={icons[0].active ? `${STATIC_ROOT}/images/icn_female.svg` : `${STATIC_ROOT}/images/icn_female_grey.svg`}/>
            <figcaption>{icons[0].caption}</figcaption>
          </figure>
          {icons[0].active && <div className='gGCircle'></div>}
        </div>
        <div className={'gGVerticalLine'}></div>
        <div className='gGIconContainer' onClick={() => {
          this.props.icon_click(icons[1].value, 'icon1', 1, icons[1].store)
        }}>
          <figure className='gGFigure'>
            <img className='gGFigureImg' id={`icon_${icons[1].caption.toLowerCase()}`} alt={icons[1].action}
                 src={icons[1].active ? `${STATIC_ROOT}/images/icn_male.svg` : `${STATIC_ROOT}/images/icn_male_grey.svg`}/>
            <figcaption>{icons[1].caption}</figcaption>
          </figure>
          {icons[1].active && <div className='gGCircle'></div>}
        </div>
      </div>
    )
  } else {
    return (
      <div className='gGIcons'>
        {icons.map((icon, index) => {
          return (
            <div key={index}>
              <figure className='gGFigure'>
                <img className='gGFigureImg' id={`icon_${icon.caption.toLowerCase()}`} onClick={() => {
                  this.props.icon_click(icon.value, 'icon' + index, index, icon.store)
                }} alt={icon.action} src={icon.current_image}/>
                <figcaption className='gGFigureCaption'>{icon.caption}</figcaption>
              </figure>
            </div>
          )
        })}
      </div>
    )
  }

}

GridIcons.propTypes = {
  icons: PropTypes.array,
}

export default GridIcons
