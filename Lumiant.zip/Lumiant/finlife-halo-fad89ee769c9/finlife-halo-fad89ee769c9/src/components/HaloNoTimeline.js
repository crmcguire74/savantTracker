import React, { useState, useCallback } from 'react';
import PropTypes from 'prop-types'
import { useDispatch, useMappedState } from 'redux-react-hook';
import MediaQuery from 'react-responsive';
import { withStyles } from '@material-ui/core/styles';
import './HaloTimeline.css';
import HaloHeader from './HaloHeader';
import { STATIC_ROOT } from '../api-config'
import { restart_halo, open_closedialog, button_action } from '../actions/hactions'
import { getTimeline } from './timeline';
import Grid from '@material-ui/core/Grid';
import CalcIconColor from './CalcIconColor';

const styles = () => ({
  root: {
    transform: 'rotate(90deg)',
  },
})

const HaloTimeline = ({classes, open}) => {
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => ({
      slide: state.halo_reducer.slide,
      halovalues: state.halo_reducer.final,
      advisor: state.halo_reducer.advisor,
    }),
    []);

  const {
    slide,
    halovalues,
    advisor,
  } = useMappedState(mapState);

  const dispatch = useDispatch();
  var onClose, onThirdAct

  if (advisor.version <= 21) {
    onClose = useCallback(
      (version, redirect) => (
        dispatch(
          open_closedialog({
            message: "Are you sure you want to exit?",
            onConfirm: () => {
              (redirect !== "" && redirect != null) ? window.location.replace(redirect) : dispatch(restart_halo)
            },
          })
        )
      ),
      [],
    )
  } else {
    onThirdAct = useCallback(
      (action, store, value) => (dispatch(button_action('next', '', ''))),
      [],
    )
  }

  const [confetti, setConfetti] = useState(false);

  if (advisor.version <= 19) {
    open = false
  }

  const confetticallback = (data) => {
    setConfetti(true)
  }

  const timelineData = getTimeline(halovalues, slide, advisor)
  // const steps = getSteps(halovalues.clientInformation, slide, advisor, confetti, timelineData)
  // console.log(steps)

  return (
    <div className='gContainer gTContainer'>
      <MediaQuery query="(max-width: 667px)">
        <HaloHeader header={slide.header} onClose={onClose} onThirdAct={onThirdAct} advisor={advisor}/>
        <div className='gTContentContainer'>
          <div className='gTQuestionContainer'>
            <div className='gTQuestionLarge'>{slide.question.large.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}</div>
            <div className='gTQuestionSmall'>{slide.question.small.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}</div>
            <Grid container spacing={10} justify="center" alignContent="center" style={{width: "85%"}}>
              <CalcIconColor size={4} color={"#CFB5D5"}
                             icon={{image: `${STATIC_ROOT}/images/icn_disease.svg`, active: true, clickable: false,}}/>
              <CalcIconColor size={4} color={"#B5E3F7"}
                             icon={{image: `${STATIC_ROOT}/images/icn-social.svg`, active: true, clickable: false,}}/>
              <CalcIconColor size={4} icon={{
                image: `${STATIC_ROOT}/images/icn_retirement.svg`,
                active: true,
                clickable: false,
              }}/>
            </Grid>
          </div>
        </div>
      </MediaQuery>
      <MediaQuery query="(min-width: 668px)">
        <HaloHeader header={slide.header} onClose={onClose} onThirdAct={onThirdAct} advisor={advisor}/>
        <div className='gTContentContainer'>
          <div className='gTQuestionContainer'>
            <div className='gTQuestionLarge'>{slide.question.large.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}</div>
            <div className='gTQuestionSmall'>{slide.question.small.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}</div>
          </div>
          <Grid container justify="center" alignContent="center">
            <CalcIconColor size={3} color={"#CFB5D5"}
                           icon={{image: `${STATIC_ROOT}/images/icn_disease.svg`, active: true, clickable: false,}}/>
            <CalcIconColor size={3} color={"#B5E3F7"}
                           icon={{image: `${STATIC_ROOT}/images/icn-social.svg`, active: true, clickable: false,}}/>
            <CalcIconColor size={3}
                           icon={{image: `${STATIC_ROOT}/images/icn_retirement.svg`, active: true, clickable: false,}}/>
          </Grid>
        </div>
      </MediaQuery>
    </div>
  )
}

HaloTimeline.propTypes = {
  classes: PropTypes.object,
  open: PropTypes.bool,
  confetti: PropTypes.bool,
  confetticallback: PropTypes.func,
}

export default (withStyles(styles))(HaloTimeline);