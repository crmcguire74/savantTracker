import { NRound } from './helpers'

export const getTimeline = (halovalues, slide, advisor) => {
  let checkboxes = Object.assign({}, slide.checks)
  let yearsLostAdjustment = 0
  let yearsAddedAdjustment = 0
  // let yearsAssistAdjustment = 0
  let yearsAssistAdjustmentKey = ""

  for (let key of Object.keys(checkboxes).sort()) {
    let disabled = false

    switch (key) {
      case 'alcoholC':
        disabled = Math.round(halovalues.yearsLostAdjustments.alcohol) > -1
        if (!disabled && !checkboxes[key].checked && advisor.version > 18) {
          yearsLostAdjustment += Math.round(halovalues.yearsLostAdjustments.alcohol)
        } else if ((Math.round(halovalues.yearsLostAdjustments.alcohol) >= 1) && advisor.version > 18) {
          yearsAddedAdjustment += Math.round(halovalues.yearsLostAdjustments.alcohol)
        }
        break;

      case 'fruitVegetableC':
        disabled = Math.round(halovalues.yearsLostAdjustments.fruitsVeggies) > -1
        if (!disabled && !checkboxes[key].checked && advisor.version > 18) {
          yearsLostAdjustment += Math.round(halovalues.yearsLostAdjustments.fruitsVeggies)
        } else if ((Math.round(halovalues.yearsLostAdjustments.fruitsVeggies) >= 1) && advisor.version > 18) {
          yearsAddedAdjustment += Math.round(halovalues.yearsLostAdjustments.fruitsVeggies)
        }
        break;

      case 'socialSupportC':
        disabled = Math.round(halovalues.yearsLostAdjustments.socialSupport) > -1
        if (!disabled && !checkboxes[key].checked && advisor.version > 19) {
          yearsLostAdjustment += Math.round(halovalues.yearsLostAdjustments.socialSupport)
        } else if ((Math.round(halovalues.yearsLostAdjustments.socialSupport) >= 1) && advisor.version > 19) {
          yearsAddedAdjustment += Math.round(halovalues.yearsLostAdjustments.socialSupport)
        }
        break;

      case 'bmiC':
        disabled = Math.abs(Math.round(halovalues.yearsLostAdjustments.bmi)) < 1
        if (!disabled && !checkboxes[key].checked) {
          yearsLostAdjustment += Math.round(halovalues.yearsLostAdjustments.bmi)
          yearsAssistAdjustmentKey += "bmi"
        }
        break;

      case 'exercisesC':
        disabled = halovalues.clientInformation.exercises
        if (!disabled && !checkboxes[key].checked) {
          yearsLostAdjustment += halovalues.yearsLostAdjustments.exercise
          yearsAssistAdjustmentKey += "exercise"
        }
        break;

      case 'smokingC':
        disabled = !halovalues.clientInformation.smokes
        if (!disabled && halovalues.yearsLostAdjustments.smoking > 0){
          disabled = true
          yearsAssistAdjustmentKey += "smoking"
        }
        
        if (!disabled && !checkboxes[key].checked) {
          if (halovalues.yearsLostAdjustments.smoking < 0 ){
            yearsLostAdjustment += Math.round(halovalues.yearsLostAdjustments.smoking)
            yearsAssistAdjustmentKey += "smoking"
          }
        }
        break;

      default:
        break;
    }

    checkboxes[key].disabled = disabled
    checkboxes[key].checked = disabled || checkboxes[key].checked
  }

  if (yearsAssistAdjustmentKey === "") {
    yearsAssistAdjustmentKey = "none"
  }

  // yearsAssistAdjustment = NRound(halovalues.yearsAssistedAdjustments[yearsAssistAdjustmentKey])
  let age = halovalues.timeline.age
  let retirementAge = halovalues.timeline.retirementAge
  let adjustedLifespan = NRound(halovalues.timeline.roundedLifespan - halovalues.timeline.yearsOfLifeLost + yearsLostAdjustment)
  let preRetirementActiveYears = retirementAge - age
  let disabilityYears = NRound(halovalues.timeline.disabilityYears + halovalues.yearsAssistedAdjustments[yearsAssistAdjustmentKey])

  if (age >= retirementAge) {
    preRetirementActiveYears = 0
    retirementAge = age
  } else if (retirementAge > (adjustedLifespan - disabilityYears)) {
    preRetirementActiveYears = adjustedLifespan - disabilityYears - age
  }

  let postRetirementActiveYears = adjustedLifespan - disabilityYears - retirementAge
  let disabilityAge = adjustedLifespan - disabilityYears

  if (postRetirementActiveYears < 0) {
    postRetirementActiveYears = 0

    if (disabilityAge < age) {
      disabilityAge = age
      disabilityYears = adjustedLifespan - disabilityAge
    }
  }

  let actWidth = ((0 < preRetirementActiveYears) && (preRetirementActiveYears < 4)) ? 4 : preRetirementActiveYears
  let retWidth = ((0 < postRetirementActiveYears) && (postRetirementActiveYears < 4)) ? 4 : postRetirementActiveYears
  let astWidth = ((0 < disabilityYears) && (disabilityYears < 4)) ? 4 : disabilityYears
  let totWidth = actWidth + retWidth + astWidth
  const mq = window.matchMedia("(max-width: 667px)");
  let widthMultiplier, activeWidth, retireWidth, assistedWidth, totalWidth

  if (mq.matches) {
    widthMultiplier = 95 / totWidth
    activeWidth = 200 * actWidth / totWidth > 95 ? "95%" : parseInt(200 * actWidth / totWidth, 10) + "%"
    retireWidth = 200 * retWidth / totWidth > 95 ? "95%" : parseInt(200 * retWidth / totWidth, 10) + "%"
    assistedWidth = 200 * astWidth / totWidth > 95 ? "95%" : parseInt(200 * astWidth / totWidth, 10) + "%"
    totalWidth = parseInt(widthMultiplier * totWidth, 10) + "%"
  } else {
    widthMultiplier = 75 / totWidth
    activeWidth = parseInt(200 * actWidth / totWidth, 10) + "%"
    retireWidth = parseInt(200 * retWidth / totWidth, 10) + "%"
    assistedWidth = parseInt(200 * astWidth / totWidth, 10) + "%"
    totalWidth = parseInt(widthMultiplier * totWidth, 10) + "%"
  }

  let displayAct = actWidth <= 0 ? "none" : "block"
  let displayRet = retWidth <= 0 ? "none" : "block"
  let displayAst = astWidth <= 0 ? "none" : "block"
  let displayFooter = astWidth + retWidth + actWidth <= 0 ? "none" : "flex"
  let displayRetGoal = retirementAge <= age ? "hidden" : "visible"
  let costYears = disabilityYears
  let disabilityYearsDisplay = parseInt(NRound(disabilityYears), 10) + " years"
  let costPerYear = halovalues.disabilityAndLongTermCare.annualCostsWhenNeeded.assistedLivingPrivateRoomCost

  if (advisor.onevtotal === "one") {
    costYears = 1
    disabilityYearsDisplay = "1 year"
  }

  if (advisor.todayvfuture === "today") {
    costPerYear = halovalues.disabilityAndLongTermCare.annualCostsToday.assistedLivingPrivateRoomCost
  }

  let totalOutOfPocketCosts = NRound(costYears * costPerYear)
  let outOfPocketCost = totalOutOfPocketCosts.toLocaleString()

  return {
    checkboxes: checkboxes,
    displayAct: displayAct,
    displayAst: displayAst,
    displayRet: displayRet,
    displayRetGoal: displayRetGoal,
    displayFooter: displayFooter,
    outOfPocketCost: outOfPocketCost,
    activeWidth: activeWidth,
    retireWidth: retireWidth,
    assistedWidth: assistedWidth,
    totalWidth: totalWidth,
    age: age,
    retirementAge: retirementAge,
    postRetirementActiveYears: postRetirementActiveYears,
    disabilityAge: disabilityAge,
    disabilityYears: disabilityYears,
    disabilityYearsDisplay: disabilityYearsDisplay,
    adjustedLifespan: adjustedLifespan,
    preRetirementActiveYears: preRetirementActiveYears,
    yearsLostAdjustment: yearsLostAdjustment,
  }
}