import React, { useCallback } from 'react'
import { useDispatch, useMappedState } from 'redux-react-hook';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { close_closedialog, close_halo } from '../actions/hactions'

const CloseDialog = () => {
  const dispatch = useDispatch();
  const onConfirmClick = useCallback(
    () => (dispatch(close_halo)),
    [],
  )
  const onDenyClick = useCallback(
    () => (dispatch(close_closedialog)),
    [],
  )
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => ({
      closedialog: state.halo_reducer.closedialog,
    }),
    []);
  const {
    closedialog,
  } = useMappedState(mapState);

  return (
    <Dialog
      open={closedialog.open}
      onClose={() => onDenyClick()}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {"options" in closedialog && "title" in closedialog.options &&
        <DialogTitle id="alert-dialog-title">{closedialog.options.title}</DialogTitle>}
      <DialogContent>
        <DialogContentText id="alert-dialog-description" style={{fontFamily: 'Avenir', color: 'black'}}>
          {"options" in closedialog ? closedialog.options.message : ''}
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={
          () => closedialog.options && typeof closedialog.options.onConfirm === "function" ? closedialog.options.onConfirm() : onConfirmClick()
        } color="primary">
          Exit
        </Button>
        <Button onClick={() => onDenyClick()}
                color="primary"
                autoFocus>
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default CloseDialog;