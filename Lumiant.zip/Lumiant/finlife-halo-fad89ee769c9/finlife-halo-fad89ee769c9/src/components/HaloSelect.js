import React, { useCallback } from 'react'
import { useDispatch, useMappedState } from 'redux-react-hook';
import PropTypes from 'prop-types';
import Select from 'react-select';
import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import Paper from '@material-ui/core/Paper';
import MenuItem from '@material-ui/core/MenuItem';
import { set_value } from '../actions/hactions';
import './IconSelect.css'

const styles = theme => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  formroot: {
    width: '20vw',
  },
  selectroot: {
    color: '#333749',
    marginTop: '0px',
  },
  formControl: {
    marginTop: '30px !important',
  },
  // root: {
  //   flexGrow: 1,
  //   height: 250,
  // },
  input: {
    display: 'flex',
    padding: 0,
    color: '#333749',
  },
  valueContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    flex: 1,
    alignItems: 'center',
    overflow: 'hidden',
    color: '#333749 !important',
  },
  noOptionsMessage: {
    padding: `${theme.spacing.unit}px ${theme.spacing.unit * 2}px`,
  },
  // singleValue: {
  //   fontSize: 16,
  // },
  placeholder: {
    color: '#333749 !important',
    //   position: 'absolute',
    //   left: 2,
    //   fontSize: 16,
  },
  paper: {
    position: 'absolute',
    zIndex: 1,
    marginTop: theme.spacing.unit,
    fontFamily: 'Avenir',
    left: 0,
    right: 0,
    minHeight: '75px',
    height: '12.5vw',
    maxHeight: '150px',
    overflowY: 'scroll',
  },
  divider: {
    height: theme.spacing.unit * 2,
  },
});


function NoOptionsMessage(props) {
  return (
    <Typography
      color="textSecondary"
      className={props.selectProps.classes.noOptionsMessage}
      {...props.innerProps}
    >
      {props.children}
    </Typography>
  );
}

function inputComponent({inputRef, ...props}) {
  return <div ref={inputRef} {...props} />;
}

function Control(props) {
  return (
    <TextField
      // style={{color:'#333749'}}
      fullWidth
      InputProps={{
        inputComponent,
        inputProps: {
          className: props.selectProps.classes.input,
          inputRef: props.innerRef,
          children: props.children,
          ...props.innerProps,
        },
      }}
      {...props.selectProps.textFieldProps}
    />
  );
}

function Option(props) {
  return (
    <MenuItem
      buttonRef={props.innerRef}
      selected={props.isFocused}
      component="div"
      {...props.innerProps}
    >
      {props.children}
    </MenuItem>
  );
}

function Placeholder(props) {
  return (
    <div
      color={props.theme.colors.primary}
      className={props.selectProps.classes.placeholder}
      {...props.innerProps}
    >
      {props.children}
    </div>
  );
}

function SingleValue(props) {
  return (
    <Typography className={props.selectProps.classes.singleValue} {...props.innerProps}>
      {props.children}
    </Typography>
  );
}

function ValueContainer(props) {
  return <div style={{color: '#333749 !important'}}
              className={props.selectProps.classes.valueContainer}>{props.children}</div>;
}

function Menu(props) {
  return (
    <Paper square className={props.selectProps.classes.paper} {...props.innerProps}>
      {props.children}
    </Paper>
  );
}

const components = {
  Control,
  Menu,
  // MultiValue,
  // NoOptionsMessage,
  Option,
  Placeholder,
  // SingleValue,
  ValueContainer,
};

const IntegrationReactSelect = ({classes, theme}) => {
  const dispatch = useDispatch();
  const input_change = useCallback(
    (value, suggest) => (dispatch(set_value('suggest', suggest.store, value))),
    [],
  )
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => ({
      suggestions: state.halo_reducer.slide.misc.suggestions,
    }),
    []);
  const {
    suggestions,
  } = useMappedState(mapState);

  const selectStyles = {
    input: base => ({
      ...base,
      color: theme.palette.text.primary,
      '& input': {
        font: 'inherit',
      },
    }),
    control: (base, state) => ({
      ...base,
      height: '34px',
      'min-height': '34px',
    }),
    valueContainer: base => ({
      ...base,
      backgroundColor: '#red !important',
      minHeight: '50px',
    }),
    menuList: base => ({
      ...base,
      minHeight: 'fit-content',
    }),
  };

  return (
    <div className={classes.root}>
      <Select
        theme={theme}
        classes={classes}
        className='gMiscInput'
        styles={selectStyles}
        options={suggestions.options}
        components={components}
        // value={suggestions.value}
        onChange={(value) => {
          input_change(value, suggestions)
        }}
        placeholder={suggestions.hint}
      />
    </div>
  );
}

IntegrationReactSelect.propTypes = {
  classes: PropTypes.object.isRequired,
  theme: PropTypes.object.isRequired,
};

export default withStyles(styles, {withTheme: true})(IntegrationReactSelect)