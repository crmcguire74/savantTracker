import React, { useCallback } from 'react'
import { useDispatch } from 'redux-react-hook';
import PropTypes from 'prop-types';
import MediaQuery from 'react-responsive';
import { set_value } from '../actions/hactions';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel'
import Checkbox from '@material-ui/core/Checkbox';
import { withStyles } from '@material-ui/core/styles';
import Floater from 'react-floater';
import { STATIC_ROOT } from '../api-config'
import './HaloTimeline.css';

const styles = theme => ({
  root: {
    marginRight: '1.0950570342vw',
    marginLeft: '-0.9581749049vw',
    [theme.breakpoints.up(1315)]: {
      marginRight: '15px',
      marginLeft: '-13px',
    },
    [theme.breakpoints.down(667)]: {
      marginRight: '0px',
      marginLeft: '0px',
    }
  },
  checkboxroot: {
    padding: '0px',
  },
  label: {
    color: '#686868 !important',
    fontFamily: 'Avenir',
    fontSize: '1.23357vw',
    fontWeight: '500',
    lineHeight: '1.43916vw',
    marginRight: '2.0532319392vw',
    marginLeft: '0.6844106464vw',
    [theme.breakpoints.up(1315)]: {
      fontSize: '16px',
      lineHeight: '18px',
      marginRight: '27px',
      marginLeft: '9px',
    },
    [theme.breakpoints.down(667)]: {
      fontSize: '16px',
      lineHeight: '18px',
      // marginRight: '27px',
      // marginLeft: '9px',
    }
  },
  default: {
    height: '3.2851711027vw',
    width: '3.2851711027vw',
    [theme.breakpoints.up(1315)]: {
      height: '44px',
      width: '44px',
    },
    [theme.breakpoints.down(667)]: {
      height: '44px',
      width: '44px',
    }
  }
})
const CheckboxFormC = ({checks, classes}) => {
  const dispatch = useDispatch();
  const input_change = useCallback(
    (event, attribute) => (dispatch(set_value('toggle', attribute, event.target.checked))),
    [],
  )

  return (
    <div>
      <MediaQuery query="(max-width: 667px)">
        <FormGroup
          children={
            <div style={{display: 'block'}}>
              {Object.keys(checks).map((check, index) => {
                return <FormControlLabel classes={{root: classes.root, label: classes.label}} key={index}
                                         value={checks[check].value}
                                         control={
                                           <Checkbox disabled={checks[check].disabled}
                                                     checked={checks[check].checked}
                                                     classes={{default: classes.default, root: classes.checkboxroot}}
                                                     onChange={(event) => {
                                                       input_change(event, check)
                                                     }}
                                                     checkedIcon={<div
                                                       style={{display: 'flex', height: '44px', width: '44px'}}><img
                                                       className={`checkedIcon ${!checks[check].disabled ? 'enabledCheck' : ''}`}
                                                       src={`${STATIC_ROOT}/images/check.png`} alt={"check"}/>
                                                       <img
                                                         className={`checkedCircle ${!checks[check].disabled ? 'enabledCheck' : ''}`}
                                                         src={`${STATIC_ROOT}/images/checkcircle.png`} alt={"circle"}/>
                                                     </div>}
                                                     icon={<div
                                                       style={{display: 'flex', height: '44px', width: '44px'}}><img
                                                       className={`uncheckCircle ${!checks[check].disabled ? 'enabledCheck' : ''}`}
                                                       src={`${STATIC_ROOT}/images/checkcircle.png`} alt={"circle"}/>
                                                     </div>}
                                           />} label={checks[check].hover != "" ?
                  <Floater
                    event="hover"
                    eventDelay={0}
                    placement="top"
                    style={{width: '100%'}}
                    showCloseButton={true}
                    styles={{
                      floater: {
                        zIndex: "99999999",
                        width: 'auto',
                        maxWidth:'50%'
                      },
                      content: {
                        fontFamily: 'Avenir',
                        fontSize: '1vm',
                      },
                      container: {
                        borderRadius: '5px',
                        color: '#ffffff',
                        textAlign: 'left',
                        // width: '50vw',
                        // maxWidth: '750px',
                        backgroundColor: '#686868',
                      },
                      arrow: {
                        color: '#686868',
                      },
                    }}
                    content={checks[check].hover}
                  >
                    <div>{checks[check].label}</div>
                  </Floater> : <div>{checks[check].label}</div>}/>
              })
              }
            </div>
          }/>
      </MediaQuery>
      <MediaQuery query="(min-width: 668px)">
        <FormGroup
          children={
            <div style={{display: 'flex'}}>
              {Object.keys(checks).map((check, index) => {
                return <FormControlLabel classes={{root: classes.root, label: classes.label}} key={index}
                                         value={checks[check].value}
                                         control={
                                           <Checkbox disabled={checks[check].disabled}
                                                     checked={checks[check].checked}
                                                     classes={{default: classes.default}}
                                                     onChange={(event) => {
                                                       input_change(event, check)
                                                     }}
                                                     checkedIcon={<div style={{display: 'flex'}}><img
                                                       className={`checkedIcon ${!checks[check].disabled ? 'enabledCheck' : ''}`}
                                                       src={`${STATIC_ROOT}/images/check.png`} alt={"check"}/>
                                                       <img
                                                         className={`checkCircle ${!checks[check].disabled ? 'enabledCheck' : ''}`}
                                                         src={`${STATIC_ROOT}/images/checkcircle.png`} alt={"circle"}/>
                                                     </div>}
                                                     icon={<div style={{display: 'flex'}}><img
                                                       className={`uncheckCircle ${!checks[check].disabled ? 'enabledCheck' : ''}`}
                                                       src={`${STATIC_ROOT}/images/checkcircle.png`} alt={"circle"}/>
                                                     </div>}
                                           />} label={checks[check].hover != "" ?
                  <Floater
                    event="hover"
                    eventDelay={0}
                    placement="top"
                    style={{width: '100%'}}
                    styles={{
                      floater: {
                        zIndex: "99999999",
                        width: 'auto',
                        maxWidth: '50%'
                      },
                      content: {
                        fontFamily: 'Avenir',
                        fontSize: '1.6vw',
                        lineHeight: '2.5vw',
                      },
                      container: {
                        borderRadius: '5px',
                        color: '#ffffff',
                        textAlign: 'left',
                        // width: '50vw',
                        // maxWidth: '750px',
                        backgroundColor: '#686868',
                      },
                      arrow: {
                        color: '#686868',
                      },
                    }}
                    content={checks[check].hover}
                  >
                    <div>{checks[check].label}</div>
                  </Floater> : <div>{checks[check].label}</div>}/>
              })
              }
            </div>
          }/>
      </MediaQuery>
    </div>
  )
}

CheckboxFormC.propTypes = {
  checks: PropTypes.object,
  classes: PropTypes.object,
}

export default withStyles(styles)(CheckboxFormC)
