import React from 'react';
import Confetti from 'react-dom-confetti'
import {EN_AU, EN_US} from "../constants/locales";

const confetticonfig = {
  angle: 90,
  spread: 85,
  startVelocity: 45,
  elementCount: 100,
  dragFriction: 0.1,
  duration: '10000',
  delay: '25',
  width: "10px",
  height: "10px",
  colors: ["#a864fd", "#29cdff", "#78ff44", "#ff718d", "#fdff6a"]
};

export const getSteps = (clientInformation, slide, advisor, confetti, timelineData) => {

  let introText = advisor.locale === EN_AU ? "personalised" : "personalized"

  var steps = [
    {
      content: <div id="step1">
        <h2>Congratulations {clientInformation.firstName} on completing your HALO Planner!</h2>
        <br></br>You are one step closer to improving your financial and personal health. Let's take a closer look at
        your {introText} results.
        <div style={{margin: 'auto', width: '1%'}}><Confetti active={confetti} config={confetticonfig}/></div></div>,
      placement: 'center',
      target: '.gc-modal',
      disableBeacon: true,
      styles: {
        buttonNext: {
          backgroundColor: 'transparent',
          border: '1px solid black',
          color: 'black'
        },
        buttonBack: {
          color: 'black'
        },
        tooltip: {
          fontFamily: 'Charter',
          maxWidth: 'unset',
        },
      }
    },
    {
      content: 'This is your longevity healthspan. It shows your projected number of active "go-go" years and assisted "slow-go" years. It also shows your total predicted longevity.',
      placement: 'top',
      target: '.gTimelineContainer',
      disableBeacon: true,
      styles: {
        buttonNext: {
          backgroundColor: 'transparent',
          border: '1px solid black',
          color: 'black'
        },
        buttonBack: {
          color: 'black'
        },
        tooltip: {
          maxWidth: '50%',
        },
      }
    },
    {
      target: '.gTActiveYearsBar',
      content: slide.timeline.active.hover,
      disableBeacon: true,
      placement: "top",
      styles: {
        options: {
          arrowColor: '#0D9000'
        },
        tooltip: {
          color: '#ffffff',
          textAlign: 'left',
          backgroundColor: '#0D9000',
          maxWidth: '50%',
        },
      }
    },
    {
      target: '.gTRetireYearsBar',
      content: slide.timeline.retire.hover,
      disableBeacon: true,
      placement: "top",
      styles: {
        options: {
          arrowColor: '#11BC01'
        },
        tooltip: {
          color: '#ffffff',
          textAlign: 'left',
          backgroundColor: '#11BC01',
          maxWidth: '50%',
        },
      }
    },
  ]
  if(advisor.locale === EN_US){
       steps.push( {
      target: '.gTAssistedYearsBar',
      content: [...slide.timeline.assisted.hover.slice(0, 1), timelineData.disabilityYearsDisplay, slide.timeline.assisted.hover.slice(2, 3), timelineData.outOfPocketCost, slide.timeline.assisted.hover.slice(4, 5)],
      disableBeacon: true,
      placement: "top",
      styles: {
        options: {
          arrowColor: '#FE912A'
        },
        tooltip: {
          color: '#ffffff',
          textAlign: 'left',
          backgroundColor: '#FE912A',
          maxWidth: '50%',
          marginRight: '2em'

        },
      }
    })
  }
  if(advisor.locale === EN_AU){
    steps.push( {
      target: '.gTAssistedYearsBar',
      content: [...slide.timeline.assisted.hover.slice(0,1)],
      disableBeacon: true,
      placement: "top",
      styles: {
        options: {
          arrowColor: '#FE912A'
        },
        tooltip: {
          color: '#ffffff',
          textAlign: 'left',
          backgroundColor: '#FE912A',
          maxWidth: '50%',
          marginRight: '2em'
        },
      }
    })
  }

  if ("mortality" in slide.timeline) {
    steps.push({
      target: '#adjustedLifespan',
      content: slide.timeline.mortality.hover,
      disableBeacon: true,
      placement: "top",
      styles: {
        options: {
          arrowColor: '#686868',
        },
        tooltip: {
          color: '#ffffff',
          textAlign: 'left',
          backgroundColor: '#686868',
          //marginRight: 'unset',
          marginRight: '2em',
          maxWidth: '60%',
        },
      }
    })
  }
  if (Math.round(timelineData.yearsLostAdjustment) <= -1) {
    steps.push({
      target: Math.round(timelineData.yearsLostAdjustment) <= -1 ? '.gTYearsLostActive' : '.gTYearsLostInactive',
      content: slide.timeline.lost.hover,
      disableBeacon: true,
      placement: "top",
      styles: {
        options: {
          arrowColor: Math.round(timelineData.yearsLostAdjustment) <= -1 ? '#E94E29' : '#686868',
        },
        tooltip: {
          color: '#ffffff',
          textAlign: 'left',
          backgroundColor: Math.round(timelineData.yearsLostAdjustment) <= -1 ? '#E94E29' : '#686868',
          marginLeft: 'unset',
          marginRight: 'unset',
          maxWidth: '40%',
        },
      }
    })
    steps.push({
      target: '.gTBehaviors',
      content: "Find out how making changes to your lifestyle can impact your health and longevity by clicking on the unchecked options below.",
      disableBeacon: true,
      placement: "top",
      styles: {
        options: {
          arrowColor: '#fff',
        },
        buttonNext: {
          backgroundColor: 'transparent',
          border: '1px solid black',
          color: 'black'
        },
        buttonBack: {
          color: 'black'
        },
        tooltip: {
          color: 'black',
          textAlign: 'left',
          maxWidth: '40%',
        },
      }
    })
  } else {
    steps.push({
      target: '.gTFooterContainer',
      content: "Awesome job! Your lifestyle behaviors are optimizing your longevity, keep up the good work!",
      disableBeacon: true,
      placement: "top",
      styles: {
        options: {
          arrowColor: '#686868',
        },
        tooltip: {
          color: '#ffffff',
          textAlign: 'left',
          backgroundColor: '#686868',
          maxWidth: '40%',
        },
      }
    })
  }
  return steps
}