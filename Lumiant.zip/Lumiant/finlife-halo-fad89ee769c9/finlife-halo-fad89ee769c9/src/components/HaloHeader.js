import React from 'react';
import PropTypes from 'prop-types'
import MediaQuery from 'react-responsive';
import './IconSelect.css';
import IconButton from '@material-ui/core/IconButton';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import Close from '@material-ui/icons/Close'

const styles = theme => ({
  label: {
    width: '5.81749vw',
    height: '1.91635vw',
    maxWidth: '85px !important',
    maxHeight: '28px !important',
    minHeight: '0px',
    minWidth: '0px',
  },
  root: {
    backgroundColor: 'transparent',
  },
  buttonroot: {
    minWidth: 'unset',
  },
})

const HaloHeader = ({header, onClose, advisor, onThirdAct, classes}) => (
  <div className='gHeaderContainer'>
    <div className='gHeader'>
      <div className='gHeaderLogo'><img className={'gHeaderLogo'} src={header.logo} alt='Halo Logo'/></div>
      <div className='gHeaderLabel'>
        <div style={{display: 'table', height: '100%', width: '100%', overflow: 'hidden'}}>
          <div style={{display: 'table-cell', verticalAlign: 'middle'}}>
            {header.text}
          </div>
        </div>
      </div>
    </div>
    <MediaQuery query="(max-width: 667px)">
      {onClose &&
        <div style={{
          position: 'absolute',
          top: '0',
          right: '0',
        }}>
          <IconButton children={<Close style={{
            height: '5vw',
            width: '5vw',
          }}/>} onClick={() => onClose(advisor.version, "redirect" in advisor ? advisor.redirect : "")}/>
        </div>
      }
      {onThirdAct &&
        <div id="thirdact" style={{
          position: 'absolute',
          top: '25px',
          right: '0',
        }}>
          <Button classes={{label: classes.label, root: classes.label}} className='gFooterButton'
                  style={{float: 'left'}} onClick={() => onThirdAct()}>
            <KeyboardArrowRight className='gFooterIcon'/>
          </Button>
        </div>
      }
    </MediaQuery>
    <MediaQuery query="(min-width: 668px)">
      {onClose &&
        <div style={{
          position: 'absolute',
          top: '1.11189vw',
          right: '1.11189vw',
        }}>
          <IconButton children={<Close style={{
            height: '1.958174904942966vw',
            width: '1.958174904942966vw',
          }}/>} onClick={() => onClose(advisor.version, "redirect" in advisor ? advisor.redirect : "")}/>
        </div>
      }
      {onThirdAct &&
        <div id="thirdact" style={{
          position: 'absolute',
          top: '0',
          right: '0', padding: '35px'
        }}>
          <Button classes={{label: classes.label, root: classes.label}} className='gFooterButton'
                  style={{float: 'left'}} onClick={() => onThirdAct()}>
            NEXT<KeyboardArrowRight className='gFooterIcon'/>
          </Button>
        </div>
      }
    </MediaQuery>
  </div>
)

HaloHeader.propTypes = {
  header: PropTypes.object.isRequired,
  onClose: PropTypes.func,
  advisor: PropTypes.object,
  onThirdAct: PropTypes.func,
}

export default withStyles(styles)(HaloHeader);