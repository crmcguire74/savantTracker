import React, { useCallback } from 'react'
import { useDispatch, useMappedState } from 'redux-react-hook';
import { set_value } from '../actions/hactions';
import TextField from '@material-ui/core/TextField';
import './IconSelect.css'
import CalcButton from './CalcButton'

const CalcInputs = ({buttons, buttonContainerStyle}) => {
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => ({
      inputs: state.halo_reducer.slide.inputs,
    }),
    []);
  const {
    inputs,
  } = useMappedState(mapState);
  const dispatch = useDispatch();
  const input_change = useCallback(
    (event, input) => (dispatch(set_value('input', input.store, input.type === 'number' ? parseInt(event.target.value, 10) : event.target.value))),
    [],
  )

  return (
    <div className='gInputGrouping'>
      {inputs.map((input, index) => {
        return (
          <TextField className='gInput' id={input.hint.replace(/(\s|\(|\))/g, "_").toLowerCase()} key={index}
                     type={input.type} placeholder={input.hint} label={<span className={'gInputLabel'}> {input.hint} </span>} name={input.name} value={input.value}
                     onChange={(event) => {
                       input_change(event, input)
                     }}/>
        )
      })}
      {buttons && buttons.length > 0 &&
        <CalcButton cssStyle={'gButton'} buttons={buttons} buttonContainerStyle={buttonContainerStyle}/>}
    </div>
  )
}

export default CalcInputs
