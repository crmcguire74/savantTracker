/* eslint-disable jsx-a11y/mouse-events-have-key-events */

import React from 'react';
import PropTypes from 'prop-types';
import Popover from '@material-ui/core/Popover';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
  paper: {
    fontFamily: 'Avenir',
    fontSize: '1.9vw',
    lineHeight: '2.5vw',
    color: '#4F4F4F',
    width: '50vw',
    maxWidth: '750px',
    backgroundColor: 'transparent',
    boxShadow: 'none',
    [theme.breakpoints.down(667)]: {
      width: '89vw',
      fontSize: '5.0965vw',
      lineHeight: '7.1329vw',
    }
  },
  popover: {
    pointerEvents: 'none',
  },
  popperClose: {
    pointerEvents: 'none',
  },
  privacyPopover: {
    background: '#EBEBEB',
    borderRadius: '5px',
    color: '#ffffff',
    textAlign: 'left',
    padding: '15px',
    zIndex: '-1',
  },
  arrowDown: {
    width: '0px',
    height: '0px',
    borderLeft: '20px solid transparent',
    borderRight: '20px solid transparent',
    borderTop: '20px solid transparent',
  }
});

class DivPopoverC extends React.Component {
  constructor(props, context) {
    super(props, context)
    this.handlePopoverOpen = this.handlePopoverOpen.bind(this);
    this.handlePopoverClose = this.handlePopoverClose.bind(this);
    this.state = {
      anchorEl: null,
      backgroundColor: '',
      color: '',
    }
  }

  handlePopoverOpen(event) {
    if (this.props.child.props.className !== '') {
      var elem = document.querySelector('.' + this.props.child.props.className);
      if (elem !== null) {
        var style = window.getComputedStyle(elem);
        this.setState({anchorEl: event.target, backgroundColor: style.backgroundColor, color: '#ffffff'});
      } else {
        this.setState({anchorEl: event.target, backgroundColor: '#EBEBEB', color: '#4F4F4F',});
      }
    } else {
      this.setState({anchorEl: event.target, backgroundColor: '#EBEBEB', color: '#4F4F4F',});
    }
  };

  handlePopoverClose() {
    this.setState({anchorEl: null});
  };

  render() {
    const {child, childClass, popover, classes} = this.props;
    const {anchorEl, backgroundColor, color} = this.state;
    const open = !!anchorEl;

    return (
      <div className={childClass} onMouseOver={this.handlePopoverOpen} onMouseOut={this.handlePopoverClose}>
        {child}
        {popover &&
          <Popover
            className={classes.popover}
            classes={{
              paper: classes.paper,
            }}
            open={open}
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            onClose={this.handlePopoverClose}
          >
            {popover.length > 0 &&
              <div className={classes.privacyPopover} style={{backgroundColor: backgroundColor, color: color}}>
                {popover instanceof Array ?
                  popover.map((text, index) => {
                    return (<span key={index}>{text}</span>)
                  }) : popover}
              </div>}
            {popover.length > 0 && <div style={{
              width: '0px',
              height: '0px',
              borderLeft: '20px solid transparent',
              borderRight: '20px solid transparent',
              borderTop: '20px solid ' + backgroundColor,
              margin: 'auto',
            }}></div>}
          </Popover>}
      </div>
    );
  }
}

DivPopoverC.propTypes = {
  child: PropTypes.node,
  childClass: PropTypes.string,
  popover: PropTypes.array,
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(DivPopoverC);