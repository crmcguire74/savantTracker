import React from 'react';
import PropTypes from 'prop-types'
import Grid from '@material-ui/core/Grid';
import './IconSelect.css'

const CalcIconColor = ({icon, color, size}) => (
  <Grid item xs={size}>
    <div>
      <figure className='gNoTFigure'>
        <img className='gNoTFigureImg' alt={icon.action} src={icon.image}/>
        {icon.caption && <figcaption>{icon.caption}</figcaption>}
      </figure>
      {icon.active && <div className='gNoTCircle' style={{backgroundColor: color}}></div>}
    </div>
  </Grid>
)

CalcIconColor.propTypes = {
  icon: PropTypes.object,
}

export default CalcIconColor