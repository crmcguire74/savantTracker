import React, { useCallback } from 'react'
import { useDispatch, useMappedState } from 'redux-react-hook';
import { set_value } from '../actions/hactions'
import './IconSelect.css';
import { STATIC_ROOT } from '../api-config'

const CalcIcons = () => {
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => ({
      icons: state.halo_reducer.slide.icons,
    }),
    []);
  const {
    icons,
  } = useMappedState(mapState);
  const dispatch = useDispatch();
  const icon_click = useCallback(
    (value, id, index, store) => {
      if (icons[index].clickable) {
        dispatch(set_value('select', store, value))
      }
    },
    [],
  )

  if (icons.length === 2) {
    return (
      <div className='gIcons'>
        <div className='gIconContainer' onClick={() => {
          icon_click(icons[0].value, 'icon0', 0, icons[0].store)
        }}>
          <figure className='gFigure'>
            <img className='gFigureImg' id={`icon_${icons[0].caption.toLowerCase()}`} alt={icons[0].action}
                 src={icons[0].active ? `${STATIC_ROOT}/images/icn_female.svg` : `${STATIC_ROOT}/images/icn_female_grey.svg`}/>
            <figcaption>{icons[0].caption}</figcaption>
          </figure>
          {icons[0].active && <div className='gCircle'></div>}
        </div>
        <div className={'gVerticalLine'}></div>
        <div className='gIconContainer' onClick={() => {
          icon_click(icons[1].value, 'icon1', 1, icons[1].store)
        }}>
          <figure className='gFigure'>
            <img className='gFigureImg' id={`icon_${icons[1].caption.toLowerCase()}`} alt={icons[1].action}
                 src={icons[1].active ? `${STATIC_ROOT}/images/icn_male.svg` : `${STATIC_ROOT}/images/icn_male_grey.svg`}/>
            <figcaption>{icons[1].caption}</figcaption>
          </figure>
          {icons[1].active && <div className='gCircle'></div>}
        </div>
      </div>
    )
  } else {
    return (
      <div className='gIcons'>
        {icons.map((icon, index) => {
          return (
            <div key={index}>
              <figure className='gFigure'>
                <img className='gFigureImg' id={`icon_${icon.caption.toLowerCase()}`} onClick={() => {
                  icon_click(icon.value, 'icon' + index, index, icon.store)
                }} alt={icon.action} src={icon.current_image}/>
                <figcaption className='gFigureCaption'>{icon.caption}</figcaption>
              </figure>
            </div>
          )
        })}
      </div>
    )
  }
}

export default CalcIcons
