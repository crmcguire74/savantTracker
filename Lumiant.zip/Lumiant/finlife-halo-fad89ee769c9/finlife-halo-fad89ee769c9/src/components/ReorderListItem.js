import React from 'react';
import PropTypes from 'prop-types';
import { findDOMNode } from 'react-dom';
import { DragSource, DropTarget } from 'react-dnd';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Memory from '@material-ui/icons/Memory';
import LocalHospital from '@material-ui/icons/LocalHospital';
import DirectionsRun from '@material-ui/icons/DirectionsRun';
import DirectionsWalk from '@material-ui/icons/DirectionsWalk';
import AttachMoney from '@material-ui/icons/AttachMoney';
import Input from '@material-ui/icons/Input';
import Accessible from '@material-ui/icons/Accessible';

const listIcon = {
  cognitive: Memory,
  care: LocalHospital,
  active: DirectionsRun,
  independent: DirectionsWalk,
  cost: AttachMoney,
  longevity: Input,
  longtermcare: Accessible,
};

const style = {
  cursor: 'move',
};

const cardSource = {
  beginDrag(props) {
    return {
      id: props.id,
      index: props.index,
    };
  },
};

const cardTarget = {
  hover(props, monitor, component) {
    const dragIndex = monitor.getItem().index;
    const hoverIndex = props.index;

    // Don't replace items with themselves
    if (dragIndex === hoverIndex) {
      return;
    }

    // Determine rectangle on screen
    const hoverBoundingRect = findDOMNode(component).getBoundingClientRect();

    // Get vertical middle
    const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;

    // Determine mouse position
    const clientOffset = monitor.getClientOffset();

    // Get pixels to the top
    const hoverClientY = clientOffset.y - hoverBoundingRect.top;

    // Only perform the move when the mouse has crossed half of the items height
    // When dragging downwards, only move when the cursor is below 50%
    // When dragging upwards, only move when the cursor is above 50%

    // Dragging downwards
    if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
      return;
    }

    // Dragging upwards
    if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
      return;
    }

    // Time to actually perform the action
    props.moveListItem(dragIndex, hoverIndex);

    // Note: we're mutating the monitor item here!
    // Generally it's better to avoid mutations,
    // but it's good here for the sake of performance
    // to avoid expensive index searches.
    monitor.getItem().index = hoverIndex;
  },
};

const withDropTarget = DropTarget('listItem', cardTarget, connect => ({
  connectDropTarget: connect.dropTarget(),
}));

const withDropSource = DragSource('listItem', cardSource, (connect, monitor) => ({
  connectDragSource: connect.dragSource(),
  isDragging: monitor.isDragging(),
}));

const ReorderListItem = ({icon, text, isDragging, connectDragSource, connectDropTarget, handleOnClick, index}) => {
  const opacity = isDragging ? 0 : 1;
  const Icon = listIcon[icon];
  return connectDragSource(
    connectDropTarget(
      <div style={{...style, opacity, border: '1px solid black', borderRadius: '5px', margin: '1px'}}>
        <ListItem
          button
          onClick={handleOnClick}
        >
          {/* <ListItemIcon>
              <Icon />
            </ListItemIcon> */}
          <ListItemText primary={`${text}`}/>
        </ListItem>
      </div>)
  );
}

ReorderListItem.propTypes = {
  connectDragSource: PropTypes.func.isRequired,
  connectDropTarget: PropTypes.func.isRequired,
  handleOnClick: PropTypes.func.isRequired,
  index: PropTypes.number.isRequired,
  isDragging: PropTypes.bool.isRequired,
  id: PropTypes.oneOfType([PropTypes.string.isRequired, PropTypes.number.isRequired]),
  text: PropTypes.string.isRequired,
  icon: PropTypes.string.isRequired,
  moveListItem: PropTypes.func.isRequired,
}

export default withDropTarget(withDropSource(ReorderListItem));