import React, { useCallback } from 'react'
import { useDispatch } from 'redux-react-hook';
import PropTypes from 'prop-types'
import { STATIC_ROOT } from '../api-config'
import { open_halo, runHaloClick } from '../actions/hactions'
import MediaQuery from 'react-responsive';

const HaloButtonC = ({advisor}) => {
  const dispatch = useDispatch();
  const onButtonClick = useCallback(
    () => {
      dispatch(open_halo)
      dispatch(runHaloClick())
    },
    [],
  )

  var buttonText = ''
  var buttonStyle = {}
  var styleLoaded = false
  if ('button_style' in advisor && advisor['button_style'] !== '') {
    buttonStyle = JSON.parse(advisor.button_style)
    if (!('mobile' in buttonStyle)) {
      buttonStyle = Object.assign({}, {'mobile': buttonStyle, 'full': buttonStyle})
    }
    buttonText = advisor.button_text
    styleLoaded = true
  }
  if ('button_simple' in advisor && 'background' in advisor.button_simple) {
    buttonStyle = {
      full: {
        backgroundColor: advisor.button_simple.background,
        border: advisor.button_simple.border,
        color: advisor.button_simple.color,
        fontFamily: advisor.button_simple.font,
        borderRadius: "4px",
        cursor: "pointer",
        fontSize: "18px",
        fontWeight: "100",
        height: "70px",
        lineHeight: "70px",
        margin: "auto",
        paddingBottom: "5px",
        paddingTop: "5px",
        textAlign: "center",
        textTransform: "unset",
        width: "350px",
      },
      mobile: {
        backgroundColor: advisor.button_simple.background,
        border: advisor.button_simple.border,
        color: advisor.button_simple.color,
        fontFamily: advisor.button_simple.font,
        borderRadius: "4px",
        cursor: "pointer",
        fontSize: "3vw",
        fontWeight: "100",
        height: "17vw",
        lineHeight: "17vw",
        margin: "auto",
        paddingBottom: "5px",
        paddingTop: "5px",
        textAlign: "center",
        textTransform: "unset",
        width: "100%",
      }
    }
    buttonText = advisor.button_text
    styleLoaded = true
  }

  return (
    <div>
      <MediaQuery query="(min-width: 668px)">
        {styleLoaded &&
        <div style={buttonStyle.full} onClick={() => onButtonClick()}>
          <div style={{ height: "100%" }}>
            <div style={{ height: '100%', float: 'left', paddingLeft: "10px", display: 'inline-block', maxWidth: '70px' }}>
              <img style={{ height: "100%" }} src={`${STATIC_ROOT}/images/genivity_flower.svg`} alt="Take the HALO Assessment" />
            </div>
            <div style={{paddingLeft: "0.5vw", display: 'inline-block'}}>
              {buttonText}
            </div>
          </div>
        </div>}
      </MediaQuery>
      <MediaQuery query="(max-width: 667px)">
        {styleLoaded &&
        <div style={buttonStyle.mobile} onClick={() => onButtonClick()}>
          <div style={{ height: "100%", display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'start' }}>
            <div style={{ height: "100%", float: 'left', paddingLeft: "10px", display: 'inline-block' }}>
              <img style={{ height: "100%"}} src={`${STATIC_ROOT}/images/genivity_flower.svg` } alt="Take the HALO Assessment" />
            </div>
            <div style={{paddingLeft: "0.5vw", display: 'inline-block', lineHeight: '5vw'}}>
              {buttonText}
            </div>
          </div>
        </div>}
      </MediaQuery>
    </div>
  )
}

HaloButtonC.propTypes = {
  advisor: PropTypes.object,
}

export default HaloButtonC