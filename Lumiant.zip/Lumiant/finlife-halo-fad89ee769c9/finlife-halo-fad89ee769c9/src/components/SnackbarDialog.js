import React, { useCallback } from 'react'
import PropTypes from 'prop-types';
import { useDispatch, useMappedState } from 'redux-react-hook';
import classNames from 'classnames';
import Dialog from '@material-ui/core/Dialog';
// import Button from '@material-ui/core/Button';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import ErrorIcon from '@material-ui/icons/Error';
import InfoIcon from '@material-ui/icons/Info';
import CloseIcon from '@material-ui/icons/Close';
import green from '@material-ui/core/colors/green';
import amber from '@material-ui/core/colors/amber';
import IconButton from '@material-ui/core/IconButton';
import WarningIcon from '@material-ui/icons/Warning';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import { withStyles } from '@material-ui/core/styles';
import { close_snackbar } from '../actions/hactions'


const variantIcon = {
  success: CheckCircleIcon,
  warning: WarningIcon,
  error: ErrorIcon,
  info: InfoIcon,
};

export const stylesC = theme => {
  // const emphasis = theme.palette.type === 'light' ? 0.8 : 0.98;
  // const backgroundColor = emphasize(theme.palette.background.default, emphasis);

  return {
    /* Styles applied to the root element. */
    root: {
      // color: theme.palette.getContrastText(backgroundColor),
      // backgroundColor,
      backgroundColor: amber[700],
      borderRadius: '5px',
      display: 'inline-flex',
      alignItems: 'center',
      flexWrap: 'nowrap',
      padding: '2px 2px',
      [theme.breakpoints.up('md')]: {
        minWidth: 288,
        maxWidth: 568,
        borderRadius: theme.shape.borderRadius,
      },
      [theme.breakpoints.down('sm')]: {
        flexGrow: 1,
      },
    },
    /* Styles applied to the message wrapper element. */
    message: {
      padding: '8px 0',
      display: 'flex',
      alignItems: 'center',
    },
    /* Styles applied to the action wrapper element if `action` is provided. */
    action: {
      display: 'flex',
      alignItems: 'center',
      marginLeft: 'auto',
      paddingLeft: 24,
      marginRight: -8,
    },
    success: {
      backgroundColor: green[600],
    },
    error: {
      backgroundColor: theme.palette.error.dark,
    },
    info: {
      backgroundColor: theme.palette.primary.dark,
    },
    warning: {
      backgroundColor: amber[700],
    },
    icon: {
      fontSize: 20,
    },
    iconVariant: {
      opacity: 0.9,
      marginRight: theme.spacing.unit,
    },
  };
};

export function MySnackbarContent(props) {
  const {classes, className, message, onClose, variant, ...other} = props;
  const Icon = variantIcon[variant];

  return (
    <Paper
      component={Typography}
      headlineMapping={{
        body1: 'div',
        body2: 'div',
      }}
      role="alertdialog"
      square
      elevation={6}
      className={classNames(classes.root, classes[variant], className)}
      {...other}
    >
      <div className={classNames(classes.root, classes[variant], className)}>
        <Icon className={classNames(classes.icon, classes.iconVariant)}/>
        <div style={{width: '80%', margin: 'auto'}} className={classes.message}>{message}</div>
        <IconButton
          key="close"
          aria-label="Close"
          color="inherit"
          className={classes.close}
          onClick={() => onClose()}
        >
          <CloseIcon className={classes.icon}/>
        </IconButton>
      </div>
    </Paper>
  );
}

MySnackbarContent.propTypes = {
  classes: PropTypes.object.isRequired,
  className: PropTypes.string,
  message: PropTypes.node,
  onClose: PropTypes.func,
  variant: PropTypes.oneOf(['success', 'warning', 'error', 'info']).isRequired,
};

const MySnackbarContentWrapper = withStyles(stylesC)(MySnackbarContent);

const SnackbarDialog = () => {
  const dispatch = useDispatch();
  const onClose = useCallback(
    () => (dispatch(close_snackbar)),
    [],
  )
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => ({
      snackbar: state.halo_reducer.snackbar,
    }),
    []);
  const {
    snackbar,
  } = useMappedState(mapState);

  return (
    <Dialog
      open={snackbar.open}
      onClose={() => onClose()}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <MySnackbarContentWrapper
        onClose={onClose}
        variant="warning"
        message={snackbar.message}
      />
    </Dialog>
  );
}

export default SnackbarDialog;