
import React from 'react';
import PropTypes from 'prop-types';
import Popover from '@material-ui/core/Popover';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
  paper: {
    fontFamily: 'Avenir',
    fontSize: '1.9vw',
    lineHeight: '2.1vw',
    color: '#4F4F4F',
    width: '50vw',
    maxWidth: '750px',
    backgroundColor: 'transparent',
    boxShadow: 'none',
    [theme.breakpoints.down(667)]: {
      width: '89vw',
      fontSize: '5.0965vw',
      lineHeight: '7.1329vw',
    }
  },
  popover: {
    pointerEvents: 'none',
  },
  popperClose: {
    pointerEvents: 'none',
  },
  privacyPopover: {
    background: '#EBEBEB',
    borderRadius: '5px',
    color: '#8d7979',
    textAlign: 'left',
    // width: '100%',
    padding: '15px',
    zIndex: '-1',
  },
});

class SpanPopover extends React.Component {
  constructor(props, context) {
    super(props, context)
    this.handlePopoverOpen = this.handlePopoverOpen.bind(this);
    this.handlePopoverClose = this.handlePopoverClose.bind(this);
    this.state = {
      anchorEl: null,
    }
  }

  handlePopoverOpen(event) {
    this.setState({anchorEl: event.target});
  };

  handlePopoverClose() {
    this.setState({anchorEl: null});
  };

  render() {
    const {child, popover, classes} = this.props;
    const {anchorEl} = this.state;
    const open = !!anchorEl;

    return (
      <span onMouseOver={this.handlePopoverOpen} onMouseOut={this.handlePopoverClose}>
        {child}
        {popover &&
          <Popover
            className={classes.popover}
            classes={{
              paper: classes.paper,
            }}
            open={open}
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            onClose={this.handlePopoverClose}
          >
            <div className={classes.privacyPopover}>
              {popover}
            </div>
            <div style={{
              width: '0px',
              height: '0px',
              borderLeft: '20px solid transparent',
              borderRight: '20px solid transparent',
              borderTop: '20px solid #EBEBEB',
              margin: 'auto',
            }}></div>
          </Popover>}
      </span>
    );
  }
}

SpanPopover.propTypes = {
  child: PropTypes.node,
  popover: PropTypes.string,
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(SpanPopover);