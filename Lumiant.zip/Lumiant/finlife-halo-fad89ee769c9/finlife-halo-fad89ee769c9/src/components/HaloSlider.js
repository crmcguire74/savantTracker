import React, { useState, useCallback } from 'react'
import { useDispatch, useMappedState } from 'redux-react-hook';
import MediaQuery from 'react-responsive';
import { set_value } from '../actions/hactions';
import { withStyles } from '@material-ui/core/styles';

// import Slider from 'react-rangeslider'
import 'rc-slider/assets/index.css';
import 'rc-tooltip/assets/bootstrap.css';
// import '../components/calcmodal/IconSelect.css'
import Tooltip from 'rc-tooltip';
import Slider from 'rc-slider';
import Input from '@material-ui/core/Input';
// const createSliderWithTooltip = Slider.createSliderWithTooltip;
// const Range = createSliderWithTooltip(Slider.Range);
// const SliderT = createSliderWithTooltip(Slider.Slider);
const Handle = Slider.Handle;

const styles = theme => ({
  input: {
    fontFamily: 'Avenir',
    fontSize: '1.75vw',
    lineHeight: '2.1vw',
    textAlign: 'center',
    [theme.breakpoints.down(667)]: {
      // width: '89vw',
      fontSize: '5.0965vw',
      lineHeight: '7.1329vw',
    }
  },
})

const handle = (props) => {
  const {value, dragging, index, ...restProps} = props;
  return (
    <Tooltip
      prefixCls="rc-slider-tooltip"
      overlay={value}
      overlayStyle={{zIndex: '999999999', fontSize: '40px !important'}}
      visible={true}
      defaultVisible={true}
      placement="top"
      key={index}
    >
      <Handle value={value} {...restProps} />
    </Tooltip>
  );
};

const HaloSlider = ({classes}) => {
  const dispatch = useDispatch();
  const slider_change = useCallback(
    (value, attribute) => (dispatch(set_value('select', attribute, value))),
    [],
  )
  const input_change = useCallback(
    (event, attribute) => {
      var val = parseInt(event.target.value, 10)
      dispatch(set_value('select', attribute, val))
    },
    [],
  )
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => ({
      slider: state.halo_reducer.slide.slider,
    }),
    []);
  const {
    slider,
  } = useMappedState(mapState);

  const [value, setValue] = useState(slider.value);

  const horizontalLabels = {
    30: {
      style: {
        fontFamily: 'Avenir',
        fontSize: '1.6vw',
        lineHeight: '2.2vw',
        fontWeight: '500',
        color: '#8B8B8B',
        marginTop: '15px',
        width: 'auto',
        marginLeft: '-3%',
      },
      label: <strong>30</strong>,
    },
    100: {
      style: {
        fontFamily: 'Avenir',
        fontSize: '1.6vw',
        lineHeight: '2.2vw',
        fontWeight: '500',
        color: '#8B8B8B',
        marginTop: '15px',
        width: 'auto',
        marginLeft: '-5%',
      },
      label: <strong>100</strong>,
    }
  }
  const horizontalLabelsMobile = {
    30: {
      style: {
        fontFamily: 'Avenir',
        fontSize: '4.0965vw',
        lineHeight: '4.71329vw',
        fontWeight: '500',
        color: '#8B8B8B',
        marginTop: '15px',
        width: 'auto',
        marginLeft: '-3%',
      },
      label: <strong>30</strong>,
    },
    100: {
      style: {
        fontFamily: 'Avenir',
        fontSize: '4.0965vw',
        lineHeight: '4.71329vw',
        fontWeight: '500',
        color: '#8B8B8B',
        marginTop: '15px',
        width: 'auto',
        marginLeft: '-5%',
      },
      label: <strong>100</strong>,
    }
  }
  var valu = slider.value
  var val = slider.value
  if (val < 30 || val === "" || isNaN(val) || val === null) {
    val = 30
  }
  if (val > 100) {
    val = 100
  }
  if (isNaN(valu)) {
    valu = ""
  }
  return (
    <div className="gc-slider-cContainer1">
      <MediaQuery query="(max-width: 667px)">
        <Slider
          min={slider.min}
          max={slider.max}
          defaultValue={val}
          // value={val}
          step={slider.step}
          value={value}
          railStyle={{color: '#37b7eb', height: '25px'}}
          trackStyle={{color: '#37b7eb', height: '25px'}}
          dotStyle={{color: '#37b7eb', height: '25px', width: '25px', bottom: '-21px', marginLeft: '-12px'}}
          handleStyle={[{color: '#37b7eb', height: '35px', width: '35px', marginLeft: '-16px'}]}
          handle={handle}
          marks={
            horizontalLabelsMobile
          }
          onChange={(e) =>{
            setValue(e)
            slider_change(e, slider.store)
          }}
          tipFormatter={value => `${value}%`}
        />
        <div style={{textAlign: "center"}}>
          <Input className='gSliderInput' classes={{input: classes.input}} type={"number"} placeholder={slider.hint}
                 label={slider.hint} name={slider.name} value={valu} onChange={(event) => {
            setValue(event.target.value);
            input_change(event, slider.store)
          }}/>
        </div>
      </MediaQuery>
      <MediaQuery query="(min-width: 668px)">
        <Slider
          min={slider.min}
          max={slider.max}
          defaultValue={slider.value}
          // value={val}
          step={slider.step}
          value={value}
          railStyle={{color: '#37b7eb', height: '25px'}}
          trackStyle={{color: '#37b7eb', height: '25px'}}
          dotStyle={{color: '#37b7eb', height: '25px', width: '25px', bottom: '-21px', marginLeft: '-12px'}}
          handleStyle={[{color: '#37b7eb', height: '35px', width: '35px', marginLeft: '-16px'}]}
          handle={handle}
          marks={horizontalLabels}
          onChange={(e) =>{
            setValue(e)
            slider_change(e, slider.store)
          }}
          tipFormatter={value => `${value}%`}
        />
        <div style={{textAlign: "center"}}>
          <Input className='gSliderInput' classes={{input: classes.input}} type={"number"} placeholder={slider.hint}
                 label={slider.hint} name={slider.name} value={valu} onChange={(event) => {
            setValue(event.target.value);
            input_change(event, slider.store)
          }}/>
        </div>
      </MediaQuery>
    </div>
  );
}

export default withStyles(styles)(HaloSlider)