import React from 'react';
import PropTypes from 'prop-types'
import MediaQuery from 'react-responsive';
import HaloHeader from './HaloHeader';
import HelpOutline from '@material-ui/icons/HelpOutline'
import SpanPopover from './SpanPopover';
import Footer from './Footer';
import { withStyles } from '@material-ui/core/styles';
import './GridSelect.css';
import ReorderList from './ReorderList';

const styles = theme => ({
  root: {
    transform: 'rotate(90deg)',
    backgroundColor: 'transparent',
  },
  dot: {
    width: '0.68441vw',
    height: '0.68441vw',
    borderRadius: '0.68441vw',
    margin: '0.13688vw',
    [theme.breakpoints.up(1315)]: {
      width: '10px',
      height: '10px',
      borderRadius: '10px',
      margin: '2px',
    },
  },
  listroot: {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    margin: '5px',
  }
})

const GridSelect = ({slide, classes}) => (
  <div className='gGContainer'>
    <MediaQuery query="(max-width: 667px)">
      <HaloHeader header={slide.header}/>
      <div className='gGContentContainer'>
        <div className='gGContent'>
          <div className='gGQuestionLarge'>
            {slide.question.large instanceof Array ?
              slide.question.large.map((text, index) => {
                return (<span key={index}>{text}</span>)
              }) : slide.question.large
            }{slide.question.popover &&
            <SpanPopover child={<HelpOutline className='gGQuestionPopover'/>} popover={slide.question.popover}/>}</div>
          <div className='gGQuestionSmall'>{slide.question.small instanceof Array ?
            slide.question.small.map((text, index) => {
              return (<span key={index}>{text}</span>)
            }) : slide.question.small
          }</div>
          {slide.list && slide.list.length > 0 &&
            <div className='gGIconsContainer'>
              <ReorderList itemList={slide.list}/>
            </div>
          }
        </div>
      </div>
      <Footer slide={slide}/>
    </MediaQuery>
    <MediaQuery query="(min-width: 668px)">
      <HaloHeader header={slide.header}/>
      <div className='gGContentContainer'>
        <div className='gGContent'>
          <div className='gGQuestionLarge'>
            {slide.question.large instanceof Array ?
              slide.question.large.map((text, index) => {
                return (<span key={index}>{text}</span>)
              }) : slide.question.large
            }{slide.question.popover &&
            <SpanPopover child={<HelpOutline className='gGQuestionPopover'/>} popover={slide.question.popover}/>}</div>
          <div className='gGQuestionSmall'>{slide.question.small instanceof Array ?
            slide.question.small.map((text, index) => {
              return (<span key={index}>{text}</span>)
            }) : slide.question.small
          }</div>
          {slide.list && slide.list.length > 0 &&
            <div className='gGIconsContainer'>
              <ReorderList classes={{root: classes.listroot}} itemList={slide.list}/>
            </div>
          }
        </div>
      </div>
      <Footer slide={slide}/>
    </MediaQuery>
  </div>
)

GridSelect.propTypes = {
  slide: PropTypes.object,
}

export default withStyles(styles)(GridSelect)