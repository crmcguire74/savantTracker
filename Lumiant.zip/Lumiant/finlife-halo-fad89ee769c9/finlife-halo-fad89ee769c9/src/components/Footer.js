import React, { useCallback } from 'react'
import { useDispatch } from 'redux-react-hook';
import { withStyles } from '@material-ui/core/styles';
import './IconSelect.css';
import MediaQuery from 'react-responsive';
import MobileStepper from '@material-ui/core/MobileStepper';
import Button from '@material-ui/core/Button';
import PropTypes from 'prop-types'
import { button_action } from '../actions/hactions'
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import {getMobileStepperSize} from "./IconSelect";

const styles = theme => ({
  label: {
    width: '5.81749vw',
    height: '1.91635vw',
    maxWidth: '85px !important',
    maxHeight: '28px !important',
    minHeight: '0px',
    minWidth: '0px',
  },
  stepperroot: {
    backgroundColor: 'transparent',
    padding: 0,
    margin: 0,
  },
  buttonroot: {
    minWidth: 'unset',
  },
})

const Footer = ({slide, classes, version}) => {
  const dispatch = useDispatch();
  const onButtonClick = useCallback(
    (action, store, value) => (dispatch(button_action(action, store, value))),
    [],
  )

  return (
    <div className='gFooter'>
      <MediaQuery query="(min-width: 668px)">
        <Button classes={{label: classes.label, root: classes.label}} className='gFooterButton' style={{float: 'left'}}
                onClick={() => onButtonClick('back')}>
          <KeyboardArrowLeft className='gFooterIcon'/>Prev
        </Button>
      </MediaQuery>
      <MediaQuery query="(max-width: 667px)">
        <MobileStepper classes={{root: classes.stepperroot}} type='dots' steps={getMobileStepperSize(version)} orientation="horizontal"
                       position="static" activeStep={slide.step}
                       backButton={
                         <Button classes={{root: classes.buttonroot}} onClick={() => onButtonClick('back')}>
                           <KeyboardArrowLeft/>
                         </Button>}
                       nextButton={
                         <Button classes={{root: classes.buttonroot}} style={{visibility: 'hidden'}}>
                           <KeyboardArrowRight/>
                         </Button>}/>
      </MediaQuery>
    </div>
  )
}

Footer.propTypes = {
  classes: PropTypes.object.isRequired,
  slide: PropTypes.object,
}

export default withStyles(styles)(Footer)
