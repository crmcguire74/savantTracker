import React, { useCallback } from 'react'
import { useDispatch, useMappedState } from 'redux-react-hook';
import { set_value } from '../actions/hactions';
import TextField from '@material-ui/core/TextField';
import './IconSelect.css'
import HaloSelect from './HaloSelect';

const MiscInputs = () => {
  const dispatch = useDispatch();
  const input_change = useCallback(
    (event, input) => (dispatch(set_value('input', input.store, event.target.value))),
    [],
  )
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => ({
      inputs: state.halo_reducer.slide.misc.inputs,
      suggestions: state.halo_reducer.slide.misc.suggestions,
    }),
    []);
  const {
    inputs,
    suggestions,
  } = useMappedState(mapState);

  return (
    <div className="gMiscInputsWrapper">
      {inputs.map((input, index) => {
        return (
          <TextField margin={'normal'} id={input.hint.replace(/(\s|\(|\))/g, "_").toLowerCase()} className='gMiscInput'
                     key={index} style={{paddingRight: '10px'}} type={input.type} placeholder={input.hint}
                     label={input.hint} name={input.name} value={input.value} onChange={(event) => {
            input_change(event, input)
          }}/>
        )
      })}
      {suggestions && suggestions.options.length > 0 && <HaloSelect suggestions={suggestions}/>}
    </div>
  )

}

export default MiscInputs
