import React from 'react';
import PropTypes from 'prop-types'
import './TitlePage.css';
import CalcButton from './CalcButton';
import Button from '@material-ui/core/Button';
import Floater from 'react-floater';
import MediaQuery from 'react-responsive';
import { STATIC_ROOT } from '../api-config'


const TitlePage = ({slide}) => (





  <div className={'titlePage'}>
    <div className={'headerGroup'}>
      <div className={'headerLogo'}>
        <img className={'headerLogo'} src={`${STATIC_ROOT}/images/logo-halo-large.svg`} alt='Halo Logo'/>
      </div>
      <div className='headerText'>{slide.header.text}</div>
    </div>
    <div className='titleAttention'>{slide.title.attention}</div>
    <div className='titleText'>{slide.title.small.map((text, index) => {
      return (<span key={index}>{text}</span>)
    })}</div>
    <div className={'titleButtonContainer'} style={{textAlign: "center"}}>
      <CalcButton cssStyle={'titleButton'} buttons={slide.buttons}/>
      <div style={{display: "inline-flex"}}>
        <MediaQuery query="(max-width: 667px)">
          <Floater
            event="click"
            showCloseButton={true}
            eventDelay={0}
            placement="top"
            style={{cursor: 'pointer'}}
            styles={{
              floater: {zIndex: 99999999, width: '90%', maxWidth: '90%'},
              content: {
                fontFamily: 'Avenir',
                fontSize: '5.0vw',
                lineHeight: '5.4vw',
              },
              container: {
                borderRadius: '5px',
                color: '#8d7979',
                textAlign: 'left',
                // width: '50vw',
                // maxWidth: '750px',
                backgroundColor: '#EBEBEB',
              },
              arrow: {
                color: '#EBEBEB',
              },
            }}
            content={slide.popover.popover.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}
          >
            <Button
              onClick={()=>{slide.popover.text

                  console.log("the content: ", slide.popover.text)

                  // render the pop over instead of the onclick event
                  // not sure why its causing issues

              }}
              label={slide.popover.text}
              className={'titlePrivacy'}
            >{slide.popover.text}</Button>
          </Floater>
          <Floater
            event="click"
            eventDelay={0}
            placement="top"
            showCloseButton={true}
            style={{cursor: 'pointer'}}
            styles={{
              floater: {zIndex: 99999999, width: '90%', maxWidth: '90%'},
              content: {
                fontFamily: 'Avenir',
                fontSize: '5.0vw',
                lineHeight: '5.4vw',
              },
              container: {
                borderRadius: '5px',
                color: '#8d7979',
                textAlign: 'left',
                // width: '50vw',
                // maxWidth: '750px',
                backgroundColor: '#EBEBEB',
              },
              arrow: {
                color: '#EBEBEB',
              },
            }}
            content={slide.disclaimer.popover.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}
          >
            <Button
              onClick={() => {
                  console.log(slide.disclaimer.text)
                  slide.disclaimer.text
              }}
              label={slide.popover.text}
              className={'titlePrivacy'}
            >{slide.disclaimer.text}</Button>
          </Floater>
        </MediaQuery>
        <MediaQuery query="(min-width: 668px)">
          <Floater
            event="click"
            showCloseButton={true}
            eventDelay={0}
            placement="top"
            style={{cursor: 'pointer'}}
            styles={{
              floater: {zIndex: 99999999, maxWidth: '30%'},
              content: {
                fontFamily: 'Avenir',
                fontSize: '1vm',
              },
              container: {
                borderRadius: '5px',
                color: '#8d7979',
                textAlign: 'left',
                // width: '50vw',
                // maxWidth: '750px',
                backgroundColor: '#EBEBEB',
              },
              arrow: {
                color: '#EBEBEB',
              },
            }}
            content={slide.popover.popover.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}
          >
            <Button
              onClick={()=>{
                  slide.popover.text
                  console.log("the content: ", slide.popover.text)
              }}
              label={slide.popover.text}
              className={'titlePrivacy'}
            >{slide.popover.text}</Button>
          </Floater>
          <Floater
            event="click"
            showCloseButton={true}
            eventDelay={0}
            placement="top"
            style={{cursor: 'pointer'}}
            styles={{
              floater: {zIndex: 99999999, maxWidth: '30%'},
              content: {
                fontFamily: 'Avenir',
                  fontSize: '1vm'
              },
              container: {
                borderRadius: '5px',
                color: '#8d7979',
                textAlign: 'left',
                // width: '50vw',
                // maxWidth: '750px',
                backgroundColor: '#EBEBEB',
              },
              arrow: {
                color: '#EBEBEB',
              },
            }}
            content={slide.disclaimer.popover.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}
          >
            <Button
              onClick={() => {

                  console.log("the content: ", slide.disclaimer.text)
                  slide.disclaimer.text
              }}
              label={slide.popover.text}
              className={'titlePrivacy'}
            >{slide.disclaimer.text}</Button>
          </Floater>
        </MediaQuery>
      </div>
    </div>
  </div>
)

// TODO: review over the this.HandleClick methods and see what is causing problems with the new implementation
// of React 18

TitlePage.propTypes = {
  slide: PropTypes.object,
  advisor: PropTypes.object,
}

export default TitlePage;