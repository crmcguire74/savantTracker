import GridSelect from './GridSelect'
import { STATIC_ROOT } from '../api-config'

export default {
  component: GridSelect,
  props: {
    value: 'Lorem ipsum',
    disabled: true,
    slide: {
      number: 21,
      next: 21,
      back: 20,
      step: 21,
      type: 'gridselect',
      header: {
        logo: `${STATIC_ROOT}/images/logo-halo-small.svg`,
        text: 'Lumiant HALO Longevity Planner',
      },
      misc: {},
      question: {
        large: ["Please select from the options below in order of concern"],
        small: "(Please check all that apply)"
      },
      icons: [{
        image: `${STATIC_ROOT}/images/icn_female.svg`,
        active: false,
        clickable: true,
        value: "female",
        caption: "FEMALE",
        store: "gender"
      },
        {
          image: `${STATIC_ROOT}/images/icn_male.svg`,
          active: false,
          clickable: true,
          value: "male",
          caption: "MALE",
          store: "gender"
        }
      ],
      buttons: [
        // { label: "Caregiving", value: true, store: "concerns", action: 'toggle', active: false }, { label: "Income", value: true, store: "concerns", action: 'toggle', active: false },      
        // { label: "Cognition", value: true, store: "concerns", action: 'toggle', active: false }, { label: "Activity", value: true, store: "concerns", action: 'toggle', active: false },
        // { label: "Health", value: true, store: "concerns", action: 'toggle', active: false }, { label: "Longevity", value: true, store: "concerns", action: 'toggle', active: false },
        // { label: "Independence", value: true, store: "concerns", action: 'toggle', active: false }, 
        // { label: "Estate", value: true, store: "concerns", action: 'toggle', active: false },
        {
          label: "SUBMIT",
          store: '',
          value: "",
          action: 'next',
          active: false
        },
      ],
      value: "",
      validate: (store) => {
        var checked = false
        for (var i = 0; i < store.halo_reducer.slide.buttons.length; i++) {
          checked |= store.halo_reducer.slide.buttons[i].active
        }
        if (!checked) {
          return "Please select which cancers have been in your immediate family."
        }
      },
      set_value: (slide, store, value) => {
        if (slide.buttons.length > 0) {
          var newbuttons = []
          for (var i = 0; i < slide.buttons.length; i++) {
            if (slide.buttons[i].store === store) {
              newbuttons.push(Object.assign({}, slide.buttons[i], {
                active: !slide.buttons[i].active
              }))
            } else {
              newbuttons.push(Object.assign({}, slide.buttons[i]))
            }
          }
          // slide.buttons = newbuttons
          return Object.assign({}, slide, {
            buttons: newbuttons,
            value: value
          })
        }
      },
    },
    version: 20,
  },
};