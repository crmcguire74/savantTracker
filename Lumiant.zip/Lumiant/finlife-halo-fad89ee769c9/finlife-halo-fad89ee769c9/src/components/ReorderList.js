import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { DragDropContext } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';
import ReorderListItem from './ReorderListItem';
import List from '@material-ui/core/List';

const ReorderList = ({itemList, classes}) => {
  const [items, setItems] = useState(itemList);

  function handleOnClick(item) {
    // You may pass handle on click event to props
    console.log(item);
  }

  function moveListItem(dragIndex, hoverIndex) {
    const movedItem = items.find((item, index) => index === dragIndex);
    const remainingItems = items.filter((item, index) => index !== dragIndex);
    setItems([
      ...remainingItems.slice(0, hoverIndex),
      movedItem,
      ...remainingItems.slice(hoverIndex)
    ])
  }


  return (
    <div>
      <List classes={classes}>
        {items.map((item, i) => (
          <ReorderListItem
            key={item.id}
            handleOnClick={() => handleOnClick(item)}
            index={i}
            icon={item.icon}
            id={item.label.replace(/\s/g, '_')}
            text={item.label}
            moveListItem={moveListItem}
          />
        ))}
      </List>
    </div>
  )
}

ReorderList.propTypes = {
  itemList: PropTypes.object,
  classes: PropTypes.object,
}

export default DragDropContext(HTML5Backend)(ReorderList);