import React, { useEffect, useCallback } from 'react'
import PropTypes from 'prop-types'
import { useDispatch } from 'redux-react-hook';
import HaloadingSVG from './HaloadingSVG';
import { runHalo, runHaloFinal, fetchAdvisor, imageLoaded, imageError } from '../actions/hactions'
import { STATIC_ROOT } from '../api-config'

const Haloading = ({api, images}) => {
  //When container mounts 
  useEffect(() => {
    if (api.state === "requested" || images.length > 0) {
      document.getElementById("LoadingFlower").style.webkitAnimationPlayState = "running"
      document.getElementById("LoadingHalo").style.webkitAnimationPlayState = "running"
      // document.getElementById("loadingdots").style.display = ''
      document.getElementById("retryButton").style.display = 'none'
      document.getElementById("loadingText").innerHTML = 'Loading all content to provide the best experience possible.'
    } else if (api.state === "timeout") {
      document.getElementById("LoadingFlower").style.webkitAnimationPlayState = "paused"
      document.getElementById("LoadingHalo").style.webkitAnimationPlayState = "paused"
      // document.getElementById("loadingdots").style.display = 'none'
      document.getElementById("retryButton").style.display = ''
      document.getElementById("loadingText").innerHTML = 'Your connection was lost please ensure a good internet connection and click the retry button below. You do not have to start over.'
    } else {
      document.getElementById("LoadingFlower").style.webkitAnimationPlayState = "paused"
      document.getElementById("LoadingHalo").style.webkitAnimationPlayState = "paused"
      // document.getElementById("loadingdots").style.display = 'none'
      document.getElementById("retryButton").style.display = 'none'
      document.getElementById("loadingText").innerHTML = 'There has been an unexpected error, please refresh and try again.'
    }
  }, [])
  //Dispatch actions
  const dispatch = useDispatch();
  const onButtonClick = useCallback(
    (endpoint) => {
      if (endpoint === 'advisor') {
        dispatch(fetchAdvisor())
      } else if (endpoint === 'midpoint') {
        dispatch(runHalo())
      } else if (endpoint === 'final') {
        dispatch(runHaloFinal())
      }
    },
    [],
  )
  const imageLoadedH = useCallback(
    (image) => (dispatch(imageLoaded(image))),
    [],
  )
  const imageErrorH = useCallback(
    (image) => (dispatch(imageError(image))),
    [],
  )

  return (
    <div style={{display: 'table', width: '100%', height: '100%'}}>
      {images && images.map((image) => {
        return (<img
          key={image}
          style={{display: 'none'}}
          src={`${STATIC_ROOT}/images/` + image}
          alt={image}
          onLoad={() => imageLoadedH(image)}
          onError={() => imageErrorH(image)}
        />)
      })}
      <div style={{display: 'table-cell', verticalAlign: 'middle'}}>
        <div style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
          <div className='gLoadingSVG'>
            <HaloadingSVG/>
          </div>
          {/* <div id='loadingdots' style={{height: '100%'}}>
            <div style={{ display: 'table', height: '100%', width: '100%', overflow: 'hidden' }}>
              <div className={'loading'}>
                is loading
              </div>
            </div>
          </div> */}
        </div>
        <div className="gLoadingText" id="loadingText"></div>
        <div className='gLoadingButtonContainer'>
          <div id="retryButton" className='gLoadingButton' style={{display: 'none', cursor: 'pointer'}}
               onClick={() => onButtonClick(api.endpoint)}>
            <div className='gLoadingButton' style={{display: 'table', overflow: 'hidden', cursor: 'pointer'}}>
              <div style={{display: 'table-cell', verticalAlign: 'middle', cursor: 'pointer'}}>
                <div style={{cursor: 'pointer'}}>Retry</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

Haloading.propTypes = {
  api: PropTypes.object,
  images: PropTypes.array,
}

export default Haloading
