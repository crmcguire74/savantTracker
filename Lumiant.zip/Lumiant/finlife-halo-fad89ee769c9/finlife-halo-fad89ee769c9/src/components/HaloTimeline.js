import React, { useState, useCallback } from 'react';
import PropTypes from 'prop-types'
import { useDispatch, useMappedState } from 'redux-react-hook';
import MediaQuery from 'react-responsive';
import Joyride from 'react-joyride';
import Floater from 'react-floater';
import { withStyles } from '@material-ui/core/styles';
import './HaloTimeline.css';
import HaloHeader from './HaloHeader';
import CheckboxForm from './CheckboxForm';
import { STATIC_ROOT } from '../api-config'
import { restart_halo, open_closedialog, button_action } from '../actions/hactions'
import { getSteps } from './steps';
import { NRound } from './helpers'
import { getTimeline } from './timeline';

const styles = () => ({
  root: {
    transform: 'rotate(90deg)',
  },
})

const HaloTimeline = ({classes, open}) => {
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => ({
      slide: state.halo_reducer.slide,
      halovalues: state.halo_reducer.final,
      advisor: state.halo_reducer.advisor,
    }),
    []);
  const {
    slide,
    halovalues,
    advisor,
  } = useMappedState(mapState);
  const dispatch = useDispatch();
  var onClose, onThirdAct
  if (advisor.version <= 23) {
    onClose = useCallback(
      (version, redirect) => (
        dispatch(
          open_closedialog({
            message: "Are you sure you want to exit?",
            onConfirm: () => {
              (redirect !== "" && redirect != null) ? window.location.replace(redirect) : dispatch(restart_halo)
            },
          })
        )
      ),
      [],
    )
  } else {
    onThirdAct = useCallback(
      (action, store, value) => (dispatch(button_action('next', '', ''))),
      [],
    )
  }
  const [confetti, setConfetti] = useState(false);
  if (advisor.version <= 19) {
    open = false
  }


  const confetticallback = (data) => {
    setConfetti(true)
  }
  const timelineData = getTimeline(halovalues, slide, advisor)
  // const steps = getSteps(halovalues.clientInformation, slide, advisor, confetti, timelineData)
  // console.log(steps)
  return (
    <div className='gContainer gTContainer'>
      <MediaQuery query="(max-width: 667px)">
        <Joyride
          callback={confetticallback}
          continuous
          scrollToFirstStep
          showProgress
          showSkipButton
          steps={
            getSteps(halovalues.clientInformation, slide, advisor, confetti, timelineData).map(x => {
              x.styles.tooltip.maxWidth = 'unset';
              return x
            })
          }
          run={open}
          floaterProps={{
            styles: {
              floater: {
                width: 'auto',
                maxWidth: '80%',
                marginRight: '1rem',
                marginLeft: 'auto',
              },
            }
          }}
          styles={
            {
              options: {
                zIndex: 99999999,
                width: '89vw',
              },
              /*
              floater: {
                tooltip: {
                  width: '98%',
                },
                width: '98%',
              },

               */
              tooltip: {
                fontFamily: 'Avenir',
                //fontSize: '1vm',
                borderRadius: '5px',
                // color: 'black',
                textAlign: 'left',
              },
              buttonNext: {
                backgroundColor: 'transparent',
                border: '1px solid white',
              },
              buttonBack: {
                color: 'white'
              },
            }
          }
        />
        <HaloHeader header={slide.header} onClose={onClose} onThirdAct={onThirdAct} advisor={advisor}/>
        <div className='gTContentContainer'>
          <div className='gTQuestionContainer'>
            <div className='gTQuestionLarge'>{slide.question.large.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}</div>
            <div className='gTQuestionSmall'>{slide.question.small.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}</div>
            {/* <CalcLinkButton link={{text: "Want to add a partner?", value:halovalues.smokes}} /> */}
          </div>
          <div className='gTimelineContainer' style={{width: timelineData.totalWidth}}>
            <div className='gVTimelineDotted'></div>
            <div className='gTimelineSubContainer'>
              <div className='gTActiveYears' style={{display: timelineData.displayAct}}>
                {/* <div className='gTGoalBuffer'>Filler</div> */}
                <div className='gTActiveEndpoints'>
                  <div className='gTimelineDotted'></div>
                  <div className='gTActiveEndpointLeft'>
                    {timelineData.age}
                    <img src={`${STATIC_ROOT}/images/icn_birthday.svg`} alt={'BIRTHDAY'}/>
                  </div>
                  {/* <div className='gTActiveEndpointRight'>{timelineData.retirementAge}</div> */}
                </div>
                {/* <div className='gTimelineDotted'></div> */}
                <Floater
                  event="hover"
                  eventDelay={0}
                  placement="right"
                  showCloseButton={true}
                  style={{width: '100%'}}
                  styles={{
                    floater: {
                      zIndex: 99999999,
                      // width: '89vw',
                      maxWidth: "65%"
                    },
                    content: {
                      fontFamily: 'Avenir',
                      fontSize: '1vm',
                    },
                    container: {
                      borderRadius: '5px',
                      color: '#ffffff',
                      textAlign: 'left',
                      // width: '50vw',
                      // maxWidth: '750px',
                      backgroundColor: '#0D9000',
                    },
                    arrow: {
                      color: '#0D9000'
                    },
                  }}
                  content={slide.timeline.active.hover}
                >
                  <div className='gTActiveYearsBar'>{NRound(timelineData.preRetirementActiveYears)}</div>
                </Floater>
                {/* <DivPopover child={<div className='gTActiveYearsBar' style={{ width: timelineData.activeWidth}}>{NRound(timelineData.preRetirementActiveYears)}</div>}
                popover={[...slide.timeline.active.hover.slice(0, 1), parseInt(NRound(timelineData.preRetirementActiveYears),10), slide.timeline.active.hover.slice(2, 3)]}/> */}
                <div className='gTActiveFooter'>{slide.timeline.active.label}</div>
                {/* <div className='gTActiveEndpoints'>
                <div className='gTActiveEndpointRight'>{timelineData.retirementAge}</div>
              </div> */}
              </div>
              <div className='gTRetireYears' style={{display: timelineData.displayRet}}>

                <div className='gTRetireEndpoints'>
                  <div className='gTimelineDotted'></div>
                  <div className='gTRetireEndpointLeft'>
                    {timelineData.retirementAge}
                    <img src={`${STATIC_ROOT}/images/icn_retirement.svg`} alt={'RETIREMENT'}/>
                  </div>
                  <div className='gTRetireGoal' style={{visibility: timelineData.displayRetGoal}}>This is your
                    retirement goal
                  </div>
                  {/* <div className='gTRetireEndpointRight'>{timelineData.disabilityAge.toFixed(0)}</div> */}
                </div>
                {/* <div className='gTimelineDotted'></div> */}
                <Floater
                  event="hover"
                  eventDelay={0}
                  placement="right"
                  style={{width: '100%'}}
                  showCloseButton={true}
                  styles={{
                    floater: {
                      zIndex: 99999999,
                      // width: '89vw',
                      maxWidth: "65%"
                    },
                    content: {
                      fontFamily: 'Avenir',
                      fontSize: '1vm',
                    },
                    container: {
                      borderRadius: '5px',
                      color: '#ffffff',
                      textAlign: 'left',
                      // width: '50vw',
                      // maxWidth: '750px',
                      backgroundColor: '#11BC01',
                    },
                    arrow: {
                      color: '#11BC01'
                    },
                  }}
                  content={slide.timeline.retire.hover}
                >
                  <div className='gTRetireYearsBar'
                       style={{width: timelineData.retireWidth}}>{timelineData.postRetirementActiveYears.toFixed(0)}</div>
                </Floater>
                {/* <DivPopover child={<div className='gTRetireYearsBar' style={{ width: timelineData.retireWidth}}>{timelineData.postRetirementActiveYears.toFixed(0)}</div>}
                popover={slide.timeline.retire.hover} /> */}
                <div className='gTRetireFooter'>{slide.timeline.retire.label}</div>
                {/* <div className='gTRetireEndpoints'>
                <div className='gTRetireEndpointRight'>{timelineData.disabilityAge.toFixed(0)}</div>
              </div> */}
              </div>
              <div className='gTAssistedYears' style={{display: timelineData.displayAst}}>
                {/* <div className='gTGoalBuffer'>Filler</div> */}
                <div className='gTAssistedEndpoints'>
                  <div className='gTimelineDotted'></div>
                  <div className='gTAssistedEndpointLeft'>{timelineData.disabilityAge.toFixed(0)}</div>
                  {/* <div className='gTAssistedEndpointRight'>{timelineData.adjustedLifespan.toFixed(0)}</div> */}
                </div>
                {advisor.locale === "en-AU" &&
                <Floater
                  event="hover"
                  eventDelay={0}
                  placement="right-end"
                  style={{width: '100%'}}
                  showCloseButton={true}
                  styles={{
                    floater: {
                      zIndex: 99999999,
                      maxWidth: '65%'
                    },
                    content: {
                      fontFamily: 'Avenir',
                      fontSize: '1vm',
                    },
                    container: {
                      borderRadius: '5px',
                      color: '#ffffff',
                      textAlign: 'left',
                      // width: '50vw',
                      // maxWidth: '750px',
                      //backgroundColor: '#FE912A',
                      backgroundColor: '#FE912A',

                    },
                    arrow: {
                      color: '#FE912A'
                    },
                  }}
                    content={[...slide.timeline.assisted.hover.slice(0,1)]}
                  >
                  <div className='gTAssistedYearsBar'>{timelineData.disabilityYears.toFixed(0)}</div>
                </Floater>
                }

                {advisor.locale === "en-US" &&
                <Floater
                  event="hover"
                  eventDelay={0}
                  placement="right-end"
                  style={{width: '100%'}}
                  showCloseButton={true}
                  styles={{
                    floater: {
                      zIndex: 99999999,
                      maxWidth: '65%'
                    },
                    content: {
                      fontFamily: 'Avenir',
                      fontSize: '1vm',
                    },
                    container: {
                      borderRadius: '5px',
                      color: '#ffffff',
                      textAlign: 'left',
                      //width: '300vw',

                      // width: '50vw',
                      // maxWidth: '750px',
                      //backgroundColor: '#FE912A',
                      backgroundColor: '#FE912A',

                    },
                    arrow: {
                      color: '#FE912A'
                    },
                  }}
                  content={[...slide.timeline.assisted.hover.slice(0, 1), timelineData.disabilityYearsDisplay, slide.timeline.assisted.hover.slice(2, 3), timelineData.outOfPocketCost, slide.timeline.assisted.hover.slice(4, 5)]}
                  >
                  <div className='gTAssistedYearsBar'>{timelineData.disabilityYears.toFixed(0)}</div>
                </Floater>
                }
                {/* <DivPopover child={<div className='gTAssistedYearsBar' style={{ width: timelineData.assistedWidth}}>{timelineData.disabilityYears.toFixed(0)}</div>}
                popover={[...slide.timeline.assisted.hover.slice(0, 1), parseInt(NRound(timelineData.disabilityYears),10), slide.timeline.assisted.hover.slice(2, 3),timelineData.outOfPocketCost,slide.timeline.assisted.hover.slice(4,5)]} /> */}
                <div className='gTAssistedFooter'>{slide.timeline.assisted.label}</div>
                <div className='gTAssistedEndpoints'>
                  <div className='gTimelineDotted'></div>
                  {"mortality" in slide.timeline ?
                    <Floater
                      event="hover"
                      eventDelay={0}
                      showCloseButton={true}
                      placement="right"
                      wrapperOptions={{width: '100%'}}
                      // style={{width:'100%'}}
                      styles={{
                        wrapper: {
                          width: '100%',
                          maxWidth: '100%',
                          // cursor: 'pointer',
                        },
                        floater: {zIndex: 99999999,},
                        content: {
                          fontFamily: 'Avenir',
                          fontSize: '1vm',
                        },
                        container: {
                          borderRadius: '5px',
                          color: '#ffffff',
                          textAlign: 'left',
                          // width: '100%',
                          // maxWidth: '750px',
                          backgroundColor: '#8B8B8B',
                        },
                        arrow: {
                          color: '#8B8B8B',
                        },
                      }}
                      content={"mortality" in slide.timeline ? slide.timeline.mortality.hover : ''}
                    >
                      <div id='adjustedLifespan'
                           className='gTAssistedEndpointLeft'>{timelineData.adjustedLifespan.toFixed(0)}</div>
                    </Floater> :
                    <div id='adjustedLifespan'
                         className='gTAssistedEndpointLeft'>{timelineData.adjustedLifespan.toFixed(0)}</div>}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='gTFooter' style={{display: timelineData.displayFooter}}>
          <div className='gTFooterContainer'>
            <Floater
              event="hover"
              eventDelay={0}
              placement="top"
              style={{width: '100%'}}
              showCloseButton={true}
              styles={{
                floater: {
                  zIndex: 99999999,
                  // width: '89vw',
                  maxWidth: "65%",
                },
                content: {
                  fontFamily: 'Avenir',
                  fontSize: '1vm',
                },
                container: {
                  borderRadius: '5px',
                  color: '#ffffff',
                  textAlign: 'left',
                  width:'auto',
                  // width: '50vw',
                  // maxWidth: '750px',
                  backgroundColor: Math.round(timelineData.yearsLostAdjustment) <= -1 ? '#E94E29' : '#686868',
                },
                arrow: {
                  color: Math.round(timelineData.yearsLostAdjustment) <= -1 ? '#E94E29' : '#686868',
                },
              }}
              content={slide.timeline.lost.hover}
            >
              <div
                className={Math.round(timelineData.yearsLostAdjustment) <= -1 ? 'gTYearsLostActive' : 'gTYearsLostInactive'}>{Math.round(timelineData.yearsLostAdjustment) <= -1 ? Math.abs(Math.round(timelineData.yearsLostAdjustment).toFixed(0)) : 0} YEARS
                LOST
              </div>
            </Floater>
            {/* <DivPopover childClass={"gTYearsLostContainer"} child={<div className={Math.round(timelineData.yearsLostAdjustment) <= -1 ? 'gTYearsLostActive' : 'gTYearsLostInactive'}>{Math.round(timelineData.yearsLostAdjustment) <= -1 ? Math.abs(Math.round(timelineData.yearsLostAdjustment).toFixed(0)) : 0} YEARS LOST</div>}
            popover={slide.timeline.lost.hover} /> */}
            <div className='gTBehaviors'><CheckboxForm checks={timelineData.checkboxes}/></div>
          </div>
        </div>
      </MediaQuery>
      <MediaQuery query="(min-width: 668px)">
        <HaloHeader header={slide.header} onClose={onClose} onThirdAct={onThirdAct} advisor={advisor}/>
        <div className='gTContentContainer'>
          <Joyride
            callback={confetticallback}
            continuous
            scrollToFirstStep
            showProgress
            showSkipButton
            steps={
              getSteps(halovalues.clientInformation, slide, advisor, confetti, timelineData)
            }
            run={open}
            floaterProps={{
              styles: {
                floater: {
                  width: 'auto',
                  maxWidth: '80%',
                  marginRight: 'auto',
                  marginLeft: 'auto',
                },
              }
            }}
            styles={
              {
                options: {
                  zIndex: 99999999,
                },
                tooltip: {
                  fontFamily: 'Avenir',
                  // dont specify font size cause it gets way to big
                  fontSize: '1.6vw',
                  lineHeight: '2.5vw',
                  borderRadius: '5px',
                  width: '100%',
                  maxWidth: '100%',
                  marginRight: 'auto',
                  marginLeft: 'auto',
                  // color: 'black',
                  textAlign: 'left',
                },
                buttonNext: {
                  backgroundColor: 'transparent',
                  border: '1px solid white',
                },
                buttonBack: {
                  color: 'white'
                },
              }
            }
          />
          <div className='gTQuestionContainer'>
            <div className='gTQuestionLarge'>{slide.question.large.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}</div>
            <div className='gTQuestionSmall'>{slide.question.small.map((text, index) => {
              return (<span key={index}>{text}</span>)
            })}</div>
          </div>
          <div className='gTimelineContainer' style={{width: timelineData.totalWidth}}>
            {advisor.version > 18 &&
              <div className='gTActiveYears' style={{width: "50px", display: timelineData.displayAst}}>
                <div className='gTGoalBuffer'>Filler</div>
                <div className='gTActiveEndpoints'>
                  <div className='gTActiveEndpointBlank'></div>
                </div>
                <div className='gTimelineDotted' style={{visibility: "hidden", height: "1px"}}></div>
                <div className='gTActiveYearsBarExt'></div>
                <div className='gTActiveFooter'></div>
              </div>}
            <div className='gTActiveYears' style={{width: timelineData.activeWidth, display: timelineData.displayAct}}>
              <div className='gTGoalBuffer'>Filler</div>
              <div className='gTActiveEndpoints'>
                <div className='gTActiveEndpointLeft'>
                  {timelineData.age}
                  <img src={`${STATIC_ROOT}/images/icn_birthday.svg`} alt={'BIRTHDAY'}/>
                </div>
                <div className='gTActiveEndpointRight'>{timelineData.retirementAge}</div>
              </div>
              <div className='gTimelineDotted'></div>
              <Floater
                event="hover"
                eventDelay={0}
                placement="top"
                style={{width: '100%'}}
                styles={{
                  floater: {
                    zIndex: 99999999,
                    //width: '50%',
                    maxWidth: '50%',
                    marginRight: 'auto',
                    marginLeft: 'auto',
                  },
                  content: {
                    fontFamily: 'Avenir',
                    fontSize:  '1.6vw',
                    lineHeight: '2.5vw',
                    //fontSize: '1vm',
                  },
                  container: {
                    borderRadius: '5px',
                    color: '#ffffff',
                    textAlign: 'left',
                    width: '100%',
                    maxWidth:'100%',
                    marginRight: 'auto',
                    marginLeft:'auto',
                    // width: '50vw',
                    // maxWidth: '750px',
                    backgroundColor: '#0D9000',
                  },
                  arrow: {
                    color: '#0D9000'
                  },
                }}
                content={slide.timeline.active.hover}
              >
                <div className='gTActiveYearsBar'>{NRound(timelineData.preRetirementActiveYears)}</div>
              </Floater>
              {/* <DivPopover child={<div className='gTActiveYearsBar'>{NRound(timelineData.preRetirementActiveYears)}</div>}
                popover={[...slide.timeline.active.hover.slice(0, 1), parseInt(NRound(timelineData.preRetirementActiveYears), 10), slide.timeline.active.hover.slice(2, 3)]} /> */}
              <div className='gTActiveFooter'>{slide.timeline.active.label}</div>
            </div>

            <div className='gTRetireYears' style={{width: timelineData.retireWidth, display: timelineData.displayRet}}>
              <div className='gTRetireGoal' style={{visibility: timelineData.displayRetGoal}}>This is your retirement
                goal
              </div>
              <div className='gTRetireEndpoints'>
                <div className='gTRetireEndpointLeft'>
                  {timelineData.retirementAge}
                  <img src={`${STATIC_ROOT}/images/icn_retirement.svg`} alt={'RETIREMENT'}/>
                </div>
                <div className='gTRetireEndpointRight'>{timelineData.disabilityAge.toFixed(0)}</div>
              </div>
              <div className='gTimelineDotted'></div>
              <Floater
                event="hover"
                eventDelay={0}
                placement="top"
                style={{width: '100%'}}
                styles={{
                  floater: {
                    zIndex: 99999999,
                    width: 'auto',
                    maxWidth: '50%',
                    //maxWidth: '50%',

                    //marginRight: 'auto',
                    //marginLeft: 'auto',
                  },
                  content: {
                    fontFamily: 'Avenir',
                    fontSize: '1.6vw',
                    lineHeight: '2.5vw',

                  },
                  container: {
                    borderRadius: '5px',
                    color: '#ffffff',
                    textAlign: 'left',
                    //width: '50vw',
                    width: '100%',
                    maxWidth: '100%',
                    //maxWidth: '500px',
                    backgroundColor: '#11BC01',
                  },
                  arrow: {
                    color: '#11BC01'
                  },
                }}
                content={slide.timeline.retire.hover}
              >
                <div className='gTRetireYearsBar'>{timelineData.postRetirementActiveYears.toFixed(0)}</div>
              </Floater>
              {/* <DivPopover child={<div className='gTRetireYearsBar'>{timelineData.postRetirementActiveYears.toFixed(0)}</div>}
                popover={slide.timeline.retire.hover} /> */}
              <div className='gTRetireFooter'>{slide.timeline.retire.label}</div>
            </div>
            <div className='gTAssistedYears'
                 style={{width: timelineData.assistedWidth, display: timelineData.displayAst}}>
              <div className='gTGoalBuffer'>Filler</div>
              <div className='gTAssistedEndpoints'>
                <div className='gTAssistedEndpointLeft'>{timelineData.disabilityAge.toFixed(0)}</div>
                <span style={{width: '100%'}}>
                {"mortality" in slide.timeline ?
                  <Floater
                    event="hover"
                    eventDelay={0}
                    placement="top"
                    wrapperOptions={{width: '100%'}}
                    // style={{width:'100%'}}
                    styles={{
                      wrapper: {
                        width: '100%',
                        // cursor: 'pointer',
                      },
                      floater: {
                        zIndex: 99999999,
                        width: 'auto',
                        maxWidth: '65%'
                      },
                      content: {
                        fontFamily: 'Avenir',
                        fontSize: '1.6vw',
                        lineHeight: '2.5vw',

                      },
                      container: {
                        borderRadius: '5px',
                        color: '#ffffff',
                        textAlign: 'left',
                        // width: '100%',
                        // maxWidth: '750px',
                        backgroundColor: '#8B8B8B',
                      },
                      arrow: {
                        color: '#8B8B8B',
                      },
                    }}
                    content={"mortality" in slide.timeline ? slide.timeline.mortality.hover : ''}
                  >
                    <div id='adjustedLifespan'
                         className='gTAssistedEndpointRight'>{timelineData.adjustedLifespan.toFixed(0)}</div>
                  </Floater> : <div id='adjustedLifespan'
                                    className='gTAssistedEndpointRight'>{timelineData.adjustedLifespan.toFixed(0)}</div>}</span>
              </div>
              <div className='gTimelineDotted'></div>

              {advisor.locale === "en-AU" &&
              <Floater
                event="hover"
                eventDelay={0}
                placement="top"
                style={{width: '100%'}}
                styles={{
                  floater: {
                    zIndex: 99999999,
                    maxWidth: '65%',
                    width:'auto'
                  },
                  content: {
                    fontFamily: 'Avenir',
                    //fontSize: '1vm',
                    fontSize: '1.6vw',
                    lineHeight: '2.5vw',
                  },
                  container: {
                    borderRadius: '5px',
                    color: '#ffffff',
                    textAlign: 'left',
                    // width: '50vw',
                    // maxWidth: '750px',
                    backgroundColor: '#FE912A',
                  },
                  arrow: {
                    color: '#FE912A'
                  },
                }}
                content={[...slide.timeline.assisted.hover.slice(0,1)]}


                //content={[...slide.timeline.assisted.hover.slice(0, 1), timelineData.disabilityYearsDisplay, slide.timeline.assisted.hover.slice(2, 3), timelineData.outOfPocketCost, slide.timeline.assisted.hover.slice(4, 5)]}
              >
                <div className='gTAssistedYearsBar'>{timelineData.disabilityYears.toFixed(0)}</div>
              </Floater>
              }


              {advisor.locale === "en-US" &&
              <Floater
                event="hover"
                eventDelay={0}
                placement="top"
                style={{width: '100%'}}
                styles={{
                  floater: {
                    zIndex: 99999999,
                    maxWidth: '65%',
                    width:'auto'
                  },
                  content: {
                    fontFamily: 'Avenir',
                    //fontSize: '1vm',
                    fontSize: '1.6vw',
                    lineHeight: '2.5vw',
                  },
                  container: {
                    borderRadius: '5px',
                    color: '#ffffff',
                    textAlign: 'left',
                    // width: '50vw',
                    // maxWidth: '750px',
                    backgroundColor: '#FE912A',
                  },
                  arrow: {
                    color: '#FE912A'
                  },
                }}
                content={[...slide.timeline.assisted.hover.slice(0, 1), timelineData.disabilityYearsDisplay, slide.timeline.assisted.hover.slice(2, 3), timelineData.outOfPocketCost, slide.timeline.assisted.hover.slice(4, 5)]}
              >
               <div className='gTAssistedYearsBar'>{timelineData.disabilityYears.toFixed(0)}</div>
              </Floater>
                }
              {/* <DivPopover child={<div className='gTAssistedYearsBar'>{timelineData.disabilityYears.toFixed(0)}</div>}
                popover={[...slide.timeline.assisted.hover.slice(0, 1), parseInt(NRound(timelineData.disabilityYears), 10), slide.timeline.assisted.hover.slice(2, 3), timelineData.outOfPocketCost,slide.timeline.assisted.hover.slice(4,5)]} /> */}
              <div className='gTAssistedFooter'>{slide.timeline.assisted.label}</div>
            </div>
            {advisor.version > 18 &&
              <div className='gTAssistedYears' style={{width: "50px", display: timelineData.displayAst}}>
                <div className='gTGoalBuffer'>Filler</div>
                <div className='gTAssistedEndpoints'>
                  <div className='gTAssistedEndpointBlank'></div>
                </div>
                <div className='gTimelineDotted' style={{visibility: "hidden", height: "1px"}}></div>
                <div className='gTAssistedYearsBarExt'></div>
                <div className='gTAssistedFooter'></div>
              </div>}
          </div>
        </div>
        <div className='gTFooter' style={{display: timelineData.displayFooter}}>
          <div className='gTFooterContainer'>
            <Floater
              event="hover"
              eventDelay={0}
              placement="top"
              style={{width: '100%'}}
              styles={{
                floater: {
                  zIndex: 99999999,
                  width: 'auto',
                  maxWidth: '40%',
                },
                content: {
                  fontFamily: 'Avenir',
                  //fontSize: '1vm',
                   fontSize: '1.6vw',
                   lineHeight: '2.5vw',
                },
                container: {
                  borderRadius: '5px',
                  color: '#ffffff',
                  textAlign: 'left',
                  // width: '50vw',
                  // maxWidth: '750px',
                  backgroundColor: Math.round(timelineData.yearsLostAdjustment) <= -1 ? '#E94E29' : '#686868',
                },
                arrow: {
                  color: Math.round(timelineData.yearsLostAdjustment) <= -1 ? '#E94E29' : '#686868',
                },
              }}
              content={slide.timeline.lost.hover}
            >
              <div className="gTYearsLostContainer">
                <div
                  className={Math.round(timelineData.yearsLostAdjustment) <= -1 ? 'gTYearsLostActive' : 'gTYearsLostInactive'}>{Math.round(timelineData.yearsLostAdjustment) <= -1 ? Math.abs(Math.round(timelineData.yearsLostAdjustment).toFixed(0)) : 0} YEARS
                  LOST
                </div>
              </div>
            </Floater>
            {/* <DivPopover childClass={"gTYearsLostContainer"} child={<div className={Math.round(timelineData.yearsLostAdjustment) <= -1 ? 'gTYearsLostActive' : 'gTYearsLostInactive'}>{Math.round(timelineData.yearsLostAdjustment) <= -1 ? Math.abs(Math.round(timelineData.yearsLostAdjustment).toFixed(0)) : 0} YEARS LOST</div>}
              popover={slide.timeline.lost.hover} /> */}
            <div className='gTBehaviors'><CheckboxForm checks={timelineData.checkboxes}/></div>
            {/* <CalcLinkButton link={{text: "Add your partner?", value:halovalues.smokes}} /> */}
          </div>
        </div>
      </MediaQuery>
    </div>
  )
}

HaloTimeline.propTypes = {
  classes: PropTypes.object,
  open: PropTypes.bool,
  confetti: PropTypes.bool,
  confetticallback: PropTypes.func,
}

export default (withStyles(styles))(HaloTimeline);