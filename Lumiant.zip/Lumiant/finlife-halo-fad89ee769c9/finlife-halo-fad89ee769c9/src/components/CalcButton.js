import React, { useCallback } from 'react'
import { useDispatch } from 'redux-react-hook';
import PropTypes from 'prop-types'
import { button_action } from '../actions/hactions'

const CalcButton = ({inline, buttons, cssStyle, buttonContainerStyle}) => {
  const dispatch = useDispatch();
  const onButtonClick = useCallback(
    (action, store, value) => (dispatch(button_action(action, store, value))),
    [],
  )

  var addedContainerStyle = {}
  var addedButtonStyle = {cursor: 'pointer'}
  var classStyle = cssStyle
  if (inline) {
    addedContainerStyle['flexWrap'] = 'nowrap'
    addedContainerStyle['marginRight'] = '2.737642585551331vw'
    classStyle = cssStyle + "Inline"
  }

  // edge case with css style being overridden swapping this to div element doesn't effect appearance
  // or function
  if(cssStyle === "titleButton") {
    return (
        <div className='gButtonContainer' style={buttonContainerStyle}>
          {buttons.map((button, index) => {
            return (
                <div key={index} style={button.addedButtonStyle} disabled={button.disabled}
                     className={button.disabled
                         ? classStyle + " disabled"
                         : button.active
                         ? classStyle + " active"
                         : classStyle + " inactive"}
                     onClick={() => onButtonClick(button.action, button.store, button.value)}>
                  <div style={{
                    display: 'table',
                    height: '100%',
                    width: '100%',
                    overflow: 'hidden'
                  }}>
                    <div id={button.label.replace(/(\s|-)/g, "_").toLowerCase()}
                         style={{display: 'table-cell', verticalAlign: 'middle'}}>
                      <div style={{cursor: 'pointer'}}>{button.label}</div>
                    </div>
                  </div>
                </div>
            )
          })}
        </div>
    )
  }else if (buttonContainerStyle){
        return (
        <div className='gButtonContainer' style={buttonContainerStyle}>
          {buttons.map((button, index) => {
            return (
                <button key={index} style={button.addedButtonStyle} disabled={button.disabled}
                     className={button.disabled
                         ? classStyle + " disabled"
                         : button.active
                         ? classStyle + " active"
                         : classStyle + " inactive"}
                     onClick={() => onButtonClick(button.action, button.store, button.value)}>
                  <div style={{
                    display: 'table',
                    height: '100%',
                    width: '100%',
                    overflow: 'hidden'
                  }}>
                    <div id={button.label.replace(/(\s|-)/g, "_").toLowerCase()}
                         style={{display: 'table-cell', verticalAlign: 'middle'}}>
                      <div style={{cursor: 'pointer'}}>{button.label}</div>
                    </div>
                  </div>
                </button>
            )
          })}
        </div>
    )
  } else {
    return (
        <div className='gButtonContainer' style={addedContainerStyle}>
          {buttons.map((button, index) => {
            return (
                <button key={index} style={button.addedButtonStyle} disabled={button.disabled}
                     className={button.disabled
                         ? classStyle + " disabled"
                         : button.active
                         ? classStyle + " active"
                         : classStyle + " inactive"}
                     onClick={() => onButtonClick(button.action, button.store, button.value)}>
                  <div style={{
                    display: 'table',
                    height: '100%',
                    width: '100%',
                    overflow: 'hidden'
                  }}>
                    <div id={button.label.replace(/(\s|-)/g, "_").toLowerCase()}
                         style={{display: 'table-cell', verticalAlign: 'middle'}}>
                      <div style={button.disabled ? {cursor: 'not-allowed'} : {cursor: 'pointer'}}>{button.label}</div>
                    </div>
                  </div>
                </button>
            )
          })}
        </div>
    )
  }
}

CalcButton.propTypes = {
  inline: PropTypes.bool,
  buttons: PropTypes.array,
  cssStyle: PropTypes.string,
}

export default CalcButton