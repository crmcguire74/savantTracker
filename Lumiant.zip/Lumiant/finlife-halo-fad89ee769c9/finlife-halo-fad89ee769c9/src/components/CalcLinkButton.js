import React, { useCallback } from 'react'
import { useDispatch } from 'redux-react-hook';
import PropTypes from 'prop-types'
import Button from '@material-ui/core/Button';
import { restart_halo_couple } from '../actions/hactions'

const CalcLinkButton = ({link, cssStyle}) => {
  const dispatch = useDispatch();
  const onButtonClick = useCallback(
    (value) => (dispatch(restart_halo_couple(value))),
    [],
  )

  return (
    <div className='gButtonContainer' style={{textAlign: "center"}}>
      <Button
        onClick={() => onButtonClick(link.value)}
        label={link.text}
        className={cssStyle}
        style={{color: "blue"}}
      >{link.text}</Button>
    </div>
  )
}

CalcLinkButton.propTypes = {
  link: PropTypes.object,
  cssStyle: PropTypes.string,
}

export default CalcLinkButton
