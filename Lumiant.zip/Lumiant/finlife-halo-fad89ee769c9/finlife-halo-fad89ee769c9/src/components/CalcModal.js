import React, { useCallback, useEffect } from 'react'
import { useDispatch, useMappedState } from 'redux-react-hook';
import TitlePage from './TitlePage';
import GridSelect from './GridSelect';
import IconSelect from './IconSelect';
import HaloTimeline from './HaloTimeline';
import HaloNoTimeline from './HaloNoTimeline';
import CloseDialog from './CloseDialog'
import Haloading from './Haloading';
import {
  button_action
} from '../actions/hactions'
import SnackbarDialog from './SnackbarDialog';

const getQueryStringParams = query => {
  return query ?
    (/^[?#]/.test(query) ? query.slice(1) : query)
      .split('&')
      .reduce((params, param) => {
        let [key, value] = param.split('=');
        params[key] = value ? decodeURIComponent(value.replace(/\+/g, ' ')) : '';
        return params;
      }, {}) : {}
};

const CalcModal = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    const queryinputs = getQueryStringParams(window.location.search)
    if (Object.keys(queryinputs).length > 0) {
      dispatch({
        type: "QUERY_INPUTS",
        inputs: queryinputs
      })
    }
  }, [])

  const onButtonClick = useCallback(
    (action, store, value) => (dispatch(button_action(action, store, value))),
    [],
  )
  //Get data from and subscribe to the store
  const mapState = useCallback(
    state => ({
      slide: state.halo_reducer.slide,
      version: state.halo_reducer.advisor.version,
      locale: state.halo_reducer.advisor.locale,
      images: state.halo_reducer.images,
      api: state.halo_reducer.api,
    }),
    []);
  const {
    slide,
    images,
    api,
    version,
    locale,
  } = useMappedState(mapState);

  var next
  if (api.state !== 'idle' || images.length > 0) {
    next = <Haloading api={api} images={images}/>
  } else {
    switch (slide.type) {
      case 'title':
        next = <TitlePage slide={slide}/>
        break
      case 'iconselect':
        next = <IconSelect slide={slide} version={version} onButtonClick={onButtonClick} locale={locale}/>
        break
      case 'gridselect':
        next = <GridSelect slide={slide} version={version}/>
        break
      case 'halotimeline':
        next = <HaloTimeline version={version}/>
        break
      case 'halonotimeline':
        next = <HaloNoTimeline version={version}/>
        break
      default:
        next = <TitlePage slide={slide}/>
        break
    }
  }
  return (
    <div className="gc-modal-container">
      <div className="gc-modal" id="gcModal">
        {next}
        <CloseDialog/>
        <SnackbarDialog/>
      </div>
    </div>
  )

}

export default CalcModal