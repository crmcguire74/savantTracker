export const NRound = (num) => {
  return Math.sign(num) * Math.round(Math.abs(num))
}