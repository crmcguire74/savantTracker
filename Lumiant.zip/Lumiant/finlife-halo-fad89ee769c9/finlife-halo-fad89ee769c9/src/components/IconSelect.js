import React from 'react';
import PropTypes from 'prop-types'
import MediaQuery from 'react-responsive';
import './IconSelect.css';
import MobileStepper from '@material-ui/core/MobileStepper';
import CalcInputs from './CalcInputs';
import MiscInputs from './MiscInputs';
import CalcIcons from './CalcIcons';
import { withStyles } from '@material-ui/core/styles';
import Footer from './Footer';
import CalcIcon from './CalcIcon';
import CalcButton from './CalcButton';
import HaloSlider from './HaloSlider';
import HaloHeader from './HaloHeader';
import HelpOutline from '@material-ui/icons/HelpOutline'
import HaloDownshift from './HaloDownshift';
import Floater from 'react-floater';

const styles = theme => ({
  root: {
    transform: 'rotate(90deg)',
    backgroundColor: 'transparent',
  },
  dot: {
    width: '0.68441vw',
    height: '0.68441vw',
    borderRadius: '0.68441vw',
    margin: '0.13688vw',
    [theme.breakpoints.up(1315)]: {
      width: '10px',
      height: '10px',
      borderRadius: '10px',
      margin: '2px',
    },
  }
})

const IconSelect = ({slide, classes, version, locale}) => (
  <div className='gContainer'>
    <MediaQuery query="(max-width: 667px)">
      <HaloHeader header={slide.header}/>
      <div className='gContentContainer'>
        {!slide.misc.inputs &&
          <div className='gMiscIcon'>{slide.misc.icon && <CalcIcon icon={slide.misc.icon}/>}</div>}
        <div className='gContent'>
          <div className='gQuestionLarge'>
            {slide.question.large instanceof Array ?
              slide.question.large.map((text, index) => {
                return (<span key={index}>{text}</span>)
              }) : slide.question.large
            }{slide.question.popover &&
            <Floater
              event="hover"
              eventDelay={0}
              placement="top"
              showCloseButton={true}
              styles={{
                floater: {
                  zIndex: "99999999",
                  maxWidth: '90%',
                },
                content: {
                  fontFamily: 'Avenir',
                  fontSize: '2.25vh',
                  lineHeight: '3vh',
                },
                container: {
                  borderRadius: '5px',
                  color: '#8d7979',
                  textAlign: 'left',
                  // width: '50vw',
                  // maxWidth: '750px',
                  backgroundColor: '#EBEBEB',
                },
                arrow: {
                  color: '#EBEBEB'
                },
              }}
              content={slide.question.popover}
            >
              <HelpOutline style={{width: 'auto'}} className='gQuestionPopover'/>
            </Floater>}</div>
          <div className='gQuestionSmall'>{slide.question.small instanceof Array ?
            slide.question.small.map((text, index) => {
              return (<span key={index}>{text}</span>)
            }) : slide.question.small
          }</div>
          {slide.icons && slide.icons.length > 0 &&
            <div className='gIconsContainer'>
              <CalcIcons/>
              {slide.buttons && slide.buttons.length > 0 &&
                <div className='gIconButtonContainer'><CalcButton cssStyle={'gButton'} buttons={slide.buttons}/></div>}
            </div>
          }
          {slide.inputs && slide.inputs.length > 0 &&
            <div className='gInputContainer'>
              <CalcInputs inputs={slide.inputs}/>
              {slide.buttons && slide.buttons.length > 0 &&
                <CalcButton cssStyle={'gButton'} buttons={slide.buttons}/>}
            </div>
          }
          {slide.slider &&
            <div className='gSliderContainer'>
              <HaloSlider slider={slide.slider}/>
              {slide.buttons && slide.buttons.length > 0 &&
                <div className='gSliderButtonContainer'><CalcButton cssStyle={'gButton'} buttons={slide.buttons}/>
                </div>}
            </div>
          }
          {slide.select &&
            <div className='gSliderContainer'>
              <HaloDownshift select={slide.select}locale={locale}/>
              <CalcButton inline={slide.inline} cssStyle={'gButton'} buttons={slide.buttons}/>
            </div>
          }
          {slide.buttons && slide.buttons.length > 0 && !slide.inputs && !slide.slider && !slide.select && !slide.icons &&
            <CalcButton inline={slide.inline} cssStyle={'gButton'} buttons={slide.buttons}/>
          }
          {slide.checks && slide.checks.length > 0 &&
            <CalcButton cssStyle={'gButton'} buttons={slide.checks}/>
          }
        </div>
        {slide.misc &&
          <div className='gMisc'>
            {slide.misc.body &&
              <div className='gMiscSubcContainer'>
                <div className='gMiscTitle'>{slide.misc.title}</div>
                <div className='gMiscLineContainer'>
                  <div className='gMiscLine'></div>
                </div>
                <div className='gMiscText'>{slide.misc.body instanceof Array ?
                  slide.misc.body.map((text, index) => {
                    return (<span key={index}>{text}</span>)
                  }) : slide.misc.body
                }</div>
              </div>}
            {slide.misc.inputs &&
              <div className='gMiscInputsContainer'>
                <MiscInputs inputs={slide.misc.inputs}/>
                <CalcButton cssStyle={'gButton'} buttons={slide.misc.buttons}/>
              </div>
            }
          </div>
        }
      </div>
      <Footer slide={slide} version={version}/>
    </MediaQuery>
    <MediaQuery query="(min-width: 668px)">
      <HaloHeader header={slide.header}/>
      <div className='gContentContainer'>
        <div className='gContent'>
          <div className='gQuestionLarge'>
            {slide.question.large instanceof Array ?
              slide.question.large.map((text, index) => {
                return (<span key={index}>{text}</span>)
              }) : slide.question.large
            }{slide.question.popover &&
            <Floater
              event="hover"
              eventDelay={0}
              placement="top"
              // style={{width:'100%'}}
              styles={{
                floater: {
                  zIndex: "99999999",
                  width: '80%', maxWidth: '800px',
                },
                content: {
                  fontFamily: 'Avenir',
                  fontSize: '1.9vw',
                  lineHeight: '2.5vw',
                },
                container: {
                  borderRadius: '5px',
                  color: '#8d7979',
                  textAlign: 'left',
                  // width: '50vw',
                  // maxWidth: '1315px',
                  backgroundColor: '#EBEBEB',
                },
                arrow: {
                  color: '#EBEBEB'
                },
              }}
              content={slide.question.popover}
            >
              <HelpOutline style={{width: 'auto'}} className='gQuestionPopover'/>
            </Floater>}</div>
          <div className='gQuestionSmall'>{slide.question.small instanceof Array ?
            slide.question.small.map((text, index) => {
              return (<span key={index}>{text}</span>)
            }) : slide.question.small
          }</div>
          {slide.icons && slide.icons.length > 0 &&
            <div className='gIconsContainer'>
              <CalcIcons/>
              {slide.buttons && slide.buttons.length > 0 &&
                <div className='gIconButtonContainer'><CalcButton cssStyle={'gButton'} buttons={slide.buttons}/></div>}
            </div>
          }
          {slide.inputs && slide.inputs.length > 0 &&
            <div className='gInputContainer'>
              <CalcInputs inputs={slide.inputs} buttons={slide.buttons} buttonContainerStyle={slide.buttonContainerStyle} />
            </div>
          }
          {slide.slider &&
            <div className='gSliderContainer'>
              <HaloSlider slider={slide.slider}/>
              {slide.buttons && slide.buttons.length > 0 &&
                <div className='gSliderButtonContainer'><CalcButton cssStyle={'gButton'} buttons={slide.buttons}/>
                </div>}
            </div>
          }
          {slide.select &&
            <div className='gSliderContainer'>
              <HaloDownshift select={slide.select}locale={locale}/>
              <CalcButton inline={slide.inline} cssStyle={'gButton'} buttons={slide.buttons}/>
            </div>
          }
          {slide.buttons && slide.buttons.length > 0 && !slide.inputs && !slide.slider && !slide.select && !slide.icons &&
            <CalcButton inline={slide.inline} cssStyle={'gButton'} buttons={slide.buttons}/>
          }
          {slide.checks && slide.checks.length > 0 &&
            <CalcButton cssStyle={'gButton'} buttons={slide.checks}/>
          }
        </div>
        {slide.misc &&
          <div className='gMisc'>
            {!slide.misc.inputs &&
              <div className='gMiscIcon'>{slide.misc.icon && <CalcIcon icon={slide.misc.icon}/>}</div>}
            {slide.misc.title &&
              <div className='gMiscLineContainer'>
                <div className='gMiscLine'></div>
              </div>
            }
            {slide.misc.body &&
              <div className='gMiscSubcContainer'>
                <div className='gMiscTitle'>{slide.misc.title}</div>
                <div className='gMiscText'>{slide.misc.body instanceof Array ?
                  slide.misc.body.map((text, index) => {
                    return (<span key={index}>{text}</span>)
                  }) : slide.misc.body
                }</div>
              </div>}
            {slide.misc.inputs &&
              <div className='gMiscInputsContainer'>
                <MiscInputs inputs={slide.misc.inputs}/>
                <CalcButton cssStyle={'gButton'} buttons={slide.misc.buttons}/>
              </div>
            }
          </div>
        }
        <div className='gStepperContainer'>
          <div className='gStepperWrapper'>
            <MobileStepper classes={{root: classes.root, dot: classes.dot}} type='dots'
                           steps={getMobileStepperSize(version)}
                           orientation="vertical"
                           position="static"
                           activeStep={slide.step}/>
          </div>
        </div>
      </div>
      <Footer slide={slide}/>
    </MediaQuery>
  </div>
)

// mobile stepper needs to be updated based on the version

export const getMobileStepperSize = (version) => {
  if (version  === 19){
    return 22
  } else if (version >= 23 || version === 21){
    return 19
  }
  return 17
}

IconSelect.propTypes = {
  slide: PropTypes.object,
  classes: PropTypes.object,
  version: PropTypes.number,
}

export default (withStyles(styles))(IconSelect);
