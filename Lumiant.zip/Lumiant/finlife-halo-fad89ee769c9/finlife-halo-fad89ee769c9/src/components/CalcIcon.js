import React from 'react';
import PropTypes from 'prop-types'
import './IconSelect.css'

const CalcIcon = ({icon}) => (
  <div className='gIconContainer'>
    <figure className='gFigure'>
      <img className='gFigureImg' alt={icon.action} src={icon.image}/>
      {icon.caption && <figcaption>{icon.caption}</figcaption>}
      {icon.active && <div className='gCircle'></div>}
    </figure>
  </div>
)

CalcIcon.propTypes = {
  icon: PropTypes.object,
}

export default CalcIcon