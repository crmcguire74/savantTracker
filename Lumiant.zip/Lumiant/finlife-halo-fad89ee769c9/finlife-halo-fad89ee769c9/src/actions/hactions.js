import { API_ROOT, API_CRED } from "../api-config";
import { getHALOJSON } from '../assessments/helpers'

export const NEXT_BUTTON = 'NEXT_BUTTON'
export const BACK_BUTTON = 'BACK_BUTTON'
export const SELECT_BUTTON = 'SELECT_BUTTON'
export const SET_VALUE = 'SET_VALUE'
export const SET_VALUE_NEXT = 'SET_VALUE_NEXT'
export const TRIGGER_FOLLOWUP = 'TRIGGER_FOLLOWUP'
export const TOAST_ERROR = 'TOAST_ERROR'
export const OPEN_HALO = 'OPEN_HALO'
export const CLOSE_HALO = 'CLOSE_HALO'
export const OPEN_SNACKBAR = 'OPEN_SNACKBAR'
export const CLOSE_SNACKBAR = 'CLOSE_SNACKBAR'
export const OPEN_CLOSEDIALOG = 'OPEN_CLOSEDIALOG'
export const CLOSE_CLOSEDIALOG = 'CLOSE_CLOSEDIALOG'
export const RESTART_HALO = 'RESTART_HALO'
export const RESTART_HALO_COUPLE = 'RESTART_HALO_COUPLE'
export const HALO_API = 'HALO_API'
export const HALO_API_SUCCESS = 'HALO_API_SUCCESS'
export const HALO_API_FAILURE = 'HALO_API_FAILURE'
export const IMAGE_LOADED = 'IMAGE_LOADED'
export const IMAGE_ERROR = 'IMAGE_ERROR'

export const next_button = (action, store, value) => {
  return {
    type: NEXT_BUTTON,
    store: store,
    value: value,
    action: action
  }
}

export const back_button = {
  type: BACK_BUTTON
}

export const select_button = {
  type: SELECT_BUTTON
}

export const open_halo = {
  type: OPEN_HALO
}

export const close_halo = {
  type: CLOSE_HALO
}

export const open_closedialog = (options) => {
  return {
    type: OPEN_CLOSEDIALOG,
    options: options,
  }
}

export const close_closedialog = {
  type: CLOSE_CLOSEDIALOG
}

export const open_snackbar = (message) => {
  return {
    type: OPEN_SNACKBAR,
    message: message,
  }
}

export const close_snackbar = {
  type: CLOSE_SNACKBAR,
}

export const restart_halo = {
  type: RESTART_HALO
}

export const restart_halo_couple = (value) => {
  return {
    type: RESTART_HALO_COUPLE,
    value: value
  }
}

export const halo_api = {
  type: HALO_API
}

export const halo_api_success = {
  type: HALO_API_SUCCESS
}
export const halo_api_failure = {
  type: HALO_API_FAILURE
}

export const set_value = (action, store, value) => {
  return {
    type: SET_VALUE,
    store: store,
    value: value,
    action: action
  }
}

export const set_value_next = (action, store, value) => {
  return {
    type: SET_VALUE_NEXT,
    store: store,
    value: value,
    action: action
  }
}

export const trigger_followup = (store, value) => {
  return {
    type: TRIGGER_FOLLOWUP,
    store: store,
    value: value,
  }
}

export const imageLoaded = (image) => {
  return {
    type: IMAGE_LOADED,
    image: image,
  }
}

export const imageError = (image) => {
  return {
    type: IMAGE_ERROR,
    image: image,
  }
}

export const button_action = (action, store, value) => {
  switch (action) {
    case "next":
      return next_button(action, store, value)
    case "back":
      return back_button
    case "setvaluenext":
      return set_value_next(action, store, value)
    case "select":
    default:
      return set_value(action, store, value)
  }
}

export const snackbar_action = (action, store, value) => {
  switch (action) {
    case "close":
      return next_button(action, store, value)
    default:
      return set_value(action, store, value)
  }
}

export const REQUEST_API = 'REQUEST_API'

export function requestAPI(api) {
  return {
    type: REQUEST_API,
    api: api
  }
}

export const RECEIVE_API = 'RECEIVE_API'

export function receiveAPI(api, json) {
  return {
    type: RECEIVE_API,
    api: api,
    json: json,
    receivedAt: Date.now()
  }
}

export const API_TIMEOUT = 'API_TIMEOUT'

export function apiTimout(api) {
  return {
    type: API_TIMEOUT,
    api: api,
  }
}

const getQueryStringParams = query => {
  return query ?
    (/^[?#]/.test(query) ? query.slice(1) : query)
      .split('&')
      .reduce((params, param) => {
        let [key, value] = param.split('=');
        params[key] = value ? decodeURIComponent(value.replace(/\+/g, ' ')) : '';
        return params;
      }, {}) : {}
};

export function fetchAdvisor() {
  // Thunk middleware knows how to handle functions.
  // It passes the dispatch method as an argument to the function,
  // thus making it able to dispatch actions itself.
  return function (dispatch) {
    // First dispatch: the app state is updated to inform
    // that the API call is starting.
    dispatch(requestAPI('advisor'))

    // dispatch(open_halo)

    // The function called by the thunk middleware can return a value,
    // that is passed on as the return value of the dispatch method.

    // In this case, we return a promise to wait for.
    // This is not required by thunk middleware, but it is convenient for us.

    // check hostname for soft release path
    let apiPath = ""
    if(window.location.hostname === "aws-halo-soft-release.genivity.com") {
      //replace hostname to prod path so button call is successful
      let path = "halo.lumiant.io"
      apiPath = `${window.location.href.replace("aws-halo-soft-release.genivity.com", "halo.lumiant.io")}`
    }else if(window.location.hostname === "halo.genivity.com") {
      apiPath = `${window.location.href.replace("halo.genivity.com", "halo.lumiant.io")}`
    }else{
      apiPath = `${window.location.href.replace(window.location.search, '')}${window.location.search.replace(/^\?/, "&")}`
    }

    return fetch(`${API_ROOT}/advisor?url=${apiPath}`,
      {
        method: "GET",
        mode: 'cors',
        credentials: API_CRED,
        header: new Headers({
          'Access-Control-Allow-Origin': window.location.origin,
          'Content-Type': 'multipart/form-data',
        })
      })
      .then(
        response => {
          response.headers.get("x-csrf-token") != null ? localStorage.setItem('halo-csrf', response.headers.get("x-csrf-token")) : null
          return response.json()
        },
        // Do not use catch, because that will also catch
        // any errors in the dispatch and resulting render,
        // causing a loop of 'Unexpected batch number' errors.
        // https://github.com/facebook/react/issues/6895
        error => console.log('An error occurred.', error)
      )
      .then(json => {
          // We can dispatch many times!
          // Here, we update the app state with the results of the API call.

          dispatch(receiveAPI('advisor', json))
          const queryinputs = getQueryStringParams(window.location.search)
          console.log("Queryintpuasedf", queryinputs)
          if (Object.keys(queryinputs).length > 0) {
            dispatch({
              type: "QUERY_INPUTS",
              inputs: queryinputs
            })
          }
        }
      )
  }
}

export function runHaloClick() {
  // Thunk middleware knows how to handle functions.
  // It passes the dispatch method as an argument to the function,
  // thus making it able to dispatch actions itself.

  return function (dispatch, getState) {
    // First dispatch: the app state is updated to inform
    // that the API call is starting.
    const halo_reducer = getState().halo_reducer;
    // dispatch(requestAPI('click'))

    // The function called by the thunk middleware can return a value,
    // that is passed on as the return value of the dispatch method.

    // In this case, we return a promise to wait for.
    // This is not required by thunk middleware, but it is convenient for us.

    return fetch(`${API_ROOT}/halo`, {
      mode: 'cors',
      credentials: API_CRED,
      header: new Headers({
        'Access-Control-Allow-Origin': window.location.host,
        // 'Content-Type': 'multipart/form-data',
        'x-csrf-token': localStorage.getItem('halo-csrf')
      }),
      method: 'post',
      body: JSON.stringify(Object.assign({}, halo_reducer.halo, {
        version: halo_reducer.advisor.version,
        locale: halo_reducer.advisor.locale,
        category: halo_reducer.advisor.category
      }))
    })
    // return fetch(`https://www.reddit.com/r/golang.json`)
    // .then(
    //   dispatch(action)
    // )
    // .then(
    //   dispatch(receiveAPI('click', json))
    // )
  }
}

export function runHalo() {
  // Thunk middleware knows how to handle functions.
  // It passes the dispatch method as an argument to the function,
  // thus making it able to dispatch actions itself.

  return function (dispatch, getState) {
    // First dispatch: the app state is updated to inform
    // that the API call is starting.
    const halo_reducer = getState().halo_reducer;
    dispatch(requestAPI('midpoint'))

    // The function called by the thunk middleware can return a value,
    // that is passed on as the return value of the dispatch method.

    // In this case, we return a promise to wait for.
    // This is not required by thunk middleware, but it is convenient for us.

    // if in the rare event personal details aren't added in due to getDetails

    // if the user details are empty override the values and use getDetails instead
    // as the survey prepopulate function doesn't seem to work if user doesn't interact
    // with input so in the call this will update the details accordingly

    if (halo_reducer.halo.firstName === ""){
      halo_reducer.halo.firstName = halo_reducer?.getDetails?.firstName || ""
    }

    if (halo_reducer.halo.lastName === "") {
      halo_reducer.halo.lastName = halo_reducer?.getDetails?.lastName || ""
    }

    if (halo_reducer.halo.email === "") {
      halo_reducer.halo.email = halo_reducer?.getDetails?.email || ""
    }

    return fetch(`${API_ROOT}/halo`,
      {
        mode: 'cors',
        credentials: API_CRED,
        header: new Headers({
          'Access-Control-Allow-Origin': window.location.host,
          // 'Content-Type': 'multipart/form-data',
          'x-csrf-token': localStorage.getItem('halo-csrf')
        }),
        method: 'post',
        body: getHALOJSON(halo_reducer)
      })
      // return fetch(`https://www.reddit.com/r/golang.json`)
      // .then(
      //   dispatch(action)
      // )
      .then(
        response => {
          response.headers.get("x-csrf-token") != null ? localStorage.setItem('halo-csrf', response.headers.get("x-csrf-token")) : null
          return response.json()
        },
        // Do not use catch, because that will also catch
        // any errors in the dispatch and resulting render,
        // causing a loop of 'Unexpected batch number' errors.
        // https://github.com/facebook/react/issues/6895
        error => console.log('An error occurred.', error)
      )
      .then(json =>
        // We can dispatch many times!
        // Here, we update the app state with the results of the API call.

        dispatch(receiveAPI('midpoint', json))
      )
  }
}

export function runHaloFinal() {
  // Thunk middleware knows how to handle functions.
  // It passes the dispatch method as an argument to the function,
  // thus making it able to dispatch actions itself.

  return function (dispatch, getState) {
    // First dispatch: the app state is updated to inform
    // that the API call is starting.
    const halo_reducer = getState().halo_reducer;

    dispatch(requestAPI('final'))

    // The function called by the thunk middleware can return a value,
    // that is passed on as the return value of the dispatch method.

    // In this case, we return a promise to wait for.
    // This is not required by thunk middleware, but it is convenient for us.

    if (halo_reducer.halo.firstName === ""){
      halo_reducer.halo.firstName = halo_reducer?.getDetails?.firstName || ""
    }

    if (halo_reducer.halo.lastName === "") {
      halo_reducer.halo.lastName = halo_reducer?.getDetails?.lastName || ""
    }

    if (halo_reducer.halo.email === "") {
      halo_reducer.halo.email = halo_reducer?.getDetails?.email || ""
    }


    return fetch(`${API_ROOT}/halo`,
      {
        mode: 'cors',
        credentials: API_CRED,
        header: new Headers({
          'Access-Control-Allow-Origin': window.location.host,
          // 'Content-Type': 'multipart/form-data',
          'x-csrf-token': localStorage.getItem('halo-csrf')
        }),
        method: 'post',
        body: getHALOJSON(halo_reducer)
      })
      // return fetch(`https://www.reddit.com/r/golang.json`)
      // .then(
      //   dispatch(action)
      // )
      .then(
        response => {
          response.headers.get("x-csrf-token") != null ? localStorage.setItem('halo-csrf', response.headers.get("x-csrf-token")) : null
          return response.json()
        },
        // Do not use catch, because that will also catch
        // any errors in the dispatch and resulting render,
        // causing a loop of 'Unexpected batch number' errors.
        // https://github.com/facebook/react/issues/6895
        error => console.log('An error occurred.', error)
      )
      .then(json =>
        // We can dispatch many times!
        // Here, we update the app state with the results of the API call.

        dispatch(receiveAPI('final', json))
      ).then(
        dispatch(button_action("next", "", ""))
      )
  }
}


export function fetchGetDetails() {

  return function (dispatch) {

    dispatch(requestAPI('getDetails'))

    let apiPath = ""
    if(window.location.hostname === "aws-halo-soft-release.genivity.com") {
      //replace hostname to prod path so button call is successful
      let path = "halo.lumiant.io"
      apiPath = `${window.location.href.replace("aws-halo-soft-release.genivity.com", "halo.lumiant.io")}`
    }else if(window.location.hostname === "halo.genivity.com") {
      apiPath = `${window.location.href.replace("halo.genivity.com", "halo.lumiant.io")}`
    }else{
      apiPath = `${window.location.href.replace(window.location.search, '')}${window.location.search.replace(/^\?/, "&")}`
    }

    const urlParams = new URLSearchParams(window.location.search)
    const qpClientId = urlParams.get("clientId")
    const qpInviteCode = urlParams.get("inviteCode")

    if ( qpClientId === null && qpInviteCode === null) {
      return
    }

    return  fetch(`${API_ROOT}/getDetails?inviteCode=${qpInviteCode}&clientId=${qpClientId}`,
      {
        method: "GET",
        mode: 'cors',
        credentials: API_CRED,
        header: new Headers({
          'Access-Control-Allow-Origin': window.location.origin,
          'Content-Type': 'multipart/form-data',
        })
      })
      .then(
        response => {
          response.headers.get("x-csrf-token") != null ? localStorage.setItem('halo-csrf', response.headers.get("x-csrf-token")) : null
          return response.json()
        },
        // Do not use catch, because that will also catch
        // any errors in the dispatch and resulting render,
        // causing a loop of 'Unexpected batch number' errors.
        // https://github.com/facebook/react/issues/6895
        error => console.log('An error occurred.', error)
      )
      .then(json => {
          // We can dispatch many times!
          // Here, we update the app state with the results of the API call.

          dispatch(receiveAPI('getDetails', json))
          const queryinputs = getQueryStringParams(window.location.search)
          console.log("Queryintpuasedf", queryinputs)
          if (Object.keys(queryinputs).length > 0) {
            dispatch({
              type: "QUERY_INPUTS",
              inputs: queryinputs
            })
          }
        }
      )
  }
}
