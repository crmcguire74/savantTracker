import { createLogic } from 'redux-logic';
import {
  NEXT_BUTTON,
  SET_VALUE,
  trigger_followup,
  SET_VALUE_NEXT,
  runHaloFinal,
  runHalo,
  open_snackbar
} from '../actions/hactions'

const nextLogic = createLogic({
  type: NEXT_BUTTON,
  validate({getState, action}, allow, reject) {
    let state = getState()
    let validate = state.halo_reducer.slide.validate
    if (validate) {
      let message = validate(state)
      if (message) {
        reject(open_snackbar(message))
      } else {
        if (action.store === 'final') {
          allow(runHaloFinal())
        } else {
          allow(action)
        }
      }
    } else {
      allow(action)
    }
  },
  process({getState, action}, dispatch, done) {
    let state = getState()
    if (action.store === 'final') {
      dispatch(runHaloFinal())
    } else if ((state.halo_reducer.advisor.version === 18 && action.store === "alzheimers") ||
      (state.halo_reducer.advisor.version > 18 && action.store === "stroke")) {
      dispatch(runHalo())
    }
    done()
  }
});

const setValueLogic = createLogic({
  type: SET_VALUE,
  validate({getState, action}, allow, reject) {
    let state = getState()
    // if (action.store === 'alzheimers'){
    //   runHalo()
    // }
    if ((action.action === 'toggle') && state.halo_reducer.halo.hasOwnProperty(action.store)) {
      action.value = !state.halo_reducer.halo[action.store]
    }
    if (state.halo_reducer.slide.followup && state.halo_reducer.slide.followup[action.value]) {
      allow(trigger_followup(action.store, action.value))
    } else {
      allow(action)
    }
  },
  process({getState, action}, dispatch, done) {
    let state = getState()
    if (action.store === 'final') {
      dispatch(runHaloFinal())
    } else if ((state.halo_reducer.advisor.version === 18 && action.store === "alzheimers") ||
      (state.halo_reducer.advisor.version > 18 && action.store === "stroke")) {
      dispatch(runHalo())
    }
    done()
  }
});

const setValueNextLogic = createLogic({
  type: SET_VALUE_NEXT,
  validate({getState, action}, allow, reject) {
    let state = getState()
    if ((action.action === 'toggle') && state.halo_reducer.halo.hasOwnProperty(action.store)) {
      action.value = !state.halo_reducer.halo[action.store]
    }
    if (state.halo_reducer.slide.followup && state.halo_reducer.slide.followup[action.value]) {
      allow(trigger_followup(action.store, action.value))
    } else {
      allow(action)
    }
  },
  process({getState, action}, dispatch, done) {
    let state = getState()
    if (action.store === 'final') {
      dispatch(runHaloFinal())
    } else if ((state.halo_reducer.advisor.version === 18 && action.store === "alzheimers") ||
      (state.halo_reducer.advisor.version > 18 && action.store === "stroke")) {
      dispatch(runHalo())
    }
    done()
  }
});

export default [nextLogic, setValueLogic, setValueNextLogic]