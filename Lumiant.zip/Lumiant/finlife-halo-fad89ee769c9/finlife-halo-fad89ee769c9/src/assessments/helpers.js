export const set_value_buttons = (slide, value) => {
  if (slide.buttons.length > 0) {
    let newbuttons = []

    for (var i = 0; i < slide.buttons.length; i++) {
      if (slide.buttons[i].value === value) {
        newbuttons.push(Object.assign({}, slide.buttons[i], {
          active: true
        }))
      } else {
        newbuttons.push(Object.assign({}, slide.buttons[i], {
          active: false
        }))
      }
    }

    return Object.assign({}, slide, {
      buttons: newbuttons
    })
  }
}

export const getHALOJSON = (halo_reducer)=> {
  // here we update what needs to be updated
  return (JSON.stringify(Object.assign({}, halo_reducer.halo, {
    version: halo_reducer.advisor.version,
    locale: halo_reducer.advisor.locale,
    category: halo_reducer.advisor.category,
    exercises: halo_reducer.advisor.version >= 20 ? (halo_reducer.halo.exercises > 0) : halo_reducer.halo.exercises,
  })))
}
