import { set_value_buttons } from "../helpers";
import React from 'react';
import { STATIC_ROOT } from "../../api-config";
import {PRIVACY_POLICY} from "../../constants/links";
import {
  both,
  cigar,
  cigarette, maxAge, maxCentimetres, maxWeightAU, minAge, minCentimetres,
  minWeightAU,
  smokingCurrent,
  smokingFormer,
  smokingNone
} from "../../constants/assessment";
import {populateFormerSmokerBtns} from "../../libs/smoker";

export const haloSlidesAUv23 = {
  0: {
    number: 0,
    next: 1,
    back: 0,
    type: 'title',
    header: {
      logo: `${STATIC_ROOT}/images/logo-halo-small.svg`,
      text: 'Lumiant HALO Longevity Planner',
    },
    title: {
      attention: "See the future, so we can plan for it.",
      small: [
        "Health and longevity projections are critical to a healthy financial plan.",
        <br></br>,
        "Let's get them right, together."
      ],
    },
    buttons: [{label: "Take the Assessment", action: "next"}],
    popover:
      {
        text: "Privacy Policy",
        type: "button",
        // TODO: zendesk article is outdated here need to update this article from JSM
        popover: [
          "By filling out the HALO (Health Analysis & Longevity Optimiser) planner, you are providing data to Lumiant to calculate your results. Your information is private. Lumiant does not share or sell your information to third parties. For more information please see: ",
          <a href={PRIVACY_POLICY}>Privacy Policy</a>
        ],
      },
    disclaimer: {
      text: "Disclaimer",
      type: "button",
      popover: ["This HALO assessment is intended for individuals in the general population who are not currently struggling with a serious health condition, such as Alzheimer's disease or cancer. We have attempted to take into account the individual's disease status with respect to diabetes, heart disease, and stroke, but even with these conditions a doctor's insights into an individual's disease state will be more accurate than the average estimates we give here. Individuals currently dealing with any serious health condition should discuss their personalised prognosis with their physician or other health care professionals."],
    },
  },
  1: {
    number: 1,
    next: 2,
    back: 0,
    step: 0,
    type: 'iconselect',
    header: {
      logo: `${STATIC_ROOT}/images/logo-halo-small.svg`,
      text: 'Lumiant HALO Longevity Planner',
    },
    misc: {
      title: "WHY IT MATTERS",
      body: "One area in which women have the upper hand is life expectancy. Women on average live 3 years longer than men. Source: Australian Institute for Health and Welfare",
    },
    icons: [{
      image: `${STATIC_ROOT}/images/icn_female.svg`,
      active: false,
      clickable: true,
      value: "female",
      caption: "FEMALE",
      store: "gender"
    },
      {
        image: `${STATIC_ROOT}/images/icn_male.svg`,
        active: false,
        clickable: true,
        value: "male",
        caption: "MALE",
        store: "gender"
      }],
    question: {large: "What is your gender?", small: "Please click an option."},
    buttons: [{label: "SUBMIT", store: '', value: "", action: 'next', active: false}],
    populate:
      (slide, store) => {
        var new_slide = Object.assign({}, slide)
        if (store.halo.gender === "female") {
          new_slide.icons = [{
            image: `${STATIC_ROOT}/images/icn_female.svg`,
            active: true,
            clickable: true,
            value: "female",
            caption: "FEMALE",
            store: "gender"
          },
            {
              image: `${STATIC_ROOT}/images/icn_male.svg`,
              active: false,
              clickable: true,
              value: "male",
              caption: "MALE",
              store: "gender"
            }]
        } else if (store.halo.gender === "female") {
          new_slide.icons = [{
            image: `${STATIC_ROOT}/images/icn_female.svg`,
            active: false,
            clickable: true,
            value: "female",
            caption: "FEMALE",
            store: "gender"
          },
            {
              image: `${STATIC_ROOT}/images/icn_male.svg`,
              active: true,
              clickable: true,
              value: "male",
              caption: "MALE",
              store: "gender"
            }]
        }
        return new_slide
      },
    validate:
      (store) => {
        if (["male", "female"].indexOf(store.halo_reducer.halo.gender) < 0) {
          return "Please select your gender."
        }
      },
    set_value:
      (slide, store, value) => {
        var newIcons = []
        if (slide.icons.length > 0) {
          for (var i = 0; i < slide.icons.length; i++) {
            if (slide.icons[i].value === value) {
              // slide.icons[i].current_image = slide.icons[i].active_image
              newIcons.push(Object.assign({}, slide.icons[i], {active: true}))
            } else {
              // slide.icons[i].current_image = slide.icons[i].inactive_image
              newIcons.push(Object.assign({}, slide.icons[i], {active: false}))
            }
          }
          slide.icons = newIcons
          return slide
        }
      },
  },
  2: {
    number: 2,
    next: 3,
    back: 1,
    step: 1,
    type: 'iconselect',
    header: {
      logo: `${STATIC_ROOT}/images/logo-halo-small.svg`,
      text: 'Lumiant HALO Longevity Planner',
    },
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_birthday.svg`, active: true, clickable: false,},
      title: "WHY IT MATTERS",
      body: "Australians over the age of 50 typically underestimate their life expectancy by up to seven years making their financial planning time horizons too short. Source: National Seniors Australia Report"
    },
    question: {large: "How many candles will be on your birthday cake this year?", small: "(how old will you be?)"},
    inputs: [{store: "age", hint: "Age", type: "number", value: ""}],
    buttons: [{label: "SUBMIT", store: '', value: "", action: 'next', active: false}],
    populate:
      (slide, store) => {
        var new_slide = Object.assign({}, slide)
        var age = parseInt(store.halo.age, 10)
        if (!isNaN(age) && age >= minAge) {
          new_slide.inputs = [{store: "age", hint: "Age", type: "number", value: age}]
        }
        return new_slide
      },
    validate:
      (store) => {
        var age = parseInt(store.halo_reducer.halo.age, 10)
        if (isNaN(age) || age < minAge) {
          return "Please enter your age. Your age must be 18 or older"
        } else if (age >  maxAge){
          return "age input not valid please try again"
        }
      },
    set_value:
      (slide, store, value) => {
        if (slide.inputs.length > 0) {
          var newinputs = []
          for (var i = 0; i < slide.inputs.length; i++) {
            if (slide.inputs[i].store === store) {
              newinputs.push(Object.assign({}, slide.inputs[i], {value: value}))
            } else {
              newinputs.push(Object.assign({}, slide.inputs[i]))
            }
          }
          slide.inputs = newinputs
          return slide
        }
      },
  },
  3: {
    number: 3,
    next: 4,
    back: 2,
    step: 2,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_height.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Body Mass Index, or BMI, has a strong association with life expectancy and years of disability.  We do the math for you by asking about your height and weight."
    },
    question: {large: "What is your height?", small: "Tip-Toes and High Heels don't count."},
    inputs: [{store: "centimetres", hint: "centimetres (cm)", type: "number", value: ""}],
    buttons: [{label: "SUBMIT", store: '', value: "", action: 'next', active: false}],
    populate:
      (slide, store) => {
        var new_slide = Object.assign({}, slide)
        var cm = parseInt(store.halo.centimetres, 10)
        if (!isNaN(cm)) {
          new_slide.inputs = [{store: "centimetres", hint: "centimetres (cm)", type: "number", value: store.halo.centimetres}]
        }
        return new_slide
      },
    validate:
      (store) => {
        var cm = parseInt(store.halo_reducer.halo.centimetres, 10)
        if (isNaN(cm)) {
          return "Please enter your height in centimetres."
        }else if (cm <= minCentimetres){
          return "Please enter valid height in centimetres"
        }else if (cm >= maxCentimetres){
          return "Height input not valid please try again"
        } else {
          store.halo_reducer.halo.height = store.halo_reducer.halo.centimetres
        }
      },
    set_value:
      (slide, store, value) => {
        if (slide.inputs.length > 0) {
          var newinputs = []
          for (var i = 0; i < slide.inputs.length; i++) {
            if (slide.inputs[i].store === store) {
              newinputs.push(Object.assign({}, slide.inputs[i], {value: value}))
            } else {
              newinputs.push(Object.assign({}, slide.inputs[i]))
            }
          }
          slide.inputs = newinputs
          return slide
        }
      },
  },
  4: {
    number: 4,
    next: '4m',
    back: 3,
    step: 3,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_weight.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "This information will not be shared. Body Mass Index, or BMI, has a strong association with life expectancy and years of disability.  We do the math for you by asking about your height and weight."
    },
    question: {large: "How much do you weigh?", small: "We’ll never tell. :-)"},
    inputs: [{store: "kilograms", hint: "Kilogram (kgs)", type: "number", value: ""}],
    buttons: [{label: "SUBMIT", store: '', value: "", action: 'next', active: false}],
    populate:
      (slide, store) => {
        var new_slide = Object.assign({}, slide)
        var kilograms = parseInt(store.halo.kilograms, 10)
        if (!isNaN(kilograms)) {
          new_slide.inputs = [
              {store: "kilograms", hint: "Kilograms (kgs)", type: "number", value: store.halo.kilograms}
          ]
        }
        return new_slide
      },
    validate:
      (store) => {
        var kilograms = parseInt(store.halo_reducer.halo.kilograms, 10)
        if (isNaN(kilograms) || kilograms === minWeightAU) {
          return "Please enter your weight in kilograms (kgs)."
        } else if (kilograms < minWeightAU || kilograms > maxWeightAU) {
          return "Please enter valid weight in kilograms (kgs)."
        } else {
          // convert kgs to grams
          // remove conversion
          store.halo_reducer.halo.weight = Math.round(convertKgToGrams(store.halo_reducer.halo.kilograms))
        }
      },
    set_value:
      (slide, store, value) => {
        if (slide.inputs.length > 0) {
          var newinputs = []
          for (var i = 0; i < slide.inputs.length; i++) {
            if (slide.inputs[i].store === store) {
              newinputs.push(Object.assign({}, slide.inputs[i], {value: value}))
            } else {
              newinputs.push(Object.assign({}, slide.inputs[i]))
            }
          }
          slide.inputs = newinputs
          return slide
        }
      },
  },
  '4m': {
    number: '4m',
    next: 5,
    back: 4,
    step: 3,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_dumbell.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "While BMI is a metric that provides a good baseline for understanding your body makeup and how it relates to your health, it isn't everything. BMI can be misleading if you are of above average muscular build and providing this information produces a more accurate longevity outlook."
    },
    question: {
      large: "Pick the option that matches closest to your body shape.",
      small: "BMI doesn't tell the whole story, your muscle mass has an affect on your longevity, too. To help us understand your muscular structure, we need a bit more information about your body shape."
    },
    inline: true,
    buttons: [{label: "Slim", store: 'musclemass', value: 0, action: 'setvaluenext', active: false},
      {label: "Athletic", store: 'musclemass', value: 1, action: 'setvaluenext', active: false},
      {label: "Muscular", store: 'musclemass', value: 2, action: 'setvaluenext', active: false},
      {label: "Oval", store: 'musclemass', value: 3, action: 'setvaluenext', active: false}],
    populate:
      (slide, store) => {
        var new_slide = Object.assign({}, slide)
        if (store.halo.gender === "female") {
          new_slide.buttons[3] = {label: "Pear", store: 'musclemass', value: 3, action: 'setvaluenext', active: false}
        }
        return new_slide
      },
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("musclemass")) {
          return "Please select an option that best reflects your body type."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  5: {
    number: 5,
    next: 6,
    back: '4m',
    step: 4,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_ethnicity.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: 'Along with family health history, your racial or ethnic background is a factor that affects your lifespan. '
    },
    question: {large: "Which of the below best describes your ethnicity/ancestry?", small: ""},
    buttons: [{label: "European", store: 'european', value: 100, action: 'setvaluenext', active: false},
      {label: "African", store: 'african', value: 100, action: 'setvaluenext', active: false},
      {label: "Asian", store: 'asian', value: 100, action: 'setvaluenext', active: false},
      {label: "Indian", store: 'indian', value: 100, action: 'setvaluenext', active: false},
      {label: "Hispanic", store: 'hispanic', value: 100, action: 'setvaluenext', active: false},
      {label: "Middle Eastern", store: 'mideastern', value: 100, action: 'setvaluenext', active: false},
      {label: "Aboriginal", store: 'aboriginal', value: 100, action: 'setvaluenext', active: false },
      {label: "Torres Strait Islander", store: "torresStraitIslander",value: 100, action: 'setvaluenext', active: false},
      {label: "Other/Mixed", store: 'ethnicity', value: 'other', action: 'select', active: false}],
    followup: {"other": "f5"},
    showfollowup:
      (store, action) => {
        if (store.halo.ethnicity === "other") {
          return "f5"
        }
        return ""
      },
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("ethnicity")) {
          return "Please select an option that best reflects your ethnicity."
        }
      },
    set_value:
      (slide, store, value) => {
        if (slide.buttons.length > 0) {
          var newbuttons = []
          for (var i = 0; i < slide.buttons.length; i++) {
            if (slide.buttons[i].store === store) {
              newbuttons.push(Object.assign({}, slide.buttons[i], {active: true}))
            } else {
              newbuttons.push(Object.assign({}, slide.buttons[i], {active: false}))
            }
          }
          return Object.assign({}, slide, {buttons: newbuttons})
        }
      },
  },
  f5: {
    number: 'f5',
    next: 6,
    back: 5,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_ethnicity.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: 'Along with family health history, your racial or ethnic background is a factor that affects your lifespan. '
    },
    question: {large: "Approximately what percent of each of the following ethnicities/ancestries?", small: ""},
    inputs: [{store: "european", hint: "European (%)", type: "number", value: ""},
      {store: "african", hint: "African (%)", type: "number", value: ""},
      {store: "indian", hint: "Indian (%)", type: "number", value: ""},
      {store: "asian", hint: "Asian (%)", type: "number", value: ""},
      {store: "mideastern", hint: "Middle Eastern (%)", type: "number", value: ""},
      {store: "hispanic", hint: "Hispanic (%)", type: "number", value: ""},
      {store: "aboriginal", hint: "Aboriginal (%)", type: "number", value: ""},
      {store: "torresStraitIslander", hint: "Torres Strait Islander (%)", type:"number", value: ""},
      {store: "otherEthnicity", hint: "Other (%)", type: "number", value: ""}],
    buttonContainerStyle: {flexGrow: 0.79, justifyContent: "space-around", flexWrap:"nowrap" },
    buttons: [{label: "SUBMIT", store: '', value: "", action: 'next', active: false,}],
    value: "",
    validate:
      (store) => {
        var total = 0
        var inputs = store.halo_reducer.slide.inputs
        for (var i = 0; i < inputs.length; i++) {
          if (inputs[i].value !== "") {
            total += inputs[i].value
          }
        }
        if (total !== 100) {
          return "Please ensure the percentages add up to 100."
        }
      },
    set_value:
      (slide, store, value) => {
        if (slide.inputs.length > 0) {
          var newinputs = []
          for (var i = 0; i < slide.inputs.length; i++) {
            if (slide.inputs[i].store === store) {
              if (value !== "") {
                newinputs.push(Object.assign({}, slide.inputs[i], {value: parseInt(value, 10)}))
              } else {
                newinputs.push(Object.assign({}, slide.inputs[i], {value: value}))
              }
            } else {
              newinputs.push(Object.assign({}, slide.inputs[i]))
            }
          }
          slide.inputs = newinputs
          return slide
        }
      },
  },
  6: {
    number: 6,
    next: 7,
    back: 5,
    step: 5,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_exercise.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "As little as 75 minutes of brisk walking a week can increase life expectancy even for those who are overweight."
    },
    question: {
      large: "How many times per week do you exercise moderately or more for at least 30 minutes?",
      small: "Anything from walking, yoga, chasing a toddler, vigorous vacuuming to CrossFit and surfing counts!"
    },
    inline: true,
    buttons: [
      {label: "0 - 2", store: 'exercises', value: 0, action: 'setvaluenext', active: false},
      {label: "3 - 5", store: 'exercises', value: 1, action: 'setvaluenext', active: false},
      {label: "6+", store: 'exercises', value: 2, action: 'setvaluenext', active: false}
    ],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("exercises")) {
          return "Please select an option that best reflects your exercise habits."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  7: {
    number: 7,
    next: 8,
    back: 6,
    step: 6,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_smoker.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Knowing your life expectancy and the risk factors that may affect it could help you lengthen your lifespan."
    },
    question: {
      large: "Do you smoke?",
      small: "You can be honest with us."
    },
    buttons: [
      {label: 'No', store: 'smokingType', value: smokingNone, action: 'setvaluenext', active: false},
      {label: 'Yes', store: 'smokingType', value: smokingCurrent, action: 'setvaluenext', active: false},
      {label: 'Former', store: 'smokingType', value: smokingFormer, action: 'setvaluenext', active: false}
    ],
    showfollowup:
        (store, action) => {
      // reset to defaults in case user goes through smoking
      // questions and goes back
      if(store.halo.smokingType === 'none'){
        store.halo.smokes = false
        store.halo.smokeCigar = 0
        store.halo.smokeCigarette = 0
        store.halo.quitSmokingAge = 0
        store.halo.smokingPattern = null
      }
      if(store.halo.smokingType === 'current'){
        store.halo.smokes = true
        // current smoker slide
        return '7C-a'
      }

      if(store.halo.smokingType === 'former'){
        store.halo.smokes = true
        // former smoker slide
        return '7F-a'
      }
      return ""
      },
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("smokes")) {
          return "Please select an option that best reflects your smoking habits."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
    '7C-a': {
    number: '7C-a',
    next: '7C-b',
    back: 7,
    step: 7,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_smoker.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Knowing your life expectancy and the risk factors that may affect it could help you lengthen your lifespan."
    },
    question: {
      large: "What do you smoke?",
    },
    buttons: [
      {
        label: "Cigarettes",
        width: '10px',
        store: 'smokingPattern',
        value: cigarette,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "Cigars",
        width: '10px',
        store: 'smokingPattern',
        value: cigar,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "Both",
        width: '10px',
        store: 'smokingPattern',
        value: both,
        action: 'setvaluenext',
        active: false
      },
    ],
    followup: {'cigar': '7C-c' },
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("smokes")) {
          return "Please select an option that best reflects your smoking habits."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  '7C-b': {
    number: '7C-b',
    next: '7C-c',
    back: '7C-a',
    step: '7C-a',
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_smoker.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Knowing your life expectancy and the risk factors that may affect it could help you lengthen your lifespan."
    },
    question: {
      large: "How many cigarettes do you smoke each day?", small: "You can be honest with us."
    },
    buttons: [
      {label: "Occasionally", width: '10px', store: 'smokeCigarette', value: 1, action: 'setvaluenext', active: false},
      {
        label: "< 10 cigarettes daily",
        width: '10px',
        store: 'smokeCigarette',
        value: 2,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "10 - 19 cigarettes daily",
        width: '10px',
        store: 'smokeCigarette',
        value: 3,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "Over 20 cigarettes daily",
        width: '10px',
        store: 'smokeCigarette',
        value: 4,
        action: 'setvaluenext',
        active: false
      },
    ],
    showfollowup:
        (store,action) => {
        if(store.halo.smokingPattern === cigarette){
          // jump over to what you eat question
          return 8
        }
        return ""
    },
    value: "",
    validate:
        (store) => {
          if (!store.halo_reducer.halo.hasOwnProperty("smokes")) {
            return "Please select an option that best reflects your smoking habits."
          }
        },
    set_value:
        (slide, store, value) => {
          return set_value_buttons(slide, value)
        },
  },
   '7C-c': {
    number: '7C-c',
    next: 8,
    back: '7C-a',
    step: '7C-a',
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_smoker.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Knowing your life expectancy and the risk factors that may affect it could help you lengthen your lifespan."
    },
    question: {
      large: "How many cigars do you smoke each day?", small: "You can be honest with us."
    },
    buttons: [
      {label: "Occasionally", width: '10px', store: 'smokeCigar', value: 1, action: 'setvaluenext', active: false},
      {
        label: "1 - 2 cigars daily",
        width: '10px',
        store: 'smokeCigar',
        value: 2,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "3 - 4 cigars daily",
        width: '10px',
        store: 'smokeCigar',
        value: 3,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "5 or more cigars daily",
        width: '10px',
        store: 'smokeCigar',
        value: 4,
        action: 'setvaluenext',
        active: false
      },
    ],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("smokes")) {
          return "Please select an option that best reflects your smoking habits."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  '7F-a': {
    number: '7F-a',
    next: '7F-b',
    back: 7,
    step: 7,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_smoker.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Knowing your life expectancy and the risk factors that may affect it could help you lengthen your lifespan."
    },
    question: {
      large: "What did you use to smoke?",
    },
    /*TODO: may need to add a new redux store as this is a new value that will be used for the survey*/
    //for each of the buttons create a follow-up based on user options
    // for now we  will assign  smokes to true as previously survey question must be true in order to get
    // to this stage
    // TODO:  create enums for smoking pattern type so we are limited to a few options
    buttons: [
      {
        label: "Cigarettes",
        width: '10px',
        store: 'smokingPattern',
        value: cigarette,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "Cigars",
        width: '10px',
        store: 'smokingPattern',
        value: cigar,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "Both",
        width: '10px',
        store: 'smokingPattern',
        value: both,
        action: 'setvaluenext',
        active: false
      },
    ],
    showfollowup:
        (store, action) => {
          if(store.halo.smokingPattern === cigar) {
            return "7F-c"
          }
        return ""
        },
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("smokes")) {
          return "Please select an option that best reflects your smoking habits."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
    '7F-b': {
    number: '7F-b',
    next: '7F-c',
    back: '7F-a',
    step: '7F-a',
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_smoker.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Knowing your life expectancy and the risk factors that may affect it could help you lengthen your lifespan."
    },
    question: {
      large: "How many cigarettes did you smoke each day?", small: "You can be honest with us."
    },
    /*TODO: may need to add a new redux store as this is a new value that will be used for the survey*/
    buttons: [
      {label: "Occasionally", width: '10px', store: 'smokeCigarette', value: 1, action: 'setvaluenext', active: false},
      {
        label: "< 10 cigarettes daily",
        width: '10px',
        store: 'smokeCigarette',
        value: 2,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "10 - 19 cigarettes daily",
        width: '10px',
        store: 'smokeCigarette',
        value: 3,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "Over 20 cigarettes daily",
        width: '10px',
        store: 'smokeCigarette',
        value: 4,
        action: 'setvaluenext',
        active: false
      },
    ],
      showfollowup:
        (store,action) => {
        if(store.halo.smokingPattern === cigarette){
          // jump over to what you eat question
          return "7F-d"
        }else if (store.halo.smokingPattern === both){
          // jump to when did you quit smoking cigarettes
          return "7F-e"
        }
        return ""
    },

    value: "",
    validate:
        (store) => {
          if (!store.halo_reducer.halo.hasOwnProperty("smokes")) {
            return "Please select an option that best reflects your smoking habits."
          }
        },
    set_value:
        (slide, store, value) => {
          return set_value_buttons(slide, value)
        },
  },
    '7F-c': {
    number: '7F-c',
    next: '7F-d',
    back: '7F-a',
    step: '7F-a',
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_smoker.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Knowing your life expectancy and the risk factors that may affect it could help you lengthen your lifespan."
    },
    question: {
      large: "How many cigars did you smoke each day?", small: "You can be honest with us."
    },
    buttons: [
      {label: "Occasionally", width: '10px', store: 'smokeCigar', value: 1, action: 'setvaluenext', active: false},
      {
        label: "1 - 2 cigars daily",
        width: '10px',
        store: 'smokeCigar',
        value: 2,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "3 - 4 cigars daily",
        width: '10px',
        store: 'smokeCigar',
        value: 3,
        action: 'setvaluenext',
        active: false
      },
      {
        label: "5 or more cigars daily",
        width: '10px',
        store: 'smokeCigar',
        value: 4,
        action: 'setvaluenext',
        active: false
      },
    ],
      showfollowup:
        (store,action) => {
          // special case if user  smoking pattern is both we  jump to a slide that asks
          // two questions for when the user quits. The first question we use as the true
          // value and the second item is there for UX purposes
          if(store.halo.smokingPattern === both){
           return "7F-f"
          }
      return ""
  },
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("smokes")) {
          return "Please select an option that best reflects your smoking habits."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  '7F-d': {
    number: '7F-d',
    next: 8,
    back: '7F-a',
    step: '7F-a',
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_smoker.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Knowing your life expectancy and the risk factors that may affect it could help you lengthen your lifespan."
    },
    question: {
      large: "When did you quit smoking?", small: "You can be honest with us."
    },
    buttons: [
      {label: "Before age 35", width: '10px', store: 'quitSmokingAge', value: 1, action: 'setvaluenext', active: false},
      {label: "Before age 45", width: '10px', store: 'quitSmokingAge', value: 2, action: 'setvaluenext', active: false},
      {label: "After age 45", width: '10px', store: 'quitSmokingAge', value: 3, action: 'setvaluenext', active: false},
    ],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("smokes")) {
          return "Please select an option that best reflects your smoking habits."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
    populate:
        (slide, store) => {
          let new_slide  = Object.assign({}, slide)
          const age = store.halo.age
          new_slide.buttons = populateFormerSmokerBtns(age, new_slide.buttons)
          return new_slide
    }
  },
    '7F-e': {
    number: '7F-e',
    next: '7F-f',
    back: '7F-a',
    step: '7F-a',
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_smoker.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Knowing your life expectancy and the risk factors that may affect it could help you lengthen your lifespan."
    },
    question: {
      large: "When did you quit smoking cigarettes?", small: "You can be honest with us."
    },
    buttons: [
      {label: "Before age 35", width: '10px', store: 'quitSmokingAge', value: 1, action: 'setvaluenext', active: false},
      {label: "Before age 45", width: '10px', store: 'quitSmokingAge', value: 2, action: 'setvaluenext', active: false},
      {label: "After age 45", width: '10px', store: 'quitSmokingAge', value: 3, action: 'setvaluenext', active: false},
    ],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("smokes")) {
          return "Please select an option that best reflects your smoking habits."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
    populate:
        (slide,store) => {
          let new_slide = Object.assign({}, slide)
          const age = store.halo.age
          new_slide.buttons = populateFormerSmokerBtns(age, new_slide.buttons)
          return new_slide
        },
    showfollowup:
        (store,action) => {
          if(store.halo.smokingPattern === both){
            return "7F-c"
          }
          return ""
        }
  },
  '7F-f': {
    number: '7F-f',
    next: 8,
    back: '7F-e',
    step: '7F-e',
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_smoker.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Knowing your life expectancy and the risk factors that may affect it could help you lengthen your lifespan."
    },
    question: {
      large: "When did you quit smoking cigars?", small: "You can be honest with us."
    },
    // buttons here do absolutely nothing. Its purely for user experience purposes
    buttons: [
      {label: "Before age 35", width: '10px', value: 1,  action: 'setvaluenext', active: false},
      {label: "Before age 45", width: '10px', value: 2, action: 'setvaluenext',active: false},
      {label: "After age 45", width: '10px', value: 3,  action: 'setvaluenext', active: false},
    ],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("smokes")) {
          return "Please select an option that best reflects your smoking habits."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
    populate:
        (slide, store) => {
          let new_slide = Object.assign({}, slide)
          const age = store.halo.age
          new_slide.buttons = populateFormerSmokerBtns(age, new_slide.buttons)
          return new_slide
        }
  },
  8: {
    number: 8,
    next: 9,
    back: 7,
    step: 7,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_fruits.png`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: `People say "you are what you eat."  Well, there is some truth to that statement.  Numerous studies have shown a small but significant association between longevity and diet. Especially important are fresh fruit and veggies.  Grab that apple and keep the doctor away!`
    },
    question: {
      large: "How many servings of fruits or vegetables do you eat in a typical day?",
      small: "(Give a hoot, eat more fruit)",
      popover: "One serving of fruits or vegetables is about the same size as your fist."
    },
    inline: true,
    buttons: [{
      label: "3 or fewer",
      width: '10px',
      store: 'fruitVegetable',
      value: "3",
      action: 'setvaluenext',
      active: false
    }, {
      label: "4", store: 'fruitVegetable', value: "4", action: 'setvaluenext', active: false
    }, {label: "5 - 6", store: 'fruitVegetable', value: "5 - 6", action: 'setvaluenext', active: false},
      {label: "7 or more", store: 'fruitVegetable', value: "7", action: 'setvaluenext', active: false}],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("fruitVegetable")) {
          return "Please select an option that best reflects the servings of fruits or vegetables you eat in a typical day."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  9: {
    number: 9,
    next: '9e',
    back: 8,
    step: 8,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_alcohol.png`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: [<b>None:</b>, ` No alcohol consumption.`, <br></br>,
        <b>Moderate:</b>, ` 1 drink/day or lessfor women, 2 drinks/day or less for men.`, <br></br>,
        <b>Heavy:</b>, ` 8 or more drinks/week for women, 15 or more drinks/week for men.`, <br></br>,
        <br></br>, `For optimal health, experts now suggest keeping your alcohol consumption to about a drink per day or less.`]
    },
    question: {
      large: "How would you describe your weekly drinking habits?",
      small: [`(If you don’t want to share this information,`, <br></br>, `please select "None")`]
    },
    inline: true,
    buttons: [{label: "None", store: 'alcohol', value: "0", action: 'setvaluenext', active: false},
      {label: "Moderate", store: 'alcohol', value: "7", action: 'setvaluenext', active: false},
      // { label: "8 - 14", store: 'alcohol', value: "8-14", action: 'setvaluenext', active: false},
      // { label: "15 - 25", store: 'alcohol', value: "15-25", action: 'setvaluenext', active: false },
      {label: "Heavy", store: 'alcohol', value: "25+", action: 'setvaluenext', active: false}],
    value: "",
    populate:
      (slide, store) => {
        var maleWhy = [<b>None:</b>, ` No alcohol consumption.`, <br></br>,
          <b>Moderate:</b>, ` 2 drinks or less per day for men.`, <br></br>,
          <b>Heavy:</b>, ` 15 drinks or more per week for men.`, <br></br>,
          <br></br>, `For optimal health, experts now suggest keeping your alcohol consumption to about a drink per day or less.`]
        var femaleWhy = [<b>None:</b>, ` No alcohol consumption.`, <br></br>,
          <b>Moderate:</b>, ` 1 drink or less per day for women.`, <br></br>,
          <b>Heavy:</b>, ` 8 drinks or more per week for women.`, <br></br>,
          <br></br>, `For optimal health, experts now suggest keeping your alcohol consumption to about a drink per day or less.`]
        var new_slide = Object.assign({}, slide)
        if (store.halo.gender === "male") {
          new_slide.misc.body = maleWhy
        } else {
          new_slide.misc.body = femaleWhy
        }
        return new_slide
      },
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("alcohol")) {
          return "Please select an option that best reflects your weekly drinking habits."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  '9e': {
    number: '9e',
    next: 10,
    back: 9,
    step: 9,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {
        image: `${STATIC_ROOT}/images/icn-social.svg`,
        clickable: false,
        active: true
      },
      title: "WHY IT MATTERS",
      body: "Humans are social creatures, and feeling supported and understood can lead to a physical improvement in health.  One study suggests receiving support from the people around you decreases your death risk by 19%"
    },
    inline: false,
    question: {
      large: ["Who do you turn to for ", <span><b>Emotional Support</b></span>, "?"],
      small: "(Please check all that apply)",
      popover: "Social support can be instrumental or emotional. Instrumental support includes financial aid, information, help with family or work, advice, food, or transportation. Emotional support includes affection, sympathy, trust, encouragement, or guidance."
    },
    buttons: [{label: "Myself", value: true, store: "selfSupport", action: 'toggle', active: false}, {
      label: "Spouse",
      value: true,
      store: "spouseSupport",
      action: 'toggle',
      active: false
    }, {label: "Family", value: true, store: "familySupport", action: 'toggle', active: false},
      {label: "Friends", value: true, store: "friendsSupport", action: 'toggle', active: false},// { label: "Group of Friends", value: true, store: "friendsSupport", action: 'toggle', active: false },
      // { label: "Community Organization", value: true, store: "communitySupport", action: 'toggle', active: false }, { label: "Religious Organization", value: true, store: "religiousSupport", action: 'toggle', active: false },
      {label: "SUBMIT", store: '', value: "", action: 'next', active: false},],
    value: "",
    validate:
      (store) => {
        return
      },
    set_value:
      (slide, store, value) => {
        if (slide.buttons.length > 0) {
          var newbuttons = []
          for (var i = 0; i < slide.buttons.length; i++) {
            if (slide.buttons[i].store === store) {
              newbuttons.push(Object.assign({}, slide.buttons[i], {active: !slide.buttons[i].active}))
            } else {
              newbuttons.push(Object.assign({}, slide.buttons[i]))
            }
          }
          // slide.buttons = newbuttons
          return Object.assign({}, slide, {buttons: newbuttons, value: value})
        }
      },
  },
  10: {
    number: 10,
    next: 11,
    back: '9e',
    step: 9,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_doctor.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Not everyone approaches healthcare the same way, and how often you visit the doctor provides insights into your general health as well as your health utilisation mindset."
    },
    question: {
      large: "How often do you visit a doctor each year (including specialists, dentists, and other medical professionals)?"
    },
    inline: true,
    buttons: [{
      label: "0 - 2",
      width: '10px',
      store: 'doctorVisitFrequency',
      value: "0-2",
      action: 'setvaluenext',
      active: false
    }, {
      label: "3 - 5", store: 'doctorVisitFrequency', value: "3-5", action: 'setvaluenext', active: false
    }, {label: "6 +", store: 'doctorVisitFrequency', value: "6+", action: 'setvaluenext', active: false}],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("doctorVisitFrequency")) {
          return "Please select an option that best reflects the amount of times you visit a doctor each year."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  11: {
    number: 11,
    next: 12,
    back: 10,
    step: 10,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_cancer.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "If cancer runs in your family, there is much you can do to recognise your potential risk and catch the disease before it strikes."
    },
    question: {
      large: ["Have any of your immediate family members (parents, siblings, children, or yourself) been diagnosed with ",
        <span><b>Cancer</b></span>, "?"]
    },
    buttons: [{label: "No", store: 'cancer', value: false, action: 'setvaluenext', active: false}, {
      label: "Yes",
      store: 'cancer',
      value: true,
      action: 'setvalue',
      active: false
    }],
    value: "",
    followup: {true: 'f11'},
    showfollowup:
      (store, action) => {
        if (store.halo.cancer === true && action.store === 'cancer' && action.value) {
          return 'f11'
        }
        return ""
      },
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("cancer")) {
          return "Please select an option that best reflects your family cancer history."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  'f11': {
    number: 'f11',
    next: 12,
    back: 11,
    step: 11,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_cancer.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "If cancer runs in your family, there is much you can do to recognize your potential risk and catch the disease before it strikes."
    },
    question: {
      large: ["Which types of ", <span><b>Cancer</b></span>, "?"], small: "(Please check all that apply)"
    },
    buttons: [{
      label: "Bladder",
      value: true,
      store: "bladderCancer",
      action: 'toggle',
      active: false
    }, {label: "Breast", value: true, store: "breastCancer", action: 'toggle', active: false},
      {label: "Colorectal", value: true, store: "colonCancer", action: 'toggle', active: false}, {
        label: "Kidney",
        value: true,
        store: "kidneyCancer",
        action: 'toggle',
        active: false
      },
      {label: "Lung", value: true, store: "lungCancer", action: 'toggle', active: false}, {
        label: "Ovarian",
        value: true,
        store: "ovarianCancer",
        action: 'toggle',
        active: false
      },
      {
        label: "Pancreatic",
        value: true,
        store: "pancreaticCancer",
        action: 'toggle',
        active: false
      }, {label: "Prostate", value: true, store: "prostateCancer", action: 'toggle', active: false},
      {label: "Skin", value: true, store: "skinMelanoma", action: 'toggle', active: false}, {
        label: "Other",
        value: true,
        store: "other",
        action: 'toggle',
        active: false
      },
      {label: "SUBMIT", store: '', value: "", action: 'next', active: false},],
    value: "",
    validate:
      (store) => {
        var checked = false
        for (var i = 0; i < store.halo_reducer.slide.buttons.length; i++) {
          checked |= store.halo_reducer.slide.buttons[i].active
        }
        if (!checked) {
          return "Please select which cancers have been in your immediate family."
        }
      },
    set_value:
      (slide, store, value) => {
        if (slide.buttons.length > 0) {
          var newbuttons = []
          for (var i = 0; i < slide.buttons.length; i++) {
            if (slide.buttons[i].store === store) {
              newbuttons.push(Object.assign({}, slide.buttons[i], {active: !slide.buttons[i].active}))
            } else {
              newbuttons.push(Object.assign({}, slide.buttons[i]))
            }
          }
          // slide.buttons = newbuttons
          return Object.assign({}, slide, {buttons: newbuttons, value: value})
        }
      },
  },
  12: {
    number: 12,
    next: 13,
    back: 11,
    step: 11,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_dimentia.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "The most important risk factors—age, family history and heredity—can't be changed, but emerging evidence suggests there may be other factors we can influence. Source: Alzheimer’s Association"
    },
    question: {
      large: ["Have any of your immediate family members (parents, siblings, children, or yourself) been diagnosed with ",
        <span><b>Alzheimer's</b></span>, " or ", <br></br>, <span><b>Severe Dementia</b></span>, "?  "],
      popover: "For the purposes of this questions, consider only Alzheimer's disease and dementia without a known disease or injury cause. Please exclude dementia caused by a known primary condition such as stroke, brain injury, HIV, Parkinson's disease and Huntington's disease.",
    },
    buttons: [{label: "No", store: 'alzheimers', value: false, action: 'setvaluenext', active: false}, {
      label: "Yes",
      store: 'alzheimers',
      value: true,
      action: 'setvaluenext',
      active: false
    }],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("alzheimers")) {
          return "Please select an option that best reflects your family Alzheimer's or severe dementia history."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  13: {
    number: 13,
    next: 14,
    back: 12,
    step: 12,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_diabetic.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Most people with type 2 diabetes have a family member - such as a mother, father, brother, or sister - with the disease."
    },
    question: {
      large: ["Have ", <span><b>you</b></span>, " or any of your ",
        <span><b>immediate family</b></span>, " members (parents, siblings, or children) been diagnosed with ",
        <br></br>, <span><b>Type 2 Diabetes</b></span>, "?  "],
      popover: "For the purpose of this question, please only consider Type 2 diabetes."
    },
    buttons: [{label: "None", store: 'diabetes', value: 0, action: 'setvaluenext', active: false}, {
      label: "Myself",
      store: 'diabetes',
      value: 2,
      action: 'setvaluenext',
      active: false
    }, {label: "Family", store: 'diabetes', value: 1, action: 'setvaluenext', active: false}, {
      label: "Both",
      store: 'diabetes',
      value: 3,
      action: 'setvaluenext',
      active: false
    }],
    value: "",
    inline: true,
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("diabetes")) {
          return "Please select an option that best reflects your Type 2 diabetes history."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  /*
  14:{
    number: 14,
    next: 15,
    back: 13,
    step: 13,
    type: 'iconselect',
    header: { logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {
        image: `${STATIC_ROOT}/images/icn_disease.svg`, clickable: false, active: true
      }
    },
    title: "WHY IT MATTERS",
    body: "Did you know that heart disease is a major cause of death in Australia, responsible for causing one in four (26%) of all deaths. Source: Australian Institute of Health and Welfare",
		question: {
      large: ["Have ", <span><b>you</b></span>, " or any of your ", <span><b>immediate family</b></span>, " members (parents, siblings, or children) been diagnosed with ",<br></br> ,<span key={1}><b>Heart Disease</b></span>, "?  "]
        }, popover: "Heart Disease is a general term capturing many types of heart conditions. Some of the more common forms of Heart Disease include Coronary Artery Disease (CAD), Heart Attack (Myocardial Infarction), Heart Arrhythmias, Heart Failure and Congenital Heart Disease. Please do not include conditions like High Cholesterol or Diabetes, which although associated with Heart Disease are not considered to be Heart Disease themselves.",
    },
    inline: true,
    buttons: [{ label: "None", store: 'heartDisease', value: 0, action: 'setvaluenext', active: false },{ label: "Myself", store: 'heartDisease', value: 2, action: 'setvaluenext', active: false },{ label: "Family", store: 'heartDisease', value: 1, action: 'setvaluenext', active: false }, { label: "Both", store: 'heartDisease', value: 3, action: 'setvaluenext', active: false }],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("heartDisease")) {
          return "Please select an option that best reflects your Type 2 heart disease history."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
    */
  14: {
    number: 14,
    next: 15,
    back: 13,
    step: 13,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_disease.svg`, clickable: false, active: true}, title: "WHY IT MATTERS",
      body: "Did you know that heart disease is a major cause of death in Australia, responsible for causing one in four (26%) of all deaths. Source: Australian Institute of Health and Welfare"
    },
    question: {
      large: ["Have ", <span><b>you</b></span>, " or any of your ",
        <span><b>immediate family</b></span>, " members (parents, siblings, or children) been diagnosed with ",
        <br></br>, <span key={1}><b>Heart Disease</b></span>, "?  "],
      popover: "Heart Disease is a general term capturing many types of heart conditions. Some of the more common forms of Heart Disease include Coronary Artery Disease (CAD), Heart Attack (Myocardial Infarction), Heart Arrhythmias, Heart Failure and Congenital Heart Disease. Please do not include conditions like High Cholesterol or Diabetes, which although associated with Heart Disease are not considered to be Heart Disease themselves."
    },
    inline: true,
    buttons: [{label: "None", store: 'heartDisease', value: 0, action: 'setvaluenext', active: false}, {
      label: "Myself",
      store: 'heartDisease',
      value: 2,
      action: 'setvaluenext',
      active: false
    }, {label: "Family", store: 'heartDisease', value: 1, action: 'setvaluenext', active: false}, {
      label: "Both",
      store: 'heartDisease',
      value: 3,
      action: 'setvaluenext',
      active: false
    }],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("heartDisease")) {
          return "Please select an option that best reflects your Type 2 heart disease history."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },

  15: {
    number: 15,
    next: 16,
    back: 14,
    step: 14,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_stroke.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "Family history is the number one risk factor for strokes. Seconds matter if you suspect someone is having a stroke; call 000 immediately."
    },
    question: {
      large: ["Have ", <span><b>you</b></span>, " or any of your ",
        <span><b>immediate family</b></span>, " members (parents, siblings, or children) been diagnosed with ",
        <br></br>, "a ", <span><b>Stroke</b></span>, "?"]
    },
    inline: true,
    buttons: [{label: "None", store: 'stroke', value: 0, action: 'setvaluenext', active: false}, {
      label: "Myself",
      store: 'stroke',
      value: 2,
      action: 'setvaluenext',
      active: false
    }, {label: "Family", store: 'stroke', value: 1, action: 'setvaluenext', active: false}, {
      label: "Both",
      store: 'stroke',
      value: 3,
      action: 'setvaluenext',
      active: false
    }],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("stroke")) {
          return "Please select an option that best reflects your family stroke history."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  16: {
    number: 16,
    next: 17,
    back: 15,
    step: 15,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
        misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_retirement.svg`, clickable: false, active: true},
      title: "",
      body: ""
    },
    question: {
      large: "When would you like to retire?", small: "If already retired, select the age at which you retired."
    },
    slider: {store: "retirementAge", value: 65, min: 30, max: 100, step: 1},
    buttons: [{label: "SUBMIT", store: '', value: "", action: 'next', active: false}],
    value: "",
    validate:
      (store) => {
        let retirementAge = store.halo_reducer.halo.retirementAge
        if (!store.halo_reducer.halo.hasOwnProperty("retirementAge")) {
          return "Please select an option that best reflects at what age you would like to retire."
        }else if(isNaN(retirementAge)){
          return "Please select an option that best reflects at what age you would like to retire."
        }else  if (retirementAge < 30 || retirementAge > 100){
          return "Please enter valid age you would like to retire."
        }
      },
    set_value:
      (slide, store, value) => {
        return Object.assign({}, slide, {slider: Object.assign({}, slide.slider, {value: value})})
      },
  },
  17: {
    number: 17,
    next: 18,
    back: 16,
    step: 16,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {image: `${STATIC_ROOT}/images/icn_location.svg`, clickable: false, active: true},
      title: "WHY IT MATTERS",
      body: "If you or a loved one are going to need care in old age or due to a disability, it will matter more than ever where you live."
    },
    question: {
      large: "Where would you like to retire?", small: "If already retired, select the state in which you live."
    },
    select: {value: '', store: 'retirementLocation'},
    buttons: [{label: "SUBMIT", store: '', value: "", action: 'next', active: false}],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("retirementLocation") || store.halo_reducer.halo.retirementLocation === "") {
          return "Please enter a state that best reflects where you would like to retire."
        }
      },
    set_value:
      (slide, store, value) => {
        // slide.slider.value = value
        // return slide
        return Object.assign({}, slide, {select: Object.assign({}, slide.select, {value: value})})
      },
  },
  18: {
    number: 18,
    next: 19,
    back: 17,
    step: 17,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      icon: {
        image: `${STATIC_ROOT}/images/icn_old-age.svg`, clickable: false, active: true
      },
      title: "WHY IT MATTERS",
      body: "Research suggests that exceptional longevity – living one to three decades beyond the average life span of approximately 80 years – runs strongly in families",
    },

    question: {
      large: ["Let’s talk longevity. How many family members have lived to be ",
        <span><b>67 years old or older</b></span>, " (parents & grandparents only)?"], small: ""
    },
    adjustedLifespan: 0,
    populate:
      (slide, store) => {
        if (store.hasOwnProperty("midpoint")) {
          return Object.assign({}, slide, {
            question: Object.assign({}, slide.question, {
              large: [...slide.question.large.slice(0, 1),
                <span><b>{Math.round(store.midpoint.timeline.familyLifespan)} years old or older</b></span>, slide.question.large.slice(2)],
              popover: "There is a longevity bonus for people who have family members (parents & grandparents) who have lived to be this age or older.  If you are not sure of the exact age please use your best guess."
            })
          })
        } else {
          return Object.assign({}, slide)
        }
      },
    inline: true,
    buttons: [{
      label: "None",
      value: 0,
      store: 'longLivedFamilyCount',
      action: 'setvaluenext',
      active: false
    }, {label: "1", value: 1, store: 'longLivedFamilyCount', action: 'setvaluenext', active: false},
      {label: "2", value: 2, store: 'longLivedFamilyCount', action: 'setvaluenext', active: false}, {
        label: "3",
        value: 3,
        store: 'longLivedFamilyCount',
        action: 'setvaluenext',
        active: false
      },
      {label: "4", value: 4, store: 'longLivedFamilyCount', action: 'setvaluenext', active: false}, {
        label: "5",
        value: 5,
        store: 'longLivedFamilyCount',
        action: 'setvaluenext',
        active: false
      },
      {label: "6", value: 6, store: 'longLivedFamilyCount', action: 'setvaluenext', active: false}],
    value: "",
    validate:
      (store) => {
        if (!store.halo_reducer.halo.hasOwnProperty("longLivedFamilyCount")) {
          return "Please select an option."
        }
      },
    set_value:
      (slide, store, value) => {
        return set_value_buttons(slide, value)
      },
  },
  19: {
    number: 19,
    next: 20,
    back: 18,
    step: 18,
    type: 'iconselect',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    misc: {
      inputs: [{store: "firstName", hint: "First Name", type: "text", value: ""},
        {store: "lastName", hint: "Last Name", type: "text", value: ""},
        {store: "email", hint: "Email", type: "email", value: ""}],
      buttons: [{label: "SEE RESULTS", store: 'final', value: "", action: 'next', active: false}],
    },
    question: {
      large: "Congratulations on taking a big step towards planning for your future health & wealth!",
      small: "To receive your HALO report please provide your name and email address. The report is sent to your advisor so you can review together and discuss how to protect your health, wealth, and legacy."
    },
    value: "",
    populate:
      (slide, store) => {
        if (store.hasOwnProperty("advisor") && store.advisor.category === "broker") {
          return Object.assign({}, slide, {
            misc: Object.assign({}, slide.misc, {
              inputs: [{store: "firstName", hint: "Your First Name", type: "text", value: ""},
                {store: "lastName", hint: "Your Last Name", type: "text", value: ""},
                {store: "email", hint: "Your Email", type: "email", value: ""},
                {store: "advisorname", hint: "Your Advisor's Name", type: "text", value: ""},]
            })
          })
        } else if (store.hasOwnProperty("advisor") && store.advisor.category === "withphone") {
          return Object.assign({}, slide, {
            misc: Object.assign({}, slide.misc, {
              inputs: [{store: "firstName", hint: "Your First Name", type: "text", value: ""},
                {store: "lastName", hint: "Your Last Name", type: "text", value: ""},
                {store: "email", hint: "Your Email", type: "email", value: ""},
                {store: "phone", hint: "Your Phone Number", type: "text", value: ""},]
            })
          })
        } else if (store.hasOwnProperty("advisor") && store.advisor.category === "nolastname") {
          return Object.assign({}, slide, {
            misc: Object.assign({}, slide.misc, {
              inputs: [{store: "firstName", hint: "Your First Name", type: "text", value: ""},
                {store: "email", hint: "Your Email", type: "email", value: ""},]
            }),
            question: {
              large: "Congratulations on taking a big step towards planning for your future health & wealth!",
              small: "To receive your HALO report please provide your name and email address."
            }
          })
        } else if (store.hasOwnProperty("advisor") && store.advisor.category === "entity" && store.advisor.selections && store.advisor.selections.length > 0) {
          return Object.assign({}, slide, {
            misc: Object.assign({}, slide.misc, {
              inputs: [{store: "firstName", hint: "Your First Name", type: "text", value: ""},
                {store: "lastName", hint: "Your Last Name", type: "text", value: ""},
                {store: "email", hint: "Your Email", type: "email", value: ""},],
              suggestions: {
                store: "advisorSelect",
                hint: "Select Your Advisor",
                type: "dropdown",
                value: null,
                options: store.advisor.selections
              },
            })
          })
        } else {
          return Object.assign({}, slide, {
            misc: Object.assign({}, slide.misc, {
              inputs: [
                {store: "firstName", hint: "Your First Name", type: "text", value: store?.getDetails ? store.getDetails.firstName : store.halo.firstName},
                {store: "lastName", hint: "Your Last Name", type: "text", value: store?.getDetails ? store.getDetails.lastName : store.halo.lastName},
                {store: "email", hint: "Your Email", type: "email", value: store?.getDetails ? store.getDetails.email : store.halo.email },
              ],
            })
          })
        }
      },
    validate:
      (store) => {
        var inputs = store.halo_reducer.slide.misc.inputs
        var errorMessage = ""
        if (inputs[0].value === "") {
          errorMessage += "Please enter your first name. "
        }
        if ((store.halo_reducer.hasOwnProperty("advisor") && store.halo_reducer.advisor.category !== "nolastname")
          && (inputs[1].value === "")) {
          errorMessage += "Please enter your last name. "
        }
        if ((store.halo_reducer.hasOwnProperty("advisor") && store.halo_reducer.advisor.category !== "nolastname")
          && (inputs[2].value === "" || !(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(inputs[2].value.toLowerCase())))) {
          errorMessage += "Please enter a valid email address. "
        } else if ((store.halo_reducer.hasOwnProperty("advisor") && store.halo_reducer.advisor.category === "nolastname")
          && (inputs[1].value === "" || !(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(inputs[1].value.toLowerCase())))) {
          errorMessage += "Please enter a valid email address. "
        }
        if ((store.halo_reducer.hasOwnProperty("advisor") && store.halo_reducer.advisor.category === "broker") && (inputs[3].value === "")) {
          errorMessage += "Please enter your advisor's name."
        }
        if ((store.halo_reducer.hasOwnProperty("advisor") && store.halo_reducer.advisor.category === "withphone") && (inputs[3].value === "")) {
          errorMessage += "Please enter your phone number."
        }
        if ((store.halo_reducer.hasOwnProperty("advisor") && store.halo_reducer.advisor.category === "entity") && ("suggestions" in store.halo_reducer.slide.misc && store.halo_reducer.slide.misc.suggestions.value === null)) {
          errorMessage += "Please select your advisor's name."
        }
        return errorMessage
      },
    set_value:
      (slide, store, value) => {
        var updatedSlide = Object.assign({}, slide)
        if (slide.misc.inputs.length > 0) {
          var newinputs = []
          for (var i = 0; i < slide.misc.inputs.length; i++) {
            if (slide.misc.inputs[i].store === store) {
              newinputs.push(Object.assign({}, slide.misc.inputs[i], {value: value}))
            } else {
              newinputs.push(Object.assign({}, slide.misc.inputs[i]))
            }
          }
          updatedSlide = Object.assign({}, slide, {misc: Object.assign({}, slide.misc, {inputs: newinputs})})
        }
        if ("suggestions" in slide.misc && slide.misc.suggestions.store === store) {
          updatedSlide.misc.suggestions.value = value
        }
        return updatedSlide
      },
  },

  20: {
    number: 20,
    next: 20,
    back: 19,
    step: 19,
    type: 'halotimeline',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    question: {
      large: ["Congratulations!", <br></br>, "Your future just got healthier."],
      small: ["A preview of your longevity projections is displayed below. Your results below are interactive (hover over or click on each element to learn more). Your advisor will follow-up directly to discuss your full results and how they affect your financial plan."]
    },
    populate:
      (slide, store) => {
        if (store.hasOwnProperty("advisor") && store.advisor.category === "nolastname") {
          return Object.assign({}, slide, {
            question: {
              large: ["Congratulations!", <br></br>, "Your future just got healthier."],
              small: ["A preview of your longevity projections is displayed below. Your results below are interactive (hover over or click on each element to learn more)."],
            }
          })
        } else {
          if (store.hasOwnProperty("final") && Object.keys(store.final).length > 0) {
            if ("timeline" in store.final && (Math.round(store.final.timeline.healthyYears) * 2 < Math.round(store.final.timeline.disabilityYears) || Math.round(store.final.timeline.healthyYears) + Math.round(store.final.timeline.disabilityYears) < 5)) {
              return Object.assign({}, haloSlidesAUv23['20a'])
            } else {
              return Object.assign({}, slide, {
                checks: Object.assign({}, slide.checks, {
                  bmiC: Object.assign({}, slide.checks.bmiC, {
                    hover: [...slide.checks.bmiC.hover.slice(0, 1), parseInt(store.final.bmiInformation.idealRangeStart, 10), slide.checks.bmiC.hover.slice(2, 3), parseInt(store.final.bmiInformation.idealRangeEnd, 10), slide.checks.bmiC.hover.slice(4, 5)],
                  })
                })
              })
            }
          } else {
            return Object.assign({}, slide, {})
          }
        }
      },
    timeline: {
      active: {
        label: "ACTIVE WORKING YEARS",
        hover: [`This section represents how many healthy years you have until you begin retirement. These are considered active working years.`],
      },
      retire: {
        label: "ACTIVE RETIREMENT YEARS",
        hover: [`In this section, you'll see how many projected years of active "go-go" retirement you have. It's important to think about how you want to spend your active years in retirement, as this will affect how you invest now. Do you want to travel? Put more toward charity?`],
      },
      assisted: {
        label: "EXTENDED CARE",
        hover: ["When it comes to care, there are many different choices from staying in your home to moving to a retirement community. Understanding your options puts you in the driver’s seat to plan for how you want to be cared for, without added stress"],
      },
      lost: {
        hover: ["Though this number represents the number of years lost due to lifestyle factors, it also shows the opportunities you have if you make changes now."],
      },
      mortality: {
        hover: ["While it's not always easy to think about life expectancy, it's a critical number to consider when building your financial plan.  The number you see here on your longevity healthspan is the 50% probability meaning you have a 50% chance of this to be this age or older.  In your full HALO Planner report, you'll see additional longevity scenarios all the way out to age 110."],
      },
    },
    checks: {
      alcoholC: {
        label: "Moderate alcohol consumption",
        hover: [],
        checked: false,
        disabled: false,
      },
      fruitVegetableC: {
        label: "Sufficient fruits & vegetables",
        hover: [],
        checked: false,
        disabled: false,
      },
      bmiC: {
        label: "Ideal BMI for longevity",
        hover: ["Ones ideal BMI for longevity is not the same as ones ideal BMI for overall health. Research shows that people who are mildly overweight tend to live slightly longer than their leaner peers, but health experts agree that keeping your BMI between ", "18.5", " - ", "24.9", " is best for overall health."],
        checked: false,
        disabled: false,
      },
      exercisesC: {
        label: "Regular exercise",
        hover: [],
        checked: false,
        disabled: false,
      },
      smokingC: {
        label: "Smoke-free life",
        hover: [],
        checked: false,
        disabled: false,
      },
    },
    set_value:
      (slide, store, value) => {
        var newSlide = Object.assign({}, slide, {checks: Object.assign({}, slide.checks)})
        newSlide.checks[store].checked = value
        return newSlide
      },
  },
  '20a': {
    number: '20a',
    next: '20a',
    back: 19,
    step: 19,
    type: 'halonotimeline',
    header: {logo: `${STATIC_ROOT}/images/logo-halo-small.svg`, text: 'Lumiant HALO Longevity Planner',},
    question: {
      large: ["Congratulations!", <br></br>, "Your future just got healthier."],
      small: ["Your full longevity report has been sent to your advisor.",
        <br/>, "You can expect a call from them soon to discuss your full results and how they affect your financial plan."]
    },
  },
};

function convertKgToGrams(kgs) {
  const gramMultiplier = 1000.0 // the amount multiplied to convert kgs into grams
  return kgs * gramMultiplier
}
