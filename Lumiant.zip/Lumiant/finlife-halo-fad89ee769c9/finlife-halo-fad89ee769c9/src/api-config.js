import {rootId,rootOriginalId} from "./constants/misc";

let backendHost = "";
let apiHost = ""
let credentials = 'same-origin'
const hostname = window && window.location && window.location.hostname;

// check the classList exists before continuing on to the next stage
// get element before extracting class list
// TODO: temporary remove refactor code
//let classes = document.getElementById(rootId).classList;
//let classesOriginal = document.getElementById(rootOriginalId).classList

let classes  = document.getElementById(rootId)
let classesOriginal = document.getElementById(rootOriginalId)

console.log("root: ", classes)
console.log("root original: ", classesOriginal)

// check if value is null
if(classes !== null) {
  for (let element = 0; element < classes.classList.length; element++) {
    let endpoint = /(\w+)_endpoint/.exec(classes.classList[element])
    if (endpoint != null && endpoint.length > 0) {
      backendHost = `https://${endpoint[1]}.lumiant.io`
      apiHost = `https://${endpoint[1]}.lumiant.io`
      break
    }
  }
}

if(classesOriginal !== null) {
  for (let element = 0; element < classesOriginal.classList.length; element++) {
    let endpoint = /(\w+)_endpoint/.exec(classesOriginal.classList[element])
    if (endpoint != null && endpoint.length > 0) {
      backendHost = `https://${endpoint[1]}.lumiant.io`
      apiHost = `https://${endpoint[1]}.lumiant.io`
      break
    }
  }
}

if (hostname === 'localhost') {
  backendHost = 'http://localhost:5000';
  apiHost = 'http://localhost:5000';
  if (window.location.port === "3000") {
    credentials = 'include'
  }
} else if (backendHost === "" && apiHost === "" && hostname === '127.0.0.1') {
  backendHost = `http://${hostname}:${window.location.port}`
  apiHost = `http://${hostname}:${window.location.port}`
} else if (backendHost === "" && apiHost === "" && (hostname === "mur6ilxg5smdvhq5nrykmrorna0eqdoa.lambda-url.ap-southeast-2.on.aws" || hostname === "halo-dev.lumiant.io")) {
  backendHost = "https://halo-dev.lumiant.io"
  apiHost = "https://halo-dev.lumiant.io"
} else if (backendHost === "" && apiHost === "" && (hostname === "pwucm4sjuh2g2jrbbjqst46sui0ilckz.lambda-url.ap-southeast-2.on.aws" || hostname === "halo-qa.lumiant.com.au")) {
  backendHost = "https://halo-qa.lumiant.com.au"
  apiHost = "https://halo-qa.lumiant.com.au"
} else if (backendHost === "" && apiHost === "" && (hostname === "5v7tuzt7vqaqu3ojeintyst46e0ilxbs.lambda-url.us-east-1.on.aws" || hostname === "halo-qa.lumiant.io")) {
  backendHost = "https://halo-qa.lumiant.io"
  apiHost = "https://halo-qa.lumiant.io"
} else if (backendHost === "" && apiHost === "" && (hostname === "37437qeok47ggy4yza6rouzwn40mwuxd.lambda-url.ap-southeast-2.on.aws" || hostname === "halo-staging.lumiant.com.au")) {
  backendHost = "https://halo-staging.lumiant.com.au"
  apiHost = "https://halo-staging.lumiant.com.au"
} else if (backendHost === "" && apiHost === "" && (hostname === "ejm5jheel23ffvtmqk7otnlfcy0ouhhd.lambda-url.us-east-1.on.aws" || hostname === "halo-staging.lumiant.io")) {
  backendHost = "https://halo-staging.lumiant.io"
  apiHost = "https://halo-staging.lumiant.io"
} else if (backendHost === "" && apiHost === "" && (hostname === "ph7cxi2h3wju54n2u6n5uwc2ru0pfvaa.lambda-url.ap-southeast-2.on.aws" || hostname === "halo.lumiant.com.au")) {
  backendHost = "https://halo.lumiant.com.au"
  apiHost = "https://halo.lumiant.com.au"
} else if (backendHost === "" && apiHost === "" && (hostname === "qblipzmvbopflkb4l42l77klhy0koqsw.lambda-url.us-east-1.on.aws" || hostname === "halo.lumiant.io")) {
  backendHost = "https://halo.lumiant.io"
  apiHost = "https://halo.lumiant.io"
} else if (backendHost === "" && apiHost === "" && (hostname === "aws-halo-soft-release.genivity.com")) {
  // api host points to prod hostname instead of softlaunch one due to how hosted page is queried which results in a error
  backendHost = "https://aws-halo-soft-release.genivity.com"
  apiHost = "https://halo.lumiant.io"
} else if (backendHost === "" && apiHost === "" && (hostname === "halo.genivity.com")) {
  backendHost = "https://halo.genivity.com"
  apiHost = "https://halo.lumiant.io"
} else if (backendHost === "") {
  backendHost = "https://halo.lumiant.io"
  apiHost = "https://halo.lumiant.io"
}

export const API_ROOT = `${apiHost}/api/v1`;
export const STATIC_ROOT = `${backendHost}/static/halo`;
export const API_CRED = credentials