export const EN_AU = 'en-AU';
export const EN_GB = 'en-GB';
export const EN_NZ = 'en-NZ';
export const EN_US = 'en-US';
