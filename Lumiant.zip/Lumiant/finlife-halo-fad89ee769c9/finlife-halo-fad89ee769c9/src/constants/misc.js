export const rootId = 'lumiant-halo-root'
export const rootOriginalId = 'genivity-halo-root'