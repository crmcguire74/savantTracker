
export const PRIVACY_POLICY = "https://support.helphub.lumiant.io/servicedesk/customer/portal/3/article/1620607089"