// smokes
export const smokingCurrent = 'current'
export const smokingFormer = 'former'
export const smokingNone = 'none'

// smoking pattern
export const cigarette = 'cigarette'
export const cigar = 'cigar'
export const both = 'both'

// constants associated with min & max inputs
// weight - US
export const maxWeightUS = 1000
export const minWeightUS = 0

// weight - AU
export const maxWeightAU = 454  // value is based off conversion from max US weight round
export const minWeightAU = 0

// height - US
export const maxInches = 12
export const maxFeet = 9
export const minInches = 0
export const minFeet =  1

// height - AU
export const maxCentimetres = 304 // value is based off conversion of max US height round
export const minCentimetres = 0

// Age
export const minAge = 18
export const maxAge = 110

// Former Smoker Quit Age
export const quitLateAge = 45
export const quitEarlyAge = 35

// Former Smoker Quit Age Value
export const quitLateValue = 3
export const quitMidValue = 2 // before age 45
export const quitEarlyValue = 1
