import cloneDeep from 'lodash.clonedeep'
import { haloSlidesv21 } from '../assessments/halov21'
import { haloSlidesv19 } from '../assessments/halov19'
import { haloSlidesv20 } from '../assessments/halov20'
import { haloSlidesAUv23 } from "../assessments/en-AU/halov23"
import {haloSlidesAUv24} from "../assessments/en-AU/halov24";
import { EN_AU, EN_GB, EN_NZ, EN_US } from '../constants/locales';
import { defaultAdvisor, haloValues } from '../debug/debugData';
import {haloSlidesv22} from "../assessments/halov22";
import {haloSlidesv23} from "../assessments/halov23";

const debug = false
const startslide = debug ? 19 : 0
const version = 21

var haloSlides

export default (state = 0, action) => {
  let new_state = {}
  let new_slide = {}
  let next_slide = {}
  // let slides = {}
  let followUpSlide = ""
  let index

  switch (action.type) {
    case 'QUERY_INPUTS':
      if ("age" in action.inputs) {
        action.inputs.age = parseInt(action.inputs.age, 10)
      }

      new_state = Object.assign({}, state, {halo: {...state.halo, ...action.inputs}})
      return new_state

    case 'OPEN_CLOSEDIALOG':
      new_state = Object.assign({}, state, {closedialog: {open: true, options: action.options}})
      return new_state

    case 'CLOSE_CLOSEDIALOG':
      new_state = Object.assign({}, state, {closedialog: {open: false}})
      return new_state

    case 'OPEN_SNACKBAR':
      new_state = Object.assign({}, state, {snackbar: {open: true, message: action.message}})
      return new_state

    case 'CLOSE_SNACKBAR':
      new_state = Object.assign({}, state, {snackbar: {open: false}})
      return new_state

    case 'OPEN_HALO':
      haloSlides = getHaloSlides(state.advisor.version, state.advisor.locale, state)
      return (Object.assign({}, state, {
        open: true,
        closedialog: {open: false},
        snackbar: {open: false},
        slides: haloSlides,
        slide: Object.assign({}, haloSlides[startslide]),
        final: {}
      }))

    case 'CLOSE_HALO':
      haloSlides = getHaloSlides(state.advisor.version, state.advisor.locale, state)
      return Object.assign({}, state, {
        open: false,
        closedialog: {open: false},
        snackbar: {open: false},
        halo: defaults,
        slide: Object.assign({}, haloSlides[startslide]),
        slides: haloSlides
      })

    case 'RESTART_HALO':
      haloSlides = getHaloSlides(state.advisor.version, state.advisor.locale, state)
      return Object.assign({}, state, {
        open: false,
        closedialog: {open: false},
        snackbar: {open: false},
        halo: defaults,
        slide: Object.assign({}, haloSlides[startslide]),
        slides: haloSlides
      })

    case 'RESTART_HALO_COUPLE':
      haloSlides = getHaloSlides(state.advisor.version, state.advisor.locale, state)
      return (Object.assign({}, state, {
        open: true,
        closedialog: {open: false},
        snackbar: {open: false},
        halo: Object.assign({}, defaults, {coupledWith: parseInt(action.value, 10)}),
        slide: Object.assign({}, haloSlides[1]),
        slides: haloSlides
      }))

    case 'NEXT_BUTTON':
      if (state.slide.showfollowup) {
        followUpSlide = state.slide.showfollowup(state)

        if (followUpSlide !== "") {
          new_slide = state.slides[followUpSlide]

          if (state.slides[followUpSlide].hasOwnProperty("populate")) {
            new_slide = state.slides[followUpSlide].populate(state.slides[followUpSlide], state)
          }

          return Object.assign({}, state, {slide: new_slide})
        }
      }

      if (typeof state.slide.next === "function") {
        next_slide = state.slide.next(state.advisor.version)
        new_slide = state.slides[next_slide]

        if (state.slides[next_slide].hasOwnProperty("populate")) {
          new_slide = state.slides[next_slide].populate(new_slide, state)
        }

        return Object.assign({}, state, {slide: Object.assign({}, new_slide)})
      } else if (state.slides.hasOwnProperty(state.slide.next)) {
        next_slide = state.slide.next
        new_slide = state.slides[next_slide]

        if (state.slides[next_slide].hasOwnProperty("populate")) {
          new_slide = state.slides[next_slide].populate(new_slide, state)
        }

        return Object.assign({}, state, {slide: Object.assign({}, new_slide)})
      } else {
        return Object.assign({}, state)
      }

    case 'BACK_BUTTON':
      // new_state = Object.assign({}, state)
      // if (state.slides[state.slide.back].processBack) {
      //   // new_state.slides = Object.assign({}, state.slides)
      //   return Object.assign({}, state, { slide: state.slides[state.slide.back] })
      // } else {
      //   return Object.assign({}, state, { slide: state.slides[state.slide.back] })
      // }
      return Object.assign({}, state, {slide: Object.assign({}, state.slides[state.slide.back])})

    case 'SET_VALUE':
      new_state = Object.assign({}, state, {halo: Object.assign({}, state.halo), slide: Object.assign({}, state.slide)})
      haloSlides = getHaloSlides(state.advisor.version, state.advisor.locale, state)

      if (action.store === 'ethnicity') {
        new_state.halo['european'] = 0
        new_state.halo['african'] = 0
        new_state.halo['asian'] = 0
        new_state.halo['indian'] = 0
        new_state.halo['mideastern'] = 0
        new_state.halo['hispanic'] = 0
        new_state.halo['otherEthnicity'] = 0
        new_state.halo['aboriginal'] = 0
        new_state.halo['torresStraitIslander'] = 0
        new_state.slides['f5'] = Object.assign({}, haloSlides['f5'])
      }

      if (action.store === "cancer" && action.value) {
        new_state.halo['bladderCancer'] = false
        new_state.halo['breastCancer'] = false
        new_state.halo['colonCancer'] = false
        new_state.halo['kidneyCancer'] = false
        new_state.halo['lungCancer'] = false
        new_state.halo['ovarianCancer'] = false
        new_state.halo['pancreaticCancer'] = false
        new_state.halo['prostateCancer'] = false
        new_state.halo['skinMelanoma'] = false
        new_state.halo['otherCancer'] = false
        new_state.slides['f11'] = Object.assign({}, haloSlides['f11'])
      }

      new_state.halo[action.store] = action.value
      new_state.slide = state.slide.set_value(state.slide, action.store, action.value)
      // new_state.slides = Object.assign({}, state.slides,)
      new_state.slides[state.slide.number] = Object.assign({}, state.slides[state.slide.number].set_value(state.slides[state.slide.number], action.store, action.value))
      return new_state

    case 'SET_VALUE_NEXT':
      new_state = Object.assign({}, state, {halo: Object.assign({}, state.halo)})
      new_state.slides = Object.assign({}, state.slides)
      haloSlides = getHaloSlides(state.advisor.version, state.advisor.locale, state)

      if (['european', 'african', 'asian', 'indian', 'mideastern', 'hispanic', 'other', 'aboriginal',
      'torresStraitIslander'].indexOf(action.store) >= 0) {
        new_state.halo['european'] = 0
        new_state.halo['african'] = 0
        new_state.halo['asian'] = 0
        new_state.halo['indian'] = 0
        new_state.halo['mideastern'] = 0
        new_state.halo['hispanic'] = 0
        new_state.halo['otherEthnicity'] = 0
        new_state.halo['aboriginal'] = 0
        new_state.halo['torresStraitIslander'] = 0
        new_state.slides['f5'] = Object.assign({}, haloSlides['f5'])

        if (action.value === 100) {
          new_state.halo['ethnicity'] = ""
        }
      }

      if (action.store === "cancer" && !action.value) {
        new_state.halo['bladderCancer'] = false
        new_state.halo['breastCancer'] = false
        new_state.halo['colonCancer'] = false
        new_state.halo['kidneyCancer'] = false
        new_state.halo['lungCancer'] = false
        new_state.halo['ovarianCancer'] = false
        new_state.halo['pancreaticCancer'] = false
        new_state.halo['prostateCancer'] = false
        new_state.halo['skinMelanoma'] = false
        new_state.halo['otherCancer'] = false
        new_state.slides['f11'] = Object.assign({}, haloSlides['f11'])
      }

      new_state.halo[action.store] = action.value
      new_state.slides[state.slide.number] = state.slides[state.slide.number].set_value(state.slides[state.slide.number], action.store, action.value)

      if (state.slide.showfollowup) {
        followUpSlide = state.slide.showfollowup(new_state, action)

        if (followUpSlide !== "") {
          new_slide = state.slides[followUpSlide]

          if (state.slides[followUpSlide].hasOwnProperty("populate")) {
            new_slide = state.slides[followUpSlide].populate(state.slides[followUpSlide], state)
          }

          return Object.assign({}, new_state, {slide: Object.assign({}, new_slide)})
        }
      }

      if (typeof state.slide.next === "function") {
        next_slide = state.slide.next(state.advisor.version)
        new_slide = state.slides[next_slide]

        if (state.slides[next_slide].hasOwnProperty("populate")) {
          new_slide = state.slides[next_slide].populate(new_slide, state)
        }

        return Object.assign({}, new_state, {slide: Object.assign({}, new_slide)})
      } else if (state.slides.hasOwnProperty(state.slide.next)) {
        next_slide = state.slide.next
        new_slide = state.slides[next_slide]

        if (state.slides[next_slide].hasOwnProperty("populate")) {
          new_slide = state.slides[next_slide].populate(new_slide, state)
        }

        return Object.assign({}, new_state, {slide: Object.assign({}, new_slide)})
      } else {
        return new_state
      }

    case 'TRIGGER_FOLLOWUP':
      new_state = Object.assign({}, state, {slide: state.slides[state.slide.followup[action.value]]})

      if (action.store === 'ethnicity') {
        haloSlides = getHaloSlides(state.advisor.version, state.advisor.locale, state)
        new_state.halo['european'] = 0
        new_state.halo['african'] = 0
        new_state.halo['asian'] = 0
        new_state.halo['indian'] = 0
        new_state.halo['mideastern'] = 0
        new_state.halo['hispanic'] = 0
        new_state.halo['aboriginal'] = 0
        new_state.halo['torresStraitIslander'] = 0
        new_state.halo['otherEthnicity'] = 0
        new_state.slides['f5'] = Object.assign({}, haloSlides['f5'])
      }

      new_state.halo[action.store] = action.value
      new_state.slides[state.slide.number] = new_state.slides[state.slide.number].set_value(new_state.slides[state.slide.number], action.store, action.value)
      return new_state

    case 'NEXT_FOLLOWUP':
      new_state = Object.assign({}, state, {slide: state.slides[state.slide.followup[action.value]]})
      return new_state

    case 'REQUEST_API':
      new_state = Object.assign({}, state, {api: {state: "requested", endpoint: action.api}})
      return new_state

    case 'API_TIMEOUT':
      new_state = Object.assign({}, state, {api: {state: "timeout", endpoint: action.api}})
      return new_state

    case 'RECEIVE_API':
      if (action.json) {

        if (action.api === "advisor") {
          haloSlides = getHaloSlides(action.json.version, action.json.locale | EN_US, state)
          new_state = Object.assign({}, state, {
            api: {state: "idle", endpoint: ''},
            open: false,
            closedialog: {open: false},
            snackbar: {open: false},
            slides: haloSlides,
            slide: Object.assign({}, haloSlides[startslide]),
            final: {}
          })
        } else {
          new_state = Object.assign({}, state, {api: {state: "idle", endpoint: ''}})
        }

        new_state[action.api] = action.json

        if ('number' in state.slide) { //added for debug capability, slide should always be valid
          next_slide = state.slide.number //stay on the same slide
          var populated_slide = state.slides[next_slide]

          if (state.slides[next_slide].hasOwnProperty("populate")) {
            populated_slide = state.slides[next_slide].populate(populated_slide, new_state)
          }

          new_state.slide = Object.assign({}, populated_slide)
        }

        if (debug && action.api === 'advisor') {
          new_state[action.api] = defaultAdvisor
        }

        return new_state
      } else {
        new_state = Object.assign({}, state, {api: {state: "timeout", endpoint: action.api}})
        return new_state
      }

    case 'IMAGE_LOADED':
      index = state.images.indexOf(action.image)
      new_state = Object.assign({}, state, {images: [...state.images.slice(0, index), ...state.images.slice(index + 1)]})
      return new_state

    case 'IMAGE_ERROR':
      // FOR NOW JUST HANDLE THIS THE SAME AS IMAGE LOADED TO NOT PREVENT HALO USAGE
      index = state.images.indexOf(action.image)
      new_state = Object.assign({}, state, {images: [...state.images.slice(0, index), ...state.images.slice(index + 1)]})
      return new_state

    default:
      if (state === 0 && !debug) {
        haloSlides = getHaloSlides(19, EN_US, state)

        return {
          halo: defaults,
          images: images,
          api: {state: "idle"},
          advisor: {},
          open: false,
          closedialog: {open: false},
          snackbar: {open: false},
          slides: haloSlides,
          slide: Object.assign({}, haloSlides[0]),
        }
      } else if (debug) {
        haloSlides = getHaloSlides(version, EN_US, state)

        return {
          halo: defaults,
          images: images,
          api: {state: "idle"},
          advisor: {},
          open: false,
          closedialog: {open: false},
          snackbar: {open: false},
          slides: haloSlides,
          slide: Object.assign({}, haloSlides[startslide]),
          final: haloValues
        }
      } else {
        return Object.assign({}, state)
      }
  }
}

let images= [
  'check.png',
  'checkcircle.png',
  'icn_birthday.svg',
  'icn_cancer.svg',
  'icn_diabetic.svg',
  'icn_dimentia.svg',
  'icn_disease.svg',
  'icn_doctor.svg',
  'icn_ethnicity.svg',
  'icn_exercise.svg',
  'icn_female_grey.svg',
  'icn_female.svg',
  'icn_male_grey.svg',
  'icn_male.svg',
  'icn_height.svg',
  'icn_location.svg',
  'icn_old-age.svg',
  'icn_retirement.svg',
  'icn_smoker.svg',
  'icn_stroke.svg',
  'icn_weight.svg',
  'icn_alcohol.png',
  'icn_fruits.png',
  'icn_dumbell.svg',
  'icn_helix.svg',
  'logo-halo-small.svg',
  'logo-halo-large.svg',
  'icn-social.svg',
]

let defaults= {
  european: 0,
  african: 0,
  asian: 0,
  hispanic: 0,
  aboriginal:0,
  torresStraitIslander:0,
  otherEthnicity: 0,
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  gender: "",
  age: null,
  height: null,
  weight: null,
  retirementAge: 65,
  retirementLocation: "",
  longLivedFamilyCount: 0,
  doctorVisitFrequency: "",
  exercises: false,
  smokes: false,
  smokingType:"",
  quitSmokingAge: 0,
  smokingPattern:"",
  smokeCigar: 0,
  smokeCigarette: 0,
  stroke: 0,
  diabetes: 0,
  heartDisease: 0,
  alzheimers: false,
  bladderCancer: false,
  breastCancer: false,
  colonCancer: false,
  kidneyCancer: false,
  lungCancer: false,
  ovarianCancer: false,
  pancreaticCancer: false,
  prostateCancer: false,
  skinMelanoma: false,
  otherCancer: false,
  fromSource: window.location.href,
  version: 18,
  locale: EN_US,
  userAgent: window.navigator.userAgent,
  coupledWith: 0, // int of input id that it is matched with.
  alcohol: null,
  fruitVegetable: null,
  spouseSupport: null,
  familySupport: null,
  friends: null,
}

// check hostname for soft release path and use prod path for fromSource
if(window.location.hostname === "aws-halo-soft-release.genivity.com" ){
  defaults.fromSource = window.location.href.replace("aws-halo-soft-release.genivity.com", "halo.lumiant.io")
} else if(window.location.hostname === "halo.genivity.com"){
  defaults.fromSource = window.location.href.replace("halo.genivity.com", "halo.lumiant.io")
}

// input fix when specific query params are present
const queryString = window.location.search
const urlParams = new URLSearchParams(queryString)
const inviteCode = urlParams.get('inviteCode')
const clientId = urlParams.get('clientId')
if (clientId && inviteCode){
  const urlObj = new URL(defaults.fromSource)
  defaults.fromSource =  urlObj.origin + urlObj.pathname
}

// Get the HALO slides to use based on the required version and locale of the algorithm.
// Both the version and locale are provided by the backend.
function getHaloSlides(version, locale, state) {
  let haloSlidesClone = {}

  switch (locale) {
    case EN_AU:
    case EN_GB:
    case EN_NZ:
      switch (version) {
        case 23:
          haloSlidesClone = cloneDeep(haloSlidesAUv23)
          return haloSlidesClone
        case 24:
          haloSlidesClone = cloneDeep(haloSlidesAUv24)
          return haloSlidesClone
        default:
          if (state !== 0) {
            for (var sl in haloSlidesClone) {
              if (haloSlidesClone[sl] && haloSlidesClone[sl].hasOwnProperty("populate")) {
                haloSlidesClone[sl] = haloSlidesClone[sl].populate(haloSlidesClone[sl], state)
              }
            }
          }
          return haloSlidesClone
      }

    default:
      // for now to test that the data is being created we will use
      switch (version) {
        case 19:
          haloSlidesClone = cloneDeep(haloSlidesv19)
          return haloSlidesClone
        case 20:
          haloSlidesClone = cloneDeep(haloSlidesv20)
          return haloSlidesClone
        case 21:
          haloSlidesClone = cloneDeep(haloSlidesv21)
          return haloSlidesClone
        case 22:
          haloSlidesClone = cloneDeep(haloSlidesv22)
          return haloSlidesClone
        case 23:
          haloSlidesClone = cloneDeep(haloSlidesv23)
          return haloSlidesClone
        default:
          if (state !== 0) {
            for (var sl in haloSlidesClone) {
              if (haloSlidesClone[sl] && haloSlidesClone[sl].hasOwnProperty("populate")) {
                haloSlidesClone[sl] = haloSlidesClone[sl].populate(haloSlidesClone[sl], state)
              }
            }
          }
          return haloSlidesClone
      }
  }
}
