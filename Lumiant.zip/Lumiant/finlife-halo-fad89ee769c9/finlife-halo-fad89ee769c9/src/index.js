import 'babel-polyfill'
import React from 'react'
import { render, createRoot } from 'react-dom/client'
import { StoreContext } from 'redux-react-hook';
import { MuiThemeProvider } from '@material-ui/core/styles';
import { gen_theme } from './style/CalcStyle'
import {rootId, rootOriginalId} from "./constants/misc";
import './index.css';
import HaloContainer from './components/HaloContainer';
import configureStore from './configureStore'

// Add the reducer to your store on the `routing` key
const store = configureStore()
const container =  document.getElementById(rootId) || document.getElementById(rootOriginalId)
//const containerOriginal = document.getElementById(rootOriginalId)
const root = createRoot(container)
//const rootOriginal = createRoot(containerOriginal)

root.render(
    <StoreContext.Provider value={store}>
    <MuiThemeProvider theme={gen_theme}>
      <HaloContainer element={container}/>
    </MuiThemeProvider>
  </StoreContext.Provider>,
)