


export const bmiMisc = "While BMI is a metric that provides a good baseline for" +
    " understanding your body makeup and how it relates to your health, it isn't everything." +
    " BMI can be misleading if you are of above average muscular build and providing this" +
    " information produces a more accurate longevity outlook."