
export const bmiQuestion = "Pick the option that matches closest to your body shape."


export const fruitVegQuestion = "How many servings of fruits or vegetables do you eat" +
    " in a typical day?"


export const retirementLocationQuestion = "Where would you like to retire?"

export const longevityQuestion = "Let’s talk longevity. How many family members have lived to be 89 years old or older" +
    " (parents & grandparents only)?"