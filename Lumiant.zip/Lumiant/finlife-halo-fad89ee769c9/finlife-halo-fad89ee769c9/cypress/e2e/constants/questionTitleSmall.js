


export const bmiQuestionSmall = "BMI doesn't tell the whole story, your muscle mass" +
    " has an affect on your longevity, too. To help us understand your muscular structure," +
    " we need a bit more information about your body shape."

export const fruitVegSmall = "(Give a hoot, eat more fruit)"

export const retirementLocationSmall = "If already retired, select the state in which you live."