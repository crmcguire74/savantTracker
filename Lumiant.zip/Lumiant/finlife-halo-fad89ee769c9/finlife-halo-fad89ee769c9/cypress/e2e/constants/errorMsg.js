

// may need to refactor logic

// weight
export const errWeightAU = "Please enter your weight in kilograms (kgs)."
export const errWeightInvalidAU = "Please enter valid weight in kilograms (kgs)"

export const errWeightUS = "Please enter your weight in pounds (lbs)."
export const errWeightInvalidUS =  "Please enter valid weight in pounds (lbs)"

export const errRetirementAgeUS = "Please select an option that best reflects at what age you would like to retire."
export const errRetirementAgeInvalidUS = "Please enter valid age you would like to retire."

export const errRetirementLocationUS = "Please enter a US state that best reflects where you would like to retire."