
// should make constants that are accessibleto both files
export const submitBtn = "SUBMIT"
export const male =  "MALE"
export const female = "FEMALE"

// Smoking
export const cigarettesBtn = "Cigarettes"
export const cigarBtn = "Cigars"
export const smokerTypeFormerBtn = "Former"

// BMI
export const slimBuildBtn = "Slim"

// Ancestry
export const europeanAncestryBtn = "European ancestry"

