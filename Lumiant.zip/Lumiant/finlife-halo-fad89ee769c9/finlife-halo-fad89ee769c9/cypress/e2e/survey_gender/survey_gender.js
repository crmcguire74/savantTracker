import {Given, Then, When} from "@badeball/cypress-cucumber-preprocessor";
import {addGender, startSurvey} from "../utils";
import {male} from "../constants/constants";

Given("user is a client and has commenced the HALO assessment", ()=>{
    startSurvey()
})

When("user adds a gender during the survey", ()=>{
    addGender(male)
})

Then("user should see the next survey question for age", ()=>{
    cy.contains("How many candles will be on your birthday cake this year?")
    cy.contains("how old will you be?")
})

When("user adds NO gender during the survey", ()=> {
    cy.contains("SUBMIT").click()
})


Then("user should see a error message to select a gender", () =>{
    cy.contains("Please select your gender.")
})