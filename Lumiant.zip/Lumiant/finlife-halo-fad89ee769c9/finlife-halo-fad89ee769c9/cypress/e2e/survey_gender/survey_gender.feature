# Created by michaelmarturano at 24/4/2024
@en-us
Feature: survey_gender
  user should be able to start HALO survey
  and be able to add in gender

  Scenario: select a gender
    Given user is a client and has commenced the HALO assessment
    When user adds a gender during the survey
    Then user should see the next survey question for age

  Scenario: doesn't select a gender
    Given user is a client and has commenced the HALO assessment
    When user adds NO gender during the survey
    Then user should see a error message to select a gender

