import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
import {
    addGender,
    addHeightInFeetInches,
    addInput,
    checkErrorMsg,
    checkMiscContent,
    checkSurveyQuestion,
    startSurvey
} from "../utils";
import {male, submitBtn} from "../constants/constants";
import {bmiQuestion} from "../constants/questionTitleLarge";
import {bmiMisc} from "../constants/miscText";
import {bmiQuestionSmall} from "../constants/questionTitleSmall";
import {errWeightInvalidUS, errWeightUS} from "../constants/errorMsg";

Given("user is a client and has completed survey before the weight section",  () =>{
    startSurvey()
    addGender(male)
    addInput(26)
    addHeightInFeetInches(5,11)
})

When("user enters \{int} weight", (weight) => {
    addInput(weight)
})

When("user enters no input for weight", () =>{
    cy.contains(submitBtn).click()
})

Then("user should proceed to the next survey question", () => {
    checkSurveyQuestion(bmiQuestion, true)
    checkSurveyQuestion(bmiQuestionSmall, false)
    checkMiscContent(bmiMisc)
})

Then("user should see a error message about invalid weight value", () =>{
    cy.contains(errWeightInvalidUS)
})

Then("user should see a error message about empty weight value", () =>{
    cy.contains(errWeightUS)
})