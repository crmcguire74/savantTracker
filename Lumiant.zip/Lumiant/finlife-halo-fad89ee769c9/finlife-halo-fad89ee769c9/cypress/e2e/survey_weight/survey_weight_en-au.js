import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
import {addGender, addInput, checkErrorMsg, checkMiscContent, checkSurveyQuestion, startSurveyAU} from "../utils";
import {male, submitBtn} from "../constants/constants";
import {bmiQuestion} from "../constants/questionTitleLarge";
import {bmiMisc} from "../constants/miscText";
import {errWeightAU, errWeightInvalidAU} from "../constants/errorMsg";

Given("user is a client and has completed survey before the weight section", () =>{
    startSurveyAU()
    addGender(male)
    addInput(26)
    addInput(180)
})

When("user enters \{int} weight", (weight) =>{
    addInput(weight)
})

When("user enters no input for weight", () =>{
    cy.contains(submitBtn).click()
})

Then("user should proceed to the next survey question", () => {
    checkSurveyQuestion(bmiQuestion, true)
    checkMiscContent(bmiMisc)
})

Then("user should see a error message about invalid weight value",  () =>{
    cy.contains(errWeightInvalidAU)
})

Then("user should see a error message about empty weight value", ()=>{
    cy.contains(errWeightAU)
})