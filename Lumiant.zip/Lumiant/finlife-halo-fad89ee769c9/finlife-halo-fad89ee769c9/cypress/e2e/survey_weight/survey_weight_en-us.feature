# Created by michaelmarturano at 26/4/2024
@en-us
Feature: survey_weight_en-us
  user should be able to start a HALO survey
  and be able to add weight in pounds


  # write a bunch of common scenarios that would typically occur
  Scenario Outline: enters a valid weight
    Given user is a client and has completed survey before the weight section
    When user enters <weight> weight
    Then user should proceed to the next survey question
    Examples:
    |weight|
    | 60   |



  Scenario Outline: enters a negative weight
    Given user is a client and has completed survey before the weight section
    When  user enters <weight> weight
    Then  user should see a error message about invalid weight value
    Examples:
    |weight|
    | -50  |


  Scenario: enters a empty value
    Given user is a client and has completed survey before the weight section
    When  user enters no input for weight
    Then  user should see a error message about empty weight value
