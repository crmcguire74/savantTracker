# Created by michaelmarturano at 23/4/2024
@intro
  @en-us
Feature: intro
  user should be able to start HALO survey
  and also be able to see privacy policy and
  disclaimer

  Scenario: client visiting the HALO survey main menu screen
    Given user is a client
    When user visits a halo hosted page
    And  user clicks on embedded HALO button
    Then user should see the intro menu screen

  @more-info
  Scenario: user should see the privacy policy floater
    Given user is a client and is on the main menu screen
    When user clicks on privacy policy button
    Then user should see a message pop up for privacy policy

  @more-info
  Scenario: user should see the disclaimer floater
    Given user is a client and is on the main menu screen
    When user clicks on disclaimer button
    Then user should see a message pop up for disclaimer
