import {Given,When, Then,} from "@badeball/cypress-cucumber-preprocessor";
import {rootId} from "../../../src/constants/misc";

Given("user is a client", ()=>{
    cy.log("regular client")
})

Given("user is a client and is on the main menu screen", () =>{
    cy.log("regular client")
    let path = Cypress.config().baseUrl
    cy.log(path)

    cy.log("end")
    if(path === "http://localhost:3000"){
        cy.visit("/advisor/test")
    }else{
        cy.visit("/advisor/test-org-us")
    }
    cy.get(`div[id=${rootId}]`).click()
    cy.get(`div[id=${rootId}]`).contains("Take the HALO Assessment")
    cy.contains("See the future, so we can plan for it.")
})

When("user visits a halo hosted page", ()=>{
    let path = Cypress.config().baseUrl
        if(path === "http://localhost:3000"){
        cy.visit("/advisor/test")
    }else{
        cy.visit("/advisor/test-org-us")
    }
})

When("user clicks on embedded HALO button", ()=>{
        cy.get(`div[id=${rootId}]`).click()
})

Then("user should see embedded HALO button", () => {
    cy.get(`div[id=${rootId}]`).contains("Take the HALO Assessment")
})

Then("user should see the intro menu screen", () =>{
    cy.contains("See the future, so we can plan for it.")
})
When("user clicks on privacy policy button", () => {
    cy.contains("Privacy Policy").click()
})

Then("user should see a message pop up for privacy policy",()=>{
    cy.contains("By filling out the HALO")
})

When("user clicks on disclaimer button", ()=>{
    cy.contains("Disclaimer").click()
})

Then("user should see a message pop up for disclaimer", ()=>{
    cy.contains("This HALO assessment is intended for individuals")
})
