import {male,female,submitBtn} from "./constants/constants";
import {rootId} from "../../src/constants/misc";


export function selectButton(index,contains) {
    if (index === undefined || index ===  null){
            cy.get("div[class='gButtonContainer']").contains(contains).click()
    }else {
        cy.get("div[class='gButtonContainer']").eq(index).contains(contains)
            .click()
    }
}

// generic inputs that is used for question that
// typically have a single input
export function addInput(value){
    cy.get('input').type(value)
    cy.contains(submitBtn).click()

}
export function addGender(gender){
    switch (gender) {
        case male:
            cy.get('figcaption').eq(1)
                .should('contain', gender).click()
            cy.contains(submitBtn).click()
            return

        case female:
            cy.get('figcaption').eq(0).should('contain', gender).click()
            cy.contains(submitBtn).click()
    }
}

export function addHeightInFeetInches(feet, inches ){
    cy.get("input[id='feet']").type(feet)
    cy.get("input[id='inches']").type(inches)
    cy.contains("SUBMIT").click()
}

// create helper methods that are typically used in the application
// start survey for US users
export function startSurvey(){
    let path = Cypress.config().baseUrl
    if (path === "http://localhost:3000" || path === "http://localhost:5000"){
        cy.visit("/advisor/test")

        // instead just see if we can find the button. the naming of the button
        cy.get(`div[id='${rootId}']`)
            .scrollIntoView({easing:"swing"})
        cy.get(`div[id='${rootId}']`).click()
        cy.contains("Take the Assessment").click()
    }else {
        cy.visit("/advisor/test-org-us")

        cy.get(`div[id='${rootId}']`)
            .scrollIntoView({easing:"swing"})
        cy.get(`div[id='${rootId}']`).click()
        cy.contains("Take the Assessment").click()
    }

}


export function startSurveyAU(){
    let path = Cypress.config().baseUrl
    if (path === "http://localhost:3000" || path === "http://localhost:5000"){
        cy.visit("/advisor/test")

        // instead just see if we can find the button. the naming of the button
        cy.get(`div[id='${rootId}']`)
            .scrollIntoView({easing:"swing"})
        cy.get(`div[id='${rootId}']`).click()
        cy.contains("Take the Assessment").click()
    }else {
        cy.visit("/advisor/test-org-au")

        cy.get(`div[id='${rootId}']`)
            .scrollIntoView({easing:"swing"})
        cy.get(`div[id='${rootId}']`).click()
        cy.contains("Take the Assessment").click()
    }
}

export function checkSurveyQuestion(content, isLarge){
    // check question content
    if (isLarge) {
        cy.get("div[class='gQuestionLarge']")
            .contains(content)
    }else{
        cy.get("div[class='gQuestionSmall']")
            .contains(content)
    }
}

export function checkMiscContent(content) {
    cy.get("div[class='gMiscText']")
        .contains(content)
}


export function checkErrorMsg(content){
    cy.get("div[class='MySnackbarContent-message-10']")
        .contains(content)
}

export function checkSVGContent(name) {

}

