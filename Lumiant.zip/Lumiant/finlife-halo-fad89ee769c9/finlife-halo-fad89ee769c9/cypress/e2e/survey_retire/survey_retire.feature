# Created by michaelmarturano at 29/4/2024
  @en-us
Feature: survey_retire
  user should be able to start a HALO survey
  and be able to add retirement age

  Scenario Outline: enters a valid retirement age
    Given user is a client and has completed survey before the retirement section
    When  user enters <age> retirement age
    Then  user should proceed to the next survey question
    Examples:
    | age  |
    |   50 |
  Scenario: enters a empty reirement age
    Given user is a client and has completed survey before the retirement section
    When  user enters no value for retirement age
    Then  user should see a error message about entering an retirement age

  Scenario Outline: enters a invalid retirement age
    Given user is a client and has completed survey before the retirement section
    When  user enters <age> retirement age
    Then  user should see a error message about invalid retirement age

    Examples:
    | age     |
    | -15     |
    | 200     |


