import {Given,When, Then} from "@badeball/cypress-cucumber-preprocessor";
import {
    addGender,
    addHeightInFeetInches,
    addInput,
    checkSurveyQuestion,
    selectButton,
    startSurvey
} from "../utils";
import {male, submitBtn} from "../constants/constants";
import {retirementLocationQuestion} from "../constants/questionTitleLarge";
import {retirementLocationSmall} from "../constants/questionTitleSmall";
import {errRetirementAgeInvalidUS, errRetirementAgeUS} from "../constants/errorMsg";


Given("user is a client and has completed survey before the retirement section", () => {
    startSurvey()
    addGender(male)
    addInput(26)
    addHeightInFeetInches(5,1)
    addInput(85)
    selectButton(null, "Muscular")
    selectButton(null, "European ancestry")
    selectButton(null, "3 - 5")
    selectButton(null, "No")
    selectButton(null, "4")
    selectButton(null, "Heavy")
    selectButton(null,"Myself")
    cy.contains(submitBtn).click()
    selectButton(null,"3 - 5")
    selectButton(null,"No")
    selectButton(null,"No")
    selectButton(null,"None")
    selectButton(null,"None")
    selectButton(null,"None")
})

When("user enters \{int} retirement age", (age) =>{
    cy.get("input").clear().type(age)
    cy.contains(submitBtn).click()
})

When("user enters no value for retirement age", ()=>{
    cy.get("input").clear()
    cy.contains(submitBtn).click()
})

Then("user should proceed to the next survey question", () =>{
    checkSurveyQuestion(retirementLocationQuestion, true)
    checkSurveyQuestion(retirementLocationSmall, false)
})

Then("user should see a error message about entering an retirement age", () => {
    cy.contains(errRetirementAgeUS)
})

Then("user should see a error message about invalid retirement age", () => {
    cy.contains(errRetirementAgeInvalidUS)
})