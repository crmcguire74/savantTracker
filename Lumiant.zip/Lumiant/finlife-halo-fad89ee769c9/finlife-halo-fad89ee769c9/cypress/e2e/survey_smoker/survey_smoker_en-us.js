import {Given, Then, When} from "@badeball/cypress-cucumber-preprocessor";
import {
    addGender,
    addHeightInFeetInches,
    addInput,
    checkSurveyQuestion,
    selectButton,
    startSurvey
} from "../utils";
import {male} from "../constants/constants";
import {fruitVegQuestion} from "../constants/questionTitleLarge";
import {fruitVegSmall} from "../constants/questionTitleSmall";




Given("user is a male client and has completed survey before the smoking section", () => {
    startSurvey()
    addGender(male)
    addInput(26)
    addHeightInFeetInches(5,11)
    addInput(170)

    // TODO make method handle box click in survey
    selectButton(null,"Muscular")
    selectButton(null,"European ancestry")
    selectButton(null,"3 - 5")
    //cy.contains("Muscular").click()
    //cy.contains("European ancestry").click()
    //cy.contains("3 - 5").click()
})

When("user enters that they aren't a smoker", () => {
    selectButton(null, "No")
    //cy.contains("No").click()
})

When("user enters current smoker answers\{string}\{string}\{string}",
    (smokerType, smokingPattern, smokingAmount) =>{

    selectButton(null,smokerType)
    selectButton(null,smokingPattern)
    selectButton(null,smokingAmount)
        //cy.contains(smokerType).click()
        //cy.contains(smokingPattern).click()
        //cy.contains(smokingAmount).click()
})


When("user enters former smoker answers\{string}\{string}\{string}\{string}",
    (smokerType, smokingPatten, smokingAmount, quitSmokingAge) =>{

    selectButton(null, smokerType)
    selectButton(null,smokingPatten)
    selectButton(null, smokingAmount)
    selectButton(null, quitSmokingAge)

        //cy.contains(smokerType).click()
        //cy.contains(smokingPatten).click()
        //cy.contains(smokingAmount).click()
        //cy.contains(quitSmokingAge).click()
})


Then("user should proceed to the next survey question", () => {
    checkSurveyQuestion(fruitVegQuestion, true)
    checkSurveyQuestion(fruitVegSmall, false)
})

Then("user should skip to the fruit and vegetable question", () => {
    checkSurveyQuestion(fruitVegQuestion, true)
    checkSurveyQuestion(fruitVegSmall, false)
})
