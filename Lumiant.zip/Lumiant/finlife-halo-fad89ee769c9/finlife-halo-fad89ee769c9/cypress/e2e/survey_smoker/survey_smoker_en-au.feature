# Created by michaelmarturano at 29/4/2024
  @en-au
Feature: survey_smoker_en-au
  user should be able to start a HALO survey
  and be able to complete the smoking questions for v23

  Scenario: enters non smoking male
    Given user is a male client and has completed survey before the smoking section
    When user enters that they aren't a smoker
    Then user should skip to the fruit and vegetable question


  Scenario Outline: enters current smoking answers male
    Given user is a male client and has completed survey before the smoking section
    When user enters current smoker answers<smokerType><smokingPattern><smokingAmount>
    Then user should skip to the fruit and vegetable question
  Examples:
  |smokerType       | smokingPattern         | smokingAmount                        |
  |  "Yes"          |      "Cigarettes"      |  "Occasionally"                      |
  |  "Yes"          |          "Cigar"       |    "Over 20 cigarettes daily"        |


    Scenario Outline: enters former smoking answers male
      Given user is a male client and has completed survey before the smoking section
      When  user enters former smoker answers<smokerType><smokingPattern><smokingAmount><quitSmokingAge>
      Then  user should proceed to the next survey question

      Examples:
      |smokerType         |  smokingPattern             | smokingAmount                  | quitSmokingAge              |
      |    "Former"       |      "Cigarettes"           |      "Occasionally"            |   "Before age 45"            |
