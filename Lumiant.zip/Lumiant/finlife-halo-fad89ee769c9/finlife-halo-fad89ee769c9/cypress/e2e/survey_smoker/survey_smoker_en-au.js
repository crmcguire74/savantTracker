import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
import {
    addGender,
    addInput,
    checkSurveyQuestion,
    selectButton,
    startSurveyAU
} from "../utils";
import {male} from "../constants/constants";
import {fruitVegQuestion} from "../constants/questionTitleLarge";
import {fruitVegSmall} from "../constants/questionTitleSmall";


Given("user is a male client and has completed survey before the smoking section", () =>{
    startSurveyAU()
    addGender(male)
    addInput(26)
    addInput(180)
    addInput(80)

    selectButton(null,"Muscular")
    selectButton(null,"European")
    selectButton(null, "3 - 5")

})


When("user enters that they aren't a smoker", () =>{
    selectButton(null,"No")
})

When("user enters current smoker answers\{string}\{string}\{string}",
    (smokerType, smokingPattern, smokingAmount) =>{
        selectButton(null, smokerType)
        selectButton(null, smokingPattern)
        selectButton(null, smokingAmount)
})

When("user enters former smoker answers\{string}\{string}\{string}\{string}",
    (smokerType, smokingPattern, smokingAmount, quitSmokingAge) =>{
        selectButton(null, smokerType)
        selectButton(null, smokingPattern)
        selectButton(null, smokingAmount)
        selectButton(null, quitSmokingAge)
})



Then("user should skip to the fruit and vegetable question", () => {
    checkSurveyQuestion(fruitVegQuestion, true)
    checkSurveyQuestion(fruitVegSmall, false)
})


Then("user should proceed to the next survey question", () =>{
    checkSurveyQuestion(fruitVegQuestion, true)
    checkSurveyQuestion(fruitVegSmall, false)
})