import {Given, Then, When} from "@badeball/cypress-cucumber-preprocessor";
import {addGender, addInput, startSurveyAU} from "../utils";
import {male} from "../constants/constants";


Given("user is a client and has completed survey before the height section", ()=>{
    startSurveyAU()
    addGender(male)
    addInput(26)
})

When("user enters negative \{int} height", (height)=>{
    addInput(height)
})

When("user enters \{int} height", (height) =>{
    addInput(height)
})

When("user enters no input for height", () =>{
    cy.contains("SUBMIT").click()
})
Then("user should proceed to the next survey question for height", ()=>{
        cy.contains("How much do you weigh")
})

Then("user should see a error message about invalid height value", ()=>{
        cy.contains("Please enter valid height in centimetres")

})

Then("user should see a error message about empty height value", ()=>{
    cy.contains("Please enter your height in centimetres")

})
