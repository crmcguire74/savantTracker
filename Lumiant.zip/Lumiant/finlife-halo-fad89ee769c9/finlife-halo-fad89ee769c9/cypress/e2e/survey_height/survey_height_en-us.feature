# Created by michaelmarturano at 26/4/2024
@en-us
Feature: survey_height_en-us
  as a user I want to start a HALO survey
  and be able to my height in feet & inches

    Scenario Outline: enter a valid height
    Given user is a client and has completed survey before the height section
    When  user enters <feet> <inches> height
    Then  user should see the next survey question for height
    Examples:
      | feet  | inches |
      | 5     |  8    |
      | 5     |  9    |

  Scenario Outline: enters a negative height
    Given user is a client and has completed survey before the height section
    When  user enters negative <feet> <inches> height

    Then user should see error message about invalid height value
    Examples:
        | feet | inches   |
        | -26  |    10    |
        | 26   |    -10   |
        | -26  |    -10   |

    # create a few scenarios where the value is empty
    Scenario: enters a empty value
      Given user is a client and has completed survey before the height section
      When  user enters no input for height
      Then  user should see error message about empty height value



