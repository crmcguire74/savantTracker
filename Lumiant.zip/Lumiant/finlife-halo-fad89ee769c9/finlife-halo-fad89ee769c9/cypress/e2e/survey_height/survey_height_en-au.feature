# Created by michaelmarturano at 24/4/2024
@en-au
Feature: survey_height_en-au
  user should be able to start a HALO survey
  and be able to add my height in centimetres


  Scenario Outline: enter a valid height
    Given user is a client and has completed survey before the height section
    When  user enters <height> height
    Then  user should proceed to the next survey question for height
    Examples:
      | height |
      | 26     |
      | 100    |


  Scenario Outline: enters a negative height
    Given user is a client and has completed survey before the height section
    When  user enters negative <height> height
    Then user should see a error message about invalid height value
    Examples:
        | height |
        | -26  |

    Scenario: enters a empty value
      Given user is a client and has completed survey before the height section
      When  user enters no input for height
      Then  user should see a error message about empty height value