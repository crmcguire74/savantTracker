import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
import {addGender, addHeightInFeetInches, addInput, startSurvey} from "../utils";
import {male} from "../constants/constants";


Given("user is a client and has completed survey before the height section", () => {
    startSurvey()
    addGender(male)
    addInput(25)
})

When("user enters \{int} \{int} height", (feet, inches) =>{
    addHeightInFeetInches(feet, inches)
})

When("user enters negative \{int} \{int} height", (feet, inches) => {
    addHeightInFeetInches(feet,inches)
})

When("user enters no input for height", ()=>{
    cy.contains("SUBMIT").click()
})

Then("user should see the next survey question for height", ()=>{
    cy.contains("How much do you weigh")
})

Then("user should see error message about invalid height value",()=>{
    cy.contains("Please enter valid height in feet and inches")
})

Then("user should see error message about empty height value", ()=>{
    cy.contains("Please enter your height in feet and inches")
})



