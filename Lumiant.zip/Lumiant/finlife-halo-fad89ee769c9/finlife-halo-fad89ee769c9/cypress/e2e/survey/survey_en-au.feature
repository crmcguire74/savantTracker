# Created by michaelmarturano at 26/4/2024
@en-au
Feature: survey_en-au
  user should be able to start HALO survey
  and complete it

  Scenario: complete full survey before submitting personal details
    Given user is a client and enters the HALO intro menu screen
    When  user enters all details except for personal credentials in the survey
    Then  user should see form to input personal credentials