# Created by michaelmarturano at 26/4/2024
@en-us
Feature: survey_en-us
  user should be able to start HALO survey
  and complete it

  Scenario: complete full survey before submitting personal credentials
    Given user is a client and enters the HALO intro menu screen
    When  user enters all details in the survey
    Then  user should see form to input personal credentials