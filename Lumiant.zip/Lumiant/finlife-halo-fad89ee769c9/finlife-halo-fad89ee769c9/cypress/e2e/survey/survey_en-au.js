import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
import {addGender, addInput, selectButton, startSurvey, startSurveyAU} from "../utils";
import {male, submitBtn} from "../constants/constants";

Given("user is a client and enters the HALO intro menu screen", () =>{
    startSurveyAU()
})


When("user enters all details except for personal credentials in the survey", () =>{
    addGender(male)
    addInput(26)
    addInput(170)
    addInput(85)
    selectButton(null, "Muscular")
    selectButton(null, "European")
    selectButton(null, "3 - 5")
    selectButton(null,"No")
    selectButton(null, "4")
    selectButton(null, "Heavy")
    // add emotional support
    selectButton(null, "Myself")
    cy.contains(submitBtn).click()

    selectButton(null,"3 - 5")
    selectButton(null,"No")
    selectButton(null,"No")
    selectButton(null,"None")
    selectButton(null, "None")
    selectButton(null,"None")
    // add retirement age
    cy.get("input").clear().type(70)
    cy.contains(submitBtn).click()

    // add retirement location
    cy.get("input").type("New South")
    cy.contains("New South Wales").click()
    cy.contains(submitBtn).click()

    selectButton(null, "3")
})


Then("user should see form to input personal credentials", () => {
    cy.log("add the credential slide")
})