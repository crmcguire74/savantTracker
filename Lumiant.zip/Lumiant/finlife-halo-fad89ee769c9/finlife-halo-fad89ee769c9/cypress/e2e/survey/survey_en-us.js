import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
import {
    addGender,
    addHeightInFeetInches,
    addInput,
    selectButton,
    startSurvey
} from "../utils";
import {male, submitBtn} from "../constants/constants";

Given("user is a client and enters the HALO intro menu screen", () => {
    startSurvey()
})



// why does an element cover muidialog content
When("user enters all details in the survey", () =>{
    addGender(male)
    addInput(27)
    addHeightInFeetInches(5,10)
    addInput(170)
    selectButton(null,"Muscular")
    selectButton(null,"European ancestry")
    selectButton(null,"3 - 5")
    selectButton(null, "No")
    selectButton(null, "4")
    selectButton(null,"Heavy")
    selectButton(null, "Myself")
    cy.contains(submitBtn).click()
    selectButton(null, "0 - 2")
    selectButton(null,"No")
    selectButton(null, "No")
    selectButton(null, "None")
    selectButton(null, "None")
    selectButton(null, "None")

    // add retirement age
    cy.get("input").clear().type(70)
    cy.contains(submitBtn).click()
    //add retirement location
    cy.get("input").type("Haw")
    cy.contains("Hawaii").click()
    cy.contains(submitBtn).click()
    selectButton(null,"3")
})


Then("user should see form to input personal credentials", () => {
    cy.contains("Congratulations on taking a big step towards planning for your future " +
        "health & wealth!")

})