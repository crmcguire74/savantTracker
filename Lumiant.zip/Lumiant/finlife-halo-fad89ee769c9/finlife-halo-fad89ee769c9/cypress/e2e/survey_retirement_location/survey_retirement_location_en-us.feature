# Created by michaelmarturano at 29/4/2024

  @en-us
Feature: survey_retirement_location_en-us
  user should be able to start a HALO survey
  and be able to enter retirement location

  Scenario Outline: enters a valid location
    Given user is a client and has completed survey before the retirement location section
    When user types in part <partialState> of the name of a state
    And  user clicks on <state> a autocomplete option
    Then user should proceed to the next survey question

    Examples:
    |partialState     | state         |
    |    "Haw"        | "Hawaii"      |

    Scenario Outline: enters a invalid location
      Given user is a client and has completed survey before the retirement location section
      When  user only types in part <partialState> of the name of a state and proceeds
      Then  user should see an error message about retirement location
      Examples:
      |partialState |
      | "Haw"       |

  Scenario: enters an empty location
    Given user is a client and has completed survey before the retirement location section
    When  user enters no input for retirement location
    Then  user should see an error message about retirement location