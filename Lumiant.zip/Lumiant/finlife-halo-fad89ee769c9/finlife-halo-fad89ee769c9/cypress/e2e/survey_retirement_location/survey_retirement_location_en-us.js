import {Given, Then, When} from "@badeball/cypress-cucumber-preprocessor";
import {
    addGender,
    addHeightInFeetInches,
    addInput,
    checkErrorMsg,
    checkSurveyQuestion,
    selectButton,
    startSurvey
} from "../utils";
import {male, submitBtn} from "../constants/constants";
import {longevityQuestion} from "../constants/questionTitleLarge";
import {errRetirementLocationUS} from "../constants/errorMsg";


Given("user is a client and has completed survey before the retirement location section",() =>{
    startSurvey()
    addGender(male)
    addInput(26)
    addHeightInFeetInches(5,1)
    addInput(85)

    selectButton(null,"Muscular")
    selectButton(null, "European ancestry")
    selectButton(null, "3 - 5")
    selectButton(null, "No")
    selectButton(null, "4")
    selectButton(null, "Heavy")
    selectButton(null, "Myself")
    cy.contains(submitBtn).click()
    selectButton(null,"3 - 5")
    selectButton(null, "No")
    selectButton(null, "No")
    selectButton(null, "None")
    selectButton(null, "None")
    selectButton(null, "None")
    cy.get("input ").clear().type(70)
    cy.contains(submitBtn).click()
})


When("user types in part \{string} of the name of a state", (partialState) =>{
    cy.get("input").type(partialState)
})

When("user only types in part \{string} of the name of a state and proceeds", (partialState) =>{
        cy.get("input").type(partialState)
        cy.contains(submitBtn).click()

})

When("user clicks on \{string} a autocomplete option", (state)=>{
    cy.contains(state).click()
    cy.contains(submitBtn).click()
})

When("user enters no input for retirement location", ()=>{
    cy.contains(submitBtn).click()
})


Then("user should proceed to the next survey question", ()=> {
    checkSurveyQuestion(longevityQuestion, true)
})

Then("user should see an error message about retirement location", () =>{
    //checkErrorMsg(errRetirementLocationUS)
    cy.contains(errRetirementLocationUS)
})