# Created by michaelmarturano at 23/4/2024
  @en-us
  @en-au
Feature: survey_age
  user should be able to start HALO survey
  and should be able to add in age

  Scenario: users enters valid age
    Given user is a client and has completed survey before the age section
    When user enters a age input
    Then user should see the next survey question for age


# TODO complete remaining scenarios
  # Scenario: user enters a empty age value
  # Scenario: user enters a negative age value
  # Scenario: user enters a really large age value
  # Scenario: use enters a non int age value