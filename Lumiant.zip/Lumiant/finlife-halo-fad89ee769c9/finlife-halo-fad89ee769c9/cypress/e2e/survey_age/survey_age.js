import {Given, When, Before,Then} from "@badeball/cypress-cucumber-preprocessor";
import {addGender, addInput, startSurvey} from "../utils";
import {male} from "../constants/constants";

Given("user is a client and has completed survey before the age section", ()=>{
    startSurvey()
    addGender(male)
})
When("user enters a age input", ()=>{
    addInput(25)
})

Then("user should see the next survey question for age", ()=>{
    cy.contains("What is your height?")
    cy.contains("Tip-Toes and High Heels don't count")
})






