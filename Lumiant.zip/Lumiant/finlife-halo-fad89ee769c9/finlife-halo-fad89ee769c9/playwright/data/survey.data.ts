export type Gender = 'Male' | 'Female';
export type Height = { feet?: number; inches?: number; centimeters?: number };
export type BodyShape = 'Slim' | 'Athletic' | 'Muscular' | 'Oval';
export type Ethnicity = 'European' | 'African' | 'Asian' | 'Hispanic' | 'Other' | 'Middle Eastern' | 'Indian';
export type SmokingStatus = 'No' | 'Yes' | 'Former';
export type SmokingType = 'Cigarettes' | 'Cigars' | 'Both';
export type CigaretteConsumption = 'Occasionally' | '< 10' | '10 - 19' | 'Over 20';
export type CigarConsumption = 'Occasionally' | '1 - 2' | '3 - 4' | '5 or more';
export type SmokingQuitAge = 'Before age 35' | 'Before age 45' | 'After age 45';
export type FruitVegetableIntake = '3 or fewer' | '4' | '5 - 6' | '7 or more';
export type DrinkingFrequency = 'None' | 'Moderate' | 'Heavy';
export type EmotionalSupport = ('Myself' | 'Spouse' | 'Family' | 'Friends')[];
export type DoctorVisitFrequency = '0 - 2' | '3 - 5' | '6 +';
export type CancerHistory = 'No' | 'Yes';
export type CancerType = (
  | 'Bladder'
  | 'Breast'
  | 'Colorectal'
  | 'Kidney'
  | 'Lung'
  | 'Ovarian'
  | 'Pancreatic'
  | 'Prostate'
  | 'Skin'
  | 'Other'
)[];
export type FamilyHistory = 'No' | 'Yes';
export type MedicalHistory = 'None' | 'Myself' | 'Family' | 'Both';
export type FamilyLongevity = 'None' | '1' | '2' | '3' | '4' | '5' | '6';
export type PersonalDetails = {
  firstName: string;
  lastName: string;
  email: string;
  advisor: string;
};

export type SurveyData = {
  basicInformation: {
    gender: Gender;
    age: number;
    height: Height;
    weight: number;
    unit: 'Kilogram' | 'Pound';
  };
  lifestyle: {
    bodyShape: BodyShape;
    ethnicity: Ethnicity;
    exercise: number;
  };
  smoking: {
    smokingStatus: SmokingStatus;
    smokingType: SmokingType;
    cigaretteConsumption: CigaretteConsumption;
    cigarConsumption: CigarConsumption;
    smokingQuitAge: SmokingQuitAge;
  };
  eatingAndDrinking: {
    fruitVegetableIntake: FruitVegetableIntake;
    drinkingFrequency: DrinkingFrequency;
    emotionalSupport: EmotionalSupport;
  };
  medicalHistory: {
    doctorVisitFrequency: DoctorVisitFrequency;
    familyCancerHistory: CancerHistory;
    cancerTypes: CancerType;
    familyAlzheimerHistory: FamilyHistory;
    familyDiabetesHistory: MedicalHistory;
    familyHeartDiseaseHistory: MedicalHistory;
    familyStrokeHistory: MedicalHistory;
  };
  retirement: {
    expectedRetirementAge: number;
    retirementState: string;
    familyLongevity: FamilyLongevity;
  };
  personalDetails: PersonalDetails;
};

const baseData = {
  basicInformation: {
    gender: 'Male',
    age: 50,
    weight: 60,
  },
  lifestyle: {
    bodyShape: 'Slim',
    ethnicity: 'African',
    exercise: 0,
  },
  eatingAndDrinking: {
    fruitVegetableIntake: '7 or more',
    drinkingFrequency: 'Heavy',
    emotionalSupport: ['Myself', 'Family'],
  },
  medicalHistory: {
    doctorVisitFrequency: '0 - 2',
    familyCancerHistory: 'No',
    cancerTypes: [],
    familyAlzheimerHistory: 'No',
    familyDiabetesHistory: 'None',
    familyHeartDiseaseHistory: 'None',
    familyStrokeHistory: 'None',
  },
  retirement: {
    familyLongevity: '6',
  },
  personalDetails: {
    firstName: 'John',
    lastName: 'Doe',
    email: 'johnDoe2024@lumiant.io',
    advisor: 'Heather Holmes',
  },
};

const localeSpecificData = {
  au: {
    basicInformation: {
      height: { centimeters: 170 },
      weight: 60,
      unit: 'Kilogram',
    },
    personalDetails: {
      advisor: 'Playwright test',
    },
    retirement: {
      expectedRetirementAge: 45,
      retirementState: 'New South Wales',
    },
  },
  us: {
    basicInformation: {
      height: { feet: 5, inches: 10 },
      weight: 75,
      unit: 'Pound',
    },
    personalDetails: {
      advisor: 'Nicola Perry',
    },
    retirement: {
      expectedRetirementAge: 55,
      retirementState: 'Hawaii',
    },
  },
};

const scenarioVariations = {
  nonSmoker: {
    smoking: {
      smokingStatus: 'No',
      smokingType: 'Both',
      cigaretteConsumption: 'Over 20',
      cigarConsumption: '5 or more',
      smokingQuitAge: 'After age 45',
    },
  },
  currentSmokerWithCancer: {
    smoking: {
      smokingStatus: 'Yes',
      smokingType: 'Cigarettes',
      cigaretteConsumption: 'Over 20',
      cigarConsumption: 'Occasionally',
      smokingQuitAge: 'After age 45',
    },
    medicalHistory: {
      doctorVisitFrequency: '3 - 5',
      familyCancerHistory: 'Yes',
      cancerTypes: ['Bladder', 'Breast'],
      familyAlzheimerHistory: 'Yes',
      familyDiabetesHistory: 'Both',
      familyHeartDiseaseHistory: 'Both',
      familyStrokeHistory: 'Both',
    },
  },
  currentSmokerNoCancer: {
    smoking: {
      smokingStatus: 'Yes',
      smokingType: 'Cigarettes',
      cigaretteConsumption: 'Over 20',
      cigarConsumption: 'Occasionally',
      smokingQuitAge: 'After age 45',
    },
  },
  formerSmokerWithCancer: {
    smoking: {
      smokingStatus: 'Former',
      smokingType: 'Both',
      cigaretteConsumption: 'Over 20',
      cigarConsumption: '5 or more',
      smokingQuitAge: 'Before age 45',
    },
    medicalHistory: {
      doctorVisitFrequency: '0 - 2',
      familyCancerHistory: 'Yes',
      cancerTypes: ['Skin', 'Lung'],
      familyAlzheimerHistory: 'Yes',
      familyDiabetesHistory: 'Family',
      familyHeartDiseaseHistory: 'Myself',
      familyStrokeHistory: 'Myself',
    },
  },
  formerSmokerNoCancer: {
    smoking: {
      smokingStatus: 'Former',
      smokingType: 'Both',
      cigaretteConsumption: 'Over 20',
      cigarConsumption: '5 or more',
      smokingQuitAge: 'Before age 45',
    },
  },
};

/**
 * Retrieves test survey data for a specific locale and variant.
 * Combines base data with locale-specific data and scenario variations.
 *
 * @param {string} locale - The locale for which to retrieve survey data ('au' or 'us')
 * @param {string} [variant='1'] - The variant number for scenario-specific data:
 *                                 '1' - Non-smoker
 *                                 '2' - Current smoker with cancer
 *                                 '3' - Current smoker without cancer
 *                                 '4' - Former smoker with cancer
 *                                 '5' - Former smoker without cancer
 * @returns {Promise<SurveyData>} A promise that resolves to the complete test survey data
 * @throws {Error} If locale data is not found for the specified locale
 */
export function testData(locale: string, variant: string = '1'): Promise<SurveyData> {
  const localeData = localeSpecificData[locale];

  if (!localeData) {
    throw new Error(`Locale data not found for: ${locale}`);
  }

  const data = {
    ...baseData,
    basicInformation: {
      ...baseData.basicInformation,
      ...localeData.basicInformation,
    },
    retirement: {
      ...baseData.retirement,
      ...localeData.retirement,
    },
    personalDetails: {
      ...baseData.personalDetails,
      ...localeData.personalDetails,
    },
    ...scenarioVariations[getScenarioKey(variant)],
  } as SurveyData;

  return Promise.resolve(data);
}

function getScenarioKey(variant: string): keyof typeof scenarioVariations {
  const scenarioMap = {
    '1': 'nonSmoker',
    '2': 'currentSmokerWithCancer',
    '3': 'currentSmokerNoCancer',
    '4': 'formerSmokerWithCancer',
    '5': 'formerSmokerNoCancer',
  };

  return scenarioMap[variant] as keyof typeof scenarioVariations;
}
