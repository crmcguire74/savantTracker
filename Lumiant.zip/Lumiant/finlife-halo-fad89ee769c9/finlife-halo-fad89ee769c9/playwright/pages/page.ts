import { Page } from '@playwright/test';
import { IntroPage } from './intro';
import { SurveyPage } from './survey';

export class HaloPage {
  readonly introPage: IntroPage;
  readonly surveyPage: SurveyPage;
  readonly locale: string;

  constructor(readonly page: Page) {
    this.introPage = new IntroPage(page);
    this.surveyPage = new SurveyPage(page);
  }
}
