import { type Locator, type Page, expect } from '@playwright/test';
import {
  Gender,
  Height,
  BodyShape,
  Ethnicity,
  SmokingStatus,
  SmokingType,
  CigaretteConsumption,
  CigarConsumption,
  SmokingQuitAge,
  FruitVegetableIntake,
  DrinkingFrequency,
  EmotionalSupport,
  DoctorVisitFrequency,
  CancerHistory,
  CancerType,
  FamilyHistory,
  MedicalHistory,
  FamilyLongevity,
  PersonalDetails,
  SurveyData,
} from '../data/survey.data';

export class SurveyPage {
  readonly page: Page;
  readonly headerLogo: Locator;
  readonly takeTheAssessmentBtn: Locator;
  readonly submitBtn: Locator;
  readonly nextBtn: Locator;
  readonly prevBtn: Locator;
  readonly seeResultBtn: Locator;
  readonly surveyModal: Locator;
  readonly surveyHeading: Locator;

  constructor(page: Page) {
    this.page = page;
    this.headerLogo = page.getByRole('img', { name: 'Halo Logo' });
    this.takeTheAssessmentBtn = page.locator('#take_the_assessment');
    this.submitBtn = page.getByRole('button', { name: 'SUBMIT' });
    this.nextBtn = page.getByRole('button', { name: 'NEXT' });
    this.prevBtn = page.getByRole('button', { name: 'PREV' });
    this.seeResultBtn = page.getByRole('button', { name: ' SEE RESULTS' });
    this.surveyModal = page.locator('#gcModal');
    this.surveyHeading = page.locator('.gQuestionLarge');
  }

  async submitSurvey() {
    const currentQuestion = await this.surveyHeading.innerText();
    await this.submitBtn.click();
    await expect(
      this.surveyHeading,
      `Failed to progress to next question. Remained on '${currentQuestion}'`
    ).not.toHaveText(currentQuestion);
  }

  async selectGenderOption(gender: Gender) {
    const locator = gender === 'Male' ? '#icon_male' : '#icon_female';
    await this.page.locator(locator).click({ timeout: 15_000 });

    const yellowCircle = this.page.locator('.gCircle').locator('..');
    const genderText = yellowCircle.getByText(gender.toLocaleUpperCase(), { exact: true });
    await expect(genderText, `Yellow circle did not appear next to selected gender: ${gender}.`).toBeVisible();
  }

  async enterAge(age: number) {
    const ageInput = age.toString();
    await this.page.getByPlaceholder('age').fill(ageInput);
  }

  async enterHeight(height: Height) {
    if (height.centimeters) {
      const centimeters = height.centimeters.toString();
      await this.page.getByPlaceholder('centimetres (cm)').fill(centimeters);
    } else if (height.feet) {
      const feet = height.feet.toString();
      const inches = height.inches?.toString() || '0';
      await this.page.getByPlaceholder('feet').fill(feet);
      await this.page.getByPlaceholder('inches').fill(inches);
    }
  }

  async enterWeight(answer: { weight: number; unit: 'Kilogram' | 'Pound' }) {
    const weightInput = answer.weight.toString();
    await this.page.getByPlaceholder(answer.unit).fill(weightInput);
  }

  async selectBodyShape(shape: BodyShape) {
    await this.page.getByRole('button', { name: shape }).click();
  }

  async selectEthnicity(ethnicity: Ethnicity) {
    await this.page.getByRole('button', { name: ethnicity }).click();
  }

  async setExerciseFrequency(exercises: number) {
    const option = exercises <= 2 ? '0 - 2' : exercises <= 5 ? '3 - 5' : '6+';
    await this.page.getByRole('button', { name: option }).click();
  }

  async setSmokingStatus(answer: SmokingStatus) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async selectSmokingType(answer: SmokingType) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async selectCigaretteConsumption(answer: CigaretteConsumption) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async selectCigarConsumption(answer: CigarConsumption) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async selectSmokingQuitAge(answer: SmokingQuitAge) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async selectFruitVegetableIntake(answer: FruitVegetableIntake) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async selectDrinkingFrequency(answer: DrinkingFrequency) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async selectEmotionalSupport(options: EmotionalSupport) {
    for (const item of options) {
      await this.page.getByRole('button', { name: item }).click();
    }
  }

  async selectDoctorVisitFrequency(answer: DoctorVisitFrequency) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async setFamilyCancerHistory(answer: CancerHistory) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async selectCancerType(options: CancerType) {
    if (options.length === 0) return;
    for (const item of options) {
      await this.page.getByRole('button', { name: item }).click();
    }
    await this.submitSurvey();
  }

  async setFamilyAlzheimerHistory(answer: FamilyHistory) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async setFamilyDiabetesHistory(answer: MedicalHistory) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async setFamilyHeartDiseaseHistory(answer: MedicalHistory) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async setFamilyStrokeHistory(answer: MedicalHistory) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async enterExpectedRetirementAge(age: number) {
    await this.page.getByRole('spinbutton').fill(age.toString());
  }

  async selectRetirementState(USstate: string) {
    const result = this.page.getByRole('menuitem', { name: USstate });

    await this.page.getByPlaceholder('state').click();
    await this.page.keyboard.type(USstate, { delay: 80 });
    await expect(result, `Could not find state: ${USstate}`).toBeVisible();
    await result.click();
  }

  async selectFamilyLongevity(answer: FamilyLongevity) {
    await this.page.getByRole('button', { name: answer }).click();
  }

  async fillPersonalDetails(answer: PersonalDetails) {
    await this.page.getByPlaceholder('First Name').fill(answer.firstName);
    await this.page.getByPlaceholder('Last Name').fill(answer.lastName);
    await this.page.getByPlaceholder('Email').fill(answer.email);
    await this.page.locator('div').filter({ hasText: /^Select Your Advisor$/ }).first().click();
    await this.page.keyboard.type(answer.advisor.split(' ')[0], { delay: 80 });
    await this.page.getByRole('option', { name: answer.advisor }).click();
  }

  async isSmokingQuitOptionDisabled(option: SmokingQuitAge): Promise<boolean> {
    return this.page.getByRole('button', { name: option }).isDisabled();
  }

  async selectOtherMixedEthnicity() {
    await this.page.getByRole('button', { name: 'Other/Mixed' }).click();
  }

  async enterEthnicityPercentage(hint: string, value: number) {
    await this.page.getByPlaceholder(hint).fill(value.toString());
  }

  async getValidationErrorMessage(): Promise<string> {
    const dialog = this.page.getByRole('alertdialog');
    await expect(dialog).toBeVisible({ timeout: 5_000 });
    return dialog.innerText();
  }

  async fillLifestyleInformation(surveyPage: SurveyPage, data: SurveyData) {
    await surveyPage.selectBodyShape(data.lifestyle.bodyShape);
    await surveyPage.selectEthnicity(data.lifestyle.ethnicity);
    await surveyPage.setExerciseFrequency(data.lifestyle.exercise);
  }

  async handleSmokingQuestions(data: SurveyData['smoking']) {
    const status = data.smokingStatus;
    const smokingType = data.smokingType;

    await this.setSmokingStatus(status);

    if (status !== 'No') {
      await this.selectSmokingType(smokingType);

      switch (smokingType) {
        case 'Cigarettes':
          await this.selectCigaretteConsumption(data.cigaretteConsumption);

          break;
        case 'Cigars':
          await this.selectCigarConsumption(data.cigarConsumption);
          break;
        case 'Both':
          await this.selectCigaretteConsumption(data.cigaretteConsumption);
          if (status === 'Former') await this.selectSmokingQuitAge(data.smokingQuitAge);
          await this.selectCigarConsumption(data.cigarConsumption);
          break;
      }
    }

    if (status === 'Former') await this.selectSmokingQuitAge(data.smokingQuitAge);
  }
}
