import { type Locator, type Page, expect } from '@playwright/test';

export class IntroPage {
  readonly page: Page;
  readonly headerLogo: Locator;
  readonly haloAssessmentBtn: Locator;
  readonly privacyPolicyBtn: Locator;
  readonly privacyPolicyLink: Locator;
  readonly disclaimerBtn: Locator;
  readonly pageBody: Locator;
  readonly surveyModal: Locator;

  constructor(page: Page) {
    this.page = page;
    this.headerLogo = page.locator('.topheader').getByRole('img');
    this.haloAssessmentBtn = page.getByText('Take the HALO Assessment', { exact: true });
    this.privacyPolicyBtn = page.getByRole('button', { name: 'Privacy Policy' });
    this.privacyPolicyLink = page.getByRole('link', { name: 'Privacy Policy' });
    this.disclaimerBtn = page.getByRole('button', { name: 'disclaimer' });
    this.pageBody = page.locator('body');
    this.surveyModal = page.locator('#gcmodal');
  }

  async navigateToIntroPage(locale: string) {
    await this.page.goto(`/advisor/test-org-${locale}`, { waitUntil: 'commit' });
    const responsePromise = this.page.waitForResponse(
      (response) =>
        response.url().includes('/api/v1/advisor?') &&
        response.status() === 200 &&
        response.request().method() === 'GET'
    );
    await responsePromise;
  }

  async clickTakeHaloAssessmentButton() {
    await this.haloAssessmentBtn.click();
    await expect(
      this.page.locator('#take_the_assessment'),
      'Take the Assessment button is not visible. Please check the page for any errors.'
    ).toBeVisible();
  }

  async assertSnapshot(locator: Locator, snapshot: string) {
    await expect(locator, 'Current page does not match the aria snapshot').toMatchAriaSnapshot(snapshot);
  }
}
