import { test as base, expect } from '@playwright/test';
import { HaloPage } from '../pages/page';

type HaloFixture = {
  halo: {
    page: HaloPage;
    locale: string;
  };
};

const halo = base.extend<HaloFixture>({
  halo: async ({ page }, use) => {
    const haloPage = new HaloPage(page);
    const locale = (
      await page.evaluate(() => navigator.language).then((locale) => locale.split('-')[1])
    ).toLocaleLowerCase();

    await haloPage.introPage.navigateToIntroPage(locale);
    await expect(haloPage.introPage.headerLogo, 'Timed out waiting for the header logo to be visible').toBeVisible({
      timeout: 10_000,
    });
    await use({ page: haloPage, locale: locale });
    await haloPage.page.close();
  },
});

export { halo, expect };
