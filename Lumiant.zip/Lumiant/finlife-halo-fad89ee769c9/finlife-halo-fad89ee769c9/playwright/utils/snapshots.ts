export const introPageAriaUS = `
      - img "HALO"
      - img "LOGO"
      - text: by Lumiant
      - paragraph: See the future, so we can plan for it.
      - paragraph: Life has unexpected events, that’s why it’s critical to consider potential health risks when developing a financial plan.
      - paragraph: "Health and wealth are closely knit together in financial planning. When creating your plan, get started by asking yourself the following questions:"
      - list:
        - listitem: How much could health care cost?
        - listitem: What are my options for paying for health care?
        - listitem: What are my projected health risks?
        - listitem: What’s my projected longevity?
      - paragraph: How HALO can help
      - img "HALO"
      - text: Longevity Planner by Lumiant
      - paragraph: "HALO by Lumiant is a health analysis and longevity optimizer that helps you:"
      - list:
        - listitem: Plan for your most active and healthy years in retirement.
        - listitem: Determine how many years of additional daily care (in-home care/ assisted living facilities) you may need and what the estimated costs could be.
        - listitem: Estimate out of pocket care costs throughout your lifespan and how those costs may change during your different life stages.
      - paragraph: Get Started
      - paragraph: What impact could your health have on your future wealth?
      - paragraph: "Take the HALO assessment to help you determine future health care costs. Note: This link will take you to Lumiant’s website to answer health and lifestyle questions in order to create a health care cost analyzes report. You will receive a summary, and the full report will be emailed directly to your Advisor, who will contact you to discuss the report and its effect on your financial plan."
      - img "Take the HALO Assessment"
      - text: Take the HALO Assessment
      - paragraph: Contact Us
      - paragraph: For more information or if you have questions, please contact me
      - text: /Michael \\d+ Chicago Ave test P:/
      - link /\\d+-\\d+-\\d+/
      - text: "E:"
      - link "michael.marturano@lumiant.io"
      - text: "W:"
      - link "lumiant.io"
      `;

export const IntroPageAriaAU = `
        - img "LOGO"
        - img "LOGO"
        - text: by Lumiant
        - paragraph: See the future, so we can plan for it.
        - paragraph: Life has unexpected events, that’s why it’s critical to consider potential health risks when developing a financial plan.
        - paragraph: "Health and wealth are closely knit together in financial planning. When creating your plan, get started by asking yourself the following questions:"
        - list:
          - listitem: What’s my projected longevity and how does living longer impact my financial plan?
          - listitem: What are my options for paying for aged care?
          - listitem: What are my projected health risks?
          - listitem: What’s my projected longevity?
        - paragraph: How HALO can help
        - img "HALO"
        - text: Longevity Planner by Lumiant
        - paragraph: "HALO by Lumiant is a health analysis and longevity optimiser that helps you:"
        - list:
          - listitem: Plan for your most active and healthy years in retirement.
          - listitem: Determine how many years of aged care you may need
          - listitem: Identify ways to potentially live longer and healthier
        - paragraph: Get Started
        - paragraph: What impact could your health have on your future wealth?
        - paragraph: "Take the HALO assessment to help you determine future health care costs. Note: This link will take you to Lumiant’s website to answer health and lifestyle questions in order to create a personalised analyses report. You will receive a summary, and the full report will be emailed directly to your Advisor, who will contact you to discuss the report and its effect on your financial plan."
        - img "Take the HALO Assessment"
        - text: Take the HALO Assessment
        - paragraph: Contact Us
        - paragraph: For more information or if you have questions, please contact me
        - text: /mike \\d+ Chicago Ave test P:/
        - link /\\d+-\\d+-\\d+/
        - text: "M:"
        - link /\\d+-\\d+-\\d+/
        - text: "E:"
        - link "adviser@lumiant.com.au"
        - text: "W:"
        - link "lumiant.io"
      `;

export const haloModalAria = `
      - img "Halo Logo"
      - text: Lumiant HALO Longevity Planner See the future, so we can plan for it. Health and longevity projections are critical to a healthy financial plan. Let's get them right, together. Take the Assessment
      - button "Privacy Policy"
      - button "Disclaimer"
      `;

export const selectGender = `
      - img "Halo Logo"
      - text
        - text: Lumiant HALO Longevity Planner What is your gender? Please click an option
      - figure "FEMALE":
        - img
        - text: FEMALE
      - figure "MALE":
        - img
        - text: MALE
      - button "SUBMIT"
      - text: "WHY IT MATTERS One area in which women have the upper hand is life expectancy. Women on average live 3 years longer than men. Source: Social Security Administration"
      - button "Prev"
      `;

export const enterAge = `
      - img "Halo Logo"
      - text: Lumiant HALO Longevity Planner How many candles will be on your birthday cake this year? (how old will you be?) Age
      - spinbutton "Age"
      - button "SUBMIT"
      - figure:
        - img
      - text: "WHY IT MATTERS More than half of Americans underestimate their life expectancy making their financial planning time horizons too short. Source: Society of Actuaries"
      - button "Prev"
      `;

export const enterHeight = `
      - img "Halo Logo"
      - text: Lumiant HALO Longevity Planner What is your height? Tip-Toes and High Heels don't count. Feet
      - spinbutton "Feet"
      - text: Inches
      - spinbutton "Inches"
      - button "SUBMIT"
      - figure:
        - img
      - text: WHY IT MATTERS Body Mass Index, or BMI, has a strong association with life expectancy and years of disability. We do the math for you by asking about your height and weight.
      - button "Prev"
      `;
