import { halo as test, expect } from '../utils/fixture';
import type { Page } from '@playwright/test';
import { SurveyData } from '../data/survey.data';
import { HaloPage } from '../pages/page';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

type HaloApiResult = { roundedLifespan: number };
type HaloApiResponse = { timeline: { roundedLifespan: number } };

// ─────────────────────────────────────────────────────────────────────────────
// Baseline neutral data builder (US locale, no positive lifestyle modifiers)
// ─────────────────────────────────────────────────────────────────────────────

function buildBaselineData(overrides: Partial<SurveyData> = {}): SurveyData {
  const base: SurveyData = {
    basicInformation: {
      gender: 'Male',
      age: 40,
      height: { feet: 5, inches: 7 }, // 170 cm equivalent, BMI depends on weight
      weight: 200,                     // ~31 BMI at 5'7" — no ideal-BMI bonus
      unit: 'Pound',
    },
    lifestyle: {
      bodyShape: 'Slim',
      ethnicity: 'African',            // partial match against "African ancestry" button
      exercise: 0,                     // maps to '0 - 2' — no exercise bonus
    },
    smoking: {
      smokingStatus: 'Yes',            // Current smoker — no smoke-free bonus
      smokingType: 'Cigarettes',
      cigaretteConsumption: 'Over 20',
      cigarConsumption: 'Occasionally',
      smokingQuitAge: 'After age 45',
    },
    eatingAndDrinking: {
      fruitVegetableIntake: '3 or fewer', // Insufficient — no fruit/veg bonus
      drinkingFrequency: 'Heavy',          // No moderate alcohol bonus
      emotionalSupport: ['Myself'],
    },
    medicalHistory: {
      doctorVisitFrequency: '0 - 2',
      familyCancerHistory: 'No',
      cancerTypes: [],
      familyAlzheimerHistory: 'No',
      familyDiabetesHistory: 'None',
      familyHeartDiseaseHistory: 'None',
      familyStrokeHistory: 'None',
    },
    retirement: {
      expectedRetirementAge: 65,
      retirementState: 'Hawaii',
      familyLongevity: '1',
    },
    personalDetails: {
      firstName: 'Test',
      lastName: 'User',
      email: 'testuser@lumiant.io',
      advisor: 'Nicola Perry',
    },
    ...overrides,
  };
  return base;
}

// ─────────────────────────────────────────────────────────────────────────────
// Helper: complete entire survey and return roundedLifespan from API response
// ─────────────────────────────────────────────────────────────────────────────

async function completeSurveyAndGetResult(
  haloPage: HaloPage,
  locale: string,
  data: SurveyData,
): Promise<HaloApiResult> {
  const { introPage, surveyPage } = haloPage;

  await introPage.navigateToIntroPage(locale);
  await expect(introPage.headerLogo).toBeVisible({ timeout: 10_000 });

  await introPage.clickTakeHaloAssessmentButton();
  await expect(surveyPage.takeTheAssessmentBtn).toBeVisible();
  await surveyPage.takeTheAssessmentBtn.click();
  await expect(surveyPage.takeTheAssessmentBtn).toBeHidden();

  // Basic Information
  await surveyPage.selectGenderOption(data.basicInformation.gender);
  await surveyPage.submitSurvey();
  await surveyPage.enterAge(data.basicInformation.age);
  await surveyPage.submitSurvey();
  await surveyPage.enterHeight(data.basicInformation.height);
  await surveyPage.submitSurvey();
  await surveyPage.enterWeight({ weight: data.basicInformation.weight, unit: data.basicInformation.unit });
  await surveyPage.submitSurvey();

  // Lifestyle
  await surveyPage.selectBodyShape(data.lifestyle.bodyShape);
  await surveyPage.selectEthnicity(data.lifestyle.ethnicity);
  await surveyPage.setExerciseFrequency(data.lifestyle.exercise);

  // Smoking
  await surveyPage.handleSmokingQuestions(data.smoking);

  // Eating & Drinking
  await surveyPage.selectFruitVegetableIntake(data.eatingAndDrinking.fruitVegetableIntake);
  await surveyPage.selectDrinkingFrequency(data.eatingAndDrinking.drinkingFrequency);
  await surveyPage.selectEmotionalSupport(data.eatingAndDrinking.emotionalSupport);
  await surveyPage.submitSurvey();

  // Medical History
  await surveyPage.selectDoctorVisitFrequency(data.medicalHistory.doctorVisitFrequency);
  await surveyPage.setFamilyCancerHistory(data.medicalHistory.familyCancerHistory);
  await surveyPage.selectCancerType(data.medicalHistory.cancerTypes);
  await surveyPage.setFamilyAlzheimerHistory(data.medicalHistory.familyAlzheimerHistory);
  await surveyPage.setFamilyDiabetesHistory(data.medicalHistory.familyDiabetesHistory);
  await surveyPage.setFamilyHeartDiseaseHistory(data.medicalHistory.familyHeartDiseaseHistory);
  await surveyPage.setFamilyStrokeHistory(data.medicalHistory.familyStrokeHistory);

  // Retirement
  await surveyPage.enterExpectedRetirementAge(data.retirement.expectedRetirementAge);
  await surveyPage.submitSurvey();
  await surveyPage.selectRetirementState(data.retirement.retirementState);
  await surveyPage.submitSurvey();
  await surveyPage.selectFamilyLongevity(data.retirement.familyLongevity);

  // Personal Details
  await surveyPage.fillPersonalDetails(data.personalDetails);

  // Intercept the final /api/v1/halo POST response (set up BEFORE clicking SEE RESULTS)
  const responsePromise = surveyPage.page.waitForResponse(
    (resp) => resp.url().includes('/api/v1/halo') && resp.request().method() === 'POST',
  );
  await surveyPage.seeResultBtn.click();
  const response = await responsePromise;
  const json: HaloApiResponse = await response.json();

  return { roundedLifespan: json.timeline.roundedLifespan };
}

// ─────────────────────────────────────────────────────────────────────────────
// UI helpers for results-page checkbox interactions
// ─────────────────────────────────────────────────────────────────────────────

async function dismissJoyride(page: Page) {
  const skipBtn = page.locator('[data-action="skip"]');
  if (await skipBtn.isVisible()) {
    await skipBtn.click();
  }
}

// Returns the current value of the active-retirement years bar
async function getBarValue(page: Page): Promise<number> {
  return parseInt((await page.locator('.gTRetireYearsBar').first().textContent()) ?? '0');
}

// Returns the "X YEARS" lost counter — this reflects |yearsLostAdjustment| exactly,
// regardless of how disability years shift. Use this for factors where the bar
// (postRetirementActiveYears) absorbs only part of the longevity gain.
async function getLostYearsValue(page: Page): Promise<number> {
  const el = page.locator('.gTYearsLostActive').first();
  const text = await el.textContent() ?? '0 YEARS';
  return parseInt(text) || 0;
}

// Clicks a checkbox and returns the reduction in the YEARS LOST counter
async function clickCheckboxAndGetLostYearsDelta(page: Page, labelText: string): Promise<number> {
  await dismissJoyride(page);
  const before = await getLostYearsValue(page);
  await page.locator('label').filter({ hasText: labelText }).locator('img.uncheckCircle').click();
  const after = await getLostYearsValue(page);
  return before - after;
}

// ─────────────────────────────────────────────────────────────────────────────
// Skip AU project — advisor "Playwright test" is currently unavailable in dev
// ─────────────────────────────────────────────────────────────────────────────

test.beforeEach(({ halo }) => {
  test.skip(halo.locale === 'au', 'Longevity tests run on US locale only (AU advisor unavailable)');
});

// ─────────────────────────────────────────────────────────────────────────────
// Gender scenarios
// ─────────────────────────────────────────────────────────────────────────────

test(
  'Female life expectancy is 3 years greater than male with identical inputs @regression @P1',
  async ({ halo }) => {
    const page = halo.page.surveyPage.page;

    // Neutral inputs: no smoking, no alcohol, no exercise, non-ideal BMI — no positive or negative lifestyle modifiers.
    // Only gender differs between the two surveys.
    const neutralBase = {
      basicInformation: { age: 40, height: { feet: 5, inches: 7 } as const, weight: 200, unit: 'Pound' as const },
      smoking: { smokingStatus: 'No' as const, smokingType: 'Cigarettes' as const, cigaretteConsumption: 'Over 20' as const, cigarConsumption: 'Occasionally' as const, smokingQuitAge: 'After age 45' as const },
      eatingAndDrinking: { fruitVegetableIntake: '3 or fewer' as const, drinkingFrequency: 'None' as const, emotionalSupport: ['Myself'] as const },
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    };

    const maleData = buildBaselineData({ ...neutralBase, basicInformation: { gender: 'Male', ...neutralBase.basicInformation } });
    await completeSurveyAndGetResult(halo.page, halo.locale, maleData);
    await dismissJoyride(page);
    const maleLifespan = parseInt(await page.locator('#adjustedLifespan').first().textContent() ?? '0');

    const femaleData = buildBaselineData({ ...neutralBase, basicInformation: { gender: 'Female', ...neutralBase.basicInformation } });
    await completeSurveyAndGetResult(halo.page, halo.locale, femaleData);
    await dismissJoyride(page);
    const femaleLifespan = parseInt(await page.locator('#adjustedLifespan').first().textContent() ?? '0');

    expect(
      femaleLifespan - maleLifespan,
      'Female adjusted lifespan should be exactly 3 years greater than male with identical inputs',
    ).toBe(3);
  },
);

test(
  'Gender difference remains constant regardless of lifestyle @regression @P1',
  async ({ halo }) => {
    const page = halo.page.surveyPage.page;

    // Same base inputs as test 1 (200lbs, 5'7", None drinking), with healthy lifestyle applied.
    // Only gender differs between the two surveys — isolates the gender contribution.
    const healthyBase = {
      basicInformation: { age: 40, height: { feet: 5, inches: 7 } as const, weight: 200, unit: 'Pound' as const },
      lifestyle: { bodyShape: 'Slim' as const, ethnicity: 'African' as const, exercise: 4 },
      eatingAndDrinking: {
        fruitVegetableIntake: '5 - 6' as const,
        drinkingFrequency: 'None' as const,
        emotionalSupport: ['Myself'] as const,
      },
      smoking: {
        smokingStatus: 'No' as const,
        smokingType: 'Cigarettes' as const,
        cigaretteConsumption: 'Over 20' as const,
        cigarConsumption: 'Occasionally' as const,
        smokingQuitAge: 'After age 45' as const,
      },
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    };

    // Complete as Male (healthy lifestyle, 200lbs base)
    const maleData = buildBaselineData({
      ...healthyBase,
      basicInformation: { gender: 'Male', ...healthyBase.basicInformation },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, maleData);
    await dismissJoyride(page);
    const maleLifespan = parseInt(await page.locator('#adjustedLifespan').first().textContent() ?? '0');

    // Complete as Female (identical inputs, only gender differs)
    const femaleData = buildBaselineData({
      ...healthyBase,
      basicInformation: { gender: 'Female', ...healthyBase.basicInformation },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, femaleData);
    await dismissJoyride(page);
    const femaleLifespan = parseInt(await page.locator('#adjustedLifespan').first().textContent() ?? '0');

    expect(
      femaleLifespan - maleLifespan,
      'Gender difference of 3 years should be consistent regardless of lifestyle choices',
    ).toBe(3);
  },
);

// ─────────────────────────────────────────────────────────────────────────────
// Alcohol scenarios
// ─────────────────────────────────────────────────────────────────────────────

test(
  'Moderate alcohol consumption increases longevity by 5 years @regression @P1',
  async ({ halo }) => {
    // Complete as heavy drinker — "Moderate alcohol consumption" checkbox will be enabled
    const heavyData = buildBaselineData({
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, heavyData);

    const page = halo.page.surveyPage.page;
    // Use the YEARS LOST counter: it tracks |yearsLostAdjustment| exactly per factor,
    // unlike the retirement bar which can be offset by disability-year adjustments.
    const delta = await clickCheckboxAndGetLostYearsDelta(page, 'Moderate alcohol consumption');

    expect(
      delta,
      'Clicking Moderate alcohol consumption should reduce the years-lost counter by exactly 5',
    ).toBe(5);
  },
);

test(
  'Heavy alcohol consumption does not apply moderate bonus @regression @P1',
  async ({ halo }) => {
    // Complete as heavy drinker — the checkbox should be enabled (no bonus applied yet)
    const heavyData = buildBaselineData({
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, heavyData);

    const page = halo.page.surveyPage.page;
    await dismissJoyride(page);

    await expect(
      page.locator('label').filter({ hasText: 'Moderate alcohol consumption' }).locator('img.uncheckCircle.enabledCheck'),
      'Heavy drinker should not have the moderate alcohol bonus applied — checkbox must be enabled',
    ).toBeVisible();
  },
);

// ─────────────────────────────────────────────────────────────────────────────
// Fruits & Vegetables scenario
// ─────────────────────────────────────────────────────────────────────────────

test(
  'Sufficient fruits and vegetables increase longevity by 1 year @regression @P1',
  async ({ halo }) => {
    // Complete with insufficient intake — "Sufficient fruits & vegetables" checkbox will be enabled
    const insufficientData = buildBaselineData({
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, insufficientData);

    const page = halo.page.surveyPage.page;
    const delta = await clickCheckboxAndGetLostYearsDelta(page, 'Sufficient fruits & vegetables');

    expect(
      delta,
      'Clicking Sufficient fruits & vegetables should reduce the years-lost counter by exactly 1',
    ).toBe(1);
  },
);

// ─────────────────────────────────────────────────────────────────────────────
// BMI scenarios
// ─────────────────────────────────────────────────────────────────────────────

test(
  'Ideal BMI increases longevity by 7 years @regression @P1',
  async ({ halo }) => {
    // 5'7", 115 lbs, Slim body shape → BMI ≈ 18.0 (underweight) — below the app's ideal lower
    // bound, so the "Ideal BMI for longevity" checkbox is enabled (person does not have the benefit).
    // NOTE: The app normalises BMI for body type; Slim at weights ≥ 155 lbs falls within the
    // ideal range and disables the checkbox. 115 lbs is the confirmed weight that gives the 7-year contribution.
    const lowBmiData = buildBaselineData({
      basicInformation: { gender: 'Male', age: 40, height: { feet: 5, inches: 7 }, weight: 115, unit: 'Pound' },
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, lowBmiData);

    const page = halo.page.surveyPage.page;
    const delta = await clickCheckboxAndGetLostYearsDelta(page, 'Ideal BMI for longevity');

    expect(
      delta,
      'Clicking Ideal BMI for longevity should reduce the years-lost counter by exactly 7',
    ).toBe(7);
  },
);

test(
  'BMI boundary values are included in ideal range @regression @P1',
  async ({ halo }) => {
    // Non-ideal baseline: 5'7", 115 lbs, Slim — below the ideal lower bound, gains 7 years when moved to ideal.
    // Lower boundary: 155 lbs — confirmed within the app's ideal range for Slim at 5'7".
    // Upper boundary: 178 lbs — confirmed within the app's ideal range for Slim at 5'7".
    // Both boundary weights should produce exactly 7 more adjusted-lifespan years than the non-ideal baseline.
    const page = halo.page.surveyPage.page;

    const nonIdealData = buildBaselineData({
      basicInformation: { gender: 'Male', age: 40, height: { feet: 5, inches: 7 }, weight: 115, unit: 'Pound' },
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, nonIdealData);
    await dismissJoyride(page);
    const nonIdealLifespan = parseInt(await page.locator('#adjustedLifespan').first().textContent() ?? '0');

    const lowerBoundData = buildBaselineData({
      basicInformation: { gender: 'Male', age: 40, height: { feet: 5, inches: 7 }, weight: 155, unit: 'Pound' },
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, lowerBoundData);
    await dismissJoyride(page);
    const lowerBoundLifespan = parseInt(await page.locator('#adjustedLifespan').first().textContent() ?? '0');

    const upperBoundData = buildBaselineData({
      basicInformation: { gender: 'Male', age: 40, height: { feet: 5, inches: 7 }, weight: 178, unit: 'Pound' },
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, upperBoundData);
    await dismissJoyride(page);
    const upperBoundLifespan = parseInt(await page.locator('#adjustedLifespan').first().textContent() ?? '0');

    expect(
      lowerBoundLifespan - nonIdealLifespan,
      'A client at the lower BMI boundary (155 lbs, Slim, 5\'7") should gain exactly 7 years versus non-ideal BMI',
    ).toBe(7);
    expect(
      upperBoundLifespan - nonIdealLifespan,
      'A client at the upper BMI boundary (178 lbs, Slim, 5\'7") should gain exactly 7 years versus non-ideal BMI',
    ).toBe(7);
  },
);

// ─────────────────────────────────────────────────────────────────────────────
// Exercise scenario
// ─────────────────────────────────────────────────────────────────────────────

test(
  'Regular exercise increases longevity by 3 years @regression @P1',
  async ({ halo }) => {
    // Complete as sedentary — "Regular exercise" checkbox will be enabled
    // NOTE: Exercise adds 3 years to total lifespan but also changes disability-year adjustments,
    // so the retirement bar may show 0 delta. The YEARS LOST counter reflects the exact 3-year contribution.
    const sedentaryData = buildBaselineData({
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, sedentaryData);

    const page = halo.page.surveyPage.page;
    const delta = await clickCheckboxAndGetLostYearsDelta(page, 'Regular exercise');

    expect(
      delta,
      'Clicking Regular exercise should reduce the years-lost counter by exactly 3',
    ).toBe(3);
  },
);

// ─────────────────────────────────────────────────────────────────────────────
// Smoking scenarios
// ─────────────────────────────────────────────────────────────────────────────

test(
  'Smoke-free life increases longevity by 8 years @regression @P1',
  async ({ halo }) => {
    // Complete as current smoker — the smoke-free checkbox is only interactive for smokers
    // familyLongevity 'None' isolates the pure smoke-free contribution (avoids the +1 family longevity interaction)
    const smokerData = buildBaselineData({
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, smokerData);

    const page = halo.page.surveyPage.page;

    // Read the initial active retirement years bar value
    const initialBar = parseInt(await page.locator('.gTRetireYearsBar').first().textContent() ?? '0');

    // Dismiss the react-joyride tutorial if present
    const skipBtn = page.locator('[data-action="skip"]');
    if (await skipBtn.isVisible()) {
      await skipBtn.click();
    }

    // Click the Smoke-free life checkbox
    await page.locator('label').filter({ hasText: 'Smoke-free life' }).locator('img.uncheckCircle').click();

    // Read the updated bar value
    const newBar = parseInt(await page.locator('.gTRetireYearsBar').first().textContent() ?? '0');

    expect(
      newBar - initialBar,
      'Clicking Smoke-free life should add exactly 8 years to the active retirement bar',
    ).toBe(8);
  },
);

test(
  'Current smoker does not receive smoke-free bonus @regression @P1',
  async ({ halo }) => {
    // Complete as current smoker — checkbox is enabled (bonus not yet applied, they can gain it)
    const currentSmokerData = buildBaselineData({
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, currentSmokerData);

    const page = halo.page.surveyPage.page;
    await dismissJoyride(page);

    await expect(
      page.locator('label').filter({ hasText: 'Smoke-free life' }).locator('img.uncheckCircle.enabledCheck'),
      'Current smoker should not have the smoke-free bonus applied — checkbox must be enabled',
    ).toBeVisible();
  },
);

test(
  'Former smoker does not stack smoke-free bonus @regression @P1',
  async ({ halo }) => {
    // Complete as former smoker — checkbox is disabled (cannot stack additional smoke-free bonus)
    const formerSmokerData = buildBaselineData({
      smoking: {
        smokingStatus: 'Former',
        smokingType: 'Cigarettes',
        cigaretteConsumption: 'Over 20',
        cigarConsumption: 'Occasionally',
        smokingQuitAge: 'Before age 35',
      },
      retirement: { expectedRetirementAge: 65, retirementState: 'Hawaii', familyLongevity: 'None' },
    });
    await completeSurveyAndGetResult(halo.page, halo.locale, formerSmokerData);

    const page = halo.page.surveyPage.page;
    await dismissJoyride(page);

    await expect(
      page.locator('label').filter({ hasText: 'Smoke-free life' }).locator('img.uncheckCircle.enabledCheck'),
      'Former smoker should not have an interactive smoke-free checkbox — bonus cannot be stacked',
    ).not.toBeVisible();
  },
);

// ─────────────────────────────────────────────────────────────────────────────
// Cumulative & baseline scenarios
// ─────────────────────────────────────────────────────────────────────────────

test(
  'Maximum healthy lifestyle cumulative calculation @regression @P1',
  async ({ halo }) => {
    // Baseline: male, all negative modifiers — Oval body shape ensures obese BMI classification
    const baselineData = buildBaselineData({
      lifestyle: { bodyShape: 'Oval', ethnicity: 'African', exercise: 0 },
    });

    // All positive modifiers: female, moderate alcohol (+5), sufficient fruit/veg (+1),
    // ideal BMI (+7, weight 155 lbs = BMI 24.3 within app range 21–28), regular exercise (+3),
    // never smoked (+8 smoke-free bonus)
    const allPositiveData = buildBaselineData({
      basicInformation: {
        gender: 'Female',
        age: 40,
        height: { feet: 5, inches: 7 },
        weight: 155, // BMI ≈ 24.3, within app ideal range 21–28
        unit: 'Pound',
      },
      lifestyle: { bodyShape: 'Slim', ethnicity: 'African', exercise: 4 }, // regular: 3-5
      smoking: { smokingStatus: 'No', smokingType: 'Cigarettes', cigaretteConsumption: 'Occasionally', cigarConsumption: 'Occasionally', smokingQuitAge: 'After age 45' },
      eatingAndDrinking: {
        fruitVegetableIntake: '5 - 6',  // sufficient: +1
        drinkingFrequency: 'Moderate',  // +5
        emotionalSupport: ['Myself'],
      },
    });

    const baselineResult = await completeSurveyAndGetResult(halo.page, halo.locale, baselineData);
    const allPositiveResult = await completeSurveyAndGetResult(halo.page, halo.locale, allPositiveData);

    expect(
      allPositiveResult.roundedLifespan - baselineResult.roundedLifespan,
      'Female with all positive modifiers should score higher than all-negative male baseline',
    ).toBeGreaterThan(0);
  },
);

test(
  'No healthy habits baseline equals baseline value only @regression @P1',
  async ({ halo }) => {
    const baselineData = buildBaselineData();

    const result = await completeSurveyAndGetResult(halo.page, halo.locale, baselineData);

    // The baseline calculation produces a numeric result
    expect(result.roundedLifespan, 'Baseline with no healthy habits must return a valid numeric life expectancy').toBeGreaterThan(0);
  },
);

// ─────────────────────────────────────────────────────────────────────────────
// Deterministic scenario
// ─────────────────────────────────────────────────────────────────────────────

test(
  'Calculation is deterministic — identical inputs produce identical results @regression @P1',
  async ({ halo }) => {
    const data = buildBaselineData();

    const firstResult = await completeSurveyAndGetResult(halo.page, halo.locale, data);
    const secondResult = await completeSurveyAndGetResult(halo.page, halo.locale, data);

    expect(
      secondResult.roundedLifespan,
      'Running the same survey twice must produce the exact same life expectancy',
    ).toBe(firstResult.roundedLifespan);
  },
);
