import { halo as test, expect } from '../utils/fixture';

import { testData } from '../data/survey.data';

test(`Verify survey flow for different locales`, { tag: ['@smoke', '@P0'] }, async ({ halo }) => {
  const introPage = halo.page.introPage;
  const surveyPage = halo.page.surveyPage;
  const data = await testData(halo.locale, '1');

  await test.step('Should be able to click the Take the Assessment button', async () => {
    await introPage.clickTakeHaloAssessmentButton();
    await expect(
      surveyPage.takeTheAssessmentBtn,
      'Take the Assessment button is not visible. Please check the page for any errors.'
    ).toBeVisible();
  });

  await test.step('Should be able to start the survey', async () => {
    await surveyPage.takeTheAssessmentBtn.click();
    await expect(
      surveyPage.takeTheAssessmentBtn,
      'Take the Assessment button is still visible, no redirection occurred.'
    ).toBeHidden();
  });

  await test.step('Fill Basic Information', async () => {
    await surveyPage.selectGenderOption(data.basicInformation.gender);
    await surveyPage.submitSurvey();
    await surveyPage.enterAge(data.basicInformation.age);
    await surveyPage.submitSurvey();
    await surveyPage.enterHeight(data.basicInformation.height);
    await surveyPage.submitSurvey();
    await surveyPage.enterWeight({ weight: data.basicInformation.weight, unit: data.basicInformation.unit });
    await surveyPage.submitSurvey();
  });

  await test.step('Fill Lifestyle Information', async () => {
    await surveyPage.selectBodyShape(data.lifestyle.bodyShape);
    await surveyPage.selectEthnicity(data.lifestyle.ethnicity);
    await surveyPage.setExerciseFrequency(data.lifestyle.exercise);
  });

  await test.step('Handle Smoking Questions', async () => {
    await surveyPage.handleSmokingQuestions(data.smoking);
  });

  await test.step('Fill In Eating and Drinking Questions', async () => {
    await surveyPage.selectFruitVegetableIntake(data.eatingAndDrinking.fruitVegetableIntake);
    await surveyPage.selectDrinkingFrequency(data.eatingAndDrinking.drinkingFrequency);
    await surveyPage.selectEmotionalSupport(data.eatingAndDrinking.emotionalSupport);
    await surveyPage.submitSurvey();
  });

  await test.step('Fill Medical History', async () => {
    await surveyPage.selectDoctorVisitFrequency(data.medicalHistory.doctorVisitFrequency);
    await surveyPage.setFamilyCancerHistory(data.medicalHistory.familyCancerHistory);
    await surveyPage.selectCancerType(data.medicalHistory.cancerTypes);
    await surveyPage.setFamilyAlzheimerHistory(data.medicalHistory.familyAlzheimerHistory);
    await surveyPage.setFamilyDiabetesHistory(data.medicalHistory.familyDiabetesHistory);
    await surveyPage.setFamilyHeartDiseaseHistory(data.medicalHistory.familyHeartDiseaseHistory);
    await surveyPage.setFamilyStrokeHistory(data.medicalHistory.familyStrokeHistory);
  });

  await test.step('Fill Retirement Information', async () => {
    await surveyPage.enterExpectedRetirementAge(data.retirement.expectedRetirementAge);
    await surveyPage.submitSurvey();
    await surveyPage.selectRetirementState(data.retirement.retirementState);
    await surveyPage.submitSurvey();
    await surveyPage.selectFamilyLongevity(data.retirement.familyLongevity);
  });

  await test.step('Fill Personal Information', async () => {
    await surveyPage.fillPersonalDetails({
      firstName: data.personalDetails.firstName,
      lastName: data.personalDetails.lastName,
      email: data.personalDetails.email,
      advisor: data.personalDetails.advisor,
    });
  });

  await test.step('Submit survey', async () => {
    await surveyPage.seeResultBtn.click();
    await expect(
      surveyPage.page.getByText('Congratulations!'),
      'Failed to submit survey. Congratulations message was not visible.'
    ).toBeVisible({ timeout: 10_000 });
  });
});
