import { halo as test, expect } from '../utils/fixture';
import { introPageAriaUS, IntroPageAriaAU, haloModalAria } from '../utils/snapshots';

test('Verify that the intro page loads', { tag: ['@smoke', '@P0'] }, async ({ halo }) => {
  const page = halo.page.introPage;
  await expect(page.headerLogo, 'Timed out waiting for the header logo to be visible').toBeVisible({
    timeout: 10_000,
  });
});

test('Verify that the intro page matches the snapshot', { tag: ['@smoke', '@P0'] }, async ({ halo }) => {
  const page = halo.page.introPage;
  await test.step('Assert that the intro page matches the snapshot', async () => {
    await page.assertSnapshot(page.pageBody, halo.locale === 'us' ? introPageAriaUS : IntroPageAriaAU);
  });
});

test('Verify that halo modal matches the snapshot', { tag: ['@smoke', '@P0'] }, async ({ halo }) => {
  const page = halo.page.introPage;
  await test.step('Assert that the halo modal matches the snapshot', async () => {
    await page.clickTakeHaloAssessmentButton();
    await page.assertSnapshot(page.surveyModal, haloModalAria);
  });
});

test(
  'Verify that the privacy policy modal opens and the link is accessible',
  { tag: ['@regression', '@P1'] },
  async ({ halo }) => {
    const page = halo.page.introPage;

    await test.step('Click Take the Assessment button', async () => {
      await page.clickTakeHaloAssessmentButton();
    });

    await test.step('Assert that the privacy policy modal opens', async () => {
      await page.privacyPolicyBtn.click();
      await expect(
        page.page.getByText('For more information please see: Privacy Policy'),
        'Privacy Policy modal is not visible. Please check the page for any errors.'
      ).toBeVisible();
    });

    await test.step('Assert that the privacy policy link is accessible', async () => {
      await page.privacyPolicyLink.click();
      await expect(
        page.privacyPolicyBtn,
        'Privacy Policy button is still visible, no redirection occured.'
      ).toBeHidden();
    });
  }
);

test('Verify that the disclaimer modal opens', { tag: ['@regression', '@P1'] }, async ({ halo }) => {
  const page = halo.page.introPage;

  await test.step('Click Take the Assessment button', async () => {
    await page.clickTakeHaloAssessmentButton();
  });

  await test.step('Assert that the disclaimer modal opens', async () => {
    await page.disclaimerBtn.click();
    await expect(
      page.page.getByText('This HALO assessment is intended for individuals in the general '),
      'Disclaimer modal is not visible. Please check the page for any errors.'
    ).toBeVisible();
  });
});
