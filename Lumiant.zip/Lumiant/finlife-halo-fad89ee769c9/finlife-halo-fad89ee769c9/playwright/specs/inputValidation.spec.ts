/**
 * Input Validation Tests
 *
 * Covers:
 *   1. Age field: rejects values below 18 and above 110
 *   2. Ethnicity percentage inputs: a variety of valid/invalid combinations
 *
 * For ethnicity tests, "Other/Mixed" is selected at the ethnicity step to
 * reach the percentage-input slide (slide f5 in US/AU v23, primary in AU v24).
 * Input hints are e.g. "European (%)", "African (%)".
 *
 * Validation error messages (from assessment source):
 *   Age < 18 : "Please enter your age. Your age must be 18 or older"
 *   Age > 110: "age input not valid please try again"
 *   Percentages ≠ 100: "Please ensure the percentages add up to 100."
 */

import { halo as test, expect } from '../utils/fixture';
import { HaloPage } from '../pages/page';

type HaloFixture = { page: HaloPage; locale: string };

// ─────────────────────────────────────────────────────────────────────────────
// Helper: navigate up to and through the age-entry step
// ─────────────────────────────────────────────────────────────────────────────

async function navigateToAgeStep(halo: HaloFixture) {
  const { introPage, surveyPage } = halo.page;

  await introPage.clickTakeHaloAssessmentButton();
  await expect(surveyPage.takeTheAssessmentBtn).toBeVisible();
  await surveyPage.takeTheAssessmentBtn.click();
  await expect(surveyPage.takeTheAssessmentBtn).toBeHidden();

  // Gender (first question) — advance past it
  await surveyPage.selectGenderOption('Male');
  await surveyPage.submitSurvey();
  // Now on the Age question
}

// ─────────────────────────────────────────────────────────────────────────────
// Helper: navigate to the ethnicity percentage-input slide.
// Selects "Other/Mixed" which triggers the percentage follow-up (slide f5).
// ─────────────────────────────────────────────────────────────────────────────

async function navigateToEthnicityPercentageStep(halo: HaloFixture) {
  const { introPage, surveyPage } = halo.page;
  const locale = halo.locale;

  await introPage.clickTakeHaloAssessmentButton();
  await expect(surveyPage.takeTheAssessmentBtn).toBeVisible();
  await surveyPage.takeTheAssessmentBtn.click();
  await expect(surveyPage.takeTheAssessmentBtn).toBeHidden();

  // Gender
  await surveyPage.selectGenderOption('Male');
  await surveyPage.submitSurvey();

  // Age
  await surveyPage.enterAge(40);
  await surveyPage.submitSurvey();

  // Height (locale-aware)
  if (locale === 'au') {
    await surveyPage.enterHeight({ centimeters: 170 });
  } else {
    await surveyPage.enterHeight({ feet: 5, inches: 7 });
  }
  await surveyPage.submitSurvey();

  // Weight (locale-aware)
  if (locale === 'au') {
    await surveyPage.enterWeight({ weight: 70, unit: 'Kilogram' });
  } else {
    await surveyPage.enterWeight({ weight: 160, unit: 'Pound' });
  }
  await surveyPage.submitSurvey();

  // Body shape advances automatically via setvaluenext
  await surveyPage.selectBodyShape('Slim');

  // Ethnicity — select Other/Mixed to reach percentage input slide
  await surveyPage.selectOtherMixedEthnicity();
  // Now on the percentage input slide (f5)
}

// ─────────────────────────────────────────────────────────────────────────────
// Beforeeach: ensure intro page is ready
// ─────────────────────────────────────────────────────────────────────────────

test.beforeEach(async ({ halo }) => {
  await expect(halo.page.introPage.headerLogo).toBeVisible({ timeout: 10_000 });
});

// ─────────────────────────────────────────────────────────────────────────────
// Age validation scenarios
// ─────────────────────────────────────────────────────────────────────────────

test(
  'Age validation rejects negative values @regression @P1',
  async ({ halo }) => {
    await navigateToAgeStep(halo);

    await halo.page.surveyPage.enterAge(-1);
    await halo.page.surveyPage.submitBtn.click();

    const errorMessage = await halo.page.surveyPage.getValidationErrorMessage();
    expect(
      errorMessage,
      'A negative age should trigger a validation error',
    ).toContain('Please enter your age');

  },
);

test(
  'Age validation rejects values over 110 @regression @P1',
  async ({ halo }) => {
    await navigateToAgeStep(halo);

    await halo.page.surveyPage.enterAge(150);
    await halo.page.surveyPage.submitBtn.click();

    const errorMessage = await halo.page.surveyPage.getValidationErrorMessage();
    expect(
      errorMessage,
      'An age of 150 should trigger a "not valid" validation error',
    ).toContain('not valid');
  },
);

// ─────────────────────────────────────────────────────────────────────────────
// Ethnicity percentage validation scenarios
// ─────────────────────────────────────────────────────────────────────────────

test(
  'System allows entering more than 100 percent in a single ethnicity before submit @regression @P1',
  async ({ halo }) => {
    await navigateToEthnicityPercentageStep(halo);

    await halo.page.surveyPage.enterEthnicityPercentage('European (%)', 150);

    await expect(
      halo.page.surveyPage.page.getByPlaceholder('European (%)'),
      'A value of 150 should be accepted in the input field before submission',
    ).toHaveValue('150');

    await halo.page.surveyPage.submitBtn.click();

    const errorMessage = await halo.page.surveyPage.getValidationErrorMessage();
    expect(
      errorMessage,
      'Entering 150% in one field and submitting should show a validation error',
    ).toContain('percentages add up to 100');
  },
);

test(
  'System allows combined total over 100 percent before submit @regression @P1',
  async ({ halo }) => {
    await navigateToEthnicityPercentageStep(halo);

    await halo.page.surveyPage.enterEthnicityPercentage('European (%)', 60);
    await halo.page.surveyPage.enterEthnicityPercentage('African (%)', 50);

    await expect(
      halo.page.surveyPage.page.getByPlaceholder('European (%)'),
      'European field should retain value of 60',
    ).toHaveValue('60');
    await expect(
      halo.page.surveyPage.page.getByPlaceholder('African (%)'),
      'African field should retain value of 50',
    ).toHaveValue('50');

    await halo.page.surveyPage.submitBtn.click();

    const errorMessage = await halo.page.surveyPage.getValidationErrorMessage();
    expect(
      errorMessage,
      'Combined ethnicity total of 110% should be rejected on submit',
    ).toContain('percentages add up to 100');
  },
);

test(
  'Single ethnicity equal to 100 percent is valid on submit @regression @P1',
  async ({ halo }) => {
    await navigateToEthnicityPercentageStep(halo);

    await halo.page.surveyPage.enterEthnicityPercentage('European (%)', 100);
    await halo.page.surveyPage.submitBtn.click();

    // A valid submission advances past this slide (no alertdialog appears)
    await expect(
      halo.page.surveyPage.page.getByRole('alertdialog'),
      'A 100% single-ethnicity entry should not show a validation error',
    ).not.toBeVisible();
  },
);

test(
  'Combined ethnicities totalling 100 percent is valid on submit @regression @P1',
  async ({ halo }) => {
    await navigateToEthnicityPercentageStep(halo);

    await halo.page.surveyPage.enterEthnicityPercentage('European (%)', 40);
    await halo.page.surveyPage.enterEthnicityPercentage('African (%)', 30);
    await halo.page.surveyPage.enterEthnicityPercentage('Asian (%)', 30);
    await halo.page.surveyPage.submitBtn.click();

    await expect(
      halo.page.surveyPage.page.getByRole('alertdialog'),
      'Combined 40+30+30=100% should not trigger a validation error',
    ).not.toBeVisible();
  },
);

test(
  'Submit is rejected when combined ethnicities total less than 100 percent @regression @P1',
  async ({ halo }) => {
    await navigateToEthnicityPercentageStep(halo);

    await halo.page.surveyPage.enterEthnicityPercentage('European (%)', 40);
    await halo.page.surveyPage.enterEthnicityPercentage('African (%)', 20);
    await halo.page.surveyPage.submitBtn.click();

    const errorMessage = await halo.page.surveyPage.getValidationErrorMessage();
    expect(
      errorMessage,
      'Combined ethnicity total of 60% should be rejected because it does not equal 100%',
    ).toContain('percentages add up to 100');
  },
);

test(
  'Validation error persists until percentages are corrected to 100 percent @regression @P1',
  async ({ halo }) => {
    await navigateToEthnicityPercentageStep(halo);

    // First submission — invalid (totals 120%)
    await halo.page.surveyPage.enterEthnicityPercentage('European (%)', 70);
    await halo.page.surveyPage.enterEthnicityPercentage('African (%)', 50);
    await halo.page.surveyPage.submitBtn.click();

    const firstError = await halo.page.surveyPage.getValidationErrorMessage();
    expect(firstError, 'First submission with 120% should show a validation error').toContain('percentages add up to 100');

    // Close the dialog (click the Close button inside the alertdialog)
    await halo.page.surveyPage.page.getByRole('alertdialog').getByRole('button').click();

    // Second submission — corrected (totals 100%)
    await halo.page.surveyPage.enterEthnicityPercentage('European (%)', 60);
    await halo.page.surveyPage.enterEthnicityPercentage('African (%)', 40);
    await halo.page.surveyPage.submitBtn.click();

    await expect(
      halo.page.surveyPage.page.getByRole('alertdialog'),
      'After correcting to 100%, no validation error should appear',
    ).not.toBeVisible();
  },
);
