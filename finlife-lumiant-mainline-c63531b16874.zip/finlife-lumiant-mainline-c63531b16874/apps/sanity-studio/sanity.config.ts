import { visionTool } from '@sanity/vision';
import { defineConfig } from 'sanity';
import { presentationTool } from 'sanity/presentation';
import { structureTool } from 'sanity/structure';

import { locations, mainDocuments } from '#app/presentation';
import { schema } from '#app/schemaTypes';
import { structure } from '#app/structure';
import { dataset, projectId } from './config';

export default defineConfig({
  name: 'default',
  title: 'Lumiant Website',

  projectId,
  dataset,

  plugins: [
    structureTool({ structure }),
    visionTool(),
    presentationTool({
      previewUrl: {
        origin: 'http://localhost:4321',
        previewMode: {
          enable: '/preview/enable',
          disable: '/preview/disable',
        },
      },
      resolve: {
        locations,
        mainDocuments,
      },
    }),
  ],

  schema: {
    types: schema.types,
  },
});
