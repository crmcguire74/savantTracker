export const projectId = process.env.SANITY_STUDIO_SANITY_PROJECT_ID as string;
export const dataset = process.env.SANITY_STUDIO_SANITY_DATASET || 'production';
export const studioHost = process.env.SANITY_STUDIO_HOST || 'lumiant';
