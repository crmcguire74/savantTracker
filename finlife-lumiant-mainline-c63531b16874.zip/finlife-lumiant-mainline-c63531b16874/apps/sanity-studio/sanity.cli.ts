import { defineCliConfig } from 'sanity/cli';

import { dataset, projectId, studioHost } from './config';

export default defineCliConfig({
  api: {
    projectId,
    dataset,
  },
  deployment: {
    appId: 'of3sm1m804a13ez1vug1rfc4',
  },
  typegen: {
    path: './src/**/*.{ts,tsx,js,jsx}',
    schema: './src/schemaTypes/schema.json',
    generates: './src/sanity.types.ts',
    overloadClientMethods: true,
  },
  studioHost,
  vite: {
    resolve: {
      alias: {
        '@': '/src',
      },
    },
  },
});
