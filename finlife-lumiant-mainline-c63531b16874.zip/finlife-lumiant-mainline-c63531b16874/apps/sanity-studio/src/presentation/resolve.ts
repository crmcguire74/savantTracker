import { defineDocuments, defineLocations } from 'sanity/presentation';

export const locations = {
  siteSettings: defineLocations({
    message: 'This document is used on all pages',
    tone: 'caution',
  }),
  home: defineLocations({
    select: { title: 'title' },
    resolve: (doc) => ({
      locations: [
        {
          title: doc?.title || 'Home',
          href: '/',
        },
      ],
    }),
  }),
  page: defineLocations({
    select: {
      title: 'title',
      slug: 'slug.current',
    },
    resolve: (doc) => ({
      locations: [
        {
          title: doc?.title || 'Page',
          href: `/${doc?.slug}`,
        },
      ],
    }),
  }),
};

export const mainDocuments = defineDocuments([
  {
    route: '/',
    type: 'home',
  },
  {
    route: '/:slug',
    filter: `_type == "page" && slug.current == $slug`,
  },
]);
