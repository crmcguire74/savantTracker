export { locations, mainDocuments } from './resolve';
