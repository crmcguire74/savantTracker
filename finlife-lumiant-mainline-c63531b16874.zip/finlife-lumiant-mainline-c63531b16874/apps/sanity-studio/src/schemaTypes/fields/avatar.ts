import { defineField, defineType } from 'sanity';

export const avatar = defineType({
  name: 'avatar',
  title: 'Avatar',
  type: 'object',
  fields: [
    defineField({
      name: 'alt',
      title: 'Alt Text',
      type: 'string',
    }),
    defineField({
      name: 'src',
      title: 'Image Source',
      type: 'image',
      options: {
        hotspot: true,
      },
    }),
    // Add more fields as needed based on the component's props
  ],
});
