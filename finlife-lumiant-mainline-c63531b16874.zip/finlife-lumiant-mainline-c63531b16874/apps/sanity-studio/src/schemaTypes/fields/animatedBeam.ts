import { defineField, defineType } from 'sanity';

export const animatedBeam = defineType({
  name: 'animatedBeam',
  title: 'Animated Beam',
  type: 'object',
  fields: [
    defineField({
      name: 'label',
      title: 'Label',
      type: 'string',
    }),
    // Add more fields as needed based on the component's props
  ],
});
