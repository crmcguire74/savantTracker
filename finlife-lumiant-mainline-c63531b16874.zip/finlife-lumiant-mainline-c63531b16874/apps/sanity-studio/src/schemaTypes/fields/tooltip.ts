import { defineField, defineType } from 'sanity';

export const tooltip = defineType({
  name: 'tooltip',
  title: 'Tooltip',
  type: 'object',
  fields: [
    defineField({
      name: 'content',
      title: 'Content',
      type: 'string',
    }),
    defineField({
      name: 'delayDuration',
      title: 'Delay Duration',
      type: 'number',
      description: 'Delay in milliseconds before the tooltip appears',
      initialValue: 700,
    }),
    // Add more fields as needed based on the component's props
  ],
});
