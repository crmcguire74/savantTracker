import { defineField, defineType } from 'sanity';

export const collapsible = defineType({
  name: 'collapsible',
  title: 'Collapsible',
  type: 'object',
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
    }),
    defineField({
      name: 'content',
      title: 'Content',
      type: 'array',
      of: [{ type: 'block' }],
    }),
    // Add more fields as needed based on the component's props
  ],
});
