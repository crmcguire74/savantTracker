import { defineField, defineType } from 'sanity';

export const motionPreset = defineType({
  name: 'motionPreset',
  title: 'Motion Preset',
  type: 'object',
  fields: [
    defineField({
      name: 'presetName',
      title: 'Preset Name',
      type: 'string',
    }),
    defineField({
      name: 'duration',
      title: 'Duration',
      type: 'number',
      description: 'Duration of the motion animation in seconds',
    }),
    // Add more fields as needed based on the component's props
  ],
});
