import { defineField, defineType } from 'sanity';

export const badge = defineType({
  name: 'badge',
  title: 'Badge',
  type: 'object',
  fields: [
    defineField({
      name: 'label',
      title: 'Label',
      type: 'string',
    }),
    defineField({
      name: 'variant',
      title: 'Variant',
      type: 'string',
      options: {
        list: [
          { title: 'Default', value: 'default' },
          { title: 'Secondary', value: 'secondary' },
          { title: 'Destructive', value: 'destructive' },
          { title: 'Outline', value: 'outline' },
        ],
      },
    }),
    // Add more fields as needed based on the component's props
  ],
});
