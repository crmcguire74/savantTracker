import { defineField, defineType } from 'sanity';

export const rating = defineType({
  name: 'rating',
  title: 'Rating',
  type: 'object',
  fields: [
    defineField({
      name: 'value',
      title: 'Value',
      type: 'number',
      description: 'The current rating value (e.g., 3.5)',
      validation: (Rule) => Rule.min(0).max(5),
    }),
    defineField({
      name: 'max',
      title: 'Maximum Rating',
      type: 'number',
      description: 'The maximum possible rating (e.g., 5)',
      initialValue: 5,
    }),
    // Add more fields as needed based on the component's props
  ],
});
