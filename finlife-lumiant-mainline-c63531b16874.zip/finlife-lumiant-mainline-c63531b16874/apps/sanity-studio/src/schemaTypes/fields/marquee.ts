import { defineField, defineType } from 'sanity';

export const marquee = defineType({
  name: 'marquee',
  title: 'Marquee',
  type: 'object',
  fields: [
    defineField({
      name: 'content',
      title: 'Content',
      type: 'string',
    }),
    defineField({
      name: 'speed',
      title: 'Speed',
      type: 'number',
      description: 'Speed of the marquee animation',
    }),
    // Add more fields as needed based on the component's props
  ],
});
