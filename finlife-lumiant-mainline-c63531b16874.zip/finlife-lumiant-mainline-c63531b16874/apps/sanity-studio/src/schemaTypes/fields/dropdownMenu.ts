import { defineField, defineType } from 'sanity';

export const dropdownMenu = defineType({
  name: 'dropdownMenu',
  title: 'Dropdown Menu',
  type: 'object',
  fields: [
    defineField({
      name: 'triggerLabel',
      title: 'Trigger Label',
      type: 'string',
    }),
    defineField({
      name: 'menuItems',
      title: 'Menu Items',
      type: 'array',
      of: [
        defineField({
          name: 'menuItem',
          title: 'Menu Item',
          type: 'object',
          fields: [
            defineField({
              name: 'label',
              title: 'Label',
              type: 'string',
            }),
            defineField({
              name: 'href',
              title: 'URL',
              type: 'url',
            }),
          ],
        }),
      ],
    }),
    // Add more fields as needed based on the component's props
  ],
});
