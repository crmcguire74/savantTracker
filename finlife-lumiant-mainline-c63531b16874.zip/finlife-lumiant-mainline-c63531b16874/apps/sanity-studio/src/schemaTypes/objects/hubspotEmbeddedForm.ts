import { defineField, defineType } from 'sanity';

export const hubspotEmbeddedFormType = defineType({
  name: 'hubspotEmbeddedForm',
  title: 'HubSpot embedded form',
  type: 'object',
  fields: [
    defineField({
      name: 'portalId',
      title: 'Portal ID',
      type: 'string',
      description: 'Numeric HubSpot portal ID (also used in the embed script URL).',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'formId',
      title: 'Form ID',
      type: 'string',
      description: 'The form GUID from HubSpot (embed code).',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'region',
      title: 'Data center region',
      type: 'string',
      description: 'Usually na1 (US) or eu1 (EU). Matches the data-region attribute on the embed.',
      initialValue: 'na1',
    }),
  ],
});
