import { defineType } from 'sanity';

export const blockContent = defineType({
  name: 'blockContent',
  title: 'Block Content',
  type: 'array',
  of: [
    {
      type: 'block',
      styles: [
        { title: 'Normal', value: 'normal' },
        { title: 'Span', value: 'span' },
        { title: 'Small', value: 'small' },
        { title: 'H1', value: 'h1' },
        { title: 'H2', value: 'h2' },
        { title: 'H3', value: 'h3' },
        { title: 'H4', value: 'h4' },
        { title: 'Quote', value: 'blockquote' },
        { title: 'Blog H2', value: 'blogH2' },
        { title: 'Blog Text', value: 'blogText' },
      ],
      lists: [
        { title: 'Bullet', value: 'bullet' },
        { title: 'Numbered', value: 'number' },
        { title: 'Circle check', value: 'circle-check' },
      ],
      marks: {
        decorators: [
          { title: 'Strong', value: 'strong' },
          { title: 'Emphasis', value: 'em' },
          { title: 'Code', value: 'code' },
          { title: 'Underline', value: 'underline' },
          { title: 'Primary', value: 'primary', icon: () => `P` },
          { title: 'Secondary', value: 'secondary', icon: () => `S` },
          { title: 'Light', value: 'light', icon: () => `L` },
          { title: 'Muted', value: 'muted', icon: () => `M` },
          {
            title: 'Gradient',
            value: 'gradient',
            icon: () => `G`,
            component: ({ children }) => (
              <span
                style={{
                  color: 'transparent',
                  backgroundClip: 'text',
                  backgroundImage:
                    'linear-gradient(to right, oklch(0.623 0.214 259.815) 15%, oklch(0.488 0.243 264.376) 55%, oklch(0.379 0.146 265.522) 95%)',
                }}
              >
                {children}
              </span>
            ),
          },
        ],
        annotations: [
          {
            name: 'link',
            title: 'Link',
            type: 'object',
            fields: [
              {
                name: 'href',
                title: 'URL',
                type: 'url',
                validation: (Rule) =>
                  Rule.uri({
                    scheme: ['http', 'https', 'mailto'],
                  }),
              },
            ],
          },
        ],
      },
      options: { spellCheck: true },
    },
    {
      type: 'image',
      fields: [
        {
          name: 'alt',
          type: 'string',
          title: 'Alternative text',
          description: 'Important for SEO and accessibility.',
          options: {
            isHighlighted: true,
          },
        },
      ],
      options: { hotspot: true },
    },
    {
      type: 'blogQuote',
    },
  ],
});
