import { defineField, defineType } from 'sanity';

export const blockHeading = defineType({
  name: 'blockHeading',
  title: 'Block Heading & Badge',
  type: 'object',
  fields: [
    defineField({
      name: 'heading',
      title: 'Heading',
      type: 'array',
      of: [
        {
          type: 'block',
          styles: [
            { title: 'H2', value: 'normal', component: ({ children }) => <h1>{children}</h1> },
            { title: 'H1', value: 'h1' },
            {
              title: '5XL',
              value: '5xl',
              component: ({ children }) => <h1 className="font-bold text-5xl leading-[100%]">{children}</h1>,
            },
            {
              title: 'Body',
              value: 'body',
              component: ({ children }) => <p className="text-md font-regular">{children}</p>,
            },
          ],
          marks: {
            decorators: [
              { title: 'Primary', value: 'primary', icon: () => `P` },
              { title: 'Secondary', value: 'secondary', icon: () => `S` },
              {
                title: 'Gradient',
                value: 'gradient',
                icon: () => `G`,
                component: ({ children }) => (
                  <span
                    style={{
                      color: 'transparent',
                      backgroundClip: 'text',
                      backgroundImage:
                        'linear-gradient(to right, oklch(0.623 0.214 259.815) 15%, oklch(0.488 0.243 264.376) 55%, oklch(0.379 0.146 265.522) 95%)',
                    }}
                  >
                    {children}
                  </span>
                ),
              },
            ],
            annotations: [],
          },
          lists: [],
        },
      ],
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'blockContent',
    }),
    defineField({
      name: 'badge',
      title: 'Badge',
      type: 'string',
      description: 'Optional badge text',
    }),
  ],
});
