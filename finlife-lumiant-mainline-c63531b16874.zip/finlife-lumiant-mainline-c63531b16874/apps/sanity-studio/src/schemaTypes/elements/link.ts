import { defineField, defineType } from 'sanity';

export const linkType = defineType({
  name: 'link',
  title: 'Link',
  type: 'object',
  fields: [
    defineField({
      name: 'label',
      title: 'Label',
      type: 'string',
      validation: (r) => r.required(),
    }),
    defineField({
      name: 'type',
      title: 'Type',
      type: 'string',
      options: {
        list: [
          { title: 'Internal', value: 'internal' },
          { title: 'External', value: 'external' },
        ],
        layout: 'radio',
      },
      validation: (r) => r.required(),
    }),
    defineField({
      name: 'internalRef',
      title: 'Internal Reference',
      type: 'reference',
      to: [
        { type: 'page' },
        { type: 'home' },
        { type: 'blog' },
        { type: 'blogPostPage' },
        { type: 'blogPostCategory' },
      ],
      hidden: ({ parent }) => parent?.type !== 'internal',
      validation: (Rule) =>
        Rule.custom((val, ctx) => {
          const parent = ctx.parent as { type?: string };
          if (parent?.type === 'internal' && !val) return 'Internal link target required';
          return true;
        }),
    }),
    defineField({
      name: 'externalUrl',
      title: 'External URL',
      type: 'url',
      hidden: ({ parent }) => parent?.type !== 'external',
      validation: (Rule) =>
        Rule.custom((val, ctx) => {
          const parent = ctx.parent as { type?: string };
          if (parent?.type === 'external' && !val) return 'External URL required';
          if (val && !/^https?:\/\//i.test(val)) return 'URL must start with http:// or https://';
          return true;
        }),
    }),
    defineField({
      name: 'newTab',
      title: 'Open In New Tab',
      type: 'boolean',
      initialValue: false,
      hidden: ({ parent }) => parent?.type !== 'external',
    }),
  ],
  preview: {
    select: {
      label: 'label',
      type: 'type',
      internalRefType: 'internalRef._type',
      internalSlug: 'internalRef.slug.current',
      externalUrl: 'externalUrl',
    },
    prepare: ({ label, type, internalRefType, internalSlug, externalUrl }) => ({
      title: label,
      subtitle:
        type === 'internal'
          ? internalRefType === 'blogPostCategory' && internalSlug
            ? `/blog/tag/${internalSlug}`
            : `/${internalSlug}`
          : externalUrl,
    }),
  },
});
