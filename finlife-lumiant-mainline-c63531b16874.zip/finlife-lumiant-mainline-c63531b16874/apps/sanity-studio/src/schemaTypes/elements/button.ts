import { defineField } from 'sanity';

export const buttonType = {
  name: 'button',
  type: 'object',
  fields: [
    defineField({
      name: 'label',
      title: 'Label',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'variant',
      title: 'Variant',
      type: 'string',
      initialValue: 'primary',
      options: {
        list: [
          { title: 'Primary', value: 'primary' },
          { title: 'Secondary', value: 'secondary' },
          { title: 'Ghost', value: 'ghost' },
          { title: 'Outline', value: 'outline' },
          { title: 'Lavender', value: 'lavender' },
        ],
        layout: 'dropdown',
      },
    }),
    defineField({
      name: 'link',
      type: 'array',
      validation: (rule) => rule.max(1).required(),
      of: [
        {
          name: 'internalLink',
          type: 'object',
          title: 'Internal Link',
          fields: [
            {
              name: 'internalReference',
              type: 'reference',
              to: [
                { type: 'page' },
                { type: 'home' },
                { type: 'blog' },
                { type: 'blogPostPage' },
                { type: 'blogPostCategory' },
              ],
            },
          ],
        },
        {
          name: 'externalLink',
          type: 'object',
          title: 'External Link',
          fields: [{ name: 'url', type: 'url' }],
        },
      ],
    }),
  ],
  preview: {
    select: { title: 'label', subtitle: 'variant' },
  },
};
