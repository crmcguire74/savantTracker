import { defineField, defineType } from 'sanity';

export const blogQuote = defineType({
  name: 'blogQuote',
  title: 'Blog Quote',
  type: 'object',
  fields: [
    defineField({
      name: 'quoteHeading',
      title: 'Quote Heading',
      type: 'string',
    }),
    defineField({
      name: 'quote',
      title: 'Quote',
      type: 'text',
      validation: (rule) => rule.required(),
      rows: 4,
    }),
  ],
  preview: {
    select: {
      title: 'quoteHeading',
      subtitle: 'quote',
    },
    prepare({ title, subtitle }) {
      return {
        title: title || 'Blog Quote',
        subtitle: subtitle || 'Quote',
      };
    },
  },
});
