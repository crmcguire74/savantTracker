import { defineField, defineType } from 'sanity';

export const blockOptions = defineType({
  name: 'blockOptions',
  title: 'Block Options',
  type: 'object',
  fields: [
    defineField({
      name: 'sanityTitle',
      title: 'Sanity Title',
      type: 'string',
      description: 'This title is for internal reference only and will not be displayed on the website.',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'bgColour',
      title: 'Background Colour',
      type: 'string',
      description: 'Enable background color for the section.',
      initialValue: 'default',
      options: {
        list: [
          { title: 'Default', value: 'default' },
          { title: 'Muted', value: 'muted' },
          { title: 'Grid', value: 'grid' },
          { title: 'White Primary Gradient', value: 'whitePrimaryGradient' },
        ],
        layout: 'dropdown',
      },
    }),
    // add spacings
    // add more block level options here
  ],
});
