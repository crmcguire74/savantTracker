import { defineField, defineType } from 'sanity';

export const imageType = defineType({
  name: 'imageBlock',
  type: 'image',
  options: { hotspot: true },
  fields: [
    defineField({
      name: 'alt',
      title: 'Alt text',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'dark',
      title: 'Dark version of the image',
      type: 'image',
      options: { hotspot: true },
    }),
  ],
  description: 'Size the image appropriately for better performance.',
  validation: (rule) => rule.required(),
});
