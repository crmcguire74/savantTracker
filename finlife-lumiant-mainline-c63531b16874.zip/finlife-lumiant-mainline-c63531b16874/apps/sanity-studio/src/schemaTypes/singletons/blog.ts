import { HouseIcon } from 'lucide-react';
import { defineField, defineType } from 'sanity';
import { blogComponent06Type } from '../blocks/blogComponent06';
import { ctaSection14Type } from '../blocks/ctaSection14';
import { heroSectionType } from '../blocks/heroSection';
import { blockHeading } from '../elements/blockHeading';
import { buttonType } from '../elements/button';

export const blogPageType = defineType({
  name: 'blog',
  type: 'document',
  title: 'Page',
  icon: HouseIcon,
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      initialValue: {
        current: '/blog',
      },
      readOnly: true,
      options: {
        source: 'title',
        maxLength: 96,
      },
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'simpleHero',
      title: 'Hero',
      type: heroSectionType.name,
    }),
    defineField({
      name: 'blog',
      title: 'Blog',
      type: blogComponent06Type.name,
    }),
    defineField({
      name: 'blogPostCategories',
      title: 'Blog Post Categories',
      description: 'Define all the categories for blog posts here.',
      type: 'array',
      of: [{ type: 'string' }],
    }),
    defineField({
      name: 'relatedPostsSection',
      title: 'Related Posts Section',
      type: 'object',
      fields: [
        defineField({
          name: 'headings',
          title: 'Headings',
          type: blockHeading.name,
        }),
        defineField({
          name: 'button',
          title: 'Button',
          type: buttonType.name,
        }),
      ],
    }),
    defineField({
      name: 'ctaSection',
      title: 'CTA Section',
      type: ctaSection14Type.name,
    }),
  ],
  preview: {
    select: {
      title: 'title',
      subtitle: 'slug.current',
    },
  },
});
