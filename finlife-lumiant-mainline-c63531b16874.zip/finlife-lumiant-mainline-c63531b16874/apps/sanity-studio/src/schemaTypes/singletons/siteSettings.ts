import { Settings } from 'lucide-react';
import { defineType } from 'sanity';
import { buttonType } from '../elements/button';

export const siteSettingsType = defineType({
  name: 'siteSettings',
  title: 'Site Settings',
  type: 'document',
  icon: Settings,
  fields: [
    {
      name: 'title',
      title: 'Site Title',
      type: 'string',
      validation: (rule) => rule.required(),
    },
    {
      name: 'description',
      title: 'Site Description',
      type: 'text',
      rows: 3,
    },
    {
      name: 'header',
      title: 'Header',
      type: 'object',
      fields: [
        {
          name: 'logo',
          title: 'Logo',
          type: 'image',
          options: {
            hotspot: true,
          },
          validation: (rule) => rule.required(),
        },
        {
          name: 'darkLogo',
          title: 'Dark Logo',
          type: 'image',
          options: {
            hotspot: true,
          },
        },
        {
          name: 'mainNav',
          title: 'Main Navigation',
          type: 'array',
          of: [{ type: 'link' }],
        },
        {
          name: 'ctaButtons',
          title: 'Header CTA buttons',
          type: 'array',
          of: [{ type: buttonType.name }],
          validation: (rule) => rule.max(2),
          description: 'Up to two actions in the header (same button type as blog / page blocks).',
        },
      ],
    },
    {
      name: 'footer',
      title: 'Footer',
      type: 'footer',
    },
    {
      name: 'hubspotContactForm',
      title: 'HubSpot — Contact form',
      type: 'hubspotEmbeddedForm',
      description: 'Embedded form on the Contact Us block (portal ID, form GUID, region).',
    },
    {
      name: 'hubspotNewsletterForm',
      title: 'HubSpot — Newsletter',
      type: 'hubspotEmbeddedForm',
      description: 'Same embed used in the blog newsletter card and the site footer.',
    },
    {
      name: 'hubspotSchedulerEmbedUrl',
      title: 'HubSpot — Book a demo (meetings embed URL)',
      type: 'url',
      description: 'Full meetings URL with embed flag, e.g. https://meetings.hubspot.com/your-org/page?embed=true',
    },
  ],
  preview: {
    select: {
      title: 'title',
    },
    prepare({ title }) {
      return {
        title: title || 'Site Settings',
      };
    },
  },
});
