import type { SchemaTypeDefinition } from 'sanity';
import { aboutCardType, aboutUsPage06 } from './blocks/aboutUsPage06';
import { aboutUsPage09 } from './blocks/aboutUsPage09';
import { bentoGrid07 } from './blocks/bentoGrid07';
import { bentoGrid07Item } from './blocks/bentoGrid07Item';
import {
  bentoGrid18,
  bentoGrid18CardStackCard,
  bentoGrid18CardStackItem,
  bentoGrid18DataTriangleCard,
  bentoGrid18FallingBadgeCard,
  bentoGrid18FallingBadgeItem,
} from './blocks/bentoGrid18';
import { bentoGridItem } from './blocks/bentoGridItem';
import { blogComponent06Type } from './blocks/blogComponent06';
import { calendarSectionType } from './blocks/calendarSection';
import { contactUsInfo } from './blocks/contactUsInfo';
import { contactUsPage10 } from './blocks/contactUsPage10';
import { ctaSection07Type } from './blocks/ctaSection07';
import { ctaSection09Type } from './blocks/ctaSection09';
import { ctaSection14Type } from './blocks/ctaSection14';
import { faqComponent13, faqComponent13Item, faqComponent13Tab } from './blocks/faqComponent13';
import { faqComponent15, faqComponentItem } from './blocks/faqComponent15';
import { featureItem } from './blocks/featureItem';
import { featuresSection02, featuresSection02Card } from './blocks/featuresSection02';
import { featuresSection03 } from './blocks/featuresSection03';
import { featuresSection03Feature } from './blocks/featuresSection03Feature';
import { featuresSection08 } from './blocks/featuresSection08';
import { featuresSection09, featuresSection09Tab } from './blocks/featuresSection09';
import { featuresSection10 } from './blocks/featuresSection10';
import { featuresSection10Card } from './blocks/featuresSection10Card';
import { featuresSection26 } from './blocks/featuresSection26';
import { featuresSection26Feature } from './blocks/featuresSection26Feature';
import { featuresSection26ProcessCard } from './blocks/featuresSection26ProcessCard';
import { heroSectionType } from './blocks/heroSection';
import { heroSection09Type } from './blocks/heroSection09';
import { heroSection10Type } from './blocks/heroSection10';
import { heroSection13Type } from './blocks/heroSection13';
import { logoCloud05Type } from './blocks/logoCloud05';
import { metricItem } from './blocks/metricItem';
import { newsletterCardType } from './blocks/newsletterCard';
import { problemCardType } from './blocks/problemCard';
import { problemSection01Type } from './blocks/problemSection01';
import { socialProof05 } from './blocks/socialProof05';
import { tabbedImageContentSection, tabbedImageContentTab } from './blocks/tabbedImageContentSection';
import { team1, teamMember } from './blocks/team1';
import { teamSection } from './blocks/teamSection';
import { testimonialItem, testimonialsComponent01 } from './blocks/testimonialsComponent01';
import { blogPostCategoryType } from './categories/blogPostCategory';
import { blogAuthorType } from './documents/blogAuthor';
import { blockContent } from './elements/blockContent';
import { blockHeading } from './elements/blockHeading';
import { blockOptions } from './elements/blockOptions';
import { blogQuote } from './elements/blogQuote';
import { buttonType } from './elements/button';
import { iconNameType } from './elements/iconName';
import { imageType } from './elements/image';
import { linkType } from './elements/link';
import { pageBuilderType } from './elements/pageBuilder';
import { animatedBeam } from './fields/animatedBeam';
import { avatar } from './fields/avatar';
import { badge } from './fields/badge';
import { card } from './fields/card';
import { collapsible } from './fields/collapsible';
import { dropdownMenu } from './fields/dropdownMenu';
import { marquee } from './fields/marquee';
import { motionPreset } from './fields/motionPreset';
import { rating } from './fields/rating';
import { tooltip } from './fields/tooltip';
import { hubspotEmbeddedFormType } from './objects/hubspotEmbeddedForm';
import { blogPostPageType } from './pages/blogPostPage';
import { pageType } from './pages/page';
import { blogPageType } from './singletons/blog';
import { footerType } from './singletons/footer';
import { homePageType } from './singletons/home';
import { siteSettingsType } from './singletons/siteSettings';

export const schema: { types: SchemaTypeDefinition[] } = {
  types: [
    // utils
    blockContent,
    blockHeading,
    blockOptions,
    blogQuote,
    hubspotEmbeddedFormType,
    siteSettingsType,
    pageBuilderType,
    imageType,
    iconNameType,
    buttonType,
    linkType,

    // blocks
    bentoGrid07,
    bentoGrid07Item,
    bentoGrid18,
    bentoGrid18CardStackCard,
    bentoGrid18CardStackItem,
    bentoGrid18DataTriangleCard,
    bentoGrid18FallingBadgeCard,
    bentoGrid18FallingBadgeItem,
    bentoGridItem,
    heroSectionType,
    heroSection09Type,
    heroSection10Type,
    heroSection13Type,
    calendarSectionType,
    logoCloud05Type,
    problemSection01Type,
    problemCardType,
    featuresSection03,
    featuresSection03Feature,
    featuresSection02,
    featuresSection02Card,
    featuresSection08,
    featureItem,
    footerType,
    ctaSection07Type,
    ctaSection09Type,
    ctaSection14Type,
    faqComponent13,
    faqComponent13Item,
    faqComponent13Tab,
    tabbedImageContentSection,
    tabbedImageContentTab,
    metricItem,
    testimonialItem,
    testimonialsComponent01,
    teamMember,
    team1,
    teamSection,
    contactUsPage10,
    contactUsInfo,
    aboutUsPage09,
    socialProof05,
    featuresSection09,
    featuresSection09Tab,
    featuresSection10Card,
    featuresSection10,
    featuresSection26,
    featuresSection26Feature,
    featuresSection26ProcessCard,
    aboutUsPage06,
    aboutCardType,
    blogComponent06Type,
    newsletterCardType,
    faqComponent15,
    faqComponentItem,

    // pages
    homePageType,
    blogPageType,
    blogPostPageType,
    pageType,

    // categories
    blogPostCategoryType,

    // documents
    blogAuthorType,

    // components
    animatedBeam,
    avatar,
    badge,
    card,
    collapsible,
    dropdownMenu,
    marquee,
    motionPreset,
    rating,
    tooltip,
  ],
};
