import { defineField, defineType } from 'sanity';

export const newsletterCardType = defineType({
  name: 'newsletterCard',
  title: 'Newsletter Card',
  type: 'object',
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'subtitle',
      title: 'Subtitle',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      title: 'title',
    },
    prepare({ title }) {
      return {
        title: `Newsletter Card: ${title}`,
      };
    },
  },
});
