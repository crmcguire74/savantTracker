import { defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';
import { blockOptions } from '../elements/blockOptions';

export const teamMember = defineType({
  name: 'teamMember',
  title: 'Team Member',
  type: 'object',
  fields: [
    defineField({
      name: 'name',
      title: 'Name',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'role',
      title: 'Role',
      type: 'string',
    }),
    defineField({
      name: 'avatar',
      title: 'Avatar',
      type: 'image',
      options: { hotspot: true },
      fields: [
        defineField({
          name: 'alt',
          title: 'Alt text',
          type: 'string',
          validation: (rule) => rule.required(),
        }),
      ],
    }),
    defineField({
      name: 'borderRadius',
      title: 'Border Radius',
      type: 'object',
      description: 'Enable rounded corners (90px radius)',
      fields: [
        defineField({
          name: 'tl',
          title: 'Top Left',
          type: 'boolean',
        }),
        defineField({
          name: 'tr',
          title: 'Top Right',
          type: 'boolean',
        }),
        defineField({
          name: 'bl',
          title: 'Bottom Left',
          type: 'boolean',
        }),
        defineField({
          name: 'br',
          title: 'Bottom Right',
          type: 'boolean',
        }),
      ],
    }),
    defineField({
      name: 'color',
      title: 'Background Color',
      type: 'string',
      description: 'Select a color for the background',
      options: {
        list: [
          { title: 'Primary', value: 'primary' },
          { title: 'Brand Lavender', value: 'brand-lavender' },
          { title: 'Brand Electric', value: 'brand-electric' },
        ],
      },
      initialValue: 'brand-electric',
    }),
    defineField({
      name: 'bio',
      title: 'Bio',
      type: 'blockContent',
      description: 'Bio content displayed on the back of the card',
    }),
  ],
});

export const team1 = defineType({
  name: 'team1',
  title: 'Team1',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: blockOptions.name,
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'members',
      title: 'Members',
      type: 'array',
      of: [{ type: 'teamMember' }],
      validation: (rule) => rule.required().min(1),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: title ? `Team 1: ${title}` : 'Team 1',
      };
    },
  },
});
