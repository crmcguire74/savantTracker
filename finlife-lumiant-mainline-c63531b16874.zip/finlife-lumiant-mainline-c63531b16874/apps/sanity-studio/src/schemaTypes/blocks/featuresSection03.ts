import { defineField, defineType } from 'sanity';
import { imageType } from '../elements/image';
import { featuresSection03Feature } from './featuresSection03Feature';

export const featuresSection03 = defineType({
  name: 'featuresSection03',
  title: 'Features Section 03',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: 'blockHeading',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'techIcon',
      title: 'Technology Icon',
      type: imageType.name,
    }),
    defineField({
      name: 'techTitle',
      title: 'Technology Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'techDescription',
      title: 'Technology Description',
      type: 'text',
      description: 'Paragraph describing the technology.',
    }),
    defineField({
      name: 'mainImage',
      title: 'Main Illustration',
      type: imageType.name,
    }),
    defineField({
      name: 'features',
      title: 'Features List',
      type: 'array',
      of: [{ type: featuresSection03Feature.name }],
      validation: (rule) => rule.required().min(1).max(6),
      description: 'Feature items shown in the right column (icon, title, description).',
    }),
    defineField({
      name: 'ctaParagraph',
      title: 'Call to Action Paragraph',
      type: 'text',
      description: 'Concluding text before the CTA button.',
    }),
    defineField({
      name: 'ctaButton',
      title: 'Call to Action Button',
      type: 'button',
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      badge: 'headings.badge',
      sanityTitle: 'blockOptions.sanityTitle',
    },
    prepare({ badge, sanityTitle }) {
      return {
        title: badge || 'Features Section 03',
        subtitle: sanityTitle ? `Features Section 03: ${sanityTitle}` : 'Features Section 03',
      };
    },
  },
});
