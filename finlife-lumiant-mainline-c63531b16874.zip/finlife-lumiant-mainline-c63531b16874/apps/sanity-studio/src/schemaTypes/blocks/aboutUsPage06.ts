import { defineField, defineType } from 'sanity';
import { blockHeading } from '#app/schemaTypes/elements/blockHeading';
import { buttonType } from '#app/schemaTypes/elements/button';
import { imageType } from '../elements/image';

export const aboutCardType = defineType({
  name: 'aboutUsCard',
  title: 'About Us Card',
  type: 'object',
  fields: [
    defineField({
      name: 'heading',
      title: 'Heading',
      type: 'blockContent',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'blockContent',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      title: 'description',
    },
  },
});

export const aboutUsPage06 = defineType({
  name: 'aboutUsPage06',
  title: 'About Us Page 06',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'button',
      title: 'Button',
      type: buttonType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'aboutUsCards',
      title: 'About Us Cards',
      type: 'array',
      of: [{ type: aboutCardType.name }],
      validation: (rule) => rule.required().min(1),
    }),
  ],
  preview: {
    select: {
      title: 'blockoptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: title ? `About Us Page 06: ${title}` : 'About Us Page 06',
      };
    },
  },
});
