import { defineField, defineType } from 'sanity';
import { iconNameType } from '../elements/iconName';

export const featureItem = defineType({
  name: 'featureItem',
  title: 'Feature Item',
  type: 'object',
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'iconName',
      title: 'Icon Name',
      type: iconNameType.name,
      description: 'Icon name used to render the feature icon.',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'color',
      title: 'Color',
      type: 'string',
      description: 'Tailwind CSS class for the icon background color (e.g., "bg-red-500")',
      validation: (rule) => rule.required(),
    }),
  ],
});
