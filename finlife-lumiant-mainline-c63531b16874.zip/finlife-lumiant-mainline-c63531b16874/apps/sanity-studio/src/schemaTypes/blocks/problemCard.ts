import { defineField, defineType } from 'sanity';

export const problemCardType = defineType({
  name: 'problemCard',
  title: 'Problem Card',
  type: 'object',
  fields: [
    defineField({
      name: 'description',
      title: 'Description',
      type: 'blockContent',
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      title: 'description',
    },
    prepare({ title }) {
      return {
        title: `Problem Card: ${title}`,
      };
    },
  },
});
