import { defineField, defineType } from 'sanity';
import { iconNameType } from '../elements/iconName';
import { featuresSection26ProcessCard } from './featuresSection26ProcessCard';

export const featuresSection26Feature = defineType({
  name: 'featuresSection26Feature',
  title: 'Features Section 26 – Feature Item',
  type: 'object',
  fields: [
    defineField({
      name: 'iconName',
      title: 'Icon',
      type: iconNameType.name,
      description: 'Icon name used to render the feature icon.',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      rows: 3,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'cards',
      title: 'Process Cards',
      type: 'array',
      of: [{ type: featuresSection26ProcessCard.name }],
      description: 'Cards shown in the process flow for this tab.',
    }),
  ],
  preview: {
    select: {
      title: 'title',
      subtitle: 'description',
    },
    prepare({ title, subtitle }) {
      return {
        title: title || 'Feature',
        subtitle: subtitle ? (subtitle as string).slice(0, 50) + (subtitle.length > 50 ? '…' : '') : undefined,
      };
    },
  },
});
