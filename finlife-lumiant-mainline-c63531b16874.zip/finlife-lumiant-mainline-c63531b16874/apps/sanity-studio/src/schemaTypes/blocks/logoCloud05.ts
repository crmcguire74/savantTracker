import { defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';
import { imageType } from '../elements/image';

export const logoCloud05Type = defineType({
  name: 'logoCloud05',
  title: 'Logo Cloud 05',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'logos',
      title: 'Logos',
      type: 'array',
      of: [
        defineField({
          name: 'logoItem',
          title: 'Logo Item',
          type: 'object',
          fields: [
            defineField({
              name: 'image',
              title: 'Image',
              type: imageType.name,
              validation: (rule) => rule.required(),
              description: 'The logo image',
            }),
          ],
          preview: {
            select: {
              title: 'image.alt',
            },
            prepare({ title }) {
              return {
                title: title || 'Logo Item',
              };
            },
          },
        }),
      ],
      validation: (rule) => rule.required().min(1),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Logo Cloud 05: ${title}`,
      };
    },
  },
});
