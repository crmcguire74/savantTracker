import { defineField, defineType } from 'sanity';

import { blockHeading } from '../elements/blockHeading';
import { buttonType } from '../elements/button';
import { imageType } from '../elements/image';

export const heroSection09Type = defineType({
  name: 'heroSection09',
  title: 'Hero Section 09',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'button',
      title: 'Button',
      type: buttonType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Hero Section 09: ${title}`,
      };
    },
  },
});
