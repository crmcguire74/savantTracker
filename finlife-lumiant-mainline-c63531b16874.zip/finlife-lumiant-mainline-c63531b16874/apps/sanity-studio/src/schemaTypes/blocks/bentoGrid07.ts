import { defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';

export const bentoGrid07 = defineType({
  name: 'bentoGrid07',
  title: 'Bento Grid 07',
  type: 'document',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'gridItems',
      title: 'Grid Items',
      type: 'array',
      of: [{ type: 'bentoGrid07Item' }, { type: 'bentoGridItem' }],
      validation: (rule) => rule.min(2).max(5), // Assuming 5 grid items based on the component
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Bento Grid 07: ${title}`,
      };
    },
  },
});
