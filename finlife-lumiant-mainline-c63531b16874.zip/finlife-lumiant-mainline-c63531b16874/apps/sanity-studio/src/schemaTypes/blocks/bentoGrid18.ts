import { defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';
import { iconNameType } from '../elements/iconName';
import { imageType } from '../elements/image';

const BADGE_COLOR_OPTIONS = [
  { title: 'Red', value: 'red' },
  { title: 'Green', value: 'green' },
  { title: 'Orange', value: 'orange' },
  { title: 'Yellow', value: 'yellow' },
  { title: 'Pink', value: 'pink' },
  { title: 'Purple', value: 'purple' },
  { title: 'Blue', value: 'blue' },
];

const fallingBadgeItem = defineType({
  name: 'bentoGrid18FallingBadgeItem',
  title: 'Falling Badge Item',
  type: 'object',
  fields: [
    defineField({
      name: 'text',
      title: 'Badge Text',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'colorOption',
      title: 'Badge Color',
      type: 'string',
      options: {
        list: BADGE_COLOR_OPTIONS,
        layout: 'dropdown',
      },
      validation: (rule) => rule.required(),
    }),
  ],
});

const fallingBadgeCard = defineType({
  name: 'bentoGrid18FallingBadgeCard',
  title: 'Falling Badge Card',
  type: 'object',
  fields: [
    defineField({
      name: 'iconName',
      title: 'Icon',
      type: iconNameType.name,
      description: 'Icon shown in the card header.',
      initialValue: 'NotebookTabs',
    }),
    defineField({
      name: 'title',
      title: 'Card Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      rows: 3,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'badges',
      title: 'Falling Badges',
      type: 'array',
      of: [{ type: 'bentoGrid18FallingBadgeItem' }],
      validation: (rule) => rule.required().min(1),
    }),
    defineField({
      name: 'modules',
      title: 'Modules',
      type: 'array',
      of: [{ type: 'string' }],
    }),
  ],
  preview: {
    select: {
      title: 'title',
    },
    prepare({ title }) {
      return {
        title: title ? `Falling Badges: ${title}` : 'Falling Badges',
      };
    },
  },
});

const dataTriangleCard = defineType({
  name: 'bentoGrid18DataTriangleCard',
  title: 'Values Triangle Card',
  type: 'object',
  fields: [
    defineField({
      name: 'iconName',
      title: 'Icon',
      type: iconNameType.name,
      description: 'Icon shown in the card header.',
      initialValue: 'NotebookTabs',
    }),
    defineField({
      name: 'title',
      title: 'Card Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      rows: 3,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'modules',
      title: 'Modules',
      type: 'array',
      of: [{ type: 'string' }],
    }),
  ],
  preview: {
    select: {
      title: 'title',
    },
    prepare({ title }) {
      return {
        title: title ? `Values Triangle: ${title}` : 'Values Triangle',
      };
    },
  },
});

const cardStackItem = defineType({
  name: 'bentoGrid18CardStackItem',
  title: 'Stack Card',
  type: 'object',
  fields: [
    defineField({
      name: 'iconName',
      title: 'Icon',
      type: iconNameType.name,
      description: 'Icon shown in the card header.',
      initialValue: 'NotebookTabs',
    }),
    defineField({
      name: 'image',
      title: 'Card Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'title',
      title: 'Card Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'href',
      title: 'Link URL',
      type: 'string',
      initialValue: '#',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'category',
      title: 'Category',
      type: 'string',
      description: 'e.g. "Family"',
      initialValue: 'Family',
    }),
    defineField({
      name: 'progress',
      title: 'Progress (%)',
      type: 'number',
      description: '0–100 for the circular progress indicator',
      validation: (rule) => rule.min(0).max(100),
      initialValue: 75,
    }),
    defineField({
      name: 'amountCurrent',
      title: 'Amount (current)',
      type: 'number',
      description: 'e.g. 24500 for $24,500',
    }),
    defineField({
      name: 'amountTarget',
      title: 'Amount (target)',
      type: 'number',
      description: 'e.g. 30000 for $30,000',
    }),
    defineField({
      name: 'tasksLeft',
      title: 'Tasks left',
      type: 'number',
      description: 'e.g. 3 for "3 Tasks left"',
    }),
    defineField({
      name: 'status',
      title: 'Status',
      type: 'string',
      description: 'e.g. "On Track"',
      initialValue: 'On Track',
    }),
  ],
  preview: {
    select: {
      title: 'title',
    },
    prepare({ title }) {
      return {
        title: title ? `Card Stack Item: ${title}` : 'Card Stack Item',
      };
    },
  },
});

const cardStackCard = defineType({
  name: 'bentoGrid18CardStackCard',
  title: 'Card Stack Card',
  type: 'object',
  fields: [
    defineField({
      name: 'iconName',
      title: 'Icon',
      type: iconNameType.name,
      description: 'Icon shown in the card header.',
      initialValue: 'NotebookTabs',
    }),
    defineField({
      name: 'title',
      title: 'Card Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      rows: 3,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'cards',
      title: 'Stack Cards',
      type: 'array',
      of: [{ type: 'bentoGrid18CardStackItem' }],
      validation: (rule) => rule.required().min(1),
    }),
    defineField({
      name: 'modules',
      title: 'Modules',
      type: 'array',
      of: [{ type: 'string' }],
    }),
  ],
  preview: {
    select: {
      title: 'title',
    },
    prepare({ title }) {
      return {
        title: title ? `Card Stack: ${title}` : 'Card Stack',
      };
    },
  },
});

export const bentoGrid18 = defineType({
  name: 'bentoGrid18',
  title: 'Bento Grid 18',
  type: 'document',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'gridItems',
      title: 'Grid Items',
      type: 'array',
      of: [
        { type: 'bentoGrid18DataTriangleCard' },
        { type: 'bentoGrid18CardStackCard' },
        { type: 'bentoGrid18FallingBadgeCard' },
      ],
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: title ? `Bento Grid 18: ${title}` : 'Bento Grid 18',
      };
    },
  },
});

export const bentoGrid18FallingBadgeItem = fallingBadgeItem;
export const bentoGrid18FallingBadgeCard = fallingBadgeCard;
export const bentoGrid18DataTriangleCard = dataTriangleCard;
export const bentoGrid18CardStackItem = cardStackItem;
export const bentoGrid18CardStackCard = cardStackCard;
