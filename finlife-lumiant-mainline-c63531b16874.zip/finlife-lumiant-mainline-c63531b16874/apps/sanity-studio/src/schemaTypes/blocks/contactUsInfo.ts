import { defineField, defineType } from 'sanity';

export const contactUsInfo = defineType({
  name: 'contactUsInfo',
  title: 'Contact Us Information',
  type: 'object',
  fields: [
    defineField({
      name: 'type',
      title: 'Type',
      type: 'string',
      options: {
        list: [
          { title: 'Mail', value: 'mail' },
          { title: 'Message', value: 'message' },
          { title: 'Phone', value: 'phone' },
        ],
      },
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'details',
      title: 'Details',
      type: 'blockContent',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'button',
      title: 'Button',
      type: 'button',
    }),
  ],
  preview: {
    select: {
      title: 'title',
      subtitle: 'description',
    },
    prepare({ title, subtitle }) {
      return {
        title: `Contact Info: ${title}`,
        subtitle: subtitle,
      };
    },
  },
});
