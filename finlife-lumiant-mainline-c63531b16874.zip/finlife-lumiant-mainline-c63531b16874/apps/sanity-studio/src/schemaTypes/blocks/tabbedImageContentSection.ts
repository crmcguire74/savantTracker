import { defineField, defineType } from 'sanity';
import { blockContent } from '../elements/blockContent';
import { blockHeading } from '../elements/blockHeading';
import { blockOptions } from '../elements/blockOptions';
import { buttonType } from '../elements/button';
import { imageType } from '../elements/image';

export const tabbedImageContentTab = defineType({
  name: 'tabbedImageContentTab',
  title: 'Tab',
  type: 'object',
  fields: [
    defineField({
      name: 'name',
      title: 'Tab Name',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'value',
      title: 'Tab Value',
      type: 'string',
      description: 'Unique value used by the tabs component (e.g. general, pricing).',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
    }),
    defineField({
      name: 'content',
      title: 'Content',
      type: blockContent.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'ctaButton',
      title: 'CTA Button',
      type: buttonType.name,
    }),
  ],
});

export const tabbedImageContentSection = defineType({
  name: 'tabbedImageContentSection',
  title: 'Tabbed image & content',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: blockOptions.name,
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'tabs',
      title: 'Tabs',
      type: 'array',
      of: [{ type: tabbedImageContentTab.name }],
      validation: (rule) => rule.required().min(1),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Tabbed image & content: ${title ?? 'Untitled'}`,
      };
    },
  },
});
