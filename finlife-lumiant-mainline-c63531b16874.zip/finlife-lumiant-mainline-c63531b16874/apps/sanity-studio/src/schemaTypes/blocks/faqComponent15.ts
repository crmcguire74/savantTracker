import { defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';
import { blockOptions } from '../elements/blockOptions';
import { imageType } from '../elements/image';

// from here
export const faqComponent15 = defineType({
  name: 'faqComponent15',
  title: 'FAQ Component 15',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: blockOptions.name,
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
    }),
    defineField({
      name: 'faqs',
      title: 'FAQs',
      type: 'array',
      of: [{ type: 'faqComponentItem' }],
      validation: (rule) => rule.required().min(1),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `FAQ Component 15: ${title}`,
      };
    },
  },
});

export const faqComponentItem = defineType({
  name: 'faqComponentItem',
  title: 'FAQ Component Item',
  type: 'object',
  fields: [
    defineField({
      name: 'question',
      title: 'Question',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'answer',
      title: 'Answer',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
  ],
});
