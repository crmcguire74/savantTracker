import { defineField, defineType } from 'sanity';
import { iconNameType } from '../elements/iconName';
import { imageType } from '../elements/image';

export const featuresSection26ProcessCard = defineType({
  name: 'featuresSection26ProcessCard',
  title: 'Process Card',
  type: 'object',
  fields: [
    defineField({
      name: 'iconName',
      title: 'Icon',
      type: iconNameType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      rows: 3,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'cardColor',
      title: 'Card colour',
      type: 'string',
      options: {
        list: [
          { title: 'Cyan', value: 'cyan' },
          { title: 'Violet', value: 'violet' },
          { title: 'Blue', value: 'blue' },
          { title: 'Amber', value: 'amber' },
        ],
        layout: 'dropdown',
      },
      initialValue: 'violet',
    }),
  ],
  preview: {
    select: {
      title: 'title',
      subtitle: 'description',
    },
    prepare({ title, subtitle }) {
      return {
        title: title || 'Process Card',
        subtitle: subtitle ? (subtitle as string).slice(0, 50) + (subtitle.length > 50 ? '…' : '') : undefined,
      };
    },
  },
});
