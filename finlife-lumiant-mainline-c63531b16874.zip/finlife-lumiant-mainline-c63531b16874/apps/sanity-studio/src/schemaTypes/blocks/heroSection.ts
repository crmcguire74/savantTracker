import { defineField, defineType } from 'sanity';

import { blockHeading } from '../elements/blockHeading';

export const heroSectionType = defineType({
  name: 'heroSection',
  title: 'Hero Section Simple',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Hero Section Simple: ${title}`,
      };
    },
  },
});
