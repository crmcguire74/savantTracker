import { defineField, defineType } from 'sanity';
import { blockContent } from '#app/schemaTypes/elements/blockContent';
import { blockHeading } from '#app/schemaTypes/elements/blockHeading';
import { buttonType } from '#app/schemaTypes/elements/button';
import { imageType } from '../elements/image';

export const aboutUsPage09 = defineType({
  name: 'aboutUsPage09',
  title: 'About Us Page 09',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'imageHeading',
      title: 'Image Heading',
      type: blockContent.name,
      validation: (rule) => rule.required(),
    }),

    defineField({
      name: 'cardImageLeft',
      title: 'Card Image Left',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),

    defineField({
      name: 'cardImageRight',
      title: 'Card Image Right',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),

    defineField({
      name: 'buttonPrimary',
      title: 'Button Primary',
      type: buttonType.name,
    }),
    defineField({
      name: 'buttonSecondary',
      title: 'Button Secondary',
      type: buttonType.name,
    }),
  ],
  preview: {
    select: {
      title: 'blockoptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: title ? `About Us Page 09: ${title}` : 'About Us Page 09',
      };
    },
  },
});
