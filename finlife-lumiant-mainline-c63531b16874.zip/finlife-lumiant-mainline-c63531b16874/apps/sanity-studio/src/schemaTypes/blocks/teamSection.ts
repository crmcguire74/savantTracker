import { defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';
import { blockOptions } from '../elements/blockOptions';
import { imageType } from '../elements/image';

export const teamSection = defineType({
  name: 'teamSection',
  title: 'Team Section',
  type: 'object',
  description: 'Center-aligned block header with a full-width team image below.',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: blockOptions.name,
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'teamImage',
      title: 'Team Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
      description: 'Full-width team photo displayed below the header.',
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Team Section: ${title}`,
      };
    },
  },
});
