import { defineField, defineType } from 'sanity';
import { iconNameType } from '../elements/iconName';

export const featuresSection03Feature = defineType({
  name: 'featuresSection03Feature',
  title: 'Feature Item (Section 03)',
  type: 'object',
  fields: [
    defineField({
      name: 'iconName',
      title: 'Icon Name',
      type: iconNameType.name,
      description: 'Icon name used to render the feature icon.',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      validation: (rule) => rule.required(),
    }),
  ],
});
