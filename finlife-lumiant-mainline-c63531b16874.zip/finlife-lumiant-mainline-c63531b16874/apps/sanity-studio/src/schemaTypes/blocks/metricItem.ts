import { defineField, defineType } from 'sanity';
import { imageType } from '../elements/image';

export const metricItem = defineType({
  name: 'metricItem',
  title: 'Metric Item',
  type: 'object',
  fields: [
    defineField({
      name: 'trendLabel',
      title: 'Trend',
      type: 'string',
      options: {
        list: [
          { title: 'Up', value: 'up' },
          { title: 'Down', value: 'down' },
          { title: 'Middle', value: 'middle' },
        ],
      },
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'trendValue',
      title: 'Trend Value',
      type: 'number',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'trendSuffix',
      title: 'Trend Suffix',
      type: 'string',
      options: {
        list: [
          { title: '%', value: '%' },
          { title: 'None', value: '' },
        ],
        layout: 'dropdown',
      },
      initialValue: '%',
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      description: 'Optional image to accompany the metric. Size appropriately.',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'content',
      title: 'Content',
      type: 'blockContent',
    }),
  ],
});
