import { defineField, defineType } from 'sanity';
import { featuresSection10Card } from './featuresSection10Card';

export const featuresSection10 = defineType({
  name: 'featuresSection10',
  title: 'Features Section 10',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: 'blockHeading',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'enterpriseCards',
      title: 'Enterprise Cards',
      type: 'array',
      of: [{ type: featuresSection10Card.name }],
      validation: (rule) => rule.required().min(3).max(3),
    }),
    defineField({
      name: 'advisorCards',
      title: 'Advisor Cards',
      type: 'array',
      of: [{ type: featuresSection10Card.name }],
      validation: (rule) => rule.required().min(3).max(3),
    }),
  ],
  preview: {
    select: {
      title: 'headings.title',
    },
    prepare({ title }) {
      return {
        title: title || 'Features Section 10',
        subtitle: 'Features Section',
      };
    },
  },
});
