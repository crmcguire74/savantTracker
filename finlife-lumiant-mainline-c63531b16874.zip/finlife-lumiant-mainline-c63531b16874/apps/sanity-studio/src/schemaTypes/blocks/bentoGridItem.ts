import { defineField, defineType } from 'sanity';
import { imageType } from '../elements/image';

export const bentoGridItem = defineType({
  name: 'bentoGridItem',
  title: 'Bento Grid Item',
  type: 'object',
  fields: [
    defineField({
      name: 'heading',
      title: 'Heading',
      type: 'blockContent',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'blockContent',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'useLumiantPortalDiagram',
      title: 'Lumiant Portal Diagram',
      description: 'Check this box to use Lumiant Portal Diagram instead of uploading an image.',
      type: 'boolean',
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'size',
      title: 'Size',
      type: 'number',
      initialValue: 3,
      options: {
        list: [
          { title: '1/3', value: 2 },
          { title: '1/2', value: 3 },
          { title: 'Full', value: 6 },
        ],
        layout: 'radio',
      },
    }),
  ],
});
