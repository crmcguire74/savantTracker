import { defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';
import { blockOptions } from '../elements/blockOptions';
import { imageType } from '../elements/image';
import { contactUsInfo } from './contactUsInfo';

export const contactUsPage10 = defineType({
  name: 'contactUsPage10',
  title: 'Contact Us Page 10',
  type: 'document',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: blockOptions.name,
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'contactInfo',
      title: 'Contact Information',
      type: 'array',
      of: [{ type: contactUsInfo.name }],
      validation: (rule) => rule.required().min(1).max(3),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Contact Us Page 10: ${title}`,
      };
    },
  },
});
