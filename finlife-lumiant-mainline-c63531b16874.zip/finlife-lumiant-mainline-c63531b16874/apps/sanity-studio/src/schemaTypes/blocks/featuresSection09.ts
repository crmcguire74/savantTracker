import { defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';
import { blockOptions } from '../elements/blockOptions';
import { iconNameType } from '../elements/iconName';
import { imageType } from '../elements/image';

export const featuresSection09Tab = defineType({
  name: 'featuresSection09Tab',
  title: 'Features Section 09 Tab',
  type: 'object',
  fields: [
    defineField({
      name: 'name',
      title: 'Tab title',
      type: 'string',
      description: 'Label displayed on the tab trigger.',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'value',
      title: 'Tab Value',
      type: 'string',
      description: 'Unique identifier used as the tab key (e.g. "upload-files").',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'iconName',
      title: 'Tab Icon',
      type: iconNameType.name,
      description: 'Lucide icon name rendered in the tab trigger (e.g. "UploadIcon").',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'content',
      title: 'Tab Content',
      type: 'object',
      fields: [
        defineField({
          name: 'title',
          title: 'Title',
          type: 'string',
          validation: (rule) => rule.required(),
        }),
        defineField({
          name: 'description',
          title: 'Description',
          type: 'string',
          validation: (rule) => rule.required(),
        }),
        defineField({
          name: 'subDescription',
          title: 'Description',
          type: 'string',
          validation: (rule) => rule.required(),
        }),
        defineField({
          name: 'buttonIconName',
          title: 'Button Icon',
          type: iconNameType.name,
          description: 'Lucide icon name shown in the avatar button (e.g. "UploadIcon").',
          validation: (rule) => rule.required(),
        }),
        defineField({
          name: 'documentationLink',
          title: 'Documentation Link',
          type: 'url',
          validation: (rule) => rule.required(),
        }),
        defineField({
          name: 'image',
          title: 'Image',
          type: imageType.name,
          validation: (rule) => rule.required(),
        }),
        defineField({
          name: 'buttonText',
          title: 'Button Text',
          type: 'string',
          validation: (rule) => rule.required(),
        }),
      ],
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      name: 'name',
      value: 'value',
    },
    prepare({ name, value }) {
      return {
        title: name ?? value,
      };
    },
  },
});

export const featuresSection09 = defineType({
  name: 'featuresSection09',
  title: 'Features Section 09',
  type: 'document',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: blockOptions.name,
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
    }),
    defineField({
      name: 'tabs',
      title: 'Tabs',
      type: 'array',
      of: [{ type: 'featuresSection09Tab' }],
      validation: (rule) => rule.required().min(1),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Features Section 09: ${title}`,
      };
    },
  },
});
