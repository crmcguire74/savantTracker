import { defineField, defineType } from 'sanity';

import { blockHeading } from '../elements/blockHeading';
import { iconNameType } from '../elements/iconName';

export const calendarSectionType = defineType({
  name: 'calendarSection',
  title: 'Calendar Section',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'cards',
      title: 'Left Cards',
      type: 'array',
      validation: (rule) => rule.required().min(4).max(4),
      of: [
        {
          type: 'object',
          fields: [
            defineField({
              name: 'iconName',
              title: 'Icon',
              type: iconNameType.name,
              validation: (rule) => rule.required(),
            }),
            defineField({
              name: 'title',
              title: 'Title',
              type: 'string',
              validation: (rule) => rule.required(),
            }),
            defineField({
              name: 'description',
              title: 'Description',
              type: 'string',
              validation: (rule) => rule.required(),
            }),
          ],
          preview: {
            select: { title: 'title', description: 'description' },
          },
        },
      ],
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Calendar Section: ${title}`,
      };
    },
  },
});
