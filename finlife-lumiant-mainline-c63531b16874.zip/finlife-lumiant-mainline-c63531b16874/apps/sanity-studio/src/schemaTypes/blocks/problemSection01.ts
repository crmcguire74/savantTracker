import { defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';
import { buttonType } from '../elements/button';
import { problemCardType } from './problemCard';

export const problemSection01Type = defineType({
  name: 'problemSection01',
  title: 'Problem Section 01',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'button',
      title: 'Button',
      type: buttonType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'problemCards',
      title: 'Problem Cards',
      type: 'array',
      of: [{ type: problemCardType.name }],
      validation: (rule) => rule.required().min(1),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Problem Section 01: ${title}`,
      };
    },
  },
});
