import { defineField, defineType } from 'sanity';

import { blockHeading } from '../elements/blockHeading';
import { buttonType } from '../elements/button';
import { imageType } from '../elements/image';

export const heroSection10Type = defineType({
  name: 'heroSection10',
  title: 'Hero Section 10',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'button',
      title: 'Button',
      type: buttonType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'showStats',
      title: 'Show Statistics Card',
      type: 'boolean',
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Hero Section 10: ${title}`,
      };
    },
  },
});
