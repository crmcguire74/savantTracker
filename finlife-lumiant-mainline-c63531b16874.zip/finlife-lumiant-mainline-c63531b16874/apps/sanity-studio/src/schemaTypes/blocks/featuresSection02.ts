import { defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';
import { buttonType } from '../elements/button';
import { iconNameType } from '../elements/iconName';

export const featuresSection02Card = defineType({
  name: 'featureSection02Card',
  title: 'Feature Section 02 Card',
  type: 'object',
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'blockContent',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'blockContent',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'iconName',
      title: 'Icon Name',
      type: iconNameType.name,
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      title: 'title',
      subtitle: 'iconName',
    },
  },
});

export const featuresSection02 = defineType({
  name: 'featuresSection02',
  title: 'Features Section 02',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'cards',
      title: 'Cards',
      type: 'array',
      of: [{ type: featuresSection02Card.name }],
      validation: (rule) => rule.required().min(1),
    }),
    defineField({
      name: 'checkpointsHeading',
      title: 'Checkpoints Heading',
      type: 'blockContent',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'checkpoints',
      title: 'Checkpoints',
      type: 'array',
      of: [{ type: 'string' }],
      validation: (rule) => rule.required().min(1),
    }),
    defineField({
      name: 'button',
      title: 'Button',
      type: buttonType.name,
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Features Section 02: ${title ?? 'Untitled'}`,
      };
    },
  },
});
