import { defineField, defineType } from 'sanity';

import { blockHeading } from '../elements/blockHeading';
import { buttonType } from '../elements/button';
import { imageType } from '../elements/image';

export const heroSection13Type = defineType({
  name: 'heroSection13',
  title: 'Hero Section 13',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'button',
      title: 'Button',
      type: buttonType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'metrics',
      title: 'Metrics',
      type: 'array',
      validation: (rule) => rule.required().min(1).max(3),
      of: [
        {
          type: 'object',
          fields: [
            defineField({
              name: 'value',
              title: 'Value',
              type: 'string',
              validation: (rule) => rule.required(),
            }),
            defineField({
              name: 'label',
              title: 'Label',
              type: 'string',
              validation: (rule) => rule.required(),
            }),
          ],
          preview: {
            select: { title: 'label', subtitle: 'value' },
          },
        },
      ],
    }),
    defineField({
      name: 'featureCards',
      title: 'Feature Cards',
      type: 'array',
      validation: (rule) => rule.required().min(1).max(3),
      of: [
        {
          type: 'object',
          fields: [
            defineField({
              name: 'title',
              title: 'Title',
              type: 'string',
              validation: (rule) => rule.required(),
            }),
            defineField({
              name: 'image',
              title: 'Image',
              type: imageType.name,
              validation: (rule) => rule.required(),
            }),
          ],
          preview: {
            select: { title: 'title' },
          },
        },
      ],
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Hero Section 13: ${title}`,
      };
    },
  },
});
