import { defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';

export const faqComponent13Item = defineType({
  name: 'faqComponent13Item',
  title: 'FAQ Item',
  type: 'object',
  fields: [
    defineField({
      name: 'question',
      title: 'Question',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'answer',
      title: 'Answer',
      type: 'text',
      rows: 4,
      validation: (rule) => rule.required(),
    }),
  ],
});

export const faqComponent13Tab = defineType({
  name: 'faqComponent13Tab',
  title: 'FAQ Tab',
  type: 'object',
  fields: [
    defineField({
      name: 'name',
      title: 'Tab Name',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'value',
      title: 'Tab Value',
      type: 'string',
      description: 'Unique value used by the tabs component (e.g. general, pricing).',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'faqs',
      title: 'FAQs',
      type: 'array',
      of: [{ type: faqComponent13Item.name }],
      validation: (rule) => rule.required().min(1),
    }),
  ],
});

export const faqComponent13 = defineType({
  name: 'faqComponent13',
  title: 'FAQ Component 13',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'tabs',
      title: 'Tabs',
      type: 'array',
      of: [{ type: faqComponent13Tab.name }],
      validation: (rule) => rule.required().min(1),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `FAQ Component 13: ${title ?? 'Untitled'}`,
      };
    },
  },
});
