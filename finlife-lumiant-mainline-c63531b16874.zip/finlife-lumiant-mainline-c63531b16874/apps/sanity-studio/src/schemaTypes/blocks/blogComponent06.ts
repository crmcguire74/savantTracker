import { defineField, defineType } from 'sanity';

import { blockHeading } from '../elements/blockHeading';
import { newsletterCardType } from './newsletterCard';

export const blogComponent06Type = defineType({
  name: 'blogComponent06',
  title: 'Blog Component 06',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'newsletterCard',
      title: 'Newsletter Card',
      type: newsletterCardType.name,
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `Blog Component 06: ${title}`,
      };
    },
  },
});
