import { defineField, defineType } from 'sanity';
import { buttonType } from '../elements/button';
import { featuresSection26Feature } from './featuresSection26Feature';

export const featuresSection26 = defineType({
  name: 'featuresSection26',
  title: 'Features Section 26',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: 'blockHeading',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'button',
      title: 'Button',
      type: buttonType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'features',
      title: 'Features',
      type: 'array',
      of: [{ type: featuresSection26Feature.name }],
      validation: (rule) => rule.required().min(1).max(6),
      description: 'Tabbed feature items (icon, title, description). Best with 3 items.',
    }),
  ],
  preview: {
    select: {
      badge: 'headings.badge',
    },
    prepare({ badge }) {
      return {
        title: badge || 'Features Section 26',
        subtitle: 'Features Section',
      };
    },
  },
});
