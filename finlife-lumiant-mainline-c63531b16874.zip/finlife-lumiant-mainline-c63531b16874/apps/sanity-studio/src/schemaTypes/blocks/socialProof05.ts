import { defineArrayMember, defineField, defineType } from 'sanity';
import { blockHeading } from '../elements/blockHeading';

// Card Type 1: Survey/Poll Card with Yes/No percentages
export const card01 = defineArrayMember({
  name: 'card01',
  title: 'Card 01',
  type: 'object',
  fields: [
    defineField({
      name: 'topText',
      title: 'Top Text',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'middleTextLg',
      title: 'Middle Text Large',
      type: 'string',
      description: 'e.g., "Loyal Customers"',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'lowerText',
      title: 'Lower Text',
      type: 'string',
      description: 'e.g., "That\'s You!"',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'badge',
      title: 'Badge',
      type: 'string',
      description: 'e.g., "#Cashback"',
    }),
    defineField({
      name: 'yesPercentage',
      title: 'Yes Percentage',
      type: 'number',
      validation: (rule) => rule.required().min(0).max(100),
    }),
    defineField({
      name: 'noPercentage',
      title: 'No Percentage',
      type: 'number',
      validation: (rule) => rule.required().min(0).max(100),
    }),
  ],
  preview: {
    select: {
      title: 'topText',
      yes: 'yesPercentage',
    },
    prepare({ title, yes }) {
      return {
        title: `Card 01: ${title || 'Untitled'}`,
        subtitle: `${yes}% Yes`,
      };
    },
  },
});

// Card Type 2
export const card02 = defineArrayMember({
  name: 'card02',
  title: 'Card 02',
  type: 'object',
  fields: [
    defineField({
      name: 'heading',
      title: 'Heading',
      type: 'string',
      description: 'e.g., "Our Latest Platform Updates"',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'includeOrnaments',
      title: 'Include Ornaments',
      type: 'boolean',
    }),
    defineField({
      name: 'stat1Value',
      title: 'Stat 1 Value',
      type: 'string',
      description: 'e.g., "350+"',
    }),
    defineField({
      name: 'stat1Label',
      title: 'Stat 1 Label',
      type: 'string',
      description: 'e.g., "Brand Ambassadors"',
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: 'image',
      options: {
        hotspot: true,
      },
    }),
  ],
  preview: {
    select: {
      title: 'heading',
      stat1: 'stat1Value',
      stat2: 'stat2Value',
    },
    prepare({ title, stat1, stat2 }) {
      return {
        title: `Card 02: ${title || 'Untitled'}`,
        subtitle: `${stat1} / ${stat2}`,
      };
    },
  },
});

// Card Type 3: Percentage stat with descriptive text
export const card03 = defineArrayMember({
  name: 'card03',
  title: 'Card 03',
  type: 'object',
  fields: [
    defineField({
      name: 'percentage',
      title: 'Percentage',
      type: 'string',
      description: 'e.g., "89%"',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'string',
      description: 'e.g., "Of New Users Earn Cashback On All Purchases!"',
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      percentage: 'percentage',
      description: 'description',
    },
    prepare({ percentage, description }) {
      return {
        title: `Card 03: ${percentage}`,
        subtitle: description,
      };
    },
  },
});

export const socialProof05 = defineType({
  name: 'socialProof05',
  title: 'Social Proof 05',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: 'blockOptions',
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),

    defineField({
      name: 'cards',
      title: 'Cards',
      type: 'array',
      of: [card01, card02, card03],
    }),
  ],
  preview: {
    select: {
      title: 'blockoptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: title ? `Social Proof 05: ${title}` : 'Social Proof 05',
      };
    },
  },
});
