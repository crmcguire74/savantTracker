import { defineField, defineType } from 'sanity';

import { blockHeading } from '../elements/blockHeading';
import { blockOptions } from '../elements/blockOptions';
import { buttonType } from '../elements/button';
import { imageType } from '../elements/image';

export const ctaSection14Type = defineType({
  name: 'ctaSection14',
  title: 'CTA Section 14',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: blockOptions.name,
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'button',
      title: 'Button',
      type: buttonType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'showKaaIcon',
      title: 'Show KAA icon',
      type: 'boolean',
      description: 'Display the KAA decorative icon in the bottom-left of the card.',
      initialValue: true,
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `CTA Section 14: ${title ?? 'Untitled'}`,
      };
    },
  },
});
