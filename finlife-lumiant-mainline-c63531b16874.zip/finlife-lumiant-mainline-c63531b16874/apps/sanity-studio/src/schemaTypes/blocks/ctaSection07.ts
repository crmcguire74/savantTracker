import { defineField, defineType } from 'sanity';
import { buttonType } from '#app/schemaTypes/elements/button';
import { blockHeading } from '../elements/blockHeading';
import { blockOptions } from '../elements/blockOptions';
import { imageType } from '../elements/image';

export const ctaSection07Type = defineType({
  name: 'ctaSection07',
  title: 'CTA Section 07',
  type: 'object',
  fields: [
    defineField({
      name: 'blockOptions',
      title: 'Block Options',
      type: blockOptions.name,
    }),
    defineField({
      name: 'headings',
      title: 'Headings',
      type: blockHeading.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'button',
      title: 'Button',
      type: buttonType.name,
    }),
    defineField({
      name: 'features',
      title: 'Features',
      type: 'array',
      of: [{ type: 'string' }],
      validation: (rule) => rule.required(),
    }),
  ],
  preview: {
    select: {
      title: 'blockOptions.sanityTitle',
    },
    prepare({ title }) {
      return {
        title: `CTA Section 07: ${title}`,
      };
    },
  },
});
