import { defineType } from 'sanity';

export const blogPostCategoryType = defineType({
  name: 'blogPostCategory',
  type: 'document',
  title: 'Blog Post Category',
  fields: [
    {
      name: 'title',
      type: 'string',
      title: 'Title',
      validation: (rule) => rule.required(),
    },
    {
      name: 'slug',
      type: 'slug',
      title: 'Slug',
      options: { source: 'title' },
      validation: (rule) => rule.required(),
    },
  ],
});
