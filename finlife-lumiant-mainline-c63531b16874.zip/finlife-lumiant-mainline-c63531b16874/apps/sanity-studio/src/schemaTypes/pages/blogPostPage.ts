import { PanelsTopLeft } from 'lucide-react';
import { defineField, defineType } from 'sanity';
import { heroSectionType } from '../blocks/heroSection';
import { blockHeading } from '../elements/blockHeading';
import { buttonType } from '../elements/button';
import { imageType } from '../elements/image';

export const blogPostPageType = defineType({
  name: 'blogPostPage',
  type: 'document',
  title: 'Blog Post',
  icon: PanelsTopLeft,
  fields: [
    defineField({
      name: 'title',
      title: 'Card Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'simpleHero',
      title: 'Simple Hero',
      type: heroSectionType.name,
    }),
    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'title',
        maxLength: 96,
      },
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'mainImage',
      title: 'Main Image',
      type: imageType.name,
      validation: (rule) => rule.required(),
    }),
    defineField({
      title: 'Categories',
      description: 'Select categories for this blog post',
      name: 'categories',
      type: 'array',
      of: [{ type: 'reference', to: [{ type: 'blogPostCategory' }] }],
      validation: (rule) => rule.required().min(1).unique(),
    }),
    defineField({
      name: 'readTime',
      title: 'Read Time (in minutes)',
      type: 'number',
      validation: (rule) => rule.required().min(1),
    }),
    defineField({
      name: 'postedOn',
      title: 'Posted on',
      type: 'datetime',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'content',
      title: 'Content',
      type: 'blockContent',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'pdfDownloads',
      title: 'PDF Downloads',
      description: 'Upload up to 5 PDFs to display at the end of this post.',
      type: 'array',
      of: [
        defineField({
          name: 'pdfDownload',
          title: 'PDF Download',
          type: 'object',
          fields: [
            defineField({
              name: 'title',
              title: 'Display Title',
              description: 'Optional title shown in the download list.',
              type: 'string',
            }),
            defineField({
              name: 'file',
              title: 'PDF File',
              type: 'file',
              options: {
                accept: '.pdf,application/pdf',
              },
              validation: (rule) => rule.required(),
            }),
          ],
          preview: {
            select: {
              title: 'title',
              subtitle: 'file.asset.originalFilename',
            },
            prepare: ({ title, subtitle }) => ({
              title: title || subtitle || 'PDF',
              subtitle: subtitle ? `File: ${subtitle}` : 'No file selected',
            }),
          },
        }),
      ],
      validation: (rule) => rule.max(5),
    }),
    defineField({
      name: 'author',
      title: 'Author',
      type: 'reference',
      to: [{ type: 'blogAuthor' }],
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'relatedPostsSection',
      title: 'Related Posts Section',
      type: 'object',
      fields: [
        defineField({
          name: 'headings',
          title: 'Headings',
          type: blockHeading.name,
        }),
        defineField({
          name: 'button',
          title: 'Button',
          type: buttonType.name,
        }),
        defineField({
          name: 'posts',
          title: 'Related Posts',
          type: 'array',
          of: [
            {
              type: 'reference',
              to: [{ type: 'blogPostPage' }],
            },
          ],
        }),
      ],
    }),
  ],
  preview: {
    select: {
      title: 'title',
      subtitle: 'slug.current',
    },
  },
});
