import type { StructureResolver } from 'sanity/structure';

export const structure: StructureResolver = (S) =>
  S.list()
    .title('Content')
    .items([
      S.listItem()
        .id('siteSettings')
        .schemaType('siteSettings')
        .title('Site Settings')
        .child(S.editor().id('siteSettings').schemaType('siteSettings').documentId('siteSettings')),
      S.divider(),
      S.listItem()
        .id('home')
        .schemaType('home')
        .title('Home')
        .child(S.editor().id('home').schemaType('home').documentId('home')),
      S.listItem()
        .id('blog')
        .schemaType('blog')
        .title('Blog')
        .child(S.editor().id('blog').schemaType('blog').documentId('blog')),
      S.documentTypeListItem('blogPostPage').title('Blog Posts'),
      S.documentTypeListItem('blogPostCategory').title('Blog Post Categories'),
      S.documentTypeListItem('page').title('Pages'),
      S.divider(),
      S.listItem()
        .title('Blocks')
        .id('blocks')
        .child(
          S.list()
            .title('Blocks')
            .items(
              S.documentTypeListItems().filter(
                // biome-ignore lint/style/noNonNullAssertion: <explanation>safe non-null assertion</explanation>
                (item) => item.getId() && !['page', 'siteSettings', 'home'].includes(item.getId()!),
              ),
            ),
        ),
    ]);
