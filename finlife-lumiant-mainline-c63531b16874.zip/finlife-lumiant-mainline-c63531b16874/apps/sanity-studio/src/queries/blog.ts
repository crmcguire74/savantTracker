import { defineQuery } from 'groq';

import { buttonGroqProjection } from './utils/buttonProjection';

export const blogPageQuery = defineQuery(`
  *[_type == "blog"][0] {
    _id,
    _type,
    simpleHero,
    blog,
    relatedPostsSection{
      ...,
      button ${buttonGroqProjection}
    },
    ctaSection{
      ...,
      button ${buttonGroqProjection}
    },
  }
`);
