import { defineQuery } from 'groq';

import { buttonGroqProjection } from './utils/buttonProjection';

export const pageQuery = defineQuery(`
  *[_type == "page" && slug.current == $slug][0] {
    _id,
    _type,
    title,
    slug,
    content[]{
      ...,
      button ${buttonGroqProjection},
      ctaButton ${buttonGroqProjection},
      buttonPrimary ${buttonGroqProjection},
      buttonSecondary ${buttonGroqProjection},
      advisorCards[]{ ..., button ${buttonGroqProjection} },
      enterpriseCards[]{ ..., button ${buttonGroqProjection} },
      cards[]{ ..., button ${buttonGroqProjection} },
      testimonials[]{ ..., button ${buttonGroqProjection} },
      contactInfo[]{ ..., button ${buttonGroqProjection} }
    }
  }
`);
