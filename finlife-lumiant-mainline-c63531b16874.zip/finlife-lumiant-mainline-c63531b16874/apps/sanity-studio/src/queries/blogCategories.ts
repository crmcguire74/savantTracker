import { defineQuery } from 'groq';

export const blogCategoriesQuery = defineQuery(`
  *[_type == "blogPostCategory"] {
    _id,
    title,
    slug,
  }
`);
