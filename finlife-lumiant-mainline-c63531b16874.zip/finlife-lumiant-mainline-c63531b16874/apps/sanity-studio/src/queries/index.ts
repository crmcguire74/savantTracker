import { blogPageQuery } from './blog';
import { blogCategoriesQuery } from './blogCategories';
import { blogPostQuery } from './blogPost';
import { blogPostsQuery, blogPostsSearchQuery, relatedBlogPostsQuery } from './blogPosts';
import { homePageQuery } from './home';
import { siteSettingsQuery } from './siteSettings';

export {
  blogCategoriesQuery,
  blogPageQuery,
  blogPostQuery,
  blogPostsQuery,
  blogPostsSearchQuery,
  homePageQuery,
  relatedBlogPostsQuery,
  siteSettingsQuery,
};
