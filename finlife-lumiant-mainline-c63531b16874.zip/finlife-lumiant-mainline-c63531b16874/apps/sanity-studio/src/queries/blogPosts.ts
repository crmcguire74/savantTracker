import { defineQuery } from 'groq';

const blogPostProjection = `{
    _id,
    _type,
    title,
    subtitle,
    slug,
    mainImage,
    categories[]->{title, slug},
    readTime,
    postedOn,
    content
  }`;

export const blogPostsQuery = defineQuery(`
  *[_type == "blogPostPage"] ${blogPostProjection}
`);

/** Related posts filtered by category slugs and excluding current slug. */
export const relatedBlogPostsQuery = defineQuery(`
  *[_type == "blogPostPage" && count(categories[]->slug.current[@ in $categorySlugs]) > 0]
    | order(postedOn asc)[0..2]
    ${blogPostProjection}
`);

/** Same as blogPostsQuery but filters by optional $searchTerm (title, subtitle). */
export const blogPostsSearchQuery = defineQuery(`
  *[_type == "blogPostPage" && (
    !defined($searchTerm) ||
    $searchTerm == "" ||
    title match "*" + $searchTerm + "*" ||
    (defined(subtitle) && subtitle match "*" + $searchTerm + "*")
  )] ${blogPostProjection}
`);
