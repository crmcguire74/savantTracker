import { defineQuery } from 'groq';

import { buttonGroqProjection, siteLinkInternalHrefSelectArms } from './utils/buttonProjection';

export const siteSettingsQuery = defineQuery(`
  *[_type == "siteSettings"][0]{
    _id,
    title,
    description,
    header{
      logo{
        asset->{
          _id,
          url,
          metadata{ lqip, dimensions{ width, height, aspectRatio } }
        },
        alt,
        hotspot
      },
      darkLogo{
        asset->{
          _id,
          url,
          metadata{ lqip, dimensions{ width, height, aspectRatio } }
        },
        alt,
        hotspot
      },
      mainNav[]{
        _key,
        label,
        type,
        newTab,
        "href": select(
          ${siteLinkInternalHrefSelectArms},
          type == "external" => externalUrl
        )
      },
      ctaButtons[]${buttonGroqProjection}
    },
    footer{
      description[],
      logo{
        asset->{
          _id,
          url,
          metadata{ lqip, dimensions{ width, height, aspectRatio } }
        },
        alt,
        hotspot
      },
      darkLogo{
        asset->{
          _id,
          url,
          metadata{ lqip, dimensions{ width, height, aspectRatio } }
        },
        alt,
        hotspot
      },
      companyLinks[]{
        _key,
        label,
        type,
        newTab,
        "href": select(
          ${siteLinkInternalHrefSelectArms},
          type == "external" => externalUrl
        )
      },
      helpLinks[]{
        _key,
        label,
        type,
        newTab,
        "href": select(
          ${siteLinkInternalHrefSelectArms},
          type == "external" => externalUrl
        )
      },
      socialLinks[]{
        _key,
        platform,
        link{
          label,
          type,
          newTab,
          "href": select(
            ${siteLinkInternalHrefSelectArms},
            type == "external" => externalUrl
          )
        }
      },
      brandLogos[]{
        _key,
        alt,
        src{
          asset->{
            _id,
            url,
            metadata{ dimensions{ width, height, aspectRatio } }
          }
        },
        link{
          label,
          type,
          newTab,
          "href": select(
            ${siteLinkInternalHrefSelectArms},
            type == "external" => externalUrl
          )
        }
      },
      copyrightOwner
    },
    hubspotContactForm{
      portalId,
      formId,
      region
    },
    hubspotNewsletterForm{
      portalId,
      formId,
      region
    },
    hubspotSchedulerEmbedUrl
  }
`);
