/**
 * GROQ `select` arms: internal button links resolve to path segments (no leading slash).
 * Blog categories use the same URL shape as tag pages (`/blog/tag/:slug`).
 */
export const siteLinkInternalHrefSelectArms = `
          type == "internal" && internalRef->_type == "blogPostCategory" => "blog/tag/" + internalRef->slug.current,
          type == "internal" => internalRef->slug.current`;

/**
 * GROQ sub-projection for `button` objects: keeps all fields and resolves internal link targets to `slug`.
 * Interpolate after `button`, `ctaButton`, or array items whose `_type` is `button`, e.g.
 * `button ${buttonGroqProjection}` or `ctaButtons[]${buttonGroqProjection}`.
 */
export const buttonGroqProjection = `{
  ...,
  link[]{
    ...,
    "slug": select(
      _type == "internalLink" && internalReference->_type == "blogPostCategory" => "blog/tag/" + internalReference->slug.current,
      _type == "internalLink" => internalReference->slug.current
    )
  }
}`;
