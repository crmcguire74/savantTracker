import { defineQuery } from 'groq';

import { buttonGroqProjection } from './utils/buttonProjection';

export const blogPostQuery = defineQuery(`
  *[_type == "blogPostPage" && slug.current == $slug][0] {
    _id,
    _type,
    title,
    simpleHero,
    subtitle,
    slug,
    mainImage,
    categories[]->{title, slug},
    readTime,
    postedOn,
    content,
    pdfDownloads[]{
      _key,
      title,
      file{
        asset->{
          _id,
          url,
          originalFilename
        }
      }
    },
    author->{
      name,
      slug,
      image,
      bio,
      website,
      email,
      socialLinks
    },
    relatedPostsSection {
      headings,
      button ${buttonGroqProjection},
      posts[]->{
        _id,
        _type,
        title,
        subtitle,
        slug,
        mainImage,
        categories[]->{title, slug},
        readTime,
        postedOn,
        content
      }
    }
  }
`);
