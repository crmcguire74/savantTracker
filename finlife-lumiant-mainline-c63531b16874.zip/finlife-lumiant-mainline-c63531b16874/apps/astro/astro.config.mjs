import node from '@astrojs/node';
import partytown from '@astrojs/partytown';
import react from '@astrojs/react';
import sanity from '@sanity/astro';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig } from 'astro/config';
import { loadEnv } from 'vite';
import svgr from 'vite-plugin-svgr';

const env = loadEnv(process.env.NODE_ENV, process.cwd(), '');

// https://astro.build/config
export default defineConfig({
  // ...(process.env.PUBLIC_SANITY_VISUAL_EDITING_ENABLED === 'true' ||
  // env.PUBLIC_SANITY_VISUAL_EDITING_ENABLED === 'true'
  //   ? {
  //       output: 'server',
  //       adapter: node({
  //         mode: 'standalone',
  //       }),
  //     }
  //   : {
  //       output: 'static',
  //     }),
  output: 'static',
  vite: {
    plugins: [svgr(), tailwindcss()],
  },
  integrations: [
    partytown({
      config: {
        forward: ['dataLayer.push'],
      },
    }),
    sanity({
      projectId:
        process.env.SANITY_PROJECT_ID || env.SANITY_PROJECT_ID || 'ykpuh3ur',
      dataset: process.env.SANITY_DATASET || env.SANITY_DATASET || 'develop',
      useCdn: false,
      apiVersion:
        process.env.SANITY_API_VERSION ||
        env.SANITY_API_VERSION ||
        '2024-06-07',
      stega: {
        studioUrl:
          process.env.SANITY_STUDIO_URL ||
          env.SANITY_STUDIO_URL ||
          'https://lumiant-dev.sanity.studio',
      },
    }),
    react(),
  ],
});
