import type { PortableTextComponents } from '@portabletext/react';
import { CircleCheck } from 'lucide-react';

const headerPortableTextComponents: PortableTextComponents = {
  types: {
    // Add more custom types as needed
    // e.g. code, video, etc.
  },
  marks: {
    strong: ({ children }) => <strong>{children}</strong>,
    em: ({ children }) => <em style={{ fontStyle: 'italic', color: '#1b6ca8' }}>{children}</em>,
    primary: ({ children }) => <span className="text-primary">{children}</span>,
    secondary: ({ children }) => <span className="text-secondary">{children}</span>,
    gradient: ({ children }) => <span className="bg-feature-gradient text-transparent bg-clip-text">{children}</span>,
    // Add more custom marks as needed
  },
  block: {
    normal: ({ children }) => <h2 className="text-2xl font-semibold md:text-3xl lg:text-4xl">{children}</h2>,
    h1: ({ children }) => (
      <h1 className="text-3xl leading-[1.29167] text-balance sm:text-4xl lg:text-5xl">{children}</h1>
    ),
    '5xl': ({ children }) => <h1 className="font-bold text-5xl tracking-normal font-sans">{children}</h1>,
    body: ({ children }) => <p className="text-md font-regular">{children}</p>,
    // Add more custom blocks as needed
  },
  list: {
    'circle-check': ({ children }) => <ul className="m-0 list-none space-y-4 p-0">{children}</ul>,
  },
  listItem: {
    'circle-check': ({ children }) => (
      <li className="flex items-start gap-3">
        <CircleCheck className="text-muted-foreground mt-0.5 size-5 shrink-0" strokeWidth={1.5} aria-hidden />
        <span className="min-w-0 flex-1 leading-relaxed">{children}</span>
      </li>
    ),
  },
};

export { headerPortableTextComponents };
