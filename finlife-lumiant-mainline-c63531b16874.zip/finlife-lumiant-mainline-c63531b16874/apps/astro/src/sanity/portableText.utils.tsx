import type { PortableTextComponents } from '@portabletext/react';
import { CircleCheck } from 'lucide-react';

import { urlForImage } from './sanity.utils';

const portableTextComponents: PortableTextComponents = {
  types: {
    image: ({ value }) => {
      const url = urlForImage(value).url();
      const webpUrl = urlForImage(value).format('webp').url();

      return (
        <picture>
          <source srcSet={webpUrl} type="image/webp" />
          <img className="responsive__img" src={url} alt={value.alt} />
        </picture>
      );
    },
    blogQuote: ({ value }) => (
      <div className="flex flex-col items-start gap-4 py-5">
        {value?.quoteHeading && <h1 className="font-medium text-xl text-foreground">{value.quoteHeading}</h1>}
        <div className="flex items-stretch gap-10">
          <div className="w-2 shrink-0 bg-feature-gradient" />
          <blockquote className="bg-feature-gradient text-transparent bg-clip-text text-xl font-light">
            {value?.quote}
          </blockquote>
        </div>
      </div>
    ),
    // Add more custom types as needed
    // e.g. code, video, etc.
  },
  marks: {
    strong: ({ children }) => <strong>{children}</strong>,
    em: ({ children }) => <em style={{ fontStyle: 'italic', color: '#1b6ca8' }}>{children}</em>,
    link: ({ children, value }) => (
      <a href={value?.href} target="_blank" rel="noopener noreferrer" className="underline text-blue-600">
        {children}
      </a>
    ),
    primary: ({ children }) => <span className="text-primary">{children}</span>,
    secondary: ({ children }) => <span className="text-secondary">{children}</span>,
    light: ({ children }) => <span className="font-light">{children}</span>,
    gradient: ({ children }) => (
      <span className="bg-feature-gradient font-semibold text-transparent bg-clip-text">{children}</span>
    ),
    muted: ({ children }) => <span className="text-muted-foreground">{children}</span>,
    // Add more custom marks as needed
  },
  block: {
    normal: ({ children }) => <p className="mb-4">{children}</p>,
    span: ({ children }) => <span>{children}</span>,
    small: ({ children }) => <p className="text-sm">{children}</p>,
    h1: ({ children }) => <h1 className="font-bold text-2xl">{children}</h1>,
    h2: ({ children }) => <h2 className="font-semibold text-xl">{children}</h2>,
    h3: ({ children }) => <h3 className="font-semibold text-lg">{children}</h3>,
    blockquote: ({ children }) => (
      <blockquote className="pl-4 text-2xl text-center font-light">
        <span className="italic">“</span>
        {children}
        <span className="italic">”</span>
      </blockquote>
    ),
    blogH2: ({ children }) => <h2 className="text-xl text-foreground">{children}</h2>,
    blogText: ({ children }) => <p className="text-xl text-muted-foreground">{children}</p>,

    // Add more custom blocks as needed
  },
  list: {
    bullet: ({ children }) => <ul className="pl-6 list-disc">{children}</ul>,
    number: ({ children }) => <ol className="pl-6 list-decimal">{children}</ol>,
    'circle-check': ({ children }) => <ul className="m-0 list-none space-y-4 p-0">{children}</ul>,
  },
  listItem: {
    bullet: ({ children }) => <li className="mb-2">{children}</li>,
    number: ({ children }) => <li className="mb-2">{children}</li>,
    'circle-check': ({ children }) => (
      <li className="flex items-start gap-3">
        <CircleCheck className="text-muted-foreground mt-0.5 size-5 shrink-0" strokeWidth={1.5} aria-hidden />
        <span className="min-w-0 flex-1 leading-relaxed">{children}</span>
      </li>
    ),
  },
};

export { portableTextComponents };
