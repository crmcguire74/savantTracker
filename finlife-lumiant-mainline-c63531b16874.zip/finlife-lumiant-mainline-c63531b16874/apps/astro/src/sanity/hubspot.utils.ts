import type { HubspotEmbeddedForm } from '@local/sanity-studio/sanity.types';
import { stegaClean } from '@sanity/client/stega';

export type HubspotEmbedFields = Pick<HubspotEmbeddedForm, 'portalId' | 'formId' | 'region'>;

/** Maps Sanity hubspot embedded form fields for the Astro app; strips stega and drops incomplete configs. */
export function hubspotFormFromSanity(
  form: { portalId?: string | null; formId?: string | null; region?: string | null } | null | undefined,
): HubspotEmbedFields | undefined {
  if (!form?.portalId || !form?.formId) return undefined;
  const regionRaw = form.region;
  return {
    portalId: stegaClean(form.portalId),
    formId: stegaClean(form.formId),
    region: regionRaw != null && regionRaw !== '' ? stegaClean(regionRaw) : undefined,
  };
}

export function hubspotSchedulerUrlFromSanity(url: string | null | undefined): string | undefined {
  if (!url) return undefined;
  const cleaned = stegaClean(url);
  return cleaned || undefined;
}
