import { sanityClient } from 'sanity:client';
import type { SanityAsset } from '@sanity/image-url';
import { createImageUrlBuilder } from '@sanity/image-url';
import type { QueryParams } from 'sanity';

export type SiteLink = {
  label: string;
  href: string;
  newTab?: boolean;
};

const loadQuery = async <T>({
  query,
  params = {},
  excludeFromPreview,
}: {
  query: string;
  params?: QueryParams;
  excludeFromPreview?: boolean;
}) => {
  const visualEditingEnabled = import.meta.env.PUBLIC_SANITY_VISUAL_EDITING_ENABLED === 'true';
  const token = import.meta.env.SANITY_API_READ_TOKEN;

  if (visualEditingEnabled && !token) {
    throw new Error('The `SANITY_API_READ_TOKEN` environment variable is required during Visual Editing.');
  }

  const enabled = visualEditingEnabled && !excludeFromPreview;

  const perspective = enabled ? 'previewDrafts' : 'published';

  const { result, resultSourceMap } = await sanityClient.fetch<T>(query, params, {
    filterResponse: false,
    perspective,
    resultSourceMap: enabled ? 'withKeyArraySelector' : false,
    stega: enabled,
    ...(enabled ? { token } : {}),
  });

  return {
    data: result,
    sourceMap: resultSourceMap,
    perspective,
  };
};

const urlForImage = (source: SanityAsset) => {
  const builder = createImageUrlBuilder(sanityClient);
  return builder.image(source);
};

const getLogo = ({ asset, alt }: { asset?: unknown; alt?: string }) => {
  return asset
    ? {
        asset: asset as SanityAsset,
        alt,
      }
    : undefined;
};

export { getLogo, loadQuery, urlForImage };
