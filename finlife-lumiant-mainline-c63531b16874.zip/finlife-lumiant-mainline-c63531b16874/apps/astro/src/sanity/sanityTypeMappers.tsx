import type {
  BlockHeading,
  BlockOptions,
  BlogPostsQueryResult,
  Button,
  ImageBlock,
} from '@local/sanity-studio/sanity.types';
import type { ButtonType } from '@local/ui/components/ui/button';
import type { PortableTextBlock } from '@portabletext/react';
import { stegaClean } from '@sanity/client/stega';
import { format } from 'date-fns/format';
import type { SectionOptions } from '#app/components/section/section';
import type { BlockHeaderType } from '#app/components/shadcn-studio/block-header/BlockHeader';
import type { BlogComponent06Card } from '#app/components/shadcn-studio/blocks/blog-component-06/blog-component-06';
import type { ImageType } from '#app/components/shadcn-studio/elements/image';
import { urlForImage } from './sanity.utils';

const mapButtonVariant = (variant?: string | null): ButtonType['variant'] => {
  if (!variant || variant === 'primary') return 'default';
  return variant as ButtonType['variant'];
};

/** Site path from a slug segment (leading slash; no change to full URLs). */
function hrefForStoredLink(first: Button['link'][number] | undefined): string {
  if (!first) return '#';
  if (first._type === 'externalLink') {
    const url = stegaClean(first.url ?? '');
    return url || '#';
  }
  if (first._type === 'internalLink') {
    const withSlug = first as typeof first & { slug?: string | null };
    const slug = withSlug.slug != null ? stegaClean(String(withSlug.slug)).trim() : '';
    if (slug) {
      const trimmed = slug.replace(/^\/+|\/+$/g, '');
      return trimmed ? `/${trimmed}` : '#';
    }
    return withSlug.internalReference?._ref || '#';
  }
  return '#';
}

export const sanityButtonMapper = (sanityButton?: Button | null): ButtonType => {
  return {
    label: sanityButton?.label || '',
    link: hrefForStoredLink(sanityButton?.link?.[0]),
    variant: mapButtonVariant(sanityButton?.variant as string | null),
  };
};

export const sanityImageMapper = (sanityImage: ImageBlock): ImageType => {
  if (!sanityImage) {
    return {
      src: '',
      alt: '',
    };
  }

  // Some Sanity images may only have a `dark.asset` (no top-level `asset`), which causes
  // `urlForImage(sanityImage)` to throw. We resolve each variant defensively.
  let src = '';
  let darkSrc: string | undefined;

  try {
    src = urlForImage(sanityImage)?.url() ?? '';
  } catch {
    src = '';
  }

  try {
    darkSrc = sanityImage.dark ? urlForImage(sanityImage.dark)?.url() : undefined;
  } catch {
    darkSrc = undefined;
  }

  // If light src can't be resolved but dark can, use dark as a fallback for `src`.
  if (!src && darkSrc) src = darkSrc;

  return {
    src,
    darkSrc,
    alt: sanityImage.alt || '',
  };
};

export const sanityHeadingsMapper = (sanityHeaders?: BlockHeading | null): BlockHeaderType => ({
  badge: sanityHeaders?.badge || '',
  heading: (sanityHeaders?.heading || []) as PortableTextBlock[],
  description: (sanityHeaders?.description || []) as PortableTextBlock[],
});

export const sanityBlockOptionsMapper = (sanityBlockOptions?: BlockOptions): SectionOptions => ({
  backgroundColor: stegaClean(sanityBlockOptions?.bgColour) || 'default',
});

export const sanityBlogPostToCardMapper = (posts: BlogPostsQueryResult): BlogComponent06Card[] =>
  posts.map((post) => {
    const postedOnDate = format(new Date(post.postedOn), 'MMM d');

    return {
      image: sanityImageMapper(post.mainImage),
      categories: post.categories.map(({ title, slug }) => ({
        title,
        slug: slug.current,
      })),
      title: post.title,
      date: postedOnDate,
      blogLink: `/blog/post/${post.slug.current}`,
    };
  });
