import type { APIRoute } from 'astro';

export const GET: APIRoute = ({ cookies, redirect, url }) => {
  cookies.delete('sanity-preview', { path: '/' });

  // Redirect back to the referring page or home
  const redirectTo = url.searchParams.get('redirect') || '/';
  return redirect(redirectTo);
};
