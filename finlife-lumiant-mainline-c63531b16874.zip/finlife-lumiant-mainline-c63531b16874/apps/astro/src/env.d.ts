/// <reference path="../.astro/types.d.ts" />
/// <reference types="astro/client" />
/// <reference types="@sanity/astro/module" />

interface ImportMetaEnv {
  readonly SANITY_PROJECT_ID: string;
  readonly SANITY_DATASET: string;
  readonly SANITY_API_VERSION: string;
  readonly SANITY_API_READ_TOKEN?: string;
  readonly PUBLIC_SANITY_VISUAL_EDITING_ENABLED: 'true' | 'false';
  readonly SANITY_STUDIO_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
