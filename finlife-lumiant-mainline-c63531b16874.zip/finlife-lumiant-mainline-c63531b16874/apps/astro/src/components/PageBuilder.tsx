import type {
  BlockHeading,
  BlockOptions,
  Button,
  PageBuilder as SanityPageBuilder,
} from '@local/sanity-studio/sanity.types';
import { stegaClean } from '@sanity/client/stega';
import { Fragment } from 'react';
import AboutUsPage06 from '#app/components/shadcn-studio/blocks/about-us-page-06';
import BentoGrid07Component from '#app/components/shadcn-studio/blocks/bento-grid-07/bento-grid-07';
import BentoGrid18Component from '#app/components/shadcn-studio/blocks/bento-grid-18/bento-grid-18';
import FeaturesSection02, {
  type FeaturesSection02Props,
} from '#app/components/shadcn-studio/blocks/features-section-02/features-section-02';
import FeaturesSection08Component from '#app/components/shadcn-studio/blocks/features-section-08/features-section-08';
import type { HubspotEmbedFields } from '#app/sanity/hubspot.utils';
import { urlForImage } from '#app/sanity/sanity.utils';
import {
  sanityBlockOptionsMapper,
  sanityButtonMapper,
  sanityHeadingsMapper,
  sanityImageMapper,
} from '#app/sanity/sanityTypeMappers';
import CalendarSection from './custom/calendar-section/calendar-section';
import HeroSection from './custom/hero-section/hero-section';
import TabbedImageContentSection from './custom/tabbed-image-content-section/tabbed-image-content-section';
import AboutUsPage09 from './shadcn-studio/blocks/about-us-page-09';
import ContactUs from './shadcn-studio/blocks/contact-us-page-10';
import type { ContactUsInfoType } from './shadcn-studio/blocks/contact-us-page-10/contact-us-info';
import CTASection07 from './shadcn-studio/blocks/cta-section-07';
import CTASection08 from './shadcn-studio/blocks/cta-section-09';
import CTASection14 from './shadcn-studio/blocks/cta-section-14';
import FAQComponent13 from './shadcn-studio/blocks/faq-component-13/faq-component-13';
import FAQComponent15 from './shadcn-studio/blocks/faq-component-15/faq-component-15';
import FeaturesSection03 from './shadcn-studio/blocks/features-section-03/features-section-03';
import FeaturesSection09 from './shadcn-studio/blocks/features-section-09';
import FeaturesSection10 from './shadcn-studio/blocks/features-section-10/features-section-10';
import FeaturesSection26 from './shadcn-studio/blocks/features-section-26/features-section-26';
import HeroSection09 from './shadcn-studio/blocks/hero-section-09/hero-section-09';
import HeroSection10 from './shadcn-studio/blocks/hero-section-10/hero-section-10';
import HeroSection13 from './shadcn-studio/blocks/hero-section-13/hero-section-13';
import LogoCloud05Component from './shadcn-studio/blocks/logo-cloud-05/logo-cloud-05';
import ProblemSection01 from './shadcn-studio/blocks/problem-section-01';
import SocialProof05, { type SocialProof05Props } from './shadcn-studio/blocks/social-proof-05';
import TeamSectionBlock from './shadcn-studio/blocks/team-section/team-section';
import Team1 from './shadcn-studio/blocks/team1';
import TestimonialsComponent from './shadcn-studio/blocks/testimonials-component-01';

/**
 * Scaffold component to render page builder blocks.
 */
type Props = {
  blocks: SanityPageBuilder;
  hubspotContactForm?: HubspotEmbedFields | null;
  hubspotSchedulerEmbedUrl?: string | null;
};

const PageBuilder = ({ blocks, hubspotContactForm, hubspotSchedulerEmbedUrl }: Props) => {
  if (!blocks || blocks.length === 0) {
    return <div>No content blocks</div>;
  }
  return (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      {blocks.map((block) => {
        switch (block._type) {
          case 'heroSection':
            return (
              <Fragment key={block._key}>
                {block.headings && (
                  <HeroSection
                    sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                    headings={sanityHeadingsMapper(block.headings)}
                  />
                )}
              </Fragment>
            );
          case 'heroSection09':
            return (
              <Fragment key={block._key}>
                {block.headings && (
                  <HeroSection09
                    sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                    headings={sanityHeadingsMapper(block.headings)}
                    image={sanityImageMapper(block.image)}
                    button={sanityButtonMapper(block.button)}
                  />
                )}
              </Fragment>
            );
          case 'heroSection10':
            return (
              <Fragment key={block._key}>
                {block.headings && (
                  <HeroSection10
                    sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                    headings={sanityHeadingsMapper(block.headings)}
                    image={sanityImageMapper(block.image)}
                    button={sanityButtonMapper(block.button)}
                    showStats={block.showStats || false}
                  />
                )}
              </Fragment>
            );
          case 'heroSection13':
            return (
              <Fragment key={block._key}>
                {block.headings && (
                  <HeroSection13
                    sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                    headings={sanityHeadingsMapper(block.headings)}
                    image={sanityImageMapper(block.image)}
                    button={sanityButtonMapper(block.button)}
                    metrics={
                      block.metrics?.map((metric) => ({
                        value: metric.value || '',
                        label: metric.label || '',
                      })) || []
                    }
                    featureCards={
                      block.featureCards?.map((card) => ({
                        title: card.title || '',
                        image: sanityImageMapper(card.image),
                      })) || []
                    }
                  />
                )}
              </Fragment>
            );
          case 'calendarSection': {
            type CalendarCard = { iconName: string; title?: string; description?: string };
            type CalendarBlock = {
              _key?: string;
              headings?: BlockHeading;
              blockOptions?: BlockOptions;
              cards?: CalendarCard[];
            };

            const calendarBlock = block as CalendarBlock;
            return (
              <Fragment key={calendarBlock._key}>
                {calendarBlock.headings && (
                  <CalendarSection
                    sectionOptions={sanityBlockOptionsMapper(calendarBlock.blockOptions)}
                    headings={sanityHeadingsMapper(calendarBlock.headings)}
                    cards={(calendarBlock.cards || []).map((card) => ({
                      iconName: stegaClean(card.iconName),
                      title: card.title || '',
                      description: card.description || '',
                    }))}
                    hubspotSchedulerEmbedUrl={hubspotSchedulerEmbedUrl}
                  />
                )}
              </Fragment>
            );
          }
          case 'featuresSection02':
            return (
              <FeaturesSection02
                key={block._key}
                headings={sanityHeadingsMapper(block.headings)}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                cards={
                  (block.cards.map((card) => ({
                    ...card,
                    iconName: stegaClean(card.iconName),
                  })) || []) as FeaturesSection02Props['cards']
                }
                checkpoints={block.checkpoints}
                checkpointsHeading={block.checkpointsHeading}
                button={sanityButtonMapper(block.button)}
              />
            );

          case 'socialProof05':
            return (
              <SocialProof05
                key={block._key}
                headings={sanityHeadingsMapper(block.headings)}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                cards={(block.cards || []) as SocialProof05Props['cards']}
              />
            );
          case 'bentoGrid07':
            return (
              <BentoGrid07Component
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                gridItems={
                  block.gridItems?.map((item) => {
                    return {
                      // _key: item._key,
                      title: item.heading,
                      description: item.description,
                      image: sanityImageMapper(item.image),
                      span: item.size,
                      useLumiantPortalDiagram: item.useLumiantPortalDiagram || false,
                    };
                  }) || []
                }
              />
            );
          case 'bentoGrid18':
            return (
              <BentoGrid18Component
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                gridItems={
                  block.gridItems?.map((item) => {
                    switch (item._type) {
                      case 'bentoGrid18FallingBadgeCard':
                        return {
                          type: 'fallingBadge',
                          title: item.title,
                          description: item.description,
                          modules: item.modules || undefined,
                          iconName: item.iconName || 'NotebookTabs',
                          badges: item.badges.map(({ colorOption, ...b }) => ({
                            ...b,
                            colorOption: stegaClean(colorOption),
                          })),
                        };
                      case 'bentoGrid18CardStackCard':
                        return {
                          type: 'cardStack',
                          title: item.title,
                          description: item.description,
                          modules: item.modules || undefined,
                          iconName: item.iconName || 'NotebookTabs',
                          cardsData: item.cards.map(({ image, ...c }, i) => ({
                            id: i,
                            image: sanityImageMapper(image),
                            ...c,
                          })),
                        };
                      default:
                        return {
                          type: 'dataTriangle',
                          title: item.title,
                          description: item.description,
                          modules: item.modules || undefined,
                          iconName: item.iconName || 'NotebookTabs',
                        };
                    }
                  }) || []
                }
              />
            );
          case 'featuresSection08':
            return (
              <FeaturesSection08Component
                key={block._key}
                tagline={block.tagline || ''}
                mainTitle={block.mainTitle || ''}
                mainDescription={block.mainDescription || ''}
                buttonText={block.buttonText || ''}
                buttonLink={block.buttonLink || '#'}
                features={
                  block.features?.map((item) => ({
                    title: item.title || '',
                    description: item.description || '',
                    iconName: item.iconName || '',
                    color: item.color || '',
                  })) || []
                }
              />
            );
          case 'featuresSection09':
            return (
              <FeaturesSection09
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                image={sanityImageMapper(block.image)}
                tabs={
                  block.tabs?.map((tab) => ({
                    ...tab,
                    content: {
                      ...tab.content,
                      image: sanityImageMapper(tab.content.image),
                    },
                  })) || []
                }
              />
            );
          case 'faqComponent13':
            return (
              <FAQComponent13
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                tabs={
                  block.tabs?.map((tab) => ({
                    name: tab.name || '',
                    value: stegaClean(tab.value) || '',
                    faqs:
                      tab.faqs?.map((faq) => ({
                        question: faq.question || '',
                        answer: faq.answer || '',
                      })) || [],
                  })) || []
                }
              />
            );
          case 'tabbedImageContentSection':
            return (
              <TabbedImageContentSection
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                tabs={
                  block.tabs?.map((tab) => ({
                    name: tab.name || '',
                    value: stegaClean(tab.value) || '',
                    image: sanityImageMapper(tab.image),
                    content: tab.content ?? [],
                    cta: tab.ctaButton ? sanityButtonMapper(tab.ctaButton as Button) : undefined,
                  })) || []
                }
              />
            );
          case 'featuresSection10':
            return (
              <FeaturesSection10
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                advisorCards={
                  block.advisorCards?.map((card) => ({
                    title: card.title || '',
                    description: card.description || '',
                    button: sanityButtonMapper(card.button),
                    image: sanityImageMapper(card.image),
                    variant: card.variant || 'primary',
                  })) || []
                }
                enterpriseCards={
                  block.enterpriseCards?.map((card) => ({
                    title: card.title || '',
                    description: card.description || '',
                    button: sanityButtonMapper(card.button),
                    image: sanityImageMapper(card.image),
                    variant: card.variant || 'primary',
                  })) || []
                }
              />
            );
          case 'featuresSection26':
            return (
              <FeaturesSection26
                key={block._key}
                headings={sanityHeadingsMapper(block.headings)}
                data={
                  block.features?.map((f, i) => ({
                    id: f._key ?? i.toString(),
                    iconName: f.iconName ?? 'UserCircle',
                    title: f.title ?? '',
                    description: f.description ?? '',
                    cards:
                      f.cards?.map((card, i) => ({
                        id: card._key ?? i.toString(),
                        iconName: card.iconName ?? 'UserCircle',
                        title: card.title ?? '',
                        description: card.description ?? '',
                        image: sanityImageMapper(card.image),
                        cardColor: card.cardColor ?? 'violet',
                      })) ?? [],
                  })) ?? []
                }
              />
            );
          case 'featuresSection03': {
            return (
              <FeaturesSection03
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                techIcon={sanityImageMapper(block.techIcon)}
                techTitle={block.techTitle}
                techDescription={block.techDescription}
                mainImage={sanityImageMapper(block.mainImage)}
                features={
                  block.features?.map((f) => ({
                    _key: f._key,
                    iconName: f.iconName || 'UserCircle',
                    title: f.title || '',
                    description: f.description || '',
                  })) ?? []
                }
                ctaParagraph={block.ctaParagraph}
                ctaButton={sanityButtonMapper(block.ctaButton)}
              />
            );
          }
          case 'logoCloud05':
            return (
              <LogoCloud05Component
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                logos={block.logos?.map((logoItem) => sanityImageMapper(logoItem.image)) || []}
              />
            );
          case 'problemSection01':
            return (
              <ProblemSection01
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                button={sanityButtonMapper(block.button)}
                cards={
                  block.problemCards?.map((card) => ({
                    text: card?.description,
                  })) || []
                }
              />
            );
          case 'testimonialsComponent01':
            return (
              <TestimonialsComponent
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                button={sanityButtonMapper(block.button as Button)}
                testimonials={block.testimonials.map((t) => {
                  return {
                    name: t.name || '',
                    role: t.role || '',
                    company: t.company || '',
                    content: t.content,
                    avatar: {
                      src: urlForImage(t.avatar).url(),
                      alt: t.avatar?.alt || '',
                    },
                  };
                })}
                metrics={
                  block.metrics?.map((m) => ({
                    trendLabel: stegaClean(m.trendLabel),
                    trendValue: m.trendValue || 0,
                    trendSuffix: m.trendSuffix ?? '%',
                    content: m.content || [],
                    image: sanityImageMapper(m.image),
                  })) || []
                }
              />
            );
          case 'ctaSection07':
            return (
              <CTASection07
                key={block._key}
                headings={sanityHeadingsMapper(block.headings)}
                image={sanityImageMapper(block.image)}
                features={block.features}
                button={block.button ? sanityButtonMapper(block.button) : undefined}
              />
            );
          case 'ctaSection09':
            return (
              <CTASection08
                key={block._key}
                headings={sanityHeadingsMapper(block.headings)}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                button={sanityButtonMapper(block.button)}
                image={sanityImageMapper(block.image)}
              />
            );
          case 'ctaSection14':
            return (
              <CTASection14
                key={block._key}
                headings={sanityHeadingsMapper(block.headings)}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                button={sanityButtonMapper(block.button)}
                image={sanityImageMapper(block.image)}
                showKaaIcon={block.showKaaIcon}
              />
            );
          case 'contactUsPage10':
            return (
              <ContactUs
                key={block._key}
                headings={sanityHeadingsMapper(block.headings)}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                contactInfo={
                  block.contactInfo.map((info) => ({
                    ...info,
                    button: info.button ? sanityButtonMapper(info.button) : undefined,
                    details: stegaClean(info.details),
                  })) as ContactUsInfoType[]
                }
                image={sanityImageMapper(block.image)}
                hubspotContactForm={hubspotContactForm}
              />
            );
          case 'teamSection':
            return (
              <TeamSectionBlock
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                teamImage={sanityImageMapper(block.teamImage)}
              />
            );
          case 'team1':
            return (
              <Team1
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                members={
                  (block.members || []).map((m) => {
                    return {
                      name: m.name || '',
                      role: m.role || '',
                      avatar: {
                        src: m.avatar ? urlForImage(m.avatar).url() : '',
                        alt: m.avatar?.alt || '',
                      },
                      borderRadius: {
                        bl: m.borderRadius?.bl || false,
                        br: m.borderRadius?.br || false,
                        tl: m.borderRadius?.tl || false,
                        tr: m.borderRadius?.tr || false,
                      },
                      color: m.color,
                      bio: m.bio,
                    };
                  }) || []
                }
              />
            );
          case 'aboutUsPage06':
            return (
              <AboutUsPage06
                key={block._key}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                button={sanityButtonMapper(block.button)}
                image={sanityImageMapper(block.image)}
                cards={block.aboutUsCards.map(({ image, ...props }) => ({ image: sanityImageMapper(image), ...props }))}
              />
            );
          case 'aboutUsPage09':
            return (
              <AboutUsPage09
                key={block._key}
                headings={sanityHeadingsMapper(block.headings)}
                sectionOptions={sanityBlockOptionsMapper(block.blockOptions)}
                image={sanityImageMapper(block.image)}
                cardImageLeft={sanityImageMapper(block.cardImageLeft)}
                cardImageRight={sanityImageMapper(block.cardImageRight)}
                imageHeading={block.imageHeading}
                primaryButton={sanityButtonMapper(block.buttonPrimary as Button)}
                secondaryButton={sanityButtonMapper(block.buttonSecondary as Button)}
              />
            );
          case 'faqComponent15':
            return (
              <FAQComponent15
                key={block._key}
                sectionOption={sanityBlockOptionsMapper(block.blockOptions)}
                headings={sanityHeadingsMapper(block.headings)}
                image={sanityImageMapper(block.image)}
                faqItems={block.faqs}
              />
            );
          default: {
            const unhandledBlock = block as { _key?: string; _type: string };
            return (
              <section
                key={unhandledBlock._key ?? Math.random().toString(36)}
                data-block={unhandledBlock._type}
                style={{ border: '1px dashed #ccc', padding: '1rem' }}
              >
                <strong>{unhandledBlock._type}</strong>
                {/* TODO: implement renderer for {type} */}
              </section>
            );
          }
        }
      })}
    </div>
  );
};

export default PageBuilder;
