import { useEffect } from 'react';
import type { HubspotEmbedFields } from '#app/sanity/hubspot.utils';

export type HubspotEmbedFormInput = HubspotEmbedFields | null | undefined;

type Props = {
  form: HubspotEmbedFormInput;
  className?: string;
};

export const HubspotEmbeddedFormContainer = ({ form, className }: Props) => {
  const portalId = form?.portalId;
  const formId = form?.formId;
  const region = form?.region || 'na1';

  useEffect(() => {
    if (!portalId) return;
    const hsScript = document.createElement('script');
    hsScript.src = `https://js.hsforms.net/forms/embed/developer/${portalId}.js`;
    hsScript.defer = true;
    document.body.append(hsScript);
  }, [portalId]);

  if (!portalId || !formId) return null;

  return <div className={className} data-region={region} data-form-id={formId} data-portal-id={portalId} />;
};
