import { Button } from '@local/ui/components/ui/button';
import { Input } from '@local/ui/components/ui/input';
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  navigationMenuTriggerStyle,
} from '@local/ui/components/ui/navigation-menu';
import { SearchIcon } from 'lucide-react';

type NavigationItems = {
  title: string;
  href: string;
  isActive?: boolean;
  dropdownItems?: { title: string; href: string }[];
}[];

const BLOG_PATH_PREFIX = '/blog';

type BlogNavProps = {
  navigationItems: NavigationItems;
  searchValue?: string;
  onSearchChange?: (value: string) => void;
  searchPlaceholder?: string;
  /** When set, tag/blog links use client-side navigation (no full page load). */
  onLinkClick?: (href: string) => void;
};

const BlogNav = ({
  navigationItems,
  searchValue = '',
  onSearchChange,
  searchPlaceholder = 'Search posts…',
  onLinkClick,
}: BlogNavProps) => {
  const handleClick = (href: string) => (e: React.MouseEvent) => {
    if (onLinkClick && (href === BLOG_PATH_PREFIX || href.startsWith(`${BLOG_PATH_PREFIX}/tag/`))) {
      e.preventDefault();
      onLinkClick(href);
    }
  };

  return (
    <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
      <NavigationMenu viewport={false} className="max-md:hidden">
        <NavigationMenuList>
          {navigationItems.map((item, index) => (
            <NavigationMenuItem key={index} className="has-data-active:text-foreground text-muted-foreground">
              <NavigationMenuLink
                href={item.href}
                className={navigationMenuTriggerStyle()}
                active={item.isActive}
                onClick={handleClick(item.href)}
              >
                {item.title}
              </NavigationMenuLink>
            </NavigationMenuItem>
          ))}
        </NavigationMenuList>
      </NavigationMenu>

      <div className="text-muted-foreground flex items-center gap-3">
        <Input
          type="search"
          placeholder={searchPlaceholder}
          className="w-[288px]"
          value={searchValue}
          onChange={(e) => onSearchChange?.(e.target.value)}
          aria-label="Search blog posts"
        />
        <Button size="icon" type="button" aria-label="Search">
          <SearchIcon />
          <span className="sr-only">Search</span>
        </Button>
      </div>
    </div>
  );
};

export default BlogNav;
