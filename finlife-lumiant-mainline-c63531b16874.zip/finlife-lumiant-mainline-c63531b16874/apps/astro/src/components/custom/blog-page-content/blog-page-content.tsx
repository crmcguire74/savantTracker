import type { BlogPostsQueryResult } from '@local/sanity-studio/sanity.types';
import Pagination03 from '@local/ui/components/shadcn-studio/pagination/pagination-03';
import { useCallback, useEffect, useMemo, useState } from 'react';
import BlogNav from '#app/components/custom/blog-nav/blog-nav';
import type { BlockHeaderType } from '#app/components/shadcn-studio/block-header/BlockHeader';
import BlogComponent06 from '#app/components/shadcn-studio/blocks/blog-component-06';
import type { BlogComponent06Card } from '#app/components/shadcn-studio/blocks/blog-component-06/blog-component-06';
import type { NewsletterCardProps } from '#app/components/shadcn-studio/blocks/blog-component-06/newsletter-card';
import type { HubspotEmbedFields } from '#app/sanity/hubspot.utils';
import { sanityBlogPostToCardMapper } from '#app/sanity/sanityTypeMappers';

const SEARCH_DEBOUNCE_MS = 300;
const BLOG_PATH = '/blog';
const SEARCH_PARAM = 'search';
const POSTS_PER_PAGE = 9;

const getSearchFromUrl = (): string => {
  if (typeof window === 'undefined') return '';
  return new URLSearchParams(window.location.search).get(SEARCH_PARAM) ?? '';
};

const updateSearchInUrl = (term: string) => {
  const path = window.location.pathname;
  const url = term.trim() ? `${path}?${SEARCH_PARAM}=${encodeURIComponent(term)}` : path;
  window.history.replaceState({}, '', url);
};

const filterPostsBySearch = (posts: BlogPostsQueryResult, term: string): BlogPostsQueryResult => {
  if (!term.trim()) return posts;
  const lower = term.toLowerCase().trim();
  return posts.filter((post) => {
    const titleMatch = post.title?.toLowerCase().includes(lower);
    const categoryMatch = post.categories?.some(
      (c) => typeof c.title === 'string' && c.title.toLowerCase().includes(lower),
    );
    return titleMatch || categoryMatch;
  });
};

export type BlogCategory = { title: string; slug: string };

type NavigationItems = {
  title: string;
  href: string;
  isActive?: boolean;
  dropdownItems?: { title: string; href: string }[];
}[];

export type BlogPageContentProps = {
  initialBlogPosts: BlogPostsQueryResult;
  categories: BlogCategory[];
  initialSelectedTagSlug: string | null;
  headings: BlockHeaderType;
  newsletterCard: NewsletterCardProps;
  hubspotNewsletterForm?: HubspotEmbedFields | null;
};

const BlogPageContent = ({
  initialBlogPosts,
  categories,
  initialSelectedTagSlug,
  headings,
  newsletterCard,
  hubspotNewsletterForm,
}: BlogPageContentProps) => {
  const [selectedTagSlug, setSelectedTagSlug] = useState<string | null>(initialSelectedTagSlug);
  const [searchTerm, setSearchTerm] = useState(() => getSearchFromUrl());
  const [debouncedTerm, setDebouncedTerm] = useState(() => getSearchFromUrl());
  const [currentPage, setCurrentPage] = useState(1);

  const tagFilteredPosts = useMemo(() => {
    if (!selectedTagSlug) return initialBlogPosts;
    return initialBlogPosts.filter((post) => post.categories?.some((c) => c.slug?.current === selectedTagSlug));
  }, [initialBlogPosts, selectedTagSlug]);

  const { totalPages, safePage, paginatedPosts } = useMemo(() => {
    const posts = filterPostsBySearch(tagFilteredPosts, debouncedTerm);
    const totalPages = Math.max(1, Math.ceil(posts.length / POSTS_PER_PAGE));
    const safePage = Math.min(currentPage, totalPages);
    const paginatedPosts = posts.slice((safePage - 1) * POSTS_PER_PAGE, safePage * POSTS_PER_PAGE);
    return { totalPages, safePage, paginatedPosts };
  }, [tagFilteredPosts, debouncedTerm, currentPage]);

  const navigationItems: NavigationItems = useMemo(
    () => [
      {
        title: 'All',
        href: BLOG_PATH,
        isActive: !selectedTagSlug,
      },
      ...categories.map((cat) => ({
        title: cat.title,
        href: `${BLOG_PATH}/tag/${cat.slug}`,
        isActive: cat.slug === selectedTagSlug,
      })),
    ],
    [categories, selectedTagSlug],
  );

  useEffect(() => {
    const t = setTimeout(() => setDebouncedTerm(searchTerm), SEARCH_DEBOUNCE_MS);
    return () => clearTimeout(t);
  }, [searchTerm]);

  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedTerm, selectedTagSlug]);

  useEffect(() => {
    updateSearchInUrl(debouncedTerm);
  }, [debouncedTerm]);

  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      if (path === BLOG_PATH) setSelectedTagSlug(null);
      else if (path.startsWith(`${BLOG_PATH}/tag/`)) setSelectedTagSlug(path.slice(`${BLOG_PATH}/tag/`.length) || null);
      const q = getSearchFromUrl();
      setSearchTerm(q);
      setDebouncedTerm(q);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const blogCards: BlogComponent06Card[] = useMemo(() => sanityBlogPostToCardMapper(paginatedPosts), [paginatedPosts]);

  const handleSearchChange = useCallback((value: string) => {
    setSearchTerm(value);
  }, []);

  const handleLinkClick = useCallback(
    (href: string) => {
      if (href === BLOG_PATH) {
        setSelectedTagSlug(null);
      } else if (href.startsWith(`${BLOG_PATH}/tag/`)) {
        const slug = href.slice(`${BLOG_PATH}/tag/`.length);
        setSelectedTagSlug(slug);
      }
      const url = searchTerm.trim() ? `${href}?${SEARCH_PARAM}=${encodeURIComponent(searchTerm)}` : href;
      window.history.pushState({}, '', url);
    },
    [searchTerm],
  );

  return (
    <>
      <BlogNav
        navigationItems={navigationItems}
        searchValue={searchTerm}
        onSearchChange={handleSearchChange}
        searchPlaceholder="Search posts…"
        onLinkClick={handleLinkClick}
      />
      <BlogComponent06
        headings={headings}
        newsletterCard={{ ...newsletterCard, hubspotNewsletterForm }}
        blogCards={blogCards}
        hideHeaderAndNewsletter={searchTerm.trim().length > 0}
      />
      {totalPages > 1 && (
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <Pagination03 currentPage={safePage} totalPages={totalPages} onPageChange={setCurrentPage} />
        </div>
      )}
    </>
  );
};

export default BlogPageContent;
