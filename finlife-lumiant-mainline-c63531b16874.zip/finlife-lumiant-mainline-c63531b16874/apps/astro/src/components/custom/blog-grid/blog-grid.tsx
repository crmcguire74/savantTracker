import { Badge } from '@local/ui/components/ui/badge';
import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { Card, CardContent, CardDescription, CardTitle } from '@local/ui/components/ui/card';
import { cn } from '@local/ui/lib/utils';
import { ArrowRightIcon, ClockIcon } from 'lucide-react';
import BlockHeader, { type BlockHeaderType } from '#app/components/shadcn-studio/block-header/BlockHeader';
import { Image, type ImageType } from '#app/components/shadcn-studio/elements/image';

export type BlogCard = {
  image: ImageType;
  categories: { title: string; slug: string }[];
  title: string;
  date: string;
  readTime?: number;
  blogLink: string;
};

export type BlogGridProps = {
  blogCards: BlogCard[];
  headings?: BlockHeaderType;
  button?: ButtonType;
};

const BlogGrid = ({ blogCards, headings, button }: BlogGridProps) => {
  return (
    <div className="items-center max-w-7xl mx-auto px-4 lg:px-0">
      <div className={cn('flex flex-col py-8 sm:py-16 lg:pb-24 gap-x-9.5')}>
        {headings && (
          <div className=" flex items-center  content-center justify-between">
            {headings && <BlockHeader headings={headings} alignment="left" />}
            {button && (
              <Button size="lg" asChild variant={button.variant}>
                <a href={button.link} className="inline-flex items-center">
                  {button.label}
                  <ArrowRightIcon className="h-5 w-5" />
                </a>
              </Button>
            )}
          </div>
        )}
        <div className={cn('flex flex-col lg:flex-row gap-6')}>
          {blogCards.map((card, index) => (
            <a href={card.blogLink} key={index} className="block transition-transform">
              <Card className="h-full py-0 shadow-none gradient-border-ombre hover:shadow-lg transition-shadow max-w-sm">
                <CardContent className="flex h-full flex-col px-0">
                  <Image image={card.image} className="max-h-60 w-full rounded-t-xl object-cover" />
                  <div className="flex flex-1 flex-col gap-4 space-y-4 p-6">
                    <div className="mb-2 -mx-0.5 flex flex-wrap gap-2">
                      {card.categories.map((category, catIndex) => (
                        <Badge
                          key={catIndex}
                          className="bg-muted border-none text-sm text-muted-foreground dark:bg-accent"
                        >
                          {category.title}
                        </Badge>
                      ))}
                    </div>
                    <CardTitle className="text-xl font-medium">{card.title}</CardTitle>
                    <CardDescription className="mt-auto flex items-center gap-1.5 py-1 text-base">
                      <ClockIcon className="text-muted-foreground size-5" />
                      <span className="text-muted-foreground">
                        {card.date}
                        {card.readTime && ` · ${card.readTime} min read`}
                      </span>
                    </CardDescription>
                  </div>
                </CardContent>
              </Card>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogGrid;
