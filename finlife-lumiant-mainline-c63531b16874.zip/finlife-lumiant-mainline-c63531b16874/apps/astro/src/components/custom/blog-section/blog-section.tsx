import type { BlogPostQueryResult } from '@local/sanity-studio/sanity.types';
import { Badge } from '@local/ui/components/ui/badge';
import { Button } from '@local/ui/components/ui/button';
import { Separator } from '@local/ui/components/ui/separator';
import { cn } from '@local/ui/lib/utils';
import { PortableText } from '@portabletext/react';
import { stegaClean } from '@sanity/client/stega';
import { ChevronLeft, ChevronRight, Download, EllipsisVertical } from 'lucide-react';
import { defaultIconForPlatform } from '#app/components/shadcn-studio/blocks/footer-component-02/footer-component-02';
import { Image } from '#app/components/shadcn-studio/elements/image';
import { portableTextComponents } from '#app/sanity/portableText.utils';
import { sanityImageMapper } from '#app/sanity/sanityTypeMappers';

export type BlogPost = NonNullable<BlogPostQueryResult>;
export type BlogAuthor = BlogPost['author'];

export type BlogSectionProps = {
  blog?: BlogPost;
  author?: BlogAuthor;
  nextPrevPosts?: {
    previousHref?: string;
    nextHref?: string;
  };
  className?: string;
};

const BlogSection = ({ blog, author, nextPrevPosts, className }: BlogSectionProps) => {
  if (!blog || !author) return null;

  const { previousHref, nextHref } = nextPrevPosts || {};
  const pdfDownloads = (blog.pdfDownloads || []).filter((pdf) => pdf?.file?.asset?.url);

  return (
    <div
      className={cn(className, `flex justify-between py-8 sm:py-16 lg:pb-24 gap-x-9.5 max-w-7xl mx-auto px-4 lg:px-0`)}
    >
      {/* Left Side - Blog Content */}
      <div className="w-full">
        {/* Badge tags (Case study) */}
        <div className="flex justify-between pb-6">
          <Badge variant="outline">Case study</Badge>
          <div>
            <EllipsisVertical />
          </div>
        </div>
        <PortableText value={blog.content} components={portableTextComponents} />
        {pdfDownloads.length > 0 && (
          <div className="mt-10 mb-4 space-y-6">
            <h3 className="text-xl font-semibold">Downloads</h3>
            <div className="space-y-4">
              {pdfDownloads.map((pdf) => {
                const fileName = pdf?.file?.asset?.originalFilename || 'Download PDF';
                const displayTitle = pdf?.title || fileName;
                const fileUrl = pdf.file?.asset?.url || '#';

                return (
                  <div key={pdf._key} className="rounded-md border p-4">
                    <div className="flex gap-4">
                      <div className="h-20 w-14 shrink-0 overflow-hidden rounded border bg-muted">
                        <object data={fileUrl} type="application/pdf" className="h-full w-full">
                          <a
                            href={fileUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="flex h-full w-full items-center justify-center text-xs text-muted-foreground"
                          >
                            PDF
                          </a>
                        </object>
                      </div>
                      <div className="flex min-w-0 flex-1 items-center justify-between gap-4">
                        <div className="min-w-0">
                          <div className="truncate font-medium text-foreground">{displayTitle}</div>
                          <div className="truncate text-sm text-muted-foreground">{fileName}</div>
                        </div>
                        <a
                          href={fileUrl}
                          target="_blank"
                          rel="noreferrer"
                          download
                          aria-label={`Download ${displayTitle}`}
                          className="inline-flex h-12 w-12 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                        >
                          <Download className="h-6 w-6" />
                        </a>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
        <Separator />
        <div className="flex justify-between flex-just pt-10 ">
          <Button size="lg" variant={'outline'} disabled={!previousHref}>
            <a href={previousHref} className="inline-flex items-center">
              <ChevronLeft />
              Previous Post
            </a>
          </Button>

          <Button size="lg" variant={'outline'} disabled={!nextHref}>
            <a href={nextHref} className="inline-flex items-center">
              Next Post
              <ChevronRight />
            </a>
          </Button>
        </div>
      </div>

      {/* Right Side - Author Card */}
      <div className="lg:min-w-68.5">
        <div className="space-y-4">
          <div>
            <Image image={sanityImageMapper(author.image)} className="w-12 h-12 rounded-full" />

            <span className="text-sm font-normal text-muted-foreground mb-2">Written by</span>
            <div className="flex flex-col  gap-3">
              <div>
                <p className="text-sm font-medium text-foreground">
                  {author.name.split(' ').map((part, index, parts) => (
                    <span key={`${part}-${index}`}>
                      {part}
                      {index === 0 && parts.length > 1 ? <br /> : index < parts.length - 1 ? ' ' : null}
                    </span>
                  ))}
                </p>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <span className="text-sm font-normal text-muted-foreground mb-2">Read Time</span>
            <p className="text-sm font-medium text-foreground">{blog.readTime} Minutes read</p>
          </div>

          <Separator />

          <div>
            <span className="text-sm font-normal text-muted-foreground mb-2">Posted on</span>
            <p className="text-sm font-medium text-foreground">
              {new Date(blog.postedOn).toLocaleDateString('en-US', {
                month: 'long',
                day: 'numeric',
                year: 'numeric',
              })}
            </p>
          </div>

          <Separator />

          <div>
            <div className="text-sm font-normal text-muted-foreground mb-2">Related Topics</div>
            <div className="flex flex-wrap gap-2">
              {blog.categories.map((category, idx) => (
                <Badge key={idx} variant="outline">
                  <a href={`/blog/tag/${category.slug.current}`}>{category.title}</a>
                </Badge>
              ))}
            </div>
          </div>

          <Separator />

          <div>
            <div className="text-sm font-medium mb-2">Social media links</div>
            <div className="flex flex-wrap items-center gap-3">
              {(author.socialLinks || [])
                .filter((link) => link?.url && link?.platform)
                .map((link) => {
                  const platform = stegaClean(link.platform);
                  return (
                    <a
                      key={`${link._key}-${link.url}`}
                      href={link.url}
                      target="_blank"
                      rel="noreferrer"
                      aria-label={platform}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {platform && defaultIconForPlatform(platform, 'text-black dark:text-white')}
                    </a>
                  );
                })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogSection;
