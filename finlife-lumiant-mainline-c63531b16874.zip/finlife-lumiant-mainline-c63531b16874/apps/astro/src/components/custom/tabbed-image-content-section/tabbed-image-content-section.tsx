import type { BlockContent } from '@local/sanity-studio/sanity.types';
import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { TabsContent } from '@local/ui/components/ui/tabs';
import { PortableText } from '@portabletext/react';
import { ArrowRightIcon } from 'lucide-react';
import { Section, type SectionOptions } from '#app/components/section/section';
import { IconLabelTabs } from '#app/components/shadcn-studio/icon-label-tabs/IconLabelTabs';
import { portableTextComponents } from '#app/sanity/portableText.utils';
import BlockHeader, { type BlockHeaderType } from '../../shadcn-studio/block-header/BlockHeader';
import { Image, type ImageType } from '../../shadcn-studio/elements/image';

export type TabbedImageContentTab = {
  name: string;
  value: string;
  image?: ImageType;
  content: BlockContent;
  cta?: ButtonType;
};

type TabbedImageContentSectionProps = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  tabs: TabbedImageContentTab[];
};

const TabbedImageContentSection = ({ sectionOptions, headings, tabs }: TabbedImageContentSectionProps) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-11 space-y-4 text-center">
          {headings && (
            <MotionPreset fade slide={{ direction: 'down', offset: 50 }} transition={{ duration: 0.7 }}>
              <BlockHeader headings={headings} />
            </MotionPreset>
          )}
        </div>

        <IconLabelTabs tabs={tabs}>
          {tabs.map((tab) => (
            <TabsContent key={tab.value} value={tab.value}>
              <div className="grid grid-cols-1 items-start gap-8 lg:gap-16 lg:grid-cols-[2fr_3fr]">
                {tab.image && (tab.image.src || tab.image.darkSrc) ? (
                  <div className="flex justify-center ml-auto lg:block">
                    <Image image={tab.image} className="w-[428px]" />
                  </div>
                ) : null}
                <MotionPreset
                  fade
                  slide={{ direction: 'right', offset: 50 }}
                  delay={0.3}
                  transition={{ duration: 0.7 }}
                  className="h-full"
                >
                  <div className="flex flex-col gap-6 h-full justify-center">
                    {tab.content?.length ? (
                      <div className="text-muted-foreground text-base leading-relaxed [&_a]:text-primary [&_a]:underline-offset-4 hover:[&_a]:underline">
                        <PortableText value={tab.content} components={portableTextComponents} />
                      </div>
                    ) : null}
                    {tab.cta?.label ? (
                      <div>
                        <Button variant={tab.cta.variant} asChild>
                          <a href={tab.cta.link} className="inline-flex items-center gap-2">
                            {tab.cta.label}
                            <ArrowRightIcon className="h-5 w-5" />
                          </a>
                        </Button>
                      </div>
                    ) : null}
                  </div>
                </MotionPreset>
              </div>
            </TabsContent>
          ))}
        </IconLabelTabs>
      </div>
    </Section>
  );
};

export default TabbedImageContentSection;
