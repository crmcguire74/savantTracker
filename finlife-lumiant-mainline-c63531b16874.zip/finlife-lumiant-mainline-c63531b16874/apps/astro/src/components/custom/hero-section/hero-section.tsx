import { cn } from '@local/ui/lib/utils';
import { Section, type SectionOptions } from '#app/components/section/section';
import BlockHeader, { type BlockHeaderType } from '#app/components/shadcn-studio/block-header/BlockHeader';
import BlogPostBreadcrumb from '#app/components/shadcn-studio/breadcrumb/breadcrumb-02';
import type { BlogAuthor } from '../blog-section/blog-section';

type HeroSectionProps = {
  sectionOptions: SectionOptions;
  headings: BlockHeaderType;
  breadcrumb?: boolean;
  className?: string;
  author?: BlogAuthor;
};

const HeroSection = ({ sectionOptions, headings, breadcrumb, className }: HeroSectionProps) => {
  return (
    <Section {...sectionOptions}>
      <div className={cn('max-w-7xl mx-auto px-4 lg:px-0 flex flex-col py-16 gap-5', className)}>
        {breadcrumb && <BlogPostBreadcrumb className={className} />}
        <BlockHeader
          headings={headings}
          className={className}
          descriptionClassName="text-xl font-regular"
          alignment="center"
        />
      </div>
    </Section>
  );
};

export default HeroSection;
