import { useEffect } from 'react';

type Props = {
  embedUrl: string | null | undefined;
};

export const HubspotScheduler = ({ embedUrl }: Props) => {
  useEffect(() => {
    if (!embedUrl) return;
    const hsScript = document.createElement('script');
    hsScript.src = 'https://static.hsappstatic.net/MeetingsEmbed/ex/MeetingsEmbedCode.js';
    hsScript.defer = true;
    document.body.append(hsScript);
  }, [embedUrl]);

  if (!embedUrl) return null;

  return <div className="meetings-iframe-container w-full -mt-4" data-src={embedUrl}></div>;
};
