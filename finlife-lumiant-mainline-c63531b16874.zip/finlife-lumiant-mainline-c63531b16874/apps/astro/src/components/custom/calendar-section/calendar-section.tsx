import { Card } from '@local/ui/components/ui/card';
import { cn } from '@local/ui/lib/utils';
import { Section, type SectionOptions } from '#app/components/section/section';
import BlockHeader, { type BlockHeaderType } from '#app/components/shadcn-studio/block-header/BlockHeader';
import { getIconByName } from '#app/components/shadcn-studio/icon-name-map';
import { HubspotScheduler } from './hubspot-scheduler';

export type CalendarCard = {
  iconName?: string;
  title: string;
  description: string;
};

export type CalendarSectionProps = {
  sectionOptions: SectionOptions;
  headings: BlockHeaderType;
  cards: CalendarCard[];
  className?: string;
  hubspotSchedulerEmbedUrl?: string | null;
};

const CalendarSection = ({
  sectionOptions,
  headings,
  cards,
  className,
  hubspotSchedulerEmbedUrl,
}: CalendarSectionProps) => {
  return (
    <Section className={cn('py-8 sm:py-16 lg:py-24', className)} {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <BlockHeader headings={headings} alignment="center" descriptionClassName="text-xl" className="mb-10" />

        <div className="grid grid-cols-1 gap-10 lg:grid-cols-10 lg:items-start">
          <div className="flex flex-col gap-4 lg:col-span-4">
            {cards.map((card) => {
              const Icon = getIconByName(card.iconName);
              return (
                <Card
                  key={card.title}
                  className="flex flex-row items-start gap-6 rounded-xl border-[#E5E5E5] bg-muted p-5 shadow-sm"
                >
                  <Icon className="mt-1 min-w-6 text-muted-foreground" />
                  <div>
                    <h3 className="text-base font-semibold">{card.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{card.description}</p>
                  </div>
                </Card>
              );
            })}
          </div>

          <div className="flex h-full items-center justify-center lg:col-span-6">
            <HubspotScheduler embedUrl={hubspotSchedulerEmbedUrl} />
          </div>
        </div>
      </div>
    </Section>
  );
};

export default CalendarSection;
