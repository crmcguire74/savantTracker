import {
  VisualEditing as InternalVisualEditing,
  type VisualEditingOptions as InternalVisualEditingOptions,
} from '@sanity/visual-editing/react';

export type VisualEditingOptions = Pick<InternalVisualEditingOptions, 'zIndex'> & {
  enabled?: boolean;
};

export const VisualEditingComponent = ({ enabled, zIndex }: VisualEditingOptions) =>
  enabled ? (
    <InternalVisualEditing
      portal
      zIndex={zIndex}
      refresh={() => {
        return new Promise((resolve) => {
          window.location.reload();
          resolve();
        });
      }}
    />
  ) : null;
