import { cn } from '@local/ui/lib/utils';
import type { PropsWithChildren } from 'react';

export type SectionOptions = {
  backgroundColor?: 'default' | 'muted' | 'grid' | 'whitePrimaryGradient';
  padding?: 'none' | 'small' | 'medium' | 'large';
};

type SectionProps = SectionOptions &
  PropsWithChildren<{
    className?: string;
  }>;

const backgroundClasses = {
  default: '',
  muted: 'bg-muted',
  grid: 'bg-[url(/src/assets/grid.svg)] dark:bg-[url(/src/assets/darkgrid.svg)] bg-repeat',
  whitePrimaryGradient: '[background-image:var(--color-white-primary-gradient)]',
};

export const Section = ({ backgroundColor = 'default', className, children }: SectionProps) => {
  return <section className={cn(backgroundClasses[backgroundColor], className)}>{children}</section>;
};
