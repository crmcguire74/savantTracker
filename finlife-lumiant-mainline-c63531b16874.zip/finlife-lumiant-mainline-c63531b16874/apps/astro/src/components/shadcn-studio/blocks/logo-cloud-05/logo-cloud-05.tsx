import { Section, type SectionOptions } from '#app/components/section/section';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';

type BrandLogo = {
  src?: string;
  alt?: string;
};

type LogoCloud05Props = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  logos: BrandLogo[];
};

const LogoCloud05 = ({ headings, logos, sectionOptions }: LogoCloud05Props) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {headings && <BlockHeader headings={headings} />}

        <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-6">
          {logos.map((logo, index) => (
            <img key={index} src={logo.src} alt={logo.alt} className="h-10" />
          ))}
        </div>
      </div>
    </Section>
  );
};

export default LogoCloud05;
