import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@local/ui/components/ui/accordion';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { TabsContent } from '@local/ui/components/ui/tabs';
import { PlusIcon } from 'lucide-react';
import { Section, type SectionOptions } from '#app/components/section/section';
import { IconLabelTabs } from '#app/components/shadcn-studio/icon-label-tabs/IconLabelTabs';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';

export type FAQComponent13Item = {
  question: string;
  answer: string;
};

export type FAQComponent13Tab = {
  name: string;
  value: string;
  faqs: FAQComponent13Item[];
};

type FAQComponent13Props = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  tabs: FAQComponent13Tab[];
};

const FAQ = ({ sectionOptions, headings, tabs }: FAQComponent13Props) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-11 space-y-4 text-center">
          {headings && (
            <MotionPreset fade slide={{ direction: 'down', offset: 50 }} transition={{ duration: 0.7 }}>
              <BlockHeader headings={headings} />
            </MotionPreset>
          )}
        </div>

        <IconLabelTabs tabs={tabs}>
          {tabs.map((tab) => (
            <TabsContent key={tab.value} value={tab.value}>
              <div className="mx-auto max-w-4xl">
                <Accordion
                  type="multiple"
                  defaultValue={tab.faqs.map((_, index) => `item-${index}`)}
                  className="grid grid-cols-1 gap-5 lg:grid-cols-2"
                >
                  {tab.faqs.map((item, index) => (
                    <MotionPreset
                      key={index}
                      fade
                      slide={{ direction: 'down', offset: 30 }}
                      delay={0.2 + index * 0.15}
                      transition={{ duration: 0.6 }}
                    >
                      <AccordionItem
                        value={`item-${index}`}
                        className="border-border bg-card rounded-md border! p-6 transition-shadow duration-200 hover:shadow-sm"
                      >
                        <AccordionTrigger className="focus-visible:border-ring focus-visible:ring-ring/50 flex flex-1 justify-start gap-3 text-sm font-medium transition-all outline-none focus-visible:ring-[3px] disabled:pointer-events-none disabled:opacity-50 [&>svg>path:last-child]:origin-center [&>svg>path:last-child]:transition-all [&>svg>path:last-child]:duration-200 [&[data-state=open]>svg]:rotate-180 [&[data-state=open]>svg>path:last-child]:rotate-90 [&[data-state=open]>svg>path:last-child]:opacity-0 py-0">
                          <PlusIcon className="text-primary pointer-events-none size-5 shrink-0 transition-transform duration-200" />
                          <span className="text-primary">{item.question}</span>
                        </AccordionTrigger>
                        <AccordionContent className="text-muted-foreground pt-2 pb-0 pl-7 text-sm leading-relaxed">
                          {item.answer}
                        </AccordionContent>
                      </AccordionItem>
                    </MotionPreset>
                  ))}
                </Accordion>
              </div>
            </TabsContent>
          ))}
        </IconLabelTabs>
      </div>
    </Section>
  );
};

export default FAQ;
