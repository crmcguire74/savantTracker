import Tabs01 from '@local/ui/components/shadcn-studio/tabs/tabs-01';
import { Avatar, AvatarFallback } from '@local/ui/components/ui/avatar';
import { Button } from '@local/ui/components/ui/button';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { ChevronRightIcon } from 'lucide-react';

import { Section, type SectionOptions } from '#app/components/section/section';
import { getIconByName } from '#app/components/shadcn-studio/icon-name-map';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';
import { Image, type ImageType } from '../../elements/image';

type TabContent = {
  name: string;
  value: string;
  iconName: string;
  content: Content;
};

type Content = {
  title: string;
  description: string;
  subDescription: string;
  buttonIconName: string;
  documentationLink: string;
  image: ImageType;
  buttonText: string;
};

type FeatureSection09Props = {
  sectionOptions: SectionOptions;
  headings: BlockHeaderType;
  image: ImageType;
  tabs: TabContent[];
};

const FeaturesSection09 = ({ sectionOptions, headings, image, tabs }: FeatureSection09Props) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className=" flex items-center justify-between gap-9 max-sm:flex-col">
          <div className="max-w-3xl">
            <MotionPreset
              component="h2"
              className="mb-4 text-2xl md:text-3xl lg:text-4xl"
              fade
              slide={{ direction: 'left', offset: 50 }}
              blur
              transition={{ duration: 0.5 }}
            >
              {headings && (
                <BlockHeader
                  headings={headings}
                  alignment="left"
                  descriptionClassName="text-muted-foreground text-xl"
                />
              )}
            </MotionPreset>
          </div>
          <MotionPreset
            fade
            blur
            zoom={{ initialScale: 0.75 }}
            delay={0.4}
            transition={{ duration: 0.5 }}
            className="mx-auto flex"
          >
            <div className="relative flex size-36 items-center justify-center">
              <div className="absolute inset-0 flex items-center justify-center">
                <Image className="z-1 size-32 rounded-4xl" image={image} />
              </div>
              <div className="absolute inset-0">
                <div className="border-primary absolute inset-12 animate-ping rounded-3xl border-2"></div>
                <div className="border-primary/60 absolute inset-8 animate-ping rounded-3xl border-2"></div>
                <div className="border-primary/40 absolute inset-6 animate-ping rounded-3xl border-2"></div>
              </div>
            </div>
          </MotionPreset>
        </div>
        <Tabs01
          backgroundColor={sectionOptions.backgroundColor === 'muted' ? 'card' : 'muted'}
          tabs={tabs.map((tab) => {
            const TabIconComponent = getIconByName(tab.iconName);
            const ContentIconComponent = getIconByName(tab.content.buttonIconName);
            return {
              name: tab.name,
              icon: <TabIconComponent />,
              value: tab.value,
              content: (
                <div className="flex flex-col items-start justify-between gap-11 lg:flex-row">
                  <MotionPreset fade slide={{ direction: 'down', offset: 70 }} blur transition={{ duration: 0.7 }}>
                    <div className="flex flex-col gap-11 lg:w-2xl">
                      <div className="flex items-center flex-row gap-4">
                        <Avatar className="border-primary border size-20">
                          <AvatarFallback className="text-primary bg-transparent [&>svg]:size-32">
                            <ContentIconComponent />
                          </AvatarFallback>
                        </Avatar>
                        <h3 className="text-4xl bg-feature-gradient text-transparent bg-clip-text pb-1">
                          {tab.content.title}
                        </h3>
                      </div>
                      <p className="text-card-foreground text-lg">{tab.content.description}</p>
                      <p className="text-muted-foreground text-base">{tab.content.subDescription}</p>
                      <Button className="group w-fit rounded-full text-base has-[>svg]:px-6" size="lg" asChild>
                        <a href={tab.content.documentationLink}>
                          {tab.content.buttonText}
                          <ChevronRightIcon className="transition-transform duration-200 group-hover:translate-x-0.5" />
                        </a>
                      </Button>
                    </div>
                  </MotionPreset>
                  <MotionPreset fade blur zoom={{ initialScale: 0.75 }} transition={{ duration: 0.7 }}>
                    <Image className="h-103 w-118 object-contain" image={tab.content.image} />
                  </MotionPreset>
                </div>
              ),
            };
          })}
        />
      </div>
    </Section>
  );
};

export default FeaturesSection09;
