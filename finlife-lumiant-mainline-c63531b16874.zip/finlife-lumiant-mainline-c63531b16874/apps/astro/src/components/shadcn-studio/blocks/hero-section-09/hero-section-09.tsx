import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { Section, type SectionOptions } from '#app/components/section/section';
import type { BlockHeaderType } from '../../block-header/BlockHeader';
import BlockHeader from '../../block-header/BlockHeader';
import { Image, type ImageType } from '../../elements/image';

type HeroSection09Props = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  button?: ButtonType;
  image?: ImageType;
};

const HeroSection = ({ headings, button, image }: HeroSection09Props) => {
  return (
    <Section className="bg-muted flex w-full py-6 md:py-24">
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 lg:min-h-[728px]">
        <div className="relative flex items-start">
          {/* Hero Content */}
          <div className="z-1 flex w-full flex-col items-center gap-7 py-8 max-lg:text-center lg:items-start lg:py-12 lg:max-w-1/2">
            {headings && <BlockHeader headings={headings} descriptionClassName="md:max-w-[60%]" alignment="left" />}

            {button && (
              <MotionPreset
                fade
                slide
                delay={0.9}
                transition={{ duration: 0.5 }}
                className="flex flex-wrap justify-center gap-4"
              >
                <Button size="lg" className="rounded-lg text-base" asChild>
                  <a href={button.link}>{button.label}</a>
                </Button>
              </MotionPreset>
            )}
          </div>

          {/* Hero Image */}
          {image && (
            <MotionPreset
              fade
              slide={{ direction: 'right' }}
              delay={1.2}
              transition={{ duration: 0.5 }}
              className="absolute right-0 lg:-right-8 xl:-right-16 shrink-0 max-lg:hidden bottom-10 xl:top-12 lg:top-24 lg:w-[75%]"
            >
              <Image image={image} />
            </MotionPreset>
          )}
        </div>
      </div>
    </Section>
  );
};

export default HeroSection;
