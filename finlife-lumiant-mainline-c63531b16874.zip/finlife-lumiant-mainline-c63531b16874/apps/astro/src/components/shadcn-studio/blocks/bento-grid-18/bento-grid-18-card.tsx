import { Card, CardDescription, CardHeader, CardTitle } from '@local/ui/components/ui/card';
import { IconContainer } from '@local/ui/components/ui/icon-container';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import type { ReactNode } from 'react';

import { getIconByName } from '#app/components/shadcn-studio/icon-name-map';
import type { BentoGrid18BaseCard } from './bento-grid-18-types';

export type FallingBadgeCardProps = BentoGrid18BaseCard & {
  children: ReactNode;
};

const BentoGrid18Card = ({ title, description, modules, children, iconName }: FallingBadgeCardProps) => {
  const IconComponent = getIconByName(iconName);
  return (
    <MotionPreset
      fade
      blur
      slide={{ direction: 'down', offset: 75 }}
      transition={{ duration: 0.45 }}
      className="overflow-hidden max-xl:min-h-120 md:col-span-3 xl:col-span-2"
    >
      <Card className="h-full justify-between overflow-hidden border-0 shadow-none gap-0">
        <CardHeader className="flex gap-4">
          <MotionPreset
            fade
            slide={{ direction: 'down', offset: 50 }}
            delay={0.1}
            transition={{ duration: 0.45 }}
            className="bg-card grid size-11 shrink-0 place-content-center"
          >
            {/* <IconComponent className="size-6" /> */}
            <IconContainer variant="outline">
              <IconComponent className="size-6 text-foreground dark:text-foreground" />
            </IconContainer>
          </MotionPreset>
          <div className="flex flex-col gap-2">
            <MotionPreset
              component="h3"
              fade
              slide={{ direction: 'down', offset: 50 }}
              delay={0.1}
              transition={{ duration: 0.45 }}
            >
              <CardTitle className="text-xl font-medium">{title}</CardTitle>
            </MotionPreset>
            <MotionPreset fade slide={{ direction: 'down', offset: 50 }} delay={0.2} transition={{ duration: 0.45 }}>
              <CardDescription className="text-lg">{description}</CardDescription>
            </MotionPreset>
          </div>
        </CardHeader>
        <MotionPreset
          fade
          slide={{ direction: 'down', offset: 50 }}
          delay={0.3}
          transition={{ duration: 0.45 }}
          className="flex-1"
        >
          {children}
        </MotionPreset>
        {modules && <div className="text-xs font-bold pt-4 mt-auto px-6">Modules: {modules.join(' | ')}</div>}
      </Card>
    </MotionPreset>
  );
};

export default BentoGrid18Card;
