import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { Section, type SectionOptions } from '#app/components/section/section';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';
import { Image, type ImageType } from '../../elements/image';

type MetricItem = {
  value: string;
  label: string;
};

type FeatureCard = {
  title: string;
  image: ImageType;
};

type HeroSection13Props = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  button?: ButtonType;
  image?: ImageType;
  metrics?: MetricItem[];
  featureCards?: FeatureCard[];
};

const HeroSection13 = ({
  sectionOptions,
  headings,
  button,
  image,
  metrics = [],
  featureCards = [],
}: HeroSection13Props) => {
  return (
    <Section className="flex-1 overflow-hidden py-4 sm:py-6 lg:py-24" {...sectionOptions}>
      <div className="mx-auto flex h-full max-w-7xl flex-col gap-12 px-4 sm:gap-16 sm:px-6 lg:gap-24 lg:px-8">
        <div className="relative grid gap-12 lg:grid-cols-5">
          <div className="flex flex-col justify-center gap-6 lg:col-span-3">
            {headings && <BlockHeader headings={headings} alignment="left" descriptionClassName="text-lg" />}
            <MotionPreset
              component="div"
              fade
              slide={{ offset: 50 }}
              blur
              transition={{ duration: 0.5 }}
              delay={0.7}
              className="flex flex-wrap items-center gap-6"
            >
              {button && (
                <Button size="lg" variant={button.variant} className="rounded-lg text-base" asChild>
                  <a href={button.link}>{button.label}</a>
                </Button>
              )}
              {metrics.map((metric) => (
                <div key={metric.label} className="flex flex-col">
                  <span className="text-xl font-medium">{metric.value}</span>
                  <span className="text-muted-foreground">{metric.label}</span>
                </div>
              ))}
            </MotionPreset>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 lg:max-w-184">
              {featureCards.map((card, index) => {
                return (
                  <MotionPreset
                    key={card.title}
                    component="div"
                    fade
                    slide={{ direction: 'down', offset: 50 }}
                    blur
                    transition={{ duration: 0.5 }}
                    delay={0.9 + index * 0.1}
                    className="bg-amber-100 dark:bg-amber-200 group relative h-39 overflow-hidden rounded-md p-3"
                  >
                    <div className="relative max-w-[87%] z-10 text-muted-foreground dark:text-black text-xl font-medium">
                      {card.title}
                    </div>
                    <div className="z-0 text-muted-foreground absolute end-4 bottom-0 right-0 transition-transform duration-500 group-hover:-translate-y-1.5 group-hover:scale-110 group-hover:drop-shadow-sm">
                      <Image image={card.image} className="w-32 object-contain" />
                    </div>
                  </MotionPreset>
                );
              })}
            </div>
          </div>

          <MotionPreset
            component="div"
            fade
            slide={{ direction: 'right', offset: 50 }}
            blur
            transition={{ duration: 0.5 }}
            delay={0.5}
            className="
             flex items-center justify-center lg:col-span-2"
          >
            {image ? (
              <Image image={image} className="size-full object-contain md:max-lg:size-3/4" />
            ) : (
              <div className="bg-muted h-80 w-full rounded-lg" />
            )}
          </MotionPreset>
        </div>
      </div>
    </Section>
  );
};

export default HeroSection13;
