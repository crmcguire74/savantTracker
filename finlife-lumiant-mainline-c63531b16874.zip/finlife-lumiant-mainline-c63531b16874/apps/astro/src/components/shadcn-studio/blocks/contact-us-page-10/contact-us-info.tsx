import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { PortableText, type PortableTextBlock } from '@portabletext/react';
import { MailIcon, MessageSquareMoreIcon, PhoneIcon } from 'lucide-react';
import { portableTextComponents } from '#app/sanity/portableText.utils';

export type ContactUsInfoType = {
  type: 'mail' | 'message' | 'phone';
  title: string;
  details: PortableTextBlock[];
  button?: ButtonType;
};

type ContactUsInfoProps = ContactUsInfoType & {
  index: number;
};

const renderIcon = (type: string) => {
  switch (type) {
    case 'mail':
      return <MailIcon />;
    case 'message':
      return <MessageSquareMoreIcon />;
    case 'phone':
      return <PhoneIcon />;
    default:
      return null;
  }
};
export const ContactUsInfo = ({ type, title, details, button }: ContactUsInfoProps) => {
  return (
    <>
      <div className="relative [&>svg]:size-10">
        <span className="bg-brand-lavender/30 text-primary absolute -top-2 left-2.5 size-10 rounded-full"></span>
        {renderIcon(type)}
      </div>
      <div className="flex-1 space-y-1">
        <h3 className="text-lg font-medium">{title}</h3>
        {details && <PortableText value={details} components={portableTextComponents} />}
        {button && (
          <Button variant={button.variant || 'secondary'} className="mt-2">
            <a href={button.link}>{button.label}</a>
          </Button>
        )}
      </div>
    </>
  );
};
