export { default } from './hero-section-10';
