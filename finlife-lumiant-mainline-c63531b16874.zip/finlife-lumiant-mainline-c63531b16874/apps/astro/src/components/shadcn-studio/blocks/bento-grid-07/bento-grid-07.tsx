import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { Section, type SectionOptions } from '#app/components/section/section';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';
import { BentoCard, type GridItem } from './bento-card';

type BentoGridProps = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  gridItems: GridItem[];
};

const BentoGrid = ({ sectionOptions, headings, gridItems }: BentoGridProps) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto max-w-7xl space-y-12 px-4 sm:space-y-16 sm:px-6 lg:space-y-12 lg:px-8">
        {headings && <BlockHeader headings={headings} />}

        <MotionPreset fade blur transition={{ duration: 0.5 }} delay={0.6}>
          <div className={`grid grid-cols-1 gap-6 rounded-xl sm:grid-cols-2 lg:grid-cols-6`}>
            {gridItems.map((item, index) => (
              <BentoCard
                key={`${item.title}-${index}`}
                muted={sectionOptions?.backgroundColor !== 'muted'}
                index={index}
                {...item}
              />
            ))}
          </div>
        </MotionPreset>
      </div>
    </Section>
  );
};

export default BentoGrid;
