export { default } from './about-us-page-06.tsx';
