export { default, type NavbarProps } from './navbar-component-05';
