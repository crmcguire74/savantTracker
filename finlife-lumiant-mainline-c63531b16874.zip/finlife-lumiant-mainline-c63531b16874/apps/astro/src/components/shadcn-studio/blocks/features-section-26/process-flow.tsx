import { Card, CardContent, CardHeader, CardTitle } from '@local/ui/components/ui/card';
import { IconContainer } from '@local/ui/components/ui/icon-container';
import { cn } from '@local/ui/lib/utils';
import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { getIconByName } from '#app/components/shadcn-studio/icon-name-map';
import { Image, type ImageType } from '../../elements/image';

const cardColorClasses: Record<string, string> = {
  cyan: 'bg-cyan-100 dark:bg-cyan-100',
  violet: 'bg-violet-100 dark:bg-violet-300',
  blue: 'bg-blue-100 dark:bg-blue-200',
  amber: 'bg-amber-100 dark:bg-amber-200',
};

export type Process = {
  id: string;
  iconName: string;
  title: string;
  description: string;
  image: ImageType;
  cardColor?: 'cyan' | 'violet' | 'blue' | 'amber';
};

export type ProcessFlowProps = {
  cards: Process[];
  interval?: number;
  setWorkflowProgress: (progress: number) => void;
  nextTab: () => void;
};

const ProcessFlow = ({ cards, interval = 2500, setWorkflowProgress, nextTab }: ProcessFlowProps) => {
  const [processStage, setProcessStage] = useState<Process[]>(cards);
  const [count, setCount] = useState<number>(1);
  const [isFading, setIsFading] = useState(false);

  // Reset state when cards change with fade-out / fade-in
  useEffect(() => {
    setIsFading(true);
    const timeout = setTimeout(() => {
      setProcessStage(cards);
      setCount(1);
      setWorkflowProgress(0);
      setIsFading(false);
    }, 200);

    return () => clearTimeout(timeout);
  }, [cards, setWorkflowProgress]);

  // Rotate cards on an interval
  useEffect(() => {
    if (cards.length === 0) return;
    const processInterval = setInterval(() => {
      setProcessStage((prevCards) => {
        if (prevCards.length === 0) return prevCards;
        const [first, ...rest] = prevCards;
        return [...rest, first];
      });
      setCount((prev) => prev + 1);
    }, interval);

    return () => clearInterval(processInterval);
  }, [cards.length, interval]);

  // Update workflow progress and advance tab when done
  useEffect(() => {
    if (cards.length === 0) {
      setWorkflowProgress(0);
      return;
    }
    if (count > cards.length) {
      nextTab();
      setCount(1);
      return;
    }

    setWorkflowProgress((count / cards.length) * 100);
  }, [cards.length, count, setWorkflowProgress, nextTab]);

  return (
    <motion.div
      className="relative mx-auto mt-2 flex w-[350px] min-h-[400px]"
      animate={{ opacity: isFading ? 0 : 1 }}
      transition={{ duration: 0.2 }}
    >
      {processStage.map((item, index) => (
        <motion.div
          key={item.id}
          className="absolute"
          style={{
            transformOrigin: 'top center',
          }}
          animate={{
            top: index * -16,
            scale: 1 - index * 0.1,
            zIndex: processStage.length - index,
          }}
          transition={{
            duration: 0.4,
            ease: 'easeInOut',
            delay: index * 0.05,
          }}
        >
          <Card
            className={cn(
              'gap-4 shadow-none z-1 w-[350px] min-h-[400px] border-none',
              cardColorClasses[item.cardColor ?? 'violet'],
            )}
          >
            <div className="relative px-6">
              <Image className="w-full h-full max-h-[160px] object-contain rounded-xl" image={item.image} />
            </div>
            <CardHeader>
              <CardTitle className="flex gap-2 items-center text-2xl font-medium text-brand-electric">
                <IconContainer variant="white" className="size-12.5">
                  {(() => {
                    const IconComponent = getIconByName(item.iconName);
                    return <IconComponent className="size-8" />;
                  })()}
                </IconContainer>
                {item.title}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-primary-foreground text-small font-light">{item.description}</p>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </motion.div>
  );
};

export default ProcessFlow;
