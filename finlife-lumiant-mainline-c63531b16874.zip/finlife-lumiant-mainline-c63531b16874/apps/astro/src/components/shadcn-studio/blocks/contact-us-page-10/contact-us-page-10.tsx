import { BorderBeam } from '@local/ui/components/ui/border-beam';
import { Card, CardContent, CardTitle } from '@local/ui/components/ui/card';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { Section, type SectionOptions } from '#app/components/section/section';
import type { HubspotEmbedFields } from '#app/sanity/hubspot.utils';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';
import { Image, type ImageType } from '../../elements/image';
import ContactUsHubspotForm from './contact-us-hubspot-embedded-form';
import { ContactUsInfo, type ContactUsInfoType } from './contact-us-info';

type ContactUsProps = {
  sectionOptions?: SectionOptions;
  contactInfo: ContactUsInfoType[];
  headings: BlockHeaderType;
  image: ImageType;
  hubspotContactForm?: HubspotEmbedFields | null;
};

const ContactUs = ({ sectionOptions, contactInfo, headings, image, hubspotContactForm }: ContactUsProps) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="space-y-4">
          <BlockHeader alignment="left" headings={headings} />
        </div>
        <div className="grid items-center gap-12 md:grid-cols-2 md:gap-16 lg:gap-7.5">
          {/* Contact Info */}
          <div>
            {image && <Image image={image} className="mb-6 rounded-lg" />}
            <div className="space-y-8 p-6 bg-white/50 rounded-md p-4 gap-4">
              {contactInfo.map((info, index) => {
                return (
                  <MotionPreset
                    key={index}
                    className="flex items-center gap-8"
                    fade
                    blur
                    slide={{ direction: 'up', offset: 50 }}
                    delay={0.6 + index * 0.15}
                    transition={{ duration: 0.5 }}
                  >
                    <ContactUsInfo
                      key={index}
                      index={0}
                      title={info.title}
                      details={info.details}
                      type={info.type}
                      button={info.button}
                    />
                  </MotionPreset>
                );
              })}
            </div>
          </div>

          {/* Form Card */}
          <MotionPreset
            fade
            blur
            zoom={{ initialScale: 0.9 }}
            delay={0.3}
            transition={{ duration: 0.8 }}
            className="h-full"
          >
            <Card
              className={` relative overflow-hidden border-none shadow-none h-full ${
                sectionOptions?.backgroundColor !== 'muted' && 'bg-muted'
              }`}
            >
              <CardContent className="h-full flex flex-col">
                <CardTitle className="mb-4 text-2xl font-semibold pb-5">Contact Us</CardTitle>

                <ContactUsHubspotForm hubspotContactForm={hubspotContactForm} />

                <p className="text-muted-foreground mt-4 text-lg">
                  I understand that my data will be held securely in accordance with the{' '}
                  {/** biome-ignore lint/a11y/useValidAnchor: <explanation>temporary anchor for privacy policy</explanation> */}
                  <a href="#" className="text-card-foreground font-semibold underline underline-offset-4">
                    privacy policy
                  </a>
                </p>
              </CardContent>

              <BorderBeam
                borderWidth={1.5}
                duration={7}
                size={400}
                className="via-primary from-transparent to-transparent"
              />
              <BorderBeam
                duration={7}
                delay={4}
                size={400}
                borderWidth={1.5}
                className="via-destructive from-transparent to-transparent"
              />
            </Card>
          </MotionPreset>
        </div>
      </div>
    </Section>
  );
};

export default ContactUs;
