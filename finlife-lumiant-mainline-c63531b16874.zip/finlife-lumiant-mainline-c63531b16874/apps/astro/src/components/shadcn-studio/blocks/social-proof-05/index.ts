export type { SocialProof05Props } from './social-proof-05';
export { default } from './social-proof-05';
