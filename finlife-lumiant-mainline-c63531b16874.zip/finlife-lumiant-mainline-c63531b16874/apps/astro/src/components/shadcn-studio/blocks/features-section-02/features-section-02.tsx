import type { BlockContent } from '@local/sanity-studio/sanity.types';
import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { PortableText } from '@portabletext/react';
import { ArrowRightIcon, CircleCheck } from 'lucide-react';
import { Section, type SectionOptions } from '#app/components/section/section';
import BlockHeader, { type BlockHeaderType } from '#app/components/shadcn-studio/block-header/BlockHeader';
import { portableTextComponents } from '#app/sanity/portableText.utils';
import FeaturesSectionCard, { type FeaturesSection02CardItem } from './features-section-02-card';

export type FeaturesSection02Props = {
  sectionOptions?: SectionOptions;
  headings: BlockHeaderType;
  cards: FeaturesSection02CardItem[];
  checkpoints: string[];
  checkpointsHeading?: BlockContent;
  button?: ButtonType;
};

const FeaturesSection02 = ({
  sectionOptions,
  headings,
  cards,
  checkpoints,
  checkpointsHeading,
  button,
}: FeaturesSection02Props) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {headings && <BlockHeader headings={headings} alignment="right" />}
        <div className="flex flex-col lg:flex-row gap-13.25">
          {/* Cards */}
          <div className="grid auto-rows-fr gap-6 pb-6 sm:grid-cols-1 lg:grid-cols-2 max-w-xl rounded-lg max-lg:shrink-0">
            {cards?.map((card) => (
              <FeaturesSectionCard {...card} />
            ))}
          </div>
          {/* Checkpoints */}
          <div className="my-auto">
            <MotionPreset
              fade
              blur
              slide={{ direction: 'right', offset: 50 }}
              delay={0.6}
              transition={{ duration: 0.5 }}
            >
              <div className="flex flex-col justify-center space-y-6">
                <div className="space-y-2">
                  {checkpointsHeading && (
                    <div className="text-2xl font-semibold [&_p]:mb-0">
                      <PortableText value={checkpointsHeading} components={portableTextComponents} />
                    </div>
                  )}
                </div>
                <div className="grid gap-3.5">
                  {checkpoints?.map((item) => (
                    <div className="flex items-center gap-4" key={item}>
                      <CircleCheck className="size-6 text-primary" />
                      <span className="text-base">{item}</span>
                    </div>
                  ))}
                </div>
                {button && (
                  <div className="flex-0">
                    <Button variant={'default'} className="rounded-lg text-base" size="lg">
                      <a href={button.link}>{button.label}</a>
                      <ArrowRightIcon className="h-5 w-5" />
                    </Button>
                  </div>
                )}
              </div>
            </MotionPreset>
          </div>
        </div>
      </div>
    </Section>
  );
};

export default FeaturesSection02;
