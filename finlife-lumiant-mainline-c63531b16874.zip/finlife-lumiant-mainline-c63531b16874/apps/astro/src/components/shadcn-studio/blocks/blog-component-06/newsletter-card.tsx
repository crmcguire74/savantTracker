import { Avatar, AvatarFallback } from '@local/ui/components/ui/avatar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@local/ui/components/ui/card';
import { MailIcon } from 'lucide-react';
import { HubspotEmbeddedFormContainer } from '#app/components/hubspot/hubspot-embedded-form';
import type { HubspotEmbedFields } from '#app/sanity/hubspot.utils';

export type NewsletterCardProps = {
  title: string;
  subtitle: string;
  hubspotNewsletterForm?: HubspotEmbedFields | null;
};

const NewsletterCard = ({ title, subtitle, hubspotNewsletterForm }: NewsletterCardProps) => {
  return (
    <Card className="bg-primary h-fit shadow-none">
      <CardHeader className="flex gap-4">
        <Avatar className="size-11.5">
          <AvatarFallback>
            <MailIcon className="size-7.5" />
          </AvatarFallback>
        </Avatar>
        <div className="flex flex-col gap-0.5">
          <CardTitle className="text-lg text-primary-foreground">{title}</CardTitle>
          <CardDescription className="text-lg text-primary-foreground">{subtitle}</CardDescription>
        </div>
      </CardHeader>
      <CardContent>
        <div className="bg-card border-primary flex items-center gap-2.5 rounded-xl border-2 px-3 py-2">
          <HubspotEmbeddedFormContainer form={hubspotNewsletterForm} className="hs-form-html hs-newsletter" />
        </div>
      </CardContent>
    </Card>
  );
};

export default NewsletterCard;
