import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@local/ui/components/ui/sheet';
import { MenuIcon, MoonIcon, SunIcon, XIcon } from 'lucide-react';
import { motion, useMotionValueEvent, useScroll, useTransform } from 'motion/react';
import { useLayoutEffect, useState } from 'react';
import Logo, { type LogoProps } from '#app/components/shadcn-studio/logo';
import { useThemeToggle } from '#app/hooks/useThemeToggle';
import type { SiteLink } from '#app/sanity/sanity.utils';

export type NavbarProps = {
  navigationData: SiteLink[];
  logo?: LogoProps['logo'];
  darkLogo?: LogoProps['logo'];
  currentUrl?: URL;
  ctaButtons?: ButtonType[];
};

const trimSlashes = (str?: string) => str?.replace(/^\/|\/$/g, '');

const DESKTOP_MAX_WIDTH = 1290;

const Navbar = ({ navigationData, logo, darkLogo, currentUrl, ctaButtons = [] }: NavbarProps) => {
  const { scrollY } = useScroll();
  const [viewportWidth, setViewportWidth] = useState(() =>
    typeof window !== 'undefined' ? window.innerWidth : DESKTOP_MAX_WIDTH,
  );
  const [resolvedMaxWidth, setResolvedMaxWidth] = useState<number | undefined>(undefined);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { isDarkMode, toggleTheme } = useThemeToggle();

  useLayoutEffect(() => {
    const update = () => setViewportWidth(window.innerWidth);
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, []);

  const input = [100, 105, 130, 200, 10000000];
  const brOutput = [0, 45, 49, 50, 50];
  const topPosOutput = [0, 1, 5, 20, 0];
  const maxWidthOutput = [viewportWidth, viewportWidth, DESKTOP_MAX_WIDTH, 1280, 1200];

  const borderRadius = useTransform(scrollY, input, brOutput, { clamp: true });
  const topPos = useTransform(scrollY, input, topPosOutput);
  const maxWidthMotion = useTransform(scrollY, input, maxWidthOutput);

  useMotionValueEvent(maxWidthMotion, 'change', (value: number | false) => {
    if (typeof value === 'number' && value > 0) {
      setResolvedMaxWidth(typeof window !== 'undefined' ? Math.min(value, window.innerWidth) : value);
    } else {
      setResolvedMaxWidth(undefined);
    }
  });

  const background = useTransform(scrollY, input, [
    'var(--background)',
    'var(--background)',
    'var(--background)',
    'oklch(from var(--background) l c h / 0.5)',
    'oklch(from var(--background) l c h / 0.5)',
  ]);

  return (
    <motion.header
      className="mx-auto bg-background shadow-[0_0px_15px_oklch(from_var(--primary)_l_c_h_/0.25)] sticky top-0 z-500 max-md:bg-background! max-md:rounded-none! max-md:top-0! drop-shadow-xl"
      style={{
        borderRadius,
        top: topPos,
        background,
        backdropFilter: 'blur(12px)',
        maxWidth: resolvedMaxWidth ?? '100%',
      }}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-4 py-3 sm:px-4">
        <a href="/">{logo && <Logo logo={logo} darkLogo={darkLogo} className="gap-3" />}</a>
        <div className="text-muted-foreground flex items-center gap-6 font-medium max-md:hidden">
          {navigationData.map((item, index) => {
            const href = trimSlashes(item.href);
            const isActive = href === trimSlashes(currentUrl?.pathname);
            return (
              <a
                key={index}
                href={`/${href}`}
                target={item.newTab ? '_blank' : '_self'}
                rel={item.newTab ? 'noreferrer' : undefined}
                className={`${
                  isActive ? 'after:w-full' : ''
                } after:content-[''] after:block after:bg-foreground after:h-px after:w-0 py-2 px-4 hover:after:w-full after:transition-all`}
              >
                {item.label}
              </a>
            );
          })}
        </div>

        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="icon"
            className="cursor-pointer max-md:hidden"
            onClick={toggleTheme}
            aria-label={`Switch to ${isDarkMode ? 'light' : 'dark'} mode`}
            title={`Switch to ${isDarkMode ? 'light' : 'dark'} mode`}
          >
            {isDarkMode ? <SunIcon /> : <MoonIcon />}
          </Button>
          {ctaButtons.map((cta) => {
            const to = 'link' in cta && cta.link ? cta.link : '';
            return (
              <Button
                key={`${cta.label}-${to}`}
                variant={cta.variant}
                className="rounded-lg text-base max-md:hidden"
                size="lg"
                asChild
              >
                <a href={to}>{cta.label}</a>
              </Button>
            );
          })}
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger className="md:hidden" asChild>
              <Button variant="outline" size="icon">
                {isMobileMenuOpen ? <XIcon /> : <MenuIcon />}
                <span className="sr-only">{isMobileMenuOpen ? 'Close menu' : 'Open menu'}</span>
              </Button>
            </SheetTrigger>
            <SheetContent
              side="right"
              hideCloseButton
              className="top-15! right-0! bottom-auto! h-auto! w-full! max-w-none! gap-0 rounded-none border-0 p-0"
            >
              <nav className="flex flex-col gap-0 px-4">
                {navigationData.map((item, index) => {
                  const isActive = trimSlashes(item.href) === trimSlashes(currentUrl?.pathname);
                  return (
                    <a
                      key={index}
                      href={item.href}
                      target={item.newTab ? '_blank' : '_self'}
                      rel={item.newTab ? 'noreferrer' : undefined}
                      className={`text-center rounded-lg px-4 py-3 text-base font-medium ${
                        isActive
                          ? 'bg-muted text-foreground'
                          : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground'
                      }`}
                    >
                      {item.label}
                    </a>
                  );
                })}
              </nav>
              <div className="flex flex-col gap-2 pb-4 px-4">
                <Button
                  variant="outline"
                  className="w-full cursor-pointer rounded-lg"
                  size="lg"
                  onClick={toggleTheme}
                  aria-label={`Switch to ${isDarkMode ? 'light' : 'dark'} mode`}
                >
                  {isDarkMode ? <SunIcon className="mr-2 size-4" /> : <MoonIcon className="mr-2 size-4" />}
                  Switch to {isDarkMode ? 'light' : 'dark'} mode
                </Button>
                {ctaButtons.map((cta) => {
                  const to = 'link' in cta && cta.link ? cta.link : '';
                  return (
                    <Button
                      key={`${cta.label}-${to}`}
                      variant={cta.variant}
                      className="w-full rounded-lg"
                      size="lg"
                      asChild
                    >
                      <a href={to || '#'}>{cta.label}</a>
                    </Button>
                  );
                })}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </motion.header>
  );
};

export default Navbar;
