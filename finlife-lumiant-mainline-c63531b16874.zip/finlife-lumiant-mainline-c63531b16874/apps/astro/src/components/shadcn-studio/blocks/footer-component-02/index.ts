export { default, type FooterProps } from './footer-component-02';
