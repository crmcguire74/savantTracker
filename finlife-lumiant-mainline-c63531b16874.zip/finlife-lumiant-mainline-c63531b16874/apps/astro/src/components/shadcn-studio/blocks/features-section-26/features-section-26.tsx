import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { cn } from '@local/ui/lib/utils';
import { ArrowRightIcon } from 'lucide-react';
import { useState } from 'react';

import DottedSheet from '#app/assets/dottedsheet.svg?react';
import type { BlockHeaderType } from '#app/components/shadcn-studio/block-header/BlockHeader';
import BlockHeader from '#app/components/shadcn-studio/block-header/BlockHeader';
import { getIconByName } from '#app/components/shadcn-studio/icon-name-map';
import ProcessFlow, { type Process } from './process-flow';

export type FeaturesSection26Item = {
  id: string;
  iconName: string;
  title: string;
  description: string;
  cards: Process[];
};

export type FeaturesSection26Props = {
  headings?: BlockHeaderType;
  button?: ButtonType;
  data: FeaturesSection26Item[];
};

const Features = ({ headings, button, data }: FeaturesSection26Props) => {
  const [activeTab, setActiveTab] = useState<string>(data[0]?.id ?? '');
  const [workflowProgress, setWorkflowProgress] = useState<number>(0);

  const activeCards = data.find((tab) => tab.id === activeTab)?.cards ?? [];

  const nextTab = () => {
    const nextIndex = data.findIndex((tab) => tab.id === activeTab) + 1;
    if (nextIndex >= data.length) {
      setActiveTab(data[0].id);
    } else {
      setActiveTab(data[nextIndex].id);
    }
  };

  return (
    <section className="py-8 sm:py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-row gap-[76px]">
          {headings && <BlockHeader alignment="left" headings={headings} />}
          {button && (
            <Button className="my-auto" size="lg">
              <a href={button.link}>
                {button.label} <ArrowRightIcon />
              </a>
            </Button>
          )}
        </div>
        <div className="grid max-lg:divide-y max-lg:divide-y-reverse lg:grid-cols-10">
          <div className="grid h-full grid-rows-3 divide-y lg:col-span-6 max-lg:order-2">
            {data.map((tab) => {
              const isActive = activeTab === tab.id;
              const IconComponent = getIconByName(tab.iconName);

              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(tab.id);
                  }}
                  className={cn(
                    'focus-visible:ring-ring/50 relative flex cursor-pointer flex-col gap-5 px-6 py-9 text-left transition-colors duration-300 outline-none focus-visible:z-1 focus-visible:ring-3',
                  )}
                >
                  <div className="flex items-center gap-5">
                    <span className={cn('text-muted-foreground [&>svg]:size-4.5', { 'text-foreground': isActive })}>
                      <IconComponent />
                    </span>
                    <h3 className={cn('text-muted-foreground text-xl font-medium', { 'text-foreground': isActive })}>
                      {tab.title}
                    </h3>
                  </div>
                  <p className="text-muted-foreground">{tab.description}</p>
                  {isActive && (
                    <div
                      data-state="workflow-progress"
                      className="bg-primary absolute inset-x-0 bottom-0 left-0 h-0.5 transition-none"
                      style={{ width: `${workflowProgress}%` }}
                    />
                  )}
                </button>
              );
            })}
          </div>

          <div className="relative flex items-center justify-center overflow-hidden px-4 lg:col-span-4 max-lg:h-100">
            <DottedSheet className="absolute inset-0 h-full w-full" />
            <div className="absolute inset-0 bg-[radial-gradient(circle,transparent_0%,var(--background)_80%)]"></div>
            <ProcessFlow
              interval={4000}
              setWorkflowProgress={setWorkflowProgress}
              nextTab={nextTab}
              cards={activeCards}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
