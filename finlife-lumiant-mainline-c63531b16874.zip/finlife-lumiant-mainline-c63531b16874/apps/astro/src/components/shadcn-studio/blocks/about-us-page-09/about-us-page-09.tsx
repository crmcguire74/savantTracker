import type { BlockContent } from '@local/sanity-studio/sanity.types';
import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { PortableText } from '@portabletext/react';
import { Section, type SectionOptions } from '#app/components/section/section';
import { headerPortableTextComponents } from '#app/sanity/headerPortableText.utils';
import { portableTextComponents } from '#app/sanity/portableText.utils';
import { BlockBadge } from '../../block-badge/BlockBadge';
import type { BlockHeaderType } from '../../block-header/BlockHeader';
import { Image, type ImageType } from '../../elements/image';

type AboutUsPage09Props = {
  sectionOptions?: SectionOptions;
  headings: BlockHeaderType;
  image: ImageType;
  imageHeading: BlockContent;
  cardImageLeft: ImageType;
  cardImageRight: ImageType;
  primaryButton: ButtonType;
  secondaryButton: ButtonType;
};

const AboutUsPage09 = ({
  sectionOptions,
  headings,
  image,
  imageHeading,
  cardImageLeft,
  cardImageRight,
  primaryButton,
  secondaryButton,
}: AboutUsPage09Props) => {
  const { heading, description, badge } = headings;
  return (
    <Section {...sectionOptions} className="bg-background py-8 sm:py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {badge && <BlockBadge className="mb-4" badge={badge} alignment="left" />}
        <div className="grid grid-cols-1 gap-9 lg:grid-cols-2">
          <div className="flex flex-col gap-9">
            <div className="flex items-center gap-6 overflow-hidden">
              <div className="to-primary h-52 w-4 bg-linear-to-t from-transparent" />
              {heading && (
                <MotionPreset slide={{ direction: 'left' }} fade blur transition={{ duration: 0.8 }}>
                  <div className="space-y-4">
                    <div className="text-muted-foreground text-3xl md:text-3xl">
                      <PortableText value={heading} components={headerPortableTextComponents} />
                    </div>
                  </div>
                </MotionPreset>
              )}
            </div>

            <MotionPreset fade blur slide={{ direction: 'up' }} delay={0.3} transition={{ duration: 0.8 }}>
              <div className={'relative'}>
                <Image className="max-h-98 w-full rounded-lg object-cover" image={image} />
                <div className={'absolute bottom-1 left-4 rounded-md'}>
                  <PortableText value={imageHeading} components={headerPortableTextComponents} />
                </div>
              </div>
            </MotionPreset>
          </div>

          <div className="flex flex-col gap-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <MotionPreset fade blur slide={{ direction: 'up' }} delay={0.6} transition={{ duration: 0.8 }}>
                <div className="relative overflow-hidden rounded-md">
                  <Image className="h-64 w-full rounded-md object-cover" image={cardImageLeft} />
                </div>
              </MotionPreset>
              <MotionPreset fade blur slide={{ direction: 'up' }} delay={0.6} transition={{ duration: 0.8 }}>
                <div className="relative overflow-hidden rounded-md">
                  <Image className="h-64 w-full rounded-md object-cover" image={cardImageRight} />
                </div>
              </MotionPreset>
            </div>
            {description && (
              <MotionPreset fade blur slide={{ direction: 'up' }} delay={0.8} transition={{ duration: 0.5 }}>
                <div className="text-muted-foreground text-md">
                  <PortableText value={description} components={portableTextComponents} />
                </div>
                <div className={'flex flex-row gap-8'}>
                  <Button variant={'default'} asChild>
                    <a href={primaryButton.link}>{primaryButton.label}</a>
                  </Button>
                  <Button variant={'outline'} asChild>
                    <a href={secondaryButton.link}> {secondaryButton.label}</a>
                  </Button>
                </div>
              </MotionPreset>
            )}
          </div>
        </div>
      </div>
    </Section>
  );
};

export default AboutUsPage09;
