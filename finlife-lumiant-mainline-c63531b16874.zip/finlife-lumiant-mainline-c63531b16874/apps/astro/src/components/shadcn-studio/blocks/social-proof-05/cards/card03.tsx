import { Card, CardContent } from '@local/ui/components/ui/card';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { ArrowUpIcon } from 'lucide-react';
import type { CardBase } from './types';

export type Card03Props = CardBase & {
  percentage: string;
  description: string;
};

const Card03 = ({ percentage, description }: Card03Props) => (
  <MotionPreset fade blur slide={{ direction: 'down', offset: 15 }} delay={1.1} transition={{ duration: 0.5 }}>
    <Card className="h-[376px] py-5">
      <CardContent className="h-full px-4 md:px-6 lg:px-8">
        <div className="relative flex h-full flex-col justify-between max-md:gap-30">
          <div className="flex items-center gap-4">
            <ArrowUpIcon className="size-10" />
            <span className="text-6xl font-semibold">{percentage}</span>
          </div>
          <p className="w-2/3 text-3xl font-medium">{description}</p>
          <MotionPreset fade blur slide={{ direction: 'right', offset: 15 }} transition={{ duration: 0.5 }} delay={1.7}>
            {/** biome-ignore lint/a11y/noSvgWithoutTitle: <explanation>decorative svg</explanation> */}
            <svg
              width="210"
              className="absolute right-0 bottom-0 rtl:rotate-y-180"
              height="198"
              viewBox="0 0 210 198"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M-0.00195312 99C-0.00195312 44.3238 44.3219 0 98.998 0H104.998C162.988 0 209.998 47.0101 209.998 105V198H98.998C44.3219 198 -0.00195312 153.676 -0.00195312 99Z"
                fill="var(--destructive)"
                fillOpacity="0.1"
              />
            </svg>
          </MotionPreset>
        </div>
      </CardContent>
    </Card>
  </MotionPreset>
);

export default Card03;
