import type { BlockContent } from '@local/sanity-studio/sanity.types';
import { Avatar, AvatarFallback, AvatarImage } from '@local/ui/components/ui/avatar';
import { Carousel, type CarouselApi, CarouselContent, CarouselItem } from '@local/ui/components/ui/carousel';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { cn } from '@local/ui/lib/utils';
import { PortableText } from '@portabletext/react';
import Autoplay from 'embla-carousel-autoplay';
import { useEffect, useState } from 'react';
import { Section, type SectionOptions } from '#app/components/section/section';
import { portableTextComponents } from '#app/sanity/portableText.utils';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';

export type TeamMember = {
  id?: string;
  name: string;
  role: string;
  avatar: {
    src: string;
    alt: string;
  };
  borderRadius?: {
    tl?: boolean;
    tr?: boolean;
    bl?: boolean;
    br?: boolean;
  };
  color?: 'primary' | 'brand-lavender' | 'brand-electric';
  bio?: BlockContent;
};

type Team1Props = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  subheading?: string;
  description?: string;
  members?: TeamMember[];
};

const Team1 = ({ sectionOptions, headings, members }: Team1Props) => {
  const [api, setApi] = useState<CarouselApi>();
  const [current, setCurrent] = useState(0);

  const count = members?.length ?? 0;
  const loopedMembers = members && count > 0 ? [...members, ...members, ...members] : [];

  useEffect(() => {
    if (!api) {
      return;
    }

    setCurrent(api.selectedScrollSnap());

    api.on('select', () => {
      setCurrent(api.selectedScrollSnap());
    });
  }, [api]);

  return (
    <Section className="relative flex h-full flex-1 flex-col py-6 md:py-24" {...sectionOptions}>
      <div className="container relative z-10 mx-auto px-4">
        <div className="container flex flex-col items-center text-center">
          {headings && <BlockHeader headings={headings} alignment="center" />}
        </div>

        <Carousel
          plugins={[
            Autoplay({
              delay: 8000,
              stopOnInteraction: true,
              stopOnFocusIn: false,
            }),
          ]}
          opts={{ loop: true, align: 'center' }}
          setApi={setApi}
          className="w-full"
        >
          <CarouselContent className="-ml-8 md:-ml-12 lg:-ml-8 mt-16 md:mt-24">
            {loopedMembers.map((member, index) => {
              const borderClasses = [
                member.borderRadius?.tl && 'rounded-tl-[90px]',
                member.borderRadius?.tr && 'rounded-tr-[90px]',
                member.borderRadius?.bl && 'rounded-bl-[90px]',
                member.borderRadius?.br && 'rounded-br-[90px]',
              ]
                .filter(Boolean)
                .join(' ');

              const colorMap = {
                primary: 'bg-primary',
                'brand-lavender': 'bg-brand-lavender',
                'brand-electric': 'bg-brand-electric',
              };

              const contrastColorMap = {
                primary: 'text-primary-foreground',
                'brand-lavender': 'text-primary-foreground',
                'brand-electric': 'text-white',
              };

              const bgColor = member.color ? colorMap[member.color] : 'bg-brand-electric';
              const contrastColor = member.color ? contrastColorMap[member.color] : 'text-black';
              const isActive = current % count === index % count;

              return (
                <CarouselItem
                  key={`${member.id || member.name}-${index}`}
                  className="basis-full md:basis-1/2 lg:basis-1/3 pl-4 md:pl-6 relative flex flex-col gap-14 items-center"
                >
                  <div className="group relative flex flex-col items-center text-center">
                    {/* Background Container */}
                    <div
                      className={cn(
                        'absolute -left-[45px] -top-[30px] h-[300px] w-[300px] opacity-50',
                        borderClasses,
                        bgColor,
                      )}
                    />
                    {/* Rotating card */}
                    <div className="relative h-[300px] w-[300px] transition-transform duration-500 [transform-style:preserve-3d] group-hover:[transform:rotateY(180deg)]">
                      {/* Image */}
                      <div className="absolute inset-0 [backface-visibility:hidden]">
                        <Avatar className={cn('h-full w-full rounded-none', borderClasses)}>
                          <AvatarImage src={member?.avatar?.src} alt={member?.avatar?.alt} />
                          <AvatarFallback className={cn('text-lg font-semibold rounded-none', borderClasses, bgColor)}>
                            {member.name}
                          </AvatarFallback>
                        </Avatar>
                      </div>

                      {/* Back text */}
                      <div className="absolute inset-0 [backface-visibility:hidden] [transform:rotateY(180deg)]">
                        <div
                          className={cn(
                            'relative flex items-center justify-center h-full w-full rounded-none overflow-hidden',
                            borderClasses,
                            bgColor,
                          )}
                        >
                          <div className={cn('overflow-hidden max-h-full w-full p-6', contrastColor)}>
                            {member.bio && <PortableText value={member.bio} components={portableTextComponents} />}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {isActive && (
                    <MotionPreset
                      fade
                      slide={{ direction: 'down', offset: 10 }}
                      blur
                      transition={{ duration: 0.5 }}
                      delay={0.1}
                    >
                      <div className="mt-7 space-y-0.5 text-center">
                        <p className="text-foreground text-xl font-medium">{member.name}</p>
                        <p className="text-muted-foreground">{member.role}</p>
                      </div>
                    </MotionPreset>
                  )}
                </CarouselItem>
              );
            })}
          </CarouselContent>
        </Carousel>
      </div>
    </Section>
  );
};

export default Team1;
