import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { Section, type SectionOptions } from '#app/components/section/section';
import type { BlockHeaderType } from '#app/components/shadcn-studio/block-header/BlockHeader';
import BlockHeader from '#app/components/shadcn-studio/block-header/BlockHeader';
import { Image, type ImageType } from '#app/components/shadcn-studio/elements/image';
import { getIconByName } from '#app/components/shadcn-studio/icon-name-map';

export type FeaturesSection03Feature = {
  _key?: string;
  iconName: string;
  title: string;
  description: string;
};

export type FeaturesSection03Props = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  techIcon?: ImageType | null;
  techTitle: string;
  techDescription?: string | null;
  mainImage?: ImageType | null;
  features: FeaturesSection03Feature[];
  ctaParagraph?: string | null;
  ctaButton?: ButtonType;
};

const FeaturesSection03 = ({
  sectionOptions,
  headings,
  techIcon,
  techTitle,
  techDescription,
  mainImage,
  features,
  ctaParagraph,
  ctaButton,
}: FeaturesSection03Props) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header: badge + main heading + intro (from blockHeading) */}
        {headings && (
          <div className="mb-10 sm:mb-14">
            <BlockHeader alignment="left" className="space-y-4 text-left" headings={headings} />
          </div>
        )}

        <div className="flex flex-row space-y-3">
          {techIcon && <Image image={techIcon} className="size-12 mr-4 object-contain" />}
          <div>
            <h3 className="text-xl mb-2 font-semibold">{techTitle}</h3>
            {techDescription && <p className="text-muted-foreground text-base leading-relaxed">{techDescription}</p>}
          </div>
        </div>

        {/* Two columns: patented tech (left) + tech list (right) */}
        <div className="grid grid-cols-1 mt-8 items-start gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Left: patented technology section + image */}
          <div className="space-y-6">
            {/* Tech block: icon + title + description */}

            {/* Main illustration (supports dark mode via Image) */}
            {mainImage && (
              <div className="relative max-w-140 overflow-hidden rounded-sm border bg-muted/30">
                <Image image={mainImage} className="w-full object-contain object-center" />
              </div>
            )}
          </div>

          {/* Right: tech list - no background, icons inline with title */}
          <div className="space-y-6">
            {features.map((item, index) => {
              const IconComponent = getIconByName(item.iconName);
              return (
                <div key={item._key ?? index} className="space-y-2">
                  <h4 className="flex items-center gap-2 text-base font-semibold">
                    <IconComponent className="size-6 shrink-0 text-muted-foreground" aria-hidden />
                    <span className="text-lg text-foreground">{item.title}</span>
                  </h4>
                  <p className="text-muted-foreground text-sm leading-relaxed">{item.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="mt-12 flex flex-col items-center gap-6 text-center sm:mt-16">
          {ctaParagraph && <p className="text-muted-foreground max-w-4xl text-lg">{ctaParagraph}</p>}
          {ctaButton?.label && (
            <Button size="lg" asChild className="w-">
              <a href={ctaButton.link || '#'}>{ctaButton.label}</a>
            </Button>
          )}
        </div>
      </div>
    </Section>
  );
};

export default FeaturesSection03;
