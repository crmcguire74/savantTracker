export { default } from './blog-component-06';
