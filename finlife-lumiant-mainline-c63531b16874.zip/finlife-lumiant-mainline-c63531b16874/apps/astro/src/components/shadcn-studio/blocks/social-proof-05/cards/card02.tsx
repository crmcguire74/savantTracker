import { Card, CardContent } from '@local/ui/components/ui/card';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import BubbleChat from '#app/assets/bubblechat.svg?react';
import BubbleHeart from '#app/assets/bubbleheart.svg?react';
import BubbleIdCard from '#app/assets/bubbleidcard.svg?react';
import BubbleReceipt from '#app/assets/bubblereceipt.svg?react';
import { urlForImage } from '#app/sanity/sanity.utils';
import { Image, type ImageType } from '../../../elements/image';
import type { CardBase } from './types';

export type Card02Props = CardBase & {
  heading: string;
  stat1Label?: string;
  stat1Value?: string;
  image?: ImageType; //
  bar?: boolean; //
  centerVertical?: boolean;
  backgroundColor: 'default' | 'contrast'; // todo
  includeOrnaments?: boolean;
};

const Card02 = ({ heading, stat1Label, stat1Value, image, bar, centerVertical, includeOrnaments }: Card02Props) => (
  <MotionPreset fade blur slide={{ direction: 'down', offset: 15 }} delay={1} transition={{ duration: 0.5 }}>
    <Card className="h-94 py-5">
      {includeOrnaments && (
        <>
          <BubbleHeart width={70} className="absolute -left-12 -top-3" />
          <BubbleIdCard width={70} className="absolute -right-7 top-1" />
          <BubbleReceipt width={100} className="absolute -left-12 -bottom-2" />
          <BubbleChat width={80} className="absolute -right-8 bottom-3" />
        </>
      )}

      {/*add check on centerVertical */}
      <CardContent
        className={`flex h-full flex-col items-center ${!centerVertical ? 'justify-center' : ''} gap-4 px-4 text-center md:px-6 lg:px-8`}
      >
        <h4 className="text-3xl font-medium">{heading}</h4>
        <div className="flex items-center justify-between">
          <div className="flex h-full flex-col items-center justify-items gap-2 text-center">
            {stat1Value && <h4 className="text-2xl font-bold md:text-3xl lg:text-4xl">{stat1Value}</h4>}
            {stat1Label && <p className="text-xl">{stat1Label}</p>}
            {image && (
              <img
                src={image ? urlForImage(image).url() : undefined}
                alt={heading}
                className={`max-h-[160px] rounded-lg pt-2`}
              />
            )}
            {/* new variation for the component */}
            {image && <Image image={image} />}
          </div>
        </div>

        {bar && (
          <MotionPreset
            fade
            blur
            zoom={{ initialScale: 0.8 }}
            transition={{ duration: 0.5 }}
            delay={1.7}
            className="h-8.5 w-full rounded-md bg-green-600/10 dark:bg-green-400/10"
          />
        )}
      </CardContent>
    </Card>
  </MotionPreset>
);

export default Card02;
