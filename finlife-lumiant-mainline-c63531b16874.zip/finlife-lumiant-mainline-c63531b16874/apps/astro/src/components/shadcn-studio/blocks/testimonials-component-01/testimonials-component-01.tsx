import type { BlockContent } from '@local/sanity-studio/sanity.types';
import { Avatar, AvatarFallback, AvatarImage } from '@local/ui/components/ui/avatar';
import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { Card, CardContent, CardTitle } from '@local/ui/components/ui/card';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@local/ui/components/ui/carousel';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { PortableText } from '@portabletext/react';
import Autoplay from 'embla-carousel-autoplay';
import { ArrowDown, ArrowUp, Minus } from 'lucide-react';
import { Section, type SectionOptions } from '#app/components/section/section';
import { portableTextComponents } from '#app/sanity/portableText.utils';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';
import { Image, type ImageType } from '../../elements/image';

export type TestimonialItem = {
  name: string;
  role: string;
  company: string;
  avatar: {
    src: string;
    alt: string;
  };
  content: BlockContent;
};

export type MetricItem = {
  trendLabel: 'up' | 'down' | 'middle';
  trendValue: number;
  trendSuffix?: string;
  image: ImageType;
  content: BlockContent;
};

type TestimonialsComponentProps = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  testimonials: TestimonialItem[];
  metrics: MetricItem[];
  button?: ButtonType;
};

const TestimonialsComponent = ({
  sectionOptions,
  headings,
  testimonials,
  metrics,
  button,
}: TestimonialsComponentProps) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <Carousel
        className="mx-auto flex flex-col lg:flex-row max-w-7xl gap-12 px-4 sm:items-center sm:gap-16 sm:px-6 lg:gap-24 lg:px-8"
        opts={{
          align: 'start',
          slidesToScroll: 1,
          loop: true,
        }}
        plugins={[Autoplay({ delay: 4000, stopOnInteraction: false })]}
      >
        {/* Left Content */}
        <div className="space-y-6 sm:w-1/2 lg:w-2/3">
          {headings && <BlockHeader headings={headings} alignment="left" />}
          {/* Metrics */}
          <div className="flex flex-row flex-wrap items-stretch gap-5">
            {(metrics ?? []).map((metric, i) => (
              <Card
                key={`${metric.trendLabel}-${i}`}
                className="max-w-43 lg:w-1/3 min-w-0 h-full hover:border-primary transition-colors duration-300 py-2"
              >
                <CardContent className="space-y-5 px-3">
                  <CardTitle>
                    <div className="flex gap-4 items-center">
                      <div>
                        {metric.trendLabel === 'up' && <ArrowUp />}
                        {metric.trendLabel === 'down' && <ArrowDown />}
                        {metric.trendLabel === 'middle' && <Minus />}
                      </div>
                      <div className="text-2xl font-semibold">
                        {metric.trendValue}
                        {metric.trendSuffix}
                      </div>
                    </div>
                  </CardTitle>
                  <div className="flex text-xs gap-2 items-center">
                    <div className="flex-1">
                      <PortableText value={metric.content || []} components={portableTextComponents} />
                    </div>
                    {metric.image && <Image image={metric.image} className="w-16 h-16 object-cover" />}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <MotionPreset fade blur transition={{ duration: 0.5 }} delay={0.6}>
            {button && (
              <Button size="lg" className="rounded-lg text-base shadow-sm bg-primary" asChild variant={button.variant}>
                <a href={button.link || '#'}>{button.label}</a>
              </Button>
            )}
          </MotionPreset>
        </div>

        {/* Right Testimonial Carousel */}
        <div className="relative space-y-4 max-w-196 sm:w-1/2 lg:w-1/3">
          <CarouselContent className="sm:-ml-6 h-100 pb-3">
            {testimonials.map((testimonial, index) => (
              <CarouselItem key={index} className="sm:pl-6 lg:basis-full">
                <Card className="hover:border-primary h-full transition-colors duration-300">
                  <CardContent className="space-y-5 lg:space-y-13 overflow-auto">
                    <div className="flex items-center gap-3">
                      <Avatar className="size-10 rounded-full">
                        <AvatarImage src={testimonial.avatar.src} alt={testimonial.avatar.src} />
                        <AvatarFallback className="rounded-full text-sm">
                          {testimonial.name
                            .split(' ', 2)
                            .map((n) => n[0])
                            .join('')}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1">
                        <h4 className="font-medium">{testimonial.name}</h4>
                        <p className="text-muted-foreground text-sm">
                          {testimonial.role} at{' '}
                          <span className="text-card-foreground font-semibold">{testimonial.company}</span>
                        </p>
                      </div>
                    </div>
                    <PortableText value={testimonial.content} components={portableTextComponents} />
                  </CardContent>
                </Card>
              </CarouselItem>
            ))}
          </CarouselContent>
          <div className="flex items-center gap-4 pl-9">
            <CarouselPrevious
              variant="default"
              className="disabled:bg-primary/10 disabled:text-primary static translate-y-0 rounded-md disabled:opacity-100"
            />
            <CarouselNext
              variant="default"
              className="disabled:bg-primary/10 disabled:text-primary static translate-y-0 rounded-md disabled:opacity-100"
            />
          </div>
        </div>
      </Carousel>
    </Section>
  );
};

export default TestimonialsComponent;
