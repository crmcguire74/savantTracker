import { Section, type SectionOptions } from '#app/components/section/section';
import type { BlockHeaderType } from '../../block-header/BlockHeader';
import BlockHeader from '../../block-header/BlockHeader';
import Card01, { type Card01Props } from './cards/card01';
import Card02, { type Card02Props } from './cards/card02';
import Card03, { type Card03Props } from './cards/card03';

type CardProps = Card01Props | Card02Props | Card03Props;

export type SocialProof05Props = {
  sectionOptions?: SectionOptions;
  headings: BlockHeaderType;
  cards: CardProps[];
};

const SocialProof05 = ({ sectionOptions, headings, cards }: SocialProof05Props) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        {headings && <BlockHeader headings={headings} alignment="center" />}

        <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
          {cards?.map((card) =>
            card._type === 'card01' ? (
              <Card01 key={card._key} {...(card as Card01Props)} />
            ) : card._type === 'card02' ? (
              <Card02 key={card._key} {...(card as Card02Props)} />
            ) : card._type === 'card03' ? (
              <Card03 key={card._key} {...(card as Card03Props)} />
            ) : null,
          )}
        </div>
      </div>
    </Section>
  );
};

export default SocialProof05;
