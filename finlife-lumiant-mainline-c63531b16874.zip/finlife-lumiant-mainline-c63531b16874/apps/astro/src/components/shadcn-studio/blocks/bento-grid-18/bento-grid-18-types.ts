import type { StackCardData } from './card-stack';

export type BentoGrid18BaseCard = {
  title: string;
  description: string;
  modules?: string[];
  iconName?: string;
};

export type BentoGrid18FallingBadgeCard = BentoGrid18BaseCard & {
  type: 'fallingBadge';
  badges: { text: string; colorOption: string }[];
};

export type BentoGrid18DataTriangleCard = BentoGrid18BaseCard & {
  type: 'dataTriangle';
};

export type BentoGrid18CardStackCard = BentoGrid18BaseCard & {
  type: 'cardStack';
  cardsData: StackCardData[];
};

export type BentoGrid18CardType = BentoGrid18FallingBadgeCard | BentoGrid18DataTriangleCard | BentoGrid18CardStackCard;
