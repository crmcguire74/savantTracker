import { Avatar, AvatarFallback } from '@local/ui/components/ui/avatar';
import { Button } from '@local/ui/components/ui/button';
import { Card, CardContent, CardDescription, CardTitle } from '@local/ui/components/ui/card';
import { cn } from '@local/ui/lib/utils';
import { ArrowRightIcon } from 'lucide-react';
import { getIconByName } from '#app/components/shadcn-studio/icon-name-map';

type FeatureItem = {
  _key?: string;
  title: string;
  description: string;
  iconName: string;
  color: string;
};

type FeaturesSection08Props = {
  tagline: string;
  mainTitle: string;
  mainDescription: string;
  buttonText: string;
  buttonLink: string;
  features: FeatureItem[];
};

const Features = ({
  tagline,
  mainTitle,
  mainDescription,
  buttonText,
  buttonLink,
  features,
}: FeaturesSection08Props) => {
  return (
    <section className="bg-muted py-8 sm:py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-center gap-12 sm:gap-16 md:grid-cols-2 lg:gap-24">
          <div className="space-y-4">
            <p className="text-primary text-sm font-medium uppercase">{tagline}</p>
            <h2 className="text-2xl font-semibold md:text-3xl lg:text-4xl">y{mainTitle}</h2>
            <p className="text-muted-foreground text-xl">{mainDescription}</p>

            <Button className="group rounded-lg text-base shadow-sm has-[>svg]:px-6" size="lg" asChild>
              <a href={buttonLink}>
                {buttonText}
                <ArrowRightIcon className="transition-transform duration-200 group-hover:translate-x-0.5" />
              </a>
            </Button>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 md:max-lg:grid-cols-1">
            {features.map((item, index) => {
              const IconComponent = getIconByName(item.iconName);

              return (
                <Card key={item._key || index} className="shadow-none transition-shadow duration-300 hover:shadow-md">
                  <CardContent>
                    <Avatar className="mb-4 size-8 rounded-sm">
                      <AvatarFallback className={cn('rounded-sm [&>svg]:size-5', item.color)}>
                        <IconComponent />
                      </AvatarFallback>
                    </Avatar>
                    <CardTitle className="group-hover:text-primary mb-2 text-base font-semibold transition-colors duration-300">
                      {item.title}
                    </CardTitle>
                    <CardDescription>{item.description}</CardDescription>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
