// Third-party Imports
import { MessagesSquareIcon, TvMinimalIcon } from 'lucide-react';
import { useRef } from 'react';

// Component Imports

import { AnimatedBeam } from '@local/ui/components/ui/animated-beam';
import { Card, CardContent } from '@local/ui/components/ui/card';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import GoalsIcon from '#app/assets/goals.svg?react';
import KAAIcon from '#app/assets/keyadviceareas.svg?react';
import NetworthIcon from '#app/assets/networth.svg?react';
import ValuesIcon from '#app/assets/values.svg?react';

//

const SmartData = () => {
  // Vars
  const containerRef = useRef<HTMLDivElement>(null);
  const div1Ref = useRef<HTMLDivElement>(null);
  const div2Ref = useRef<HTMLDivElement>(null);
  const div3Ref = useRef<HTMLDivElement>(null);
  const div4Ref = useRef<HTMLDivElement>(null);
  const div5Ref = useRef<HTMLDivElement>(null);
  const div6Ref = useRef<HTMLDivElement>(null);
  const span1Ref = useRef<HTMLSpanElement>(null);
  const span2Ref = useRef<HTMLSpanElement>(null);
  const span3Ref = useRef<HTMLSpanElement>(null);
  const span4Ref = useRef<HTMLSpanElement>(null);
  const span5Ref = useRef<HTMLSpanElement>(null);

  return (
    <div ref={containerRef} className="relative z-1 py-2">
      <div className="flex w-full flex-col items-center gap-6">
        <div className="grid w-full grid-cols-[1fr_1fr_1.5fr_1fr] place-items-center gap-4">
          <div
            ref={div1Ref}
            className="bg-card flex w-fit items-center gap-1.5 rounded-full border px-1.5 py-1 shadow-md"
          >
            <ValuesIcon width={17} className="fill-primary" />

            <span className="text-card-foreground text-sm max-sm:hidden">Values</span>
          </div>

          <div
            ref={div2Ref}
            className="bg-card flex w-fit items-center gap-1.5 rounded-full border px-1.5 py-1 shadow-md"
          >
            <GoalsIcon width={17} className="fill-primary" />

            <span className="text-card-foreground text-sm max-sm:hidden">Goals</span>
          </div>

          <div
            ref={div3Ref}
            className="bg-card flex w-fit items-center gap-1.5 rounded-full border px-1.5 py-1 shadow-md"
          >
            <KAAIcon width={17} height={18} className="fill-primary" />

            <span className="text-card-foreground text-sm max-sm:hidden">Key Advice Areas</span>
          </div>

          <div
            ref={div4Ref}
            className="bg-card flex w-fit items-center gap-1.5 rounded-full border px-1.5 py-1 shadow-md"
          >
            <NetworthIcon width={17} className="fill-primary" />

            <span className="text-card-foreground text-sm max-sm:hidden">Net Worth</span>
          </div>
        </div>

        <div className="grid w-full grid-cols-[1fr_1fr_1.5fr_1fr] place-items-center gap-4 text-center">
          <span ref={span1Ref} className="size-0.5" />
          <span ref={span2Ref} className="size-0.5" />
          <span ref={span3Ref} className="size-0.5" />
          <span ref={span4Ref} className="size-0.5" />
        </div>

        <div className="flex justify-center">
          <span ref={span5Ref} className="size-0.5" />
        </div>

        <div className="flex justify-center">
          <div
            ref={div5Ref}
            className="bg-primary text-primary-foreground flex w-fit items-center gap-1.5 rounded-full border p-1.5 shadow-md"
          >
            <TvMinimalIcon className="size-4.5" />
            <span className="text-sm">Client Portal</span>
          </div>
        </div>

        <div className="relative w-full px-3 sm:px-6">
          <Card ref={div6Ref} className="relative h-46 pb-0">
            <CardContent className="flex h-full items-end justify-center">
              {/** biome-ignore lint/a11y/noSvgWithoutTitle: <explanation>decorative SVG</explanation> */}
              <svg width="226" height="106" viewBox="0 0 226 106" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clipPath="url(#clip0_22224_100126)">
                  <circle
                    cx="112.648"
                    cy="115"
                    r="113.25"
                    // fill="var(--)"
                    className="fill-neutral-900"
                    fillOpacity="0.2"
                    stroke="url(#paint0_linear_22224_100126)"
                    strokeWidth="1.5"
                  />
                  <circle
                    cx="112.648"
                    cy="122.5"
                    r="90.75"
                    className="fill-neutral-900"
                    fillOpacity="0.2"
                    stroke="url(#paint1_linear_22224_100126)"
                    strokeWidth="1.5"
                  />
                  <circle
                    cx="112.648"
                    cy="122.5"
                    r="60.75"
                    className="fill-neutral-900"
                    fillOpacity="0.2"
                    stroke="url(#paint2_linear_22224_100126)"
                    strokeWidth="1.5"
                  />
                </g>
                <defs>
                  <linearGradient
                    id="paint0_linear_22224_100126"
                    x1="112.648"
                    y1="2.5"
                    x2="112.648"
                    y2="201.81"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stopColor="var(--primary)" />
                    <stop offset="1" stopColor="white" stopOpacity="0" />
                  </linearGradient>
                  <linearGradient
                    id="paint1_linear_22224_100126"
                    x1="112.648"
                    y1="32.5"
                    x2="112.648"
                    y2="191.948"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stopColor="var(--primary)" />
                    <stop offset="1" stopColor="white" stopOpacity="0" />
                  </linearGradient>
                  <linearGradient
                    id="paint2_linear_22224_100126"
                    x1="112.648"
                    y1="62.5"
                    x2="112.648"
                    y2="168.799"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stopColor="var(--primary)" />
                    <stop offset="1" stopColor="white" stopOpacity="0" />
                  </linearGradient>
                  <clipPath id="clip0_22224_100126">
                    <rect width="225" height="105" fill="white" transform="translate(0.148438 0.5)" />
                  </clipPath>
                </defs>
              </svg>

              <MotionPreset
                fade
                className="bg-card absolute bottom-1/3 left-3 flex w-fit items-center gap-1.5 rounded-full border px-1.5 py-1 shadow-md"
                motionProps={{
                  animate: {
                    y: [0, -4, 0],
                    opacity: 1,
                  },
                  transition: {
                    y: {
                      duration: 1.5,
                      repeat: Infinity,
                      ease: 'easeOut',
                      delay: 0.8,
                    },
                  },
                }}
              >
                <img
                  src="https://cdn.shadcnstudio.com/ss-assets/avatar/avatar-5.png"
                  alt="avatar"
                  className="size-5 rounded-full"
                />
                <span className="text-card-foreground text-sm max-sm:hidden">Hamish, Advisor</span>
              </MotionPreset>
              <MotionPreset
                fade
                className="bg-card absolute bottom-4 left-1/7 flex w-fit items-center gap-1.5 rounded-full border px-1.5 py-1 shadow-md"
                motionProps={{
                  animate: {
                    y: [0, -4, 0],
                    opacity: 1,
                  },
                  transition: {
                    y: {
                      duration: 1.5,
                      repeat: Infinity,
                      ease: 'easeOut',
                      delay: 0.8,
                    },
                  },
                }}
              >
                <img
                  src="https://cdn.shadcnstudio.com/ss-assets/avatar/avatar-1.png"
                  alt="avatar"
                  className="size-5 rounded-full"
                />
                <span className="text-card-foreground text-sm max-sm:hidden">Shaz, Client</span>
              </MotionPreset>
              <MotionPreset
                fade
                className="bg-card absolute right-1/6 bottom-1/3 flex w-fit items-center gap-1.5 rounded-full border px-1.5 py-1 shadow-md"
                motionProps={{
                  animate: {
                    y: [0, -4, 0],
                    opacity: 1,
                  },
                  transition: {
                    y: {
                      duration: 1.5,
                      repeat: Infinity,
                      ease: 'easeOut',
                      delay: 0.8,
                    },
                  },
                }}
              >
                <img
                  src="https://cdn.shadcnstudio.com/ss-assets/avatar/avatar-3.png"
                  alt="avatar"
                  className="size-5 rounded-full"
                />
                <span className="text-card-foreground text-sm max-sm:hidden">Ashray, Client</span>
              </MotionPreset>

              <MotionPreset
                fade
                className="bg-card absolute right-3 bottom-4 flex w-fit items-center gap-1.5 rounded-full border px-1.5 py-1 shadow-md"
                motionProps={{
                  animate: {
                    y: [0, -4, 0],
                    opacity: 1,
                  },
                  transition: {
                    y: {
                      duration: 1.5,
                      repeat: Infinity,
                      ease: 'easeOut',
                      delay: 0.8,
                    },
                  },
                }}
              >
                <img
                  src="https://cdn.shadcnstudio.com/ss-assets/avatar/avatar-9.png"
                  alt="avatar"
                  className="size-5 rounded-full"
                />
                <span className="text-card-foreground text-sm max-sm:hidden">Elise, Support</span>
              </MotionPreset>

              <div className="absolute -bottom-17 left-1/2 size-16 -translate-x-1/2 -translate-y-1/2 flex justify-center items-center rounded-full bg-primary">
                {/** biome-ignore lint/a11y/noSvgWithoutTitle: <explanation>decorative SVG</explanation> */}
                <svg width="38" height="38" viewBox="0 0 47 38" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M45.6376 8.80212L29.2136 4.24732C28.8083 4.13106 28.5031 3.79731 28.4246 3.38432C28.3461 2.97132 28.5075 2.54945 28.8421 2.29348C30.789 0.784541 33.1908 -0.023588 35.6571 0.00052435H36.0379C40.8831 0.216474 45.0118 3.57594 46.1932 8.26388C46.2331 8.41841 46.1868 8.58236 46.072 8.69356C45.9572 8.80476 45.7914 8.84618 45.6376 8.80212Z"
                    fill="#0C0C16"
                  />
                  <path
                    d="M35.0774 10.9667L20.9158 36.9059C20.7194 37.2615 20.3431 37.4826 19.9342 37.4826C19.5253 37.4826 19.149 37.2615 18.9526 36.9059C16.0856 31.8117 15.8979 25.6529 18.4493 20.3963C18.6187 20.0499 18.9571 19.8152 19.3434 19.7764C21.9389 19.53 24.4517 18.7385 26.7149 17.4546C28.5919 16.3917 30.2668 15.011 31.6636 13.3753C31.731 13.2981 31.736 13.185 31.6756 13.1023C31.6153 13.0195 31.5054 12.9888 31.4104 13.0281C29.4072 13.8325 27.3044 14.3673 25.158 14.6183C24.353 14.7166 23.5432 14.7724 22.7321 14.7857C22.4914 14.7857 22.2507 14.7857 22.0069 14.7857C12.5368 14.6987 3.97414 9.18264 0.0455341 0.638187C-0.032445 0.480237 -0.00888257 0.291515 0.105588 0.15719C0.220058 0.0228648 0.403786 -0.0316586 0.573856 0.0182262L34.3927 9.37033C34.7207 9.46085 34.9893 9.69449 35.1225 10.0051C35.2558 10.3158 35.2391 10.6697 35.0774 10.9667Z"
                    fill="#0C0C16"
                  />
                </svg>
              </div>
              {/* <Logo className="[&_line]:stroke-primary-foreground [&_path]:stroke-primary-foreground [&_rect]:fill-primary absolute -bottom-17 left-1/2 size-16 -translate-x-1/2 -translate-y-1/2" /> */}
            </CardContent>
          </Card>
          <Card className="bg-muted absolute inset-x-12 -bottom-4 -z-1 h-25" />
          <div className="absolute inset-x-0 top-6 flex justify-center">
            <div className="bg-background flex items-center gap-4 rounded-xl border px-5 py-2 shadow-lg">
              <MessagesSquareIcon className="size-6 shrink-0" />

              <span className="text-sm max-sm:text-xs">
                Make each conversation the beginning of an inspiring journey.
              </span>
            </div>
          </div>
        </div>
      </div>

      <AnimatedBeam
        containerRef={containerRef}
        fromRef={div1Ref}
        toRef={span1Ref}
        className="bg-feature-gradient bg-clip-text -z-2"
        duration={4}
      />
      <AnimatedBeam
        containerRef={containerRef}
        fromRef={div2Ref}
        toRef={span2Ref}
        className="bg-feature-gradient bg-clip-text -z-2"
        duration={4}
      />
      <AnimatedBeam
        containerRef={containerRef}
        fromRef={div3Ref}
        toRef={span3Ref}
        reverse
        className="bg-feature-gradient bg-clip-text -z-2"
        duration={4}
      />
      <AnimatedBeam
        containerRef={containerRef}
        fromRef={div4Ref}
        toRef={span4Ref}
        reverse
        className="bg-feature-gradient bg-clip-text -z-2"
        duration={4}
      />
      <AnimatedBeam
        containerRef={containerRef}
        fromRef={span1Ref}
        toRef={span5Ref}
        className="bg-feature-gradient bg-clip-text -z-2"
        duration={4}
        curvature={-10}
      />
      <AnimatedBeam
        containerRef={containerRef}
        fromRef={span2Ref}
        toRef={span5Ref}
        className="bg-feature-gradient bg-clip-text -z-2"
        duration={4}
        curvature={-10}
      />
      <AnimatedBeam
        containerRef={containerRef}
        fromRef={span3Ref}
        toRef={span5Ref}
        reverse
        className="bg-feature-gradient bg-clip-text -z-2"
        duration={4}
        curvature={-10}
      />
      <AnimatedBeam
        containerRef={containerRef}
        fromRef={span4Ref}
        toRef={span5Ref}
        reverse
        className="bg-feature-gradient bg-clip-text -z-2"
        duration={4}
        curvature={-10}
      />
      <AnimatedBeam
        containerRef={containerRef}
        fromRef={span5Ref}
        toRef={div5Ref}
        className="bg-feature-gradient bg-clip-text -z-2"
        duration={4}
      />
      <AnimatedBeam
        containerRef={containerRef}
        fromRef={div5Ref}
        toRef={div6Ref}
        className="bg-feature-gradient bg-clip-text -z-2"
        duration={4}
      />
    </div>
  );
};

export default SmartData;
