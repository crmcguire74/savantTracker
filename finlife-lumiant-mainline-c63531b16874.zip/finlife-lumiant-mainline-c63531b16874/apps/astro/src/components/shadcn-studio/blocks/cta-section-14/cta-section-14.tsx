import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { Card, CardContent } from '@local/ui/components/ui/card';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { cn } from '@local/ui/lib/utils';
import { ArrowRightIcon } from 'lucide-react';
import KAAIcon from '#app/assets/kaa.svg?react';
import { Section, type SectionOptions } from '#app/components/section/section';
import { Image } from '#app/components/shadcn-studio/elements/image';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';

type CTASection14Props = {
  sectionOptions?: SectionOptions;
  headings: BlockHeaderType;
  button: ButtonType;
  image: {
    src: string;
    alt: string;
  };
  showKaaIcon?: boolean;
  className?: string;
};

const CTASection14 = ({
  sectionOptions,
  headings,
  button,
  image,
  showKaaIcon = true,
  className,
}: CTASection14Props) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="container mx-auto max-w-7xl px-4 lg:px-0">
        <MotionPreset fade blur slide={{ direction: 'down', offset: 50 }} transition={{ duration: 0.7 }}>
          <Card
            className={cn(
              'group relative overflow-hidden rounded-2xl border-none bg-ombre-gradient py-0 shadow-none',
              className,
            )}
          >
            {showKaaIcon && <KAAIcon className="absolute -left-[95px] bottom-10" />}
            <CardContent className="lg:pl-14 lg:pr-0">
              <div className="grid grid-cols-1 items-end gap-5 lg:grid-cols-2 lg:gap-10">
                {/* Left Column - Content */}
                <div className="flex h-full flex-col justify-center space-y-8 py-12 text-white">
                  <BlockHeader
                    alignment="left"
                    className="text-white"
                    descriptionClassName="text-white opacity-80"
                    headings={headings}
                  />

                  <div>
                    <Button size="lg" asChild>
                      <a href={button.link} className="inline-flex items-center gap-2">
                        {button.label}
                        <ArrowRightIcon className="h-5 w-5" />
                      </a>
                    </Button>
                  </div>
                </div>

                {/* Right Column - Image */}
                <div className="relative pt-2 -mr-[2px]">
                  <Image
                    image={image}
                    className="w-full object-cover object-right transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </MotionPreset>
      </div>
    </Section>
  );
};

export default CTASection14;
