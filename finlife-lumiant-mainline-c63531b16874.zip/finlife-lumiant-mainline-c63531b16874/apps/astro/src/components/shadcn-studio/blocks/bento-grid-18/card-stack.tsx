import { cn } from '@local/ui/lib/utils';
import { CheckCircle2, ChevronRight, Droplets } from 'lucide-react';
import { motion, useMotionValue, useTransform } from 'motion/react';
import { type ReactNode, useState } from 'react';
import { Image, type ImageType } from '../../elements/image';

type CardRotateProps = {
  children: ReactNode;
  onSendToBack: () => void;
  sensitivity: number;
};

const CardRotate = ({ children, onSendToBack, sensitivity }: CardRotateProps) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useTransform(y, [-100, 100], [60, -60]);
  const rotateY = useTransform(x, [-100, 100], [-60, 60]);

  const handleDragEnd = (_: unknown, info: { offset: { x: number; y: number } }) => {
    if (Math.abs(info.offset.x) > sensitivity || Math.abs(info.offset.y) > sensitivity) {
      onSendToBack();
    } else {
      x.set(0);
      y.set(0);
    }
  };

  return (
    <motion.div
      className="absolute cursor-grab"
      style={{ x, y, rotateX, rotateY }}
      drag
      dragConstraints={{ top: 0, right: 0, bottom: 0, left: 0 }}
      dragElastic={0.6}
      whileTap={{ cursor: 'grabbing' }}
      onDragEnd={handleDragEnd}
      tabIndex={-1}
    >
      {children}
    </motion.div>
  );
};

export type StackCardData = {
  id: number;
  image: ImageType;
  title: string;
  href: string;
  /** Optional: category label (e.g. "Family") */
  category?: string;
  /** Progress 0-100 for the circular indicator */
  progress?: number;
  /** Current amount for display (e.g. 24500) */
  amountCurrent?: number;
  /** Target amount for display (e.g. 30000) */
  amountTarget?: number;
  /** Number of tasks left */
  tasksLeft?: number;
  /** Status label (e.g. "On Track") */
  status?: string;
  /** @deprecated use category, progress, amountCurrent, amountTarget, tasksLeft, status instead */
  avatars?: { src: string; fallback: string }[];
  /** @deprecated */
  days?: number;
};

export type StackProps = {
  randomRotation?: boolean;
  sensitivity?: number;
  sendToBackOnClick?: boolean;
  cardsData?: StackCardData[];
  animationConfig?: { stiffness: number; damping: number };
  className?: string;
  perspective?: number;
};

const CardStack = ({
  randomRotation = false,
  sensitivity = 200,
  cardsData = [],
  animationConfig = { stiffness: 260, damping: 20 },
  className,
  sendToBackOnClick = false,
  perspective,
}: StackProps) => {
  const [cards, setCards] = useState(cardsData);

  const sendToBack = (id: number) => {
    setCards((prev) => {
      const newCards = [...prev];
      const index = newCards.findIndex((card) => card.id === id);
      const [card] = newCards.splice(index, 1);
      newCards.unshift(card);
      return newCards;
    });
  };

  return (
    <div className={cn('relative', className)} style={{ perspective: perspective ?? 600 }} tabIndex={-1}>
      {cards.map((card, index) => {
        const randomRotate = randomRotation ? Math.random() * 10 - 5 : 0;
        return (
          <CardRotate key={card.id} onSendToBack={() => sendToBack(card.id)} sensitivity={sensitivity}>
            <motion.div
              className={cn(
                'flex h-57.5 w-51.25 flex-col overflow-hidden rounded-xl border border-white/60 shadow-sm focus-visible:outline-none',
                index === cards.length - 1 ? 'bg-pink-300' : 'bg-white',
              )}
              onClick={() => sendToBackOnClick && sendToBack(card.id)}
              animate={{
                rotateZ: (cards.length - index - 1) * 2 - randomRotate,
                transformOrigin: 'center center',
              }}
              initial={false}
              transition={{
                type: 'spring',
                stiffness: animationConfig.stiffness,
                damping: animationConfig.damping,
              }}
              tabIndex={-1}
            >
              {/* Image - ~40–45% height */}
              <div className="h-[42%] shrink-0 p-1.5">
                <div className="h-full overflow-hidden rounded-t-xl">
                  <Image image={card.image} className="pointer-events-none h-full w-full object-cover" />
                </div>
              </div>
              {/* Content */}
              <div className="flex flex-1 flex-col gap-2 px-3 pb-3 pt-2.5">
                <h4 className="line-clamp-2 font-semibold leading-tight text-foreground">{card.title}</h4>
                {/* Row 1: Category + Progress */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex flex-col">
                    <div className="flex min-w-0 items-center gap-1.5">
                      <div className="flex size-6 shrink-0 items-center justify-center rounded-full bg-muted">
                        <Droplets className="size-3.5 text-muted-foreground" />
                      </div>
                      <span className="truncate text-sm font-medium text-foreground">{card.category ?? 'Family'}</span>
                    </div>
                    <span className="truncate text-xs text-muted-foreground">
                      {card.amountCurrent != null && card.amountTarget != null
                        ? `$${card.amountCurrent.toLocaleString()}/$${card.amountTarget.toLocaleString()}`
                        : '$24,500/$30,000'}
                    </span>
                  </div>
                  <div
                    className="relative flex size-12 shrink-0 items-center justify-center rounded-full"
                    style={{
                      background: `conic-gradient(var(--color-primary) 0% ${card.progress ?? 75}%, var(--color-muted) ${card.progress ?? 75}% 100%)`,
                    }}
                  >
                    <div className="absolute inset-[2px] flex items-center justify-center rounded-full bg-card">
                      <span className="text-xs font-bold text-foreground">{card.progress ?? 75}%</span>
                    </div>
                  </div>
                </div>
                {/* Row 2: Amount + Tasks */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="size-4 shrink-0 text-teal-600 dark:text-teal-400" />
                    <span className="text-xxs font-medium text-foreground">{card.status ?? 'On Track'}</span>
                  </div>
                  <a
                    href={card.href}
                    className="flex shrink-0 items-center gap-0.5 text-xs font-medium text-foreground hover:underline"
                  >
                    {card.tasksLeft != null ? `${card.tasksLeft} Tasks left` : '3 Tasks left'}
                    <ChevronRight className="size-4" />
                  </a>
                </div>
              </div>
            </motion.div>
          </CardRotate>
        );
      })}
    </div>
  );
};

export { CardRotate, CardStack };
