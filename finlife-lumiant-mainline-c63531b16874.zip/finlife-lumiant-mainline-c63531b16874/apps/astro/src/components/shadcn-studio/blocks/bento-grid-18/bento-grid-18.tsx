import { Section, type SectionOptions } from '#app/components/section/section';
import BlockHeader, { type BlockHeaderType } from '#app/components/shadcn-studio/block-header/BlockHeader';
import BentoGrid18Card from './bento-grid-18-card';
import type {
  BentoGrid18CardStackCard,
  BentoGrid18CardType,
  BentoGrid18DataTriangleCard,
  BentoGrid18FallingBadgeCard,
} from './bento-grid-18-types';
import { CardStack } from './card-stack';
import DataTriangle from './data-triangle';
import FallingBadge, { type BadgeItem } from './falling-badge';

export type { BentoGrid18CardStackCard, BentoGrid18DataTriangleCard, BentoGrid18FallingBadgeCard };

export type BentoGrid18Props = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  gridItems: Array<BentoGrid18CardStackCard | BentoGrid18DataTriangleCard | BentoGrid18FallingBadgeCard>;
};

const BADGE_COLOR_CLASSES: Record<string, string> = {
  red: 'bg-values-red/60',
  green: 'bg-values-green/60',
  orange: 'bg-values-orange/60',
  yellow: 'bg-values-yellow/60',
  pink: 'bg-values-pink/60',
  purple: 'bg-values-purple/60',
  blue: 'bg-values-blue/60',
};

const BentoGrid18 = ({ sectionOptions, headings, gridItems }: BentoGrid18Props) => {
  const renderBentoCard = (item: BentoGrid18CardType) => {
    switch (item.type) {
      case 'fallingBadge': {
        const badges: BadgeItem[] = (item.badges || []).map((b) => ({
          text: b.text,
          className: BADGE_COLOR_CLASSES[b.colorOption] ?? BADGE_COLOR_CLASSES.blue,
        }));
        return <FallingBadge badges={badges} trigger="scroll" gravity={1.2} className="p-0" />;
      }
      case 'dataTriangle':
        return <DataTriangle />;
      case 'cardStack':
        return (
          <div className="relative flex h-67 justify-center overflow-hidden px-6">
            <CardStack
              cardsData={item.cardsData}
              perspective={3500}
              className="w-67.5 focus-visible:outline-none [&>div]:top-1/2 [&>div]:-translate-y-1/2 flex justify-center"
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-6 px-4 sm:px-6 md:grid-cols-6 lg:px-8">
        {headings && (
          <div className="col-span-full">
            <BlockHeader headings={headings} />
          </div>
        )}
        {gridItems.map((item, i) => (
          <BentoGrid18Card
            key={`${item.type}-${i}`}
            title={item.title}
            description={item.description}
            modules={item.modules}
            iconName={item.iconName}
          >
            {renderBentoCard(item)}
          </BentoGrid18Card>
        ))}
      </div>
    </Section>
  );
};

export default BentoGrid18;
