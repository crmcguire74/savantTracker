import { Badge } from '@local/ui/components/ui/badge';
import { Card, CardContent } from '@local/ui/components/ui/card';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import type { CardBase } from './types';

export type Card01Props = CardBase & {
  topText: string;
  middleTextLg: string;
  lowerText: string;
  badge?: string;
  yesPercentage: number;
  noPercentage: number;
  backgroundColor?: string;
};

const Card01 = ({ topText, middleTextLg, lowerText, badge, yesPercentage, noPercentage }: Card01Props) => (
  <MotionPreset fade blur slide={{ direction: 'down', offset: 15 }} delay={0.9} transition={{ duration: 0.5 }}>
    <Card className="h-94 py-5">
      <CardContent className="flex h-full justify-between gap-6 px-4 md:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-20">
          <div className="space-y-6 font-medium">
            <p className="text-xl">{topText}</p>
            <h4 className="text-3xl">{middleTextLg}</h4>
            <p className="text-xl">{lowerText}</p>
          </div>
          {badge && (
            <div>
              <Badge className="bg-primary/10 [a&]:hover:bg-primary/5 focus-visible:ring-primary/20 dark:focus-visible:ring-primary/40 text-primary rounded-sm border-none px-3 py-1 focus-visible:outline-none">
                {badge}
              </Badge>
            </div>
          )}
        </div>
        <div className="h-full">
          <div className="flex h-3/5 w-full flex-col justify-center gap-2 rounded-t-lg bg-green-600/20 px-3 py-2.5 dark:bg-green-400/20">
            <p className="text-xl font-medium">Yes</p>
            <h4 className="text-2xl font-semibold md:text-3xl lg:text-4xl">{yesPercentage}%</h4>
          </div>
          <div className="flex h-2/5 w-full flex-col justify-center gap-2 rounded-b-lg bg-amber-600/20 px-3 py-2.5 dark:bg-amber-400/20">
            <p className="text-xl font-medium">No</p>
            <h4 className="text-2xl font-semibold md:text-3xl lg:text-4xl">{noPercentage}%</h4>
          </div>
        </div>
      </CardContent>
    </Card>
  </MotionPreset>
);

export default Card01;
