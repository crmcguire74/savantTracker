import { Badge } from '@local/ui/components/ui/badge';
import { Card, CardContent, CardDescription, CardTitle } from '@local/ui/components/ui/card';
import { ClockIcon } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { Section, type SectionOptions } from '#app/components/section/section';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';
import { Image, type ImageType } from '../../elements/image';
import NewsletterCard, { type NewsletterCardProps } from './newsletter-card';

const headerTransition = { type: 'spring' as const, stiffness: 300, damping: 30 };

const cardTransition = { type: 'spring' as const, stiffness: 400, damping: 30 };
const CARD_STAGGER_MS = 0.04;

export type BlogComponent06Card = {
  image: ImageType;
  categories: { title: string; slug: string }[];
  title: string;
  date: string;
  blogLink: string;
};

type BlogComponent06Props = {
  sectionOptions?: SectionOptions;
  headings: BlockHeaderType;
  blogCards: BlogComponent06Card[];
  newsletterCard: NewsletterCardProps;
  /** When true, hides the header and newsletter block (e.g. when searching). */
  hideHeaderAndNewsletter?: boolean;
};

const BlogComponent06 = ({
  sectionOptions,
  headings,
  blogCards,
  newsletterCard,
  hideHeaderAndNewsletter = false,
}: BlogComponent06Props) => {
  return (
    <Section {...sectionOptions} className="py-8 sm:py-16 lg:pb-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatePresence initial={false}>
          {!hideHeaderAndNewsletter && (
            <motion.div
              key="header-newsletter"
              className="grid grid-cols-1 gap-16 md:grid-cols-2 overflow-hidden"
              initial={{ opacity: 0, height: 0, marginBottom: 0 }}
              animate={{
                opacity: 1,
                height: 'auto',
                marginBottom: 96,
                transition: headerTransition,
              }}
              exit={{
                opacity: 0,
                height: 0,
                marginBottom: 0,
                transition: headerTransition,
              }}
            >
              {headings && <BlockHeader headings={headings} alignment="left" />}
              <NewsletterCard {...newsletterCard} />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Blog Grid */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout" initial={false}>
            {blogCards.map((card, index) => (
              <motion.div
                key={card.blogLink}
                layout
                initial={{ opacity: 0, y: 16 }}
                animate={{
                  opacity: 1,
                  y: 0,
                  transition: {
                    ...cardTransition,
                    delay: index * CARD_STAGGER_MS,
                  },
                }}
                exit={{ opacity: 0, y: -8, transition: { duration: 0.15 } }}
              >
                <a href={card.blogLink} className="block">
                  <Card className="py-0 shadow-none max-lg:last:col-span-full gradient-border-ombre">
                    <CardContent className="px-0">
                      <Image image={card.image} className="max-h-60 w-full rounded-t-xl object-cove" />
                      <div className="gap-4 space-y-4 p-6">
                        <div className="mb-2 -mx-0.5 flex flex-wrap gap-2">
                          {card.categories.map((category, catIndex) => (
                            <Badge
                              key={catIndex}
                              className="bg-muted border-none text-sm text-muted-foreground dark:bg-accent!"
                            >
                              {category.title}
                            </Badge>
                          ))}
                        </div>
                        <CardTitle className="text-xl font-medium">{card.title}</CardTitle>
                        <CardDescription className="flex items-center gap-1.5 py-1 text-base">
                          <ClockIcon className="text-muted-foreground size-5" />
                          <span className="text-muted-foreground">{card.date}</span>
                        </CardDescription>
                      </div>
                    </CardContent>
                  </Card>
                </a>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </Section>
  );
};

export default BlogComponent06;
