import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { Card, CardContent } from '@local/ui/components/ui/card';
import { CheckIcon } from 'lucide-react';
import { Section, type SectionOptions } from '#app/components/section/section';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';
import { Image, type ImageType } from '../../elements/image';

type CTASection07Props = {
  sectionOptions?: SectionOptions;
  headings: BlockHeaderType;
  features: string[];
  image: ImageType;
  button?: ButtonType;
};

const CTASection07 = ({ sectionOptions, headings, features, image, button }: CTASection07Props) => {
  return (
    <Section className="py-8 theme-force-light" {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-0">
        <Card className="bg-brand-aqua py-8 rounded-3xl border-none shadow-none">
          <CardContent className="flex flex-col items-center justify-between  px-8 sm:px-16 lg:flex-row lg:pl-24">
            <div className="flex grow flex-col gap-4">
              <BlockHeader alignment="left" className="mb-0! text-card-foreground" headings={headings} />
              <div className="grid gap-4 md:grid-cols-1">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-4 py-1">
                    <div className="bg-white flex size-5 items-center justify-center rounded-full p-0.5">
                      <CheckIcon className="text-card-foreground size-4" />
                    </div>
                    <span className="font-medium text-card-foreground">{feature}</span>
                  </div>
                ))}
              </div>
              {button && (
                <div className="grid gap-4 md:grid-cols-1">
                  <Button size="lg" className="max-w-82 rounded-lg text-base">
                    <a href={button.link}>{button.label}</a>
                  </Button>
                </div>
              )}
            </div>
            <Image className="max-h-92 rounded-xl" image={image} />
          </CardContent>
        </Card>
      </div>
    </Section>
  );
};

export default CTASection07;
