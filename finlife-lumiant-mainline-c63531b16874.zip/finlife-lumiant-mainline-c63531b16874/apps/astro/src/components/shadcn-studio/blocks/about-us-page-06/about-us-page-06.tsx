import type { BlockContent } from '@local/sanity-studio/sanity.types';
import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { Card, CardContent, CardTitle } from '@local/ui/components/ui/card';
import { PortableText } from '@portabletext/react';
import AboutUsPage06Icon from '#app/assets/aboutuspage06.svg?react';
import { Section, type SectionOptions } from '#app/components/section/section';
import { portableTextComponents } from '#app/sanity/portableText.utils';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';
import { Image, type ImageType } from '../../elements/image';

type CardItem = {
  heading: BlockContent;
  description: BlockContent;
  image: ImageType;
};

type AboutUsPage06Props = {
  sectionOptions?: SectionOptions;
  headings: BlockHeaderType;
  button: ButtonType;
  cards: CardItem[];
  image: ImageType;
};

const AboutUsPage06 = ({ sectionOptions, headings, button, cards, image }: AboutUsPage06Props) => (
  <Section {...sectionOptions} className="py-8 sm:py-16 lg:py-24">
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      {/* Header */}

      <div className="mb-8 flex items-center justify-between gap-16 max-md:flex-col">
        {headings && <BlockHeader headings={headings} alignment="left" />}

        {button && (
          <Button variant={'default'} className="rounded-lg text-base max-lg:self-center" size="lg">
            <a href={button.link}>{button.label}</a>
          </Button>
        )}
      </div>

      <div className="grid gap-16 lg:grid-cols-2">
        <div className="relative flex h-max justify-center">
          {/* Decorative SVG Lines */}
          <AboutUsPage06Icon />

          {/* Main Image */}
          <Image image={image} />

          {/* Decorative Dot Pattern - Bottom Left */}
          <div className="absolute bottom-5 left-12 grid grid-cols-7 gap-1 opacity-50 sm:bottom-11 sm:left-22 md:bottom-22 md:left-38 lg:bottom-36 lg:left-35 xl:bottom-21 xl:left-21">
            {Array.from({ length: 98 }).map((_, i) => (
              <div key={i} className="bg-primary/50 size-1 rounded-full" />
            ))}
          </div>

          {/* Decorative Dot Pattern - Bottom Right */}
          <div className="absolute right-2.5 -bottom-7 grid grid-cols-7 gap-1 opacity-50 sm:right-6 sm:-bottom-11 md:right-21 md:bottom-1 lg:right-7">
            {Array.from({ length: 98 }).map((_, i) => (
              <div key={i} className="bg-primary/50 size-1 rounded-full" />
            ))}
          </div>
        </div>

        <div className="grid gap-6 sm:grid-cols-2">
          {cards?.map((card, index) => {
            return (
              <Card key={index} className="border-none shadow-none transition-shadow duration-300 hover:shadow-sm">
                <CardContent className="flex h-full flex-col items-center justify-center text-center">
                  {card.image && <Image image={card.image} className="max-h-[110px] rounded-lg pt-2 mb-6" />}
                  <CardTitle className="text-sm font-bold">
                    <PortableText value={card.heading} components={portableTextComponents} />
                  </CardTitle>
                  <div className={'text-sm'}>
                    <PortableText value={card.description} components={portableTextComponents} />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  </Section>
);

export default AboutUsPage06;
