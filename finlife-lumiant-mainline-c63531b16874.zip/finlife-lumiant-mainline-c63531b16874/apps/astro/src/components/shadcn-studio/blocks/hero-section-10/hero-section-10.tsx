import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { Section, type SectionOptions } from '#app/components/section/section';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';
import { Image, type ImageType } from '../../elements/image';
import StatisticsCard from './statistics-card-01';

type HeroSection10Props = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  button?: ButtonType;
  image?: ImageType;
  showStats?: boolean;
};

const HeroSection10 = ({ sectionOptions, headings, button, image, showStats }: HeroSection10Props) => {
  return (
    <Section className="relative flex h-full flex-1 flex-col py-6 md:py-24" {...sectionOptions}>
      <div className="mx-auto flex w-full justify-between max-w-7xl flex-1 items-center px-4 sm:px-6 lg:px-6 gap-8 md:gap-12 flex-col md:flex-row">
        {/* Hero Content */}
        <div className="md:w-3/5 md:max-w-3/5 lg:max-w-3/5">
          {headings && <BlockHeader headings={headings} alignment="left" />}

          {button && (
            <MotionPreset
              fade
              slide
              delay={0.9}
              transition={{ duration: 0.5 }}
              className="flex flex-wrap items-center gap-4"
            >
              <Button size="lg" variant={button.variant} className="rounded-lg text-base shadow-sm" asChild>
                <a href={button.link}>{button.label}</a>
              </Button>
            </MotionPreset>
          )}
        </div>

        {/* Hero Image */}
        {image && (
          <div className="relative flex h-full md:w-3/5 md:max-w-3/5 flex-col items-center gap-4 sm:mb-auto lg:mb-0">
            <div className="hidden md:inline">
              <MotionPreset
                fade
                className="absolute top-49 -left-6 w-55 origin-top-left scale-85 z-50"
                motionProps={{
                  animate: {
                    y: [0, -16, 0],
                    opacity: 1,
                  },
                  transition: {
                    y: {
                      duration: 2.1,
                      repeat: Infinity,
                      ease: 'easeOut',
                      delay: 2.7,
                    },
                    opacity: {
                      duration: 0.5,
                      delay: 2.7,
                    },
                  },
                }}
              >
                {showStats && (
                  <StatisticsCard
                    title="Goals"
                    text="Deeper client understanding creates more opportunities to serve, engage families, and inspire action."
                  />
                )}
              </MotionPreset>
            </div>
            <div className="hidden md:inline">
              <MotionPreset
                fade
                className="absolute top-13 left-76 w-55 origin-top-left scale-85 z-50"
                motionProps={{
                  animate: {
                    y: [0, -16, 0],
                    opacity: 1,
                  },
                  transition: {
                    y: {
                      duration: 2.1,
                      repeat: Infinity,
                      ease: 'easeOut',
                      delay: 2.7,
                    },
                    opacity: {
                      duration: 0.5,
                      delay: 2.7,
                    },
                  },
                }}
              >
                {showStats && (
                  <StatisticsCard
                    title="HALO"
                    text="Unlock deeper client motivation by visualizing the impact of lifestyle choices on their life, health, and wealth."
                    badgeVariant={'amber'}
                    className="bg-background/60"
                  />
                )}
              </MotionPreset>
            </div>
            <div className="hidden md:inline">
              <MotionPreset
                fade
                className="absolute top-130 right-10 w-55 origin-top-left scale-85 z-50"
                motionProps={{
                  animate: {
                    y: [0, -16, 0],
                    opacity: 1,
                  },
                  transition: {
                    y: {
                      duration: 2.1,
                      repeat: Infinity,
                      ease: 'easeOut',
                      delay: 2.7,
                    },
                    opacity: {
                      duration: 0.5,
                      delay: 2.7,
                    },
                  },
                }}
              >
                {showStats && (
                  <StatisticsCard
                    title="Key Advice Areas"
                    text="Activate 12 pre-defined Key Advice Areas, achieve your clients goals and dreams."
                  />
                )}
              </MotionPreset>
            </div>
            <MotionPreset fade blur slide={{ direction: 'right' }} zoom delay={0.5} transition={{ duration: 0.5 }}>
              <Image image={image} className="h-full object-cover" />
            </MotionPreset>
          </div>
        )}
      </div>
    </Section>
  );
};

export default HeroSection10;
