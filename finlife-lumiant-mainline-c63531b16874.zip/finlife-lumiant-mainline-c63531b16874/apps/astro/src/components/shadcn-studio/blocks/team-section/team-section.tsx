import { Section, type SectionOptions } from '#app/components/section/section';
import type { BlockHeaderType } from '#app/components/shadcn-studio/block-header/BlockHeader';
import BlockHeader from '#app/components/shadcn-studio/block-header/BlockHeader';
import { Image, type ImageType } from '#app/components/shadcn-studio/elements/image';

export type TeamSectionProps = {
  sectionOptions?: SectionOptions;
  headings: BlockHeaderType;
  teamImage: ImageType;
};

const TeamSection = ({ sectionOptions, headings, teamImage }: TeamSectionProps) => {
  return (
    <Section {...sectionOptions} className="pt-8 sm:pt-16 lg:pt-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <BlockHeader headings={headings} alignment="center" />
      </div>
      <div className="w-full">
        <Image image={teamImage} className="w-full object-cover" />
      </div>
    </Section>
  );
};

export default TeamSection;
