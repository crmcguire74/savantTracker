import type { BlockContent } from '@local/sanity-studio/sanity.types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@local/ui/components/ui/card';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { PortableText } from '@portabletext/react';
import { portableTextComponents } from '#app/sanity/portableText.utils';
import { Image, type ImageType } from '../../elements/image';
import SmartData from './smart-data';

export type GridItem = {
  _key?: string;
  title: BlockContent;
  description: BlockContent;
  image?: ImageType;
  useLumiantPortalDiagram?: boolean;
  span?: 1 | 2 | 3 | 4 | 5 | 6; // Number of columns to span out of 6
};

type BentoCardProps = GridItem & {
  index: number;
  muted: boolean;
};

export const BentoCard = ({
  index,
  muted,
  _key,
  title,
  description,
  useLumiantPortalDiagram,
  image,
  span = 3,
}: BentoCardProps) => {
  const gridItemColumnClasses = {
    1: 'sm:col-span-1 lg:col-span-1',
    2: 'sm:col-span-2 lg:col-span-2',
    3: 'sm:col-span-2 lg:col-span-3',
    4: 'sm:col-span-2 lg:col-span-4',
    5: 'sm:col-span-2 lg:col-span-5',
    6: 'sm:col-span-2 lg:col-span-6 lg:flex-row',
  };

  return (
    <MotionPreset
      key={_key || index}
      fade
      blur
      slide={{ offset: 15 }}
      transition={{ duration: 0.5 }}
      className={`h-full ${gridItemColumnClasses[span]}`} // This needs to be dynamic based on item type
      delay={0.7 + index * 0.15}
    >
      <Card
        className={`${muted ? 'bg-muted' : ''} border-none h-full shadow-none ${span === 6 && 'lg:flex-row w-full'}`}
      >
        <CardContent className="flex flex-2 justify-center">
          {useLumiantPortalDiagram ? (
            <SmartData />
          ) : (
            image && <Image image={image} className={`w-auto h-full ${span === 6 && 'lg:max-h-50'}`} />
          )}
        </CardContent>
        <CardHeader className="mt-4 gap-4 flex-2 h-fit">
          <CardTitle className="text-2xl">
            <PortableText value={title} components={portableTextComponents} />
          </CardTitle>
          <CardDescription className="text-lg font-regular">
            <PortableText value={description} components={portableTextComponents} />
          </CardDescription>
        </CardHeader>
      </Card>
    </MotionPreset>
  );
};
