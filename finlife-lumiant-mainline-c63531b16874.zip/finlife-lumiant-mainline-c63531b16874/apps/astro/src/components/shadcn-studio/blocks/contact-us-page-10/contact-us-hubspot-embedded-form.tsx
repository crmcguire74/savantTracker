import { HubspotEmbeddedFormContainer } from '#app/components/hubspot/hubspot-embedded-form';
import type { HubspotEmbedFields } from '#app/sanity/hubspot.utils';
import './contact-us-hubspot-embedded-form.css';

type Props = {
  hubspotContactForm?: HubspotEmbedFields | null;
};

const ContactUsHubspotForm = ({ hubspotContactForm }: Props) => {
  return (
    <HubspotEmbeddedFormContainer form={hubspotContactForm} className="w-full space-y-2 hs-form-html hs-contact" />
  );
};

export default ContactUsHubspotForm;
