import { Avatar, AvatarFallback } from '@local/ui/components/ui/avatar';
import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { Card, CardContent, CardDescription, CardTitle } from '@local/ui/components/ui/card';
import { cn } from '@local/ui/lib/utils';
import { ArrowRightIcon, ClockIcon, CreditCardIcon, SquareCheckBigIcon } from 'lucide-react';
import { Image, type ImageType } from '../../elements/image';

export type FeatureSection10CardVariant = 'primary' | 'blue' | 'purple';

const featureSection10CardVariantMap: Record<
  FeatureSection10CardVariant,
  {
    icon: React.ElementType;
    iconColorClass: string;
    titleColorClass: string;
    cardClasses: string;
    buttonClasses: string;
  }
> = {
  primary: {
    icon: CreditCardIcon,
    iconColorClass: 'text-foreground',
    titleColorClass: 'text-foreground',
    cardClasses: 'hover:border-primary hover:bg-primary/10',
    buttonClasses:
      'text-foreground group-hover:bg-primary! group-hover:text-primary-foreground! dark:group-hover:bg-primary/90!',
  },
  blue: {
    icon: SquareCheckBigIcon,
    iconColorClass: 'text-cyan-600 bg-cyan-50/30 group-hover:bg-card dark:bg-card dark:text-brand-aqua',
    titleColorClass: 'text-cyan-800 dark:text-brand-aqua',
    cardClasses: 'hover:border-cyan-600 hover:bg-cyan-50/30 dark:hover:bg-cyan-50/10 dark:hover:border-brand-aqua',
    buttonClasses: 'text-cyan-600 group-hover:bg-brand-aqua! dark:text-brand-aqua! dark:group-hover:bg-cyan-900!',
  },
  purple: {
    icon: ClockIcon,
    iconColorClass: 'text-violet-800 dark:text-brand-lavender',
    titleColorClass: 'text-violet-900 dark:text-brand-lavender',
    cardClasses:
      'hover:border-violet-800 hover:bg-violet-50/30 dark:hover:bg-violet-50/10 dark:hover:border-brand-lavender',
    buttonClasses:
      'text-violet-800 group-hover:bg-brand-lavender! dark:text-brand-lavender! dark:group-hover:bg-violet-900!',
  },
};

export type FeatureSection10CardProps = {
  title: string;
  description: string;
  image?: ImageType;
  button: ButtonType;
  variant: FeatureSection10CardVariant;
};

const FeatureSection10Card = ({ title, description, button, image, variant }: FeatureSection10CardProps) => {
  const {
    icon: Icon,
    iconColorClass,
    titleColorClass,
    cardClasses,
    buttonClasses,
  } = featureSection10CardVariantMap[variant];

  return (
    <Card className={cn('group h-90 flex-1 transition-all duration-500 hover:flex-2', cardClasses)}>
      <CardContent className="flex h-full">
        <div className="flex flex-col space-y-6 shrink-4 h-full">
          <Avatar className="size-10 shadow-sm">
            <AvatarFallback className={`bg-card ${iconColorClass}`}>
              <Icon className="size-5" />
            </AvatarFallback>
          </Avatar>
          <div className="space-y-2">
            <CardTitle className={`line-clamp-2 text-lg font-semibold ${titleColorClass}`}>{title}</CardTitle>
            <CardDescription className="line-clamp-5">{description}</CardDescription>
          </div>
          {button && (
            <Button
              className={cn(
                'group mt-auto w-fit justify-start rounded-full bg-transparent! text-base transition-all duration-300 has-[>svg]:px-6',
                buttonClasses,
              )}
              size="lg"
              asChild
            >
              <a href={button.link}>
                {button.label}
                <ArrowRightIcon className="transition-transform duration-200 group-hover:translate-x-0.5" />
              </a>
            </Button>
          )}
        </div>
        {image && (
          <div className="">
            <Image
              image={image}
              className="mx-auto my-auto hidden w-40 h-full shrink-0 object-contain group-hover:inline sm:w-56"
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FeatureSection10Card;
