import Tabs11 from '@local/ui/components/shadcn-studio/tabs/tabs-11';
import { BellRingIcon, LayoutDashboardIcon } from 'lucide-react';
import { useState } from 'react';
import { Section, type SectionOptions } from '#app/components/section/section';
import type { BlockHeaderType } from '../../block-header/BlockHeader';
import BlockHeader from '../../block-header/BlockHeader';
import FeatureSection10Card, { type FeatureSection10CardProps } from './feature-section-10-card';

type FeatureSection10Props = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  advisorCards: FeatureSection10CardProps[];
  enterpriseCards: FeatureSection10CardProps[];
};

type Tabs = 'enterprises' | 'advisors';

const FeaturesSection10 = ({ sectionOptions, headings, advisorCards, enterpriseCards }: FeatureSection10Props) => {
  // biome-ignore lint/correctness/noUnusedVariables: <explanation>to be implemented</explanation>
  const [selectedTab, setSelectedTab] = useState<Tabs>('enterprises');

  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        {headings && <BlockHeader alignment="left" className="space-y-4" headings={headings} />}

        <Tabs11
          tabs={[
            {
              name: (
                <>
                  <LayoutDashboardIcon /> Enterprises
                </>
              ),
              value: 'enterprises',
              content: (
                <div className="flex gap-6 max-lg:flex-col">
                  {advisorCards.map((card, index) => (
                    <FeatureSection10Card key={index} {...card} />
                  ))}
                </div>
              ),
            },
            {
              name: (
                <>
                  <BellRingIcon /> Advisors
                </>
              ),
              value: 'advisors',
              content: (
                <div className="flex gap-6 max-lg:flex-col">
                  {enterpriseCards.map((card, index) => (
                    <FeatureSection10Card key={index} {...card} />
                  ))}
                </div>
              ),
            },
          ]}
        />
      </div>
    </Section>
  );
};

export default FeaturesSection10;
