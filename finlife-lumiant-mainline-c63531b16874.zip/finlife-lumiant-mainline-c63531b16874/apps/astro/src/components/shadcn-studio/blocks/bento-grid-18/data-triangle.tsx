import { IconContainer } from '@local/ui/components/ui/icon-container';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import DataTriangleIcon from '#app/assets/dataTriangle.svg?react';
import GoalsIcon from '#app/assets/goals-outline.svg?react';
import KeyAdviceAreasIcon from '#app/assets/keyadviceareas-outline.svg?react';
import NetworthIcon from '#app/assets/networth-outline.svg?react';
import ValuesIcon from '#app/assets/values-outline.svg?react';

const DataTriangle = () => {
  return (
    <MotionPreset
      fade
      slide={{ direction: 'down', offset: 50 }}
      delay={0.75}
      transition={{ duration: 0.45 }}
      className="grid flex-1 grid-cols-2 grid-rows-[100px_100px] px-10"
    >
      <div className="relative font-medium">
        <div className="absolute right-0 bottom-0 w-25 h-24 border-r border-b border-dashed">
          <DataTriangleIcon className="absolute right-1 bottom-1 w-25 fill-brand-electric hover:stroke-brand-electric hover:drop-shadow-md hover:drop-shadow-brand-electric/40" />
          <IconContainer
            variant="filled"
            label="Values"
            labelPosition="left"
            className="absolute right-10 top-3 bg-brand-electric text-foreground"
          >
            <ValuesIcon className="stroke-background" />
          </IconContainer>
        </div>
      </div>
      <div className="relative text-end font-medium">
        <div className="absolute bottom-0 left-0 w-25 h-24 border-b border-dashed">
          <DataTriangleIcon className="absolute bottom-1 left-1 w-25 rotate-y-180 fill-brand-lavender hover:stroke-brand-lavender hover:drop-shadow-md hover:drop-shadow-brand-lavender/40" />
          <IconContainer
            variant="filled"
            label="Goals"
            labelPosition="right"
            className="absolute left-10 top-3 bg-brand-lavender text-foreground shadow-lg"
          >
            <GoalsIcon className="stroke-background" />
          </IconContainer>
        </div>
      </div>
      <div className="relative font-medium">
        <div className="absolute top-0 right-0 w-25 h-24 border-r border-dashed">
          <DataTriangleIcon className="absolute top-1 right-1 w-25 rotate-x-180 fill-brand-aqua hover:stroke-brand-aqua hover:drop-shadow-md hover:drop-shadow-brand-aqua/40" />
          <IconContainer
            variant="filled"
            label="Net Worth"
            labelPosition="left"
            className="absolute right-10 bottom-3 bg-brand-aqua text-foreground shadow-lg"
          >
            <NetworthIcon className="stroke-background" />
          </IconContainer>
        </div>
      </div>
      <div className="relative text-end font-medium">
        <div className="absolute top-0 left-0 w-25 h-24">
          <div className="drop-shadow-lg/35">
            <DataTriangleIcon className="absolute top-1 left-1 hover:stroke-primary hover:drop-shadow-md hover:drop-shadow-primary/40 w-25 fill-primary rotate-180" />
          </div>
          <IconContainer
            variant="filled"
            label="Key Advice Areas"
            labelPosition="right"
            className="absolute left-10 bottom-3 text-foreground shadow-xl"
          >
            <KeyAdviceAreasIcon className="stroke-background" />
          </IconContainer>
        </div>
      </div>
    </MotionPreset>
  );
};

export default DataTriangle;
