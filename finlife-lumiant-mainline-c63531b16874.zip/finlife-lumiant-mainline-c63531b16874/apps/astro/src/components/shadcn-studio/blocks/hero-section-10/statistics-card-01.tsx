import { Badge, type BadgeVariants } from '@local/ui/components/ui/badge';
import { Card, CardContent, CardHeader } from '@local/ui/components/ui/card';

import { cn } from '@local/ui/lib/utils';

// Statistics card data type
type StatisticsCardProps = {
  title: string;
  text: string;
  badgeVariant?: BadgeVariants['variant'];
  className?: string;
};

const StatisticsCard = ({ title, text, badgeVariant = 'secondary', className }: StatisticsCardProps) => {
  return (
    <Card className={cn(`gap-1.5 p-3 bg-background/40 border-brand-electric/50 backdrop-blur-xl`, className)}>
      <CardHeader className="flex items-center justify-between px-3">
        <span className="bg-feature-gradient font-semibold text-transparent bg-clip-text">{title}</span>
        <Badge variant={badgeVariant}>Pro</Badge>
      </CardHeader>
      <CardContent className="flex flex-col gap-2 px-3">
        <p className="font-regular text-xs">{text}</p>
      </CardContent>
    </Card>
  );
};

export default StatisticsCard;
