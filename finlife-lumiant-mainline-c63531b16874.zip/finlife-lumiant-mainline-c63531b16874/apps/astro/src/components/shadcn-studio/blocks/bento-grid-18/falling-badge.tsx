import { Badge } from '@local/ui/components/ui/badge';
import { cn } from '@local/ui/lib/utils';
import Matter from 'matter-js';
import { useEffect, useRef, useState } from 'react';

export type BadgeItem = {
  text: string;
  className?: string;
};

type FallingBadgeProps = {
  badges?: BadgeItem[];
  trigger?: 'auto' | 'scroll' | 'click' | 'hover';
  backgroundColor?: string;
  wireframes?: boolean;
  gravity?: number;
  className?: string;
  mouseConstraintStiffness?: number;
};

const FallingBadge: React.FC<FallingBadgeProps> = ({
  badges = [],
  trigger = 'auto',
  backgroundColor = 'transparent',
  wireframes = false,
  gravity = 1,
  className,
  mouseConstraintStiffness = 0.2,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const badgesRef = useRef<HTMLDivElement | null>(null);
  const canvasContainerRef = useRef<HTMLDivElement | null>(null);
  const [effectStarted, setEffectStarted] = useState(false);

  useEffect(() => {
    if (trigger === 'auto') {
      setEffectStarted(true);
      return;
    }
    if (trigger === 'scroll' && containerRef.current) {
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setEffectStarted(true);
            observer.disconnect();
          }
        },
        { threshold: 0.9 },
      );
      observer.observe(containerRef.current);
      return () => observer.disconnect();
    }
  }, [trigger]);

  useEffect(() => {
    if (!effectStarted) return;

    const { Engine, Render, World, Bodies, Runner, Mouse, MouseConstraint } = Matter;
    if (!containerRef.current || !canvasContainerRef.current) return;

    const containerRect = containerRef.current.getBoundingClientRect();
    const width = containerRect.width;
    const height = containerRect.height;
    if (width <= 0 || height <= 0) return;

    const engine = Engine.create();
    engine.world.gravity.y = gravity;

    const render = Render.create({
      element: canvasContainerRef.current,
      engine,
      options: {
        width,
        height,
        background: backgroundColor,
        wireframes,
      },
    });

    const boundaryOptions = {
      isStatic: true,
      render: { fillStyle: 'transparent' },
    };
    const floor = Bodies.rectangle(width / 2, height + 25, width, 50, boundaryOptions);
    const leftWall = Bodies.rectangle(-25, height / 2, 50, height, boundaryOptions);
    const rightWall = Bodies.rectangle(width + 25, height / 2, 50, height, boundaryOptions);
    const ceiling = Bodies.rectangle(width / 2, -25, width, 50, boundaryOptions);

    if (!badgesRef.current) return;
    const badgeElements = badgesRef.current.querySelectorAll('[data-badge-item]');
    const badgeBodies = [...badgeElements].map((elem) => {
      const rect = (elem as HTMLElement).getBoundingClientRect();
      const x = rect.left - containerRect.left + rect.width / 2;
      const y = rect.top - containerRect.top + rect.height / 2;
      const body = Bodies.rectangle(x, y, rect.width, rect.height, {
        render: { fillStyle: 'transparent' },
        restitution: 0.8,
        frictionAir: 0.01,
        friction: 0.2,
        chamfer: { radius: rect.height / 2 },
      });
      Matter.Body.setVelocity(body, { x: (Math.random() - 0.5) * 5, y: 0 });
      Matter.Body.setAngularVelocity(body, (Math.random() - 0.5) * 0.05);
      return { elem, body };
    });

    badgeBodies.forEach(({ elem, body }) => {
      const el = elem as HTMLElement;
      el.style.position = 'absolute';
      el.style.left = `${body.position.x - body.bounds.max.x + body.bounds.min.x / 2}px`;
      el.style.top = `${body.position.y - body.bounds.max.y + body.bounds.min.y / 2}px`;
      el.style.transform = 'none';
    });

    const mouse = Mouse.create(containerRef.current);
    const mouseConstraint = MouseConstraint.create(engine, {
      mouse,
      constraint: {
        stiffness: mouseConstraintStiffness,
        render: { visible: false },
      },
    });
    render.mouse = mouse;

    World.add(engine.world, [
      floor,
      leftWall,
      rightWall,
      ceiling,
      mouseConstraint,
      ...badgeBodies.map((bb) => bb.body),
    ]);

    const runner = Runner.create();
    Runner.run(runner, engine);
    Render.run(render);

    const updateLoop = () => {
      badgeBodies.forEach(({ body, elem }) => {
        const { x, y } = body.position;
        const el = elem as HTMLElement;
        el.style.left = `${x}px`;
        el.style.top = `${y}px`;
        el.style.transform = `translate(-50%, -50%) rotate(${body.angle}rad)`;
      });
      Matter.Engine.update(engine);
      requestAnimationFrame(updateLoop);
    };
    updateLoop();

    return () => {
      Render.stop(render);
      Runner.stop(runner);
      if (render.canvas) render.canvas.remove();
      World.clear(engine.world, false);
      Engine.clear(engine);
    };
  }, [effectStarted, gravity, wireframes, backgroundColor, mouseConstraintStiffness]);

  const handleTrigger = () => {
    if (!effectStarted && (trigger === 'click' || trigger === 'hover')) {
      setEffectStarted(true);
    }
  };

  const isInteractive = trigger === 'click' || trigger === 'hover';
  const containerClassName = 'relative z-[1] h-[266px] w-full cursor-pointer overflow-hidden';
  const commonProps = {
    ref: containerRef,
    className: containerClassName,
    ...(trigger === 'click' && { onClick: handleTrigger }),
    ...(trigger === 'hover' && { onMouseEnter: handleTrigger }),
    ...(isInteractive && {
      role: 'button',
      tabIndex: 0,
      onKeyDown: (e: React.KeyboardEvent<HTMLDivElement>) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleTrigger();
        }
      },
    }),
  };
  return (
    <div {...commonProps}>
      <div ref={badgesRef} className={cn('flex flex-wrap items-center justify-center gap-2 p-4', className)}>
        {badges.map((badge, index) => (
          <Badge
            key={index}
            data-badge-item
            className={cn('select-none text-lg text-medium text-foreground border-border py-1.5 px-3', badge.className)}
          >
            {badge.text}
          </Badge>
        ))}
      </div>
      <div className="absolute top-0 left-0 z-0" ref={canvasContainerRef} />
    </div>
  );
};

export default FallingBadge;
