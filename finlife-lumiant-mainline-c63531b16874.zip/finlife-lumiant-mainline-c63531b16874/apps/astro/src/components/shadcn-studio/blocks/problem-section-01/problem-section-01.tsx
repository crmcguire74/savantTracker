import type { BlockContent } from '@local/sanity-studio/sanity.types';
import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { Card, CardContent } from '@local/ui/components/ui/card';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { PortableText } from '@portabletext/react';
import { XIcon } from 'lucide-react';
import DotsSvg from '#app/assets/dots.svg?react';
import { Section, type SectionOptions } from '#app/components/section/section';
import { portableTextComponents } from '#app/sanity/portableText.utils';
import type { BlockHeaderType } from '../../block-header/BlockHeader';
import BlockHeader from '../../block-header/BlockHeader';

type CardItem = {
  text?: BlockContent;
};

type ProblemSection01Props = {
  sectionOptions?: SectionOptions;
  headings?: BlockHeaderType;
  button: ButtonType;
  cards?: CardItem[];
};

const ProblemSection01 = ({ sectionOptions, headings, button, cards }: ProblemSection01Props) => {
  return (
    <Section className="relative flex h-full flex-1 flex-col py-24" {...sectionOptions}>
      <div className="mx-auto gap-4 md:gap-16 flex flex-col lg:flex-row justify-between w-full max-w-7xl flex-1 items-start px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="relative space-y-12 lg:w-1/2 lg:max-w-1/2">
          <DotsSvg height={50} width={56} className="absolute text-slate-300 opacity-50 -left-8 -top-11" />
          {headings && <BlockHeader headings={headings} alignment="left" />}
          <Button asChild className="rounded-lg text-base shadow-sm" size="lg">
            <a href={button.link}>{button.label}</a>
          </Button>
        </div>

        <div className="flex lg:w-1/2 lg:max-w-1/2 flex-col items-center gap-4">
          {/* Cards */}
          {cards && (
            <div className="relative grid grid-cols-1 gap-4 md:max-lg:grid-cols-2">
              {cards.map((card, index) => (
                <MotionPreset
                  key={index}
                  component="div"
                  fade
                  slide={{
                    direction: 'right',
                    offset: 200,
                  }}
                  transition={{ duration: 0.5 }}
                  className="z-5"
                >
                  <Card
                    key={index}
                    className={`${
                      sectionOptions?.backgroundColor === 'muted' ? '' : 'bg-muted'
                    } rounded-lg border-none py-4 shadow-none transition-shadow duration-300 hover:shadow-sm `}
                  >
                    <CardContent>
                      <div className="flex items-center gap-3">
                        <XIcon className="flex shrink-0" />
                        <span className="flex items-center gap-2.5">
                          <span className="text-muted-foreground font-medium">
                            {card?.text && <PortableText value={card.text} components={portableTextComponents} />}
                          </span>
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </MotionPreset>
              ))}
              <DotsSvg height={50} width={56} className="absolute text-violet-400 opacity-50 -right-3 -bottom-9" />
            </div>
          )}
        </div>
      </div>
    </Section>
  );
};

export default ProblemSection01;
