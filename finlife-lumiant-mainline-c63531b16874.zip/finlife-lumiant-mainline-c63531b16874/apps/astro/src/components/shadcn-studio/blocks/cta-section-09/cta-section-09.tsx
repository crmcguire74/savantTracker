import { Button, type ButtonType } from '@local/ui/components/ui/button';
import { Card, CardContent } from '@local/ui/components/ui/card';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { cn } from '@local/ui/lib/utils';
import { ArrowRightIcon } from 'lucide-react';
import KAAIcon from '#app/assets/kaa.svg?react';
import { Section, type SectionOptions } from '#app/components/section/section';
import { Image } from '#app/components/shadcn-studio/elements/image';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';

type CTASection08Props = {
  sectionOptions?: SectionOptions;
  headings: BlockHeaderType;
  button: ButtonType;
  image: {
    src: string;
    alt: string;
  };
  className?: string;
  icon?: boolean;
};

const CTASection08 = ({ sectionOptions, headings, button, image, icon = true, className }: CTASection08Props) => {
  return (
    <Section className="py-8 sm:py-16 lg:py-24" {...sectionOptions}>
      <div className="mx-auto max-w-7xl px-4 lg:px-0">
        <MotionPreset fade blur slide={{ direction: 'down', offset: 50 }} transition={{ duration: 0.7 }}>
          <Card
            className={cn(
              'relative overflow-hidden rounded-3xl border-none bg-ombre-gradient py-8 shadow-none sm:py-16 lg:py-24',
              className,
            )}
          >
            {icon && <KAAIcon className="absolute -left-[95px] bottom-10" />}
            <CardContent className="px-8 sm:px-16 lg:px-24">
              <div className="space-y-4 md:max-w-96 xl:max-w-lg">
                <BlockHeader
                  alignment="left"
                  className="text-white"
                  descriptionClassName="text-white"
                  headings={headings}
                />
              </div>

              <MotionPreset fade blur slide delay={0.6} transition={{ duration: 0.5 }}>
                <Button size="lg" asChild>
                  <a href={button.link} className="inline-flex items-center gap-2">
                    {button.label}
                    <ArrowRightIcon className="h-5 w-5" />
                  </a>
                </Button>
              </MotionPreset>

              <MotionPreset
                className="absolute -top-5 -right-20 scale-120 max-lg:-bottom-9 max-lg:hidden xl:right-0"
                fade
                blur
                slide={{ direction: 'right' }}
                delay={0.6}
                transition={{ duration: 0.7 }}
              >
                <Image image={image} className="max-h-173 w-full" />
              </MotionPreset>
            </CardContent>
          </Card>
        </MotionPreset>
      </div>
    </Section>
  );
};

export default CTASection08;
