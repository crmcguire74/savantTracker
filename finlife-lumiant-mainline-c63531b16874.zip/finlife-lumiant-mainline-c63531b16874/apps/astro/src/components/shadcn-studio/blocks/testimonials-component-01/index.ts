export { default } from './testimonials-component-01';
