import { Separator } from '@local/ui/components/ui/separator';
import { cn } from '@local/ui/lib/utils';
import { PortableText, type PortableTextBlock } from '@portabletext/react';
import { Link } from 'lucide-react';
import type { ReactNode } from 'react';
import Facebook from '#app/assets/brand/facebook.svg?react';
import GithubIcon from '#app/assets/brand/github.svg?react';
import InstagramIcon from '#app/assets/brand/instagram.svg?react';
import LinkedinIcon from '#app/assets/brand/linkedin.svg?react';
import TwitterIcon from '#app/assets/brand/twitter.svg?react';
import YoutubeIcon from '#app/assets/brand/youtube.svg?react';
import { HubspotEmbeddedFormContainer } from '#app/components/hubspot/hubspot-embedded-form';
import Logo, { type LogoProps } from '#app/components/shadcn-studio/logo';
import type { HubspotEmbedFields } from '#app/sanity/hubspot.utils';
import { portableTextComponents } from '#app/sanity/portableText.utils';
import type { SiteLink } from '#app/sanity/sanity.utils';

export type SocialLink = { platform: string; href: string; icon?: ReactNode };

export type FooterProps = {
  description?: PortableTextBlock[];
  companyLinks?: SiteLink[];
  helpLinks?: SiteLink[];
  newsletterEnabled?: boolean;
  newsletterLabel?: string;
  socialLinks?: SocialLink[];
  copyrightOwner?: string;
  logo?: LogoProps['logo'];
  darkLogo?: LogoProps['logo'];
  hubspotNewsletterForm?: HubspotEmbedFields | null;
};

export const defaultIconForPlatform = (p: string, className?: string) => {
  switch (p.toLowerCase()) {
    case 'github':
      return <GithubIcon className={cn('size-5', className)} />;
    case 'instagram':
      return <InstagramIcon className={cn('size-5 text-sky-600 dark:text-sky-400', className)} />;
    case 'twitter':
      return <TwitterIcon className={cn('size-5 text-amber-600 dark:text-amber-400', className)} />;
    case 'x':
      return <TwitterIcon className={cn('size-5 text-amber-600 dark:text-amber-400', className)} />;
    case 'youtube':
      return <YoutubeIcon className={cn('size-5 text-destructive', className)} />;
    case 'linkedin':
      return <LinkedinIcon className={cn('size-5', className)} />;
    case 'facebook':
      return <Facebook className={cn('size-5', className)} />;
    case 'website':
      return <Link className={cn('size-5', className)} />;
    default:
      return <span className="text-xs uppercase">{p}</span>;
  }
};

const Footer = ({
  description = [] as PortableTextBlock[],
  companyLinks = [],
  helpLinks = [],
  newsletterEnabled = true,
  newsletterLabel = 'Subscribe to newsletter',
  socialLinks = [],
  copyrightOwner,
  logo,
  darkLogo,
  hubspotNewsletterForm,
}: FooterProps) => {
  const year = new Date().getFullYear();

  return (
    <footer>
      <div className="mx-auto grid max-w-7xl grid-cols-6 gap-6 px-4 py-8 sm:gap-8 sm:px-6 sm:py-16 md:py-24 border-t border-image-lavender-fade">
        {/* Brand + description + socials */}
        <div className="col-span-full flex flex-col items-start gap-4 lg:col-span-2">
          <a href="/" aria-label="Home">
            {logo && <Logo logo={logo} darkLogo={darkLogo} className="gap-3" />}
          </a>
          {description && <PortableText value={description} components={portableTextComponents} />}
          <Separator className="!w-35" />
          {socialLinks.length > 0 && (
            <div className="flex items-center gap-4">
              {socialLinks.map((link: SocialLink) => (
                <a
                  key={link.platform + link.href}
                  href={link.href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={link.platform}
                >
                  {link.icon ?? defaultIconForPlatform(link.platform)}
                </a>
              ))}
            </div>
          )}
        </div>

        {/* Link groups + newsletter + partner logos */}
        <div className="col-span-full grid grid-cols-2 gap-6 sm:grid-cols-4 lg:col-span-4 lg:gap-8">
          <div className="flex flex-col gap-5">
            <div className="text-lg font-medium">Company</div>
            <ul className="text-muted-foreground space-y-3">
              {companyLinks.length === 0 && <li className="opacity-60">No links</li>}
              {companyLinks.map((link: SiteLink) => (
                <li key={link.href + link.label}>
                  <a
                    href={link.href}
                    target={link.newTab ? '_blank' : '_self'}
                    rel={link.newTab ? 'noreferrer' : undefined}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="flex flex-col gap-5">
            <div className="text-lg font-medium">Help</div>
            <ul className="text-muted-foreground space-y-3">
              {helpLinks.length === 0 && <li className="opacity-60">No links</li>}
              {helpLinks.map((link: SiteLink) => (
                <li key={link.href + link.label}>
                  <a
                    href={link.href}
                    target={link.newTab ? '_blank' : '_self'}
                    rel={link.newTab ? 'noreferrer' : undefined}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="col-span-full flex flex-col gap-5 sm:col-span-2">
            {newsletterEnabled && (
              <div>
                <p className="mb-3 text-lg font-medium">{newsletterLabel}</p>
                <div className="flex gap-2">
                  <HubspotEmbeddedFormContainer
                    form={hubspotNewsletterForm}
                    className="hs-form-html hs-newsletter-footer"
                  />
                </div>
              </div>
            )}
            <Separator />
          </div>
        </div>
      </div>

      <Separator />

      <div className="mx-auto flex max-w-7xl justify-center px-4 py-6 sm:px-6">
        <p className="text-center font-medium text-balance">
          ©{year} {copyrightOwner}. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
