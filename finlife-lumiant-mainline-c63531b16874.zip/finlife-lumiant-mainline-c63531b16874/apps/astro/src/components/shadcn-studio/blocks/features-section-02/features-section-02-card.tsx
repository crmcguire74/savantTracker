import type { BlockContent } from '@local/sanity-studio/sanity.types';
import { Card, CardContent, CardTitle } from '@local/ui/components/ui/card';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { PortableText } from '@portabletext/react';
import { getIconByName } from '#app/components/shadcn-studio/icon-name-map';
import { portableTextComponents } from '#app/sanity/portableText.utils';

export type FeaturesSection02CardItem = {
  title: BlockContent;
  description: BlockContent;
  iconName: string;
};

const FeaturesSectionCard = ({ title, description, iconName }: FeaturesSection02CardItem) => {
  const IconComponent = getIconByName(iconName);

  return (
    <MotionPreset fade slide={{ direction: 'down' }} transition={{ duration: 0.7 }} className="h-full">
      <Card className="h-full shadow-none transition-shadow duration-300 hover:shadow-sm">
        <CardContent className="flex h-full flex-col items-start justify-start text-left">
          <span className="bg-primary mb-6 inline-flex items-center justify-center rounded-full border-2 border-primary/20 p-2 text-primary-foreground">
            <IconComponent className="size-4 shrink-0" aria-hidden="true" />
          </span>
          <CardTitle className="text-sm font-bold">
            <PortableText value={title} components={portableTextComponents} />
          </CardTitle>
          <div className="text-sm">
            <PortableText value={description} components={portableTextComponents} />
          </div>
        </CardContent>
      </Card>
    </MotionPreset>
  );
};

export default FeaturesSectionCard;
