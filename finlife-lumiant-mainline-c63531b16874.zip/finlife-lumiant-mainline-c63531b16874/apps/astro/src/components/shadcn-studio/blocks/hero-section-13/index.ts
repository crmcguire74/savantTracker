export { default } from './hero-section-13';
