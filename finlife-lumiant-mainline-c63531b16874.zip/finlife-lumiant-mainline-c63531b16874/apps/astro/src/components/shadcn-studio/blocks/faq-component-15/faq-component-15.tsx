import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@local/ui/components/ui/accordion';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { Section, type SectionOptions } from '#app/components/section/section';
import BlockHeader, { type BlockHeaderType } from '../../block-header/BlockHeader';
import { Image, type ImageType } from '../../elements/image';

type FAQItem = {
  question: string;
  answer: string;
};

type FAQComponentProps = {
  sectionOption?: SectionOptions;
  headings: BlockHeaderType;
  image?: ImageType;
  faqItems: FAQItem[];
};

const getImageHeight = (count: number) => {
  if (count <= 3) return 'h-64 sm:h-72';
  if (count <= 6) return 'h-80 sm:h-96';
  return 'h-96 sm:h-[32rem]';
};

const FAQComponent15 = ({ sectionOption, headings, image, faqItems }: FAQComponentProps) => {
  return (
    <Section className="bg-muted py-8 sm:py-16 lg:py-24" {...sectionOption}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {headings && <BlockHeader headings={headings} alignment="center" />}
        <div className="grid grid-cols-1 items-center gap-8 lg:grid-cols-[2fr_3fr]">
          {/* Left Section - Dark Background with Image */}
          {image && (
            <div className="flex justify-center lg:block">
              <Image image={image} className={getImageHeight(faqItems.length)} />
            </div>
          )}
          {/* Right Section - FAQ Accordion */}
          <MotionPreset fade slide={{ direction: 'right', offset: 50 }} delay={0.3} transition={{ duration: 0.7 }}>
            <Accordion type="single" collapsible className="space-y-2" defaultValue="item-0">
              {faqItems.map((item, index) => (
                <MotionPreset
                  key={index}
                  fade
                  slide={{ direction: 'up', offset: 30 }}
                  delay={0.6 + index * 0.15}
                  transition={{ duration: 0.6 }}
                >
                  <AccordionItem
                    value={`item-${index}`}
                    className="bg-card rounded-md border-b-0 shadow-md data-[state=open]:shadow-lg"
                  >
                    <AccordionTrigger className="px-5 text-base hover:no-underline [&>svg]:size-5">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground px-5 text-base leading-relaxed">
                      {item.answer}
                    </AccordionContent>
                  </AccordionItem>
                </MotionPreset>
              ))}
            </Accordion>
          </MotionPreset>
        </div>
      </div>
    </Section>
  );
};

export default FAQComponent15;
