export type CardBase = {
  _key: string;
  _type: string;
};
