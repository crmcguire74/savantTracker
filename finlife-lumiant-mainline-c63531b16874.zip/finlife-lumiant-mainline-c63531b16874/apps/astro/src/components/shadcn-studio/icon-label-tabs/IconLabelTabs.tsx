import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { ScrollArea, ScrollBar } from '@local/ui/components/ui/scroll-area';
import { Tabs, TabsList, TabsTrigger } from '@local/ui/components/ui/tabs';
import type { ReactNode } from 'react';

export type IconLabelTab = {
  name: string;
  value: string;
};

type IconLabelTabsProps = {
  tabs: IconLabelTab[];
  children: ReactNode;
};

/**
 * Shared horizontal tab rail (initial + full label) used by FAQ component 13 and tabbed image/content sections.
 */
export function IconLabelTabs({ tabs, children }: IconLabelTabsProps) {
  const defaultValue = tabs[0]?.value ?? '';

  return (
    <Tabs defaultValue={defaultValue} className="space-y-2">
      <MotionPreset
        fade
        className="text-center"
        slide={{ direction: 'down', offset: 50 }}
        delay={0.5}
        transition={{ duration: 0.7 }}
      >
        <ScrollArea>
          <TabsList className="mx-auto h-40 w-40 gap-6 bg-transparent group-data-[orientation=horizontal]/tabs:h-fit">
            {tabs.map((tab) => (
              <TabsTrigger
                key={tab.value}
                value={tab.value}
                className="border border-border data-[state=active]:border-transparent data-[state=active]:bg-primary dark:data-[state=active]:bg-primary dark:data-[state=active]:text-primary-foreground data-[state=active]:text-primary-foreground data-[state=active]:font-semibold hover:text-foreground hover:bg-primary/20 flex min-w-37 cursor-pointer flex-col items-center justify-start gap-4 rounded-md p-6 text-base font-normal transition-colors duration-300 data-[state=active]:shadow-md"
              >
                <span className="text-4xl">{tab.name.charAt(0)}</span>
                <span className="text-lg max-w-full text-center leading-tight whitespace-normal wrap-break-word">
                  {tab.name}
                </span>
              </TabsTrigger>
            ))}
          </TabsList>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </MotionPreset>
      {children}
    </Tabs>
  );
}
