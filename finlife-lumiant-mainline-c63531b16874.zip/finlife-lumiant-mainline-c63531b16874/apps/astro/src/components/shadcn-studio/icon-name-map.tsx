import {
  ArrowRightIcon,
  ChartNoAxesCombined,
  Church,
  CircleCheck,
  Dna,
  FileSearch,
  Frame,
  GitPullRequestArrow,
  HandHeart,
  Home,
  LayoutDashboard,
  Leaf,
  type LucideIcon,
  Notebook,
  NotebookTabs,
  Route,
  ServerCrash,
  Unplug,
  UserCheck,
  UserCircle,
} from 'lucide-react';
import type { FunctionComponent, JSX, SVGProps } from 'react';
import GoalsIcon from '#app/assets/goals.svg?react';
import GoalsOutlineIcon from '#app/assets/goals-outline.svg?react';
import HaloOutlineIcon from '#app/assets/halo-outline.svg?react';
import KeyAdviceAreasIcon from '#app/assets/keyadviceareas.svg?react';
import KeyAdviceAreasOutlineIcon from '#app/assets/keyadviceareas-outline.svg?react';
import NetworthIcon from '#app/assets/networth.svg?react';
import NetworthOutlineIcon from '#app/assets/networth-outline.svg?react';
import ValuesIcon from '#app/assets/values.svg?react';
import ValuesOutlineIcon from '#app/assets/values-outline.svg?react';

type IconComponent =
  | LucideIcon
  | ((props: React.SVGProps<SVGSVGElement>) => JSX.Element)
  | FunctionComponent<SVGProps<SVGSVGElement>>;

export const ICON_COMPONENTS: Record<string, IconComponent> = {
  // Lucide icons
  UserCircle,
  UserCheck,
  HandHeart,
  Church,
  Home,
  Dna,
  Leaf,
  ArrowRightIcon,
  ChartNoAxesCombined,
  Notebook,
  NotebookTabs,
  Route,
  CircleCheck,
  Frame,
  FileSearch,
  LayoutDashboard,
  GitPullRequestArrow,
  Unplug,
  ServerCrash,

  // Custom SVG icons
  Values: ValuesIcon,
  Goals: GoalsIcon,
  NetWorth: NetworthIcon,
  KeyAdviceAreas: KeyAdviceAreasIcon,
  ValuesOutline: ValuesOutlineIcon,
  GoalsOutline: GoalsOutlineIcon,
  NetWorthOutline: NetworthOutlineIcon,
  KeyAdviceAreasOutline: KeyAdviceAreasOutlineIcon,
  HaloOutline: HaloOutlineIcon,
};

export const getIconByName = (name?: string): IconComponent => {
  if (!name) return UserCircle;

  return ICON_COMPONENTS[name] ?? UserCircle;
};
