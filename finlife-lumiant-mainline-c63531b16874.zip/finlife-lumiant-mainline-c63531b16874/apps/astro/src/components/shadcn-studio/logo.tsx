import { cn } from '@local/ui/lib/utils';
import type { SanityAsset } from '@sanity/image-url';

import { urlForImage } from '#app/sanity/sanity.utils';

type Logo = {
  asset: SanityAsset;
  alt?: string;
};

export type LogoProps = {
  className?: string;
  logo: Logo;
  darkLogo?: Logo;
};

const Logo = ({ className, logo, darkLogo }: LogoProps) => {
  const imageUrl = urlForImage(logo.asset).width(32).height(32).fit('max').url();
  const darkImageUrl = darkLogo ? urlForImage(darkLogo.asset).width(32).height(32).fit('max').url() : imageUrl;

  return (
    <div className={cn('flex items-center gap-2.5', className)}>
      <img src={imageUrl} alt={logo?.alt ?? 'Logo'} className="block dark:hidden" />
      <img src={darkImageUrl} alt={darkLogo?.alt ?? 'Logo'} className="hidden dark:block" />
    </div>
  );
};

export default Logo;
