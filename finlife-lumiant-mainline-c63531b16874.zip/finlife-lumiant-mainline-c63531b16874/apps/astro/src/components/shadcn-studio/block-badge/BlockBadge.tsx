import { Badge } from '@local/ui/components/ui/badge';
import { BorderBeam } from '@local/ui/components/ui/border-beam';
import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { cn } from '@local/ui/lib/utils';

type BlockBadgeProps = {
  badge: string;
  alignment?: 'left' | 'center' | 'right';
  className?: string;
};

export const BlockBadge = ({ badge, alignment, className }: BlockBadgeProps) => {
  const blockAlignment =
    alignment === 'center' ? 'justify-center' : alignment === 'right' ? 'justify-end' : 'justify-start';
  return (
    <MotionPreset
      component="div"
      fade
      blur
      slide={{ direction: 'down', offset: 20 }}
      transition={{ duration: 0.5 }}
      className={cn(`flex w-full items-center gap-3 ${blockAlignment}`, className)}
    >
      <div className="relative rounded-full">
        <Badge variant="outline" className="rounded-full px-3 py-1 text-sm">
          {badge}
        </Badge>
        <BorderBeam
          borderWidth={1}
          duration={9}
          size={100}
          className="from-brand-electric dark:from-destructive via-primary to-transparent max-md:hidden "
        />
      </div>
    </MotionPreset>
  );
};
