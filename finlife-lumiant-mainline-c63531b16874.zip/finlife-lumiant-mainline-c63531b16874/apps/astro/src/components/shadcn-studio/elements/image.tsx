import { cn } from '@local/ui/lib/utils';

export type ImageType = {
  src: string;
  alt: string;
  darkSrc?: string;
};

export type ImageProps = {
  image: ImageType;
  className?: string;
};

export const Image = ({ image, className }: ImageProps) => {
  if (image.darkSrc === undefined) {
    return <img src={image.src} alt={image.alt} className={className} />;
  }
  return (
    <>
      <img src={image.src} alt={image.alt} className={cn('dark:hidden!', className)} />
      <img src={image.darkSrc} alt={image.alt} className={cn('hidden! dark:inline-block!', className)} />
    </>
  );
};
