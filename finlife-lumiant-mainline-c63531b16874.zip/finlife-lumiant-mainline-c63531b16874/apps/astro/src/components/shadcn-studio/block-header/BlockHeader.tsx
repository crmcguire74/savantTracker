import { MotionPreset } from '@local/ui/components/ui/motion-preset';
import { PortableText, type PortableTextBlock } from '@portabletext/react';
import { headerPortableTextComponents } from '#app/sanity/headerPortableText.utils';
import { portableTextComponents } from '#app/sanity/portableText.utils';
import { BlockBadge } from '../block-badge/BlockBadge';

export type BlockHeaderType = {
  badge?: string;
  heading?: PortableTextBlock[];
  description?: PortableTextBlock[];
};

export type BlockHeaderProps = {
  headings: BlockHeaderType;
  alignment?: 'left' | 'center' | 'right';
  className?: string;
  descriptionClassName?: string;
};

const BlockHeader = ({ headings, className, descriptionClassName, alignment = 'center' }: BlockHeaderProps) => {
  const { badge, heading, description } = headings;
  const descriptionBlocks = description ?? [];
  const textAlignment = alignment === 'center' ? 'text-center' : alignment === 'right' ? 'text-right' : 'text-left';
  return (
    <div className={`flex flex-col gap-6 ${textAlignment} mb-4 ${className || ''}`}>
      {badge && <BlockBadge badge={badge} alignment={alignment} />}
      {heading && (
        <MotionPreset component="span" fade blur slide transition={{ duration: 0.5 }}>
          <PortableText value={heading} components={headerPortableTextComponents} />
        </MotionPreset>
      )}
      {descriptionBlocks.length > 0 && (
        <MotionPreset
          component="div"
          fade
          blur
          slide
          delay={0.3}
          transition={{ duration: 0.5 }}
          className={`text-muted-foreground sm:text-lg md:text-xl ${descriptionClassName || ''}`}
        >
          <PortableText value={descriptionBlocks} components={portableTextComponents} />
        </MotionPreset>
      )}
    </div>
  );
};

export default BlockHeader;
