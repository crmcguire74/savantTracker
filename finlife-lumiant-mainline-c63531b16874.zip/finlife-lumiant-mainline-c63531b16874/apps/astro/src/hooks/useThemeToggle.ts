import { type MouseEvent, useLayoutEffect, useState } from 'react';

type DocumentWithViewTransition = Document & {
  startViewTransition?: (callback: () => void) => { ready: Promise<void> };
};

export const useThemeToggle = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);

  useLayoutEffect(() => {
    setIsDarkMode(document.documentElement.classList.contains('dark'));
  }, []);

  const toggleTheme = (event: MouseEvent<HTMLButtonElement>) => {
    const nextIsDarkMode = !isDarkMode;
    const applyTheme = () => {
      setIsDarkMode(nextIsDarkMode);
      document.documentElement.classList.toggle('dark', nextIsDarkMode);
      localStorage.theme = nextIsDarkMode ? 'dark' : 'light';
    };

    const isReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const doc = document as DocumentWithViewTransition;
    if (!doc.startViewTransition || isReducedMotion) {
      applyTheme();
      return;
    }

    const { top, left, width, height } = event.currentTarget.getBoundingClientRect();
    const x = left + width / 2;
    const y = top + height / 2;
    const endRadius = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y));

    const transition = doc.startViewTransition(() => {
      applyTheme();
    });

    transition.ready.then(() => {
      document.documentElement.animate(
        {
          clipPath: [`circle(0px at ${x}px ${y}px)`, `circle(${endRadius}px at ${x}px ${y}px)`],
        },
        {
          duration: 500,
          easing: 'ease-in-out',
          pseudoElement: '::view-transition-new(root)',
        },
      );
    });
  };

  return { isDarkMode, toggleTheme };
};
