# @local/api

Backend API for Lumiant application.

## Setup

```bash
mise install uv
eval "$(mise activate zsh)"
```

## Local Development

For detailed instructions on running the local stack and testing APIs locally, see the [main README's Local Development & Testing section](../../README.md#local-development--testing).

### Quick Start

```bash
# 1. Start the local MySQL database
npm run rds:start

# 2. Start the API server (builds and runs SAM Local)
npm run start

# 3. Test the API at http://127.0.0.1:3000
# Use Postman, curl, or any HTTP client

# Stop the database when done
npm run rds:stop
```

### Common Commands

```bash
npm run start          # Build and start local API server
npm run rds:start      # Start local MySQL database
npm run rds:stop       # Stop local MySQL database
npm run build          # Build API bundle
npm run test           # Run tests
npm run lint           # Lint code
npm run format         # Format code
```

## Regional API Support

API resources and fields are region-specific based on `LUMIANT_REGION` environment variable.

### Region-Specific Resources
- **AU**: Superannuation, SuperBeneficiary (+ global resources)
- **US**: Global resources only

Configuration: `src/lumiant_api/config/region_config.py`

### Build Regional Documentation

```bash
# Build all regions
npm run build-openapi:all-regions

# Build specific region
LUMIANT_REGION=au npm run build-openapi
LUMIANT_REGION=us npm run build-openapi
```

Output: `build/openapi.{region}.docs.json`

Multi-region CDK deploy:

1) Build once (produces both AU/US specs):
   - `turbo build --filter=@local/api`
2) Deploy both stacks; CDK selects the correct spec per region:
   - `cd packages/lumiant-cdk`
   - `npx cdk deploy QA-*`

### Deploy Documentation

Deploy regional documentation to S3:

```bash
# Set AWS profile
export AWS_PROFILE=lumiant-qa

# Deploy to QA
npm run deploy-docs:qa:all    # Both AU and US
npm run deploy-docs:qa:au     # AU only
npm run deploy-docs:qa:us     # US only

# Other environments
npm run deploy-docs:dev:all      # Dev - both regions
npm run deploy-docs:staging:all  # Staging - both regions
npm run deploy-docs:prod:all     # Production - both regions

# Dry run to preview
npm run deploy-docs:dry-run
```

Configuration: `deployment/config.json`
