#!/usr/bin/env python3
import shutil
from dataclasses import dataclass
from pathlib import Path
from time import sleep
from typing import List

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer


@dataclass
class SourceDestinationPath:
    source: str
    destination: str


class FileSyncHandler(FileSystemEventHandler):
    def __init__(self, source: Path, destination: Path):
        self.source = source
        self.destination = Path(destination).resolve()

    def on_modified(self, event):
        if event.is_directory or not event.src_path.endswith(".py"):
            return
        self.copy_modified(path=Path(event.src_path))

    def copy_modified(self, path: Path):
        relative_path = path.relative_to(self.source)
        destination_path = self.destination / relative_path
        destination_path.parent.mkdir(parents=True, exist_ok=True)

        shutil.copy2(path, destination_path)
        print(f"Copied {relative_path} to {destination_path}")


class Watch:
    def __init__(self, paths: List[SourceDestinationPath]) -> None:
        self.paths = paths
        self.observer = Observer()
        self.observe_paths()

    def observe_paths(self):
        for path in self.paths:
            source = Path(path.source).resolve()
            destination = Path(path.destination).resolve()

            self.run_initial_copy(source=source, destination=destination)

            event_handler = FileSyncHandler(source=source, destination=destination)
            self.observer.schedule(event_handler, source, recursive=True)

    def run_initial_copy(self, source: Path, destination: Path):
        print(f"Copying {source} to {destination}")
        if destination.exists():
            shutil.rmtree(destination)

        shutil.copytree(source, destination)

    def start(self):
        print("Watching for changes... (Ctrl+C to stop)")
        self.observer.start()
        try:
            while True:
                sleep(1)
        except KeyboardInterrupt:
            self.observer.stop()
        self.observer.join()


def main():
    watcher = Watch(
        paths=[
            SourceDestinationPath(source="src/lumiant_api", destination="dist/lumiant_api"),
            SourceDestinationPath(source="../core/src/lumiant_core", destination="dist/lumiant_core"),
            SourceDestinationPath(source="../lumiant-legacy/src/lumiant", destination="dist/lumiant"),
        ]
    )
    watcher.start()


if __name__ == "__main__":
    main()
