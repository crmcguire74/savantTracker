CREATE DATABASE  IF NOT EXISTS `lumiant` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `lumiant`;
-- MySQL dump 10.13  Distrib 8.0.43, for macos15 (arm64)
--
-- Host: 127.0.0.1    Database: lumiant
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Account`
--

DROP TABLE IF EXISTS `Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Account` (
  `account_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `basiq_account_id` varchar(40) DEFAULT NULL,
  `basiq_connection_id` varchar(100) DEFAULT NULL,
  `life_insurance` tinyint(1) DEFAULT '0',
  `account_number` varchar(20) NOT NULL,
  `account_name` varchar(255) DEFAULT NULL,
  `account_currency` varchar(3) DEFAULT NULL,
  `account_type` enum('S','I','L') NOT NULL,
  `account_class_product` varchar(255) DEFAULT NULL,
  `available_redraw` decimal(20,8) DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `fee` decimal(20,8) DEFAULT NULL,
  `instalment_amount` decimal(20,8) DEFAULT NULL,
  `interest_rate` decimal(20,8) DEFAULT NULL,
  `interest_type` varchar(50) DEFAULT NULL,
  `next_instalment_date` date DEFAULT NULL,
  `offset_account_number` varchar(20) DEFAULT NULL,
  `repayment_frequency` varchar(50) DEFAULT NULL,
  `repayment_type` varchar(50) DEFAULT NULL,
  `balance` decimal(20,8) DEFAULT NULL,
  `available_funds` decimal(20,8) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `transaction_intervals_from` datetime DEFAULT NULL,
  `transaction_intervals_to` datetime DEFAULT NULL,
  `institution` varchar(255) NOT NULL,
  `account_holder` varchar(256) DEFAULT NULL,
  `basiq_data_id` int DEFAULT NULL,
  `life_covered` decimal(20,8) DEFAULT NULL,
  `income_protection` tinyint(1) DEFAULT '0',
  `income_covered` decimal(20,8) DEFAULT NULL,
  `trauma_insurance` tinyint(1) DEFAULT '0',
  `trauma_covered` decimal(20,8) DEFAULT NULL,
  `tpd_insurance` tinyint(1) DEFAULT '0',
  `tpd_covered` decimal(20,8) DEFAULT NULL,
  `business_expense_insurance` tinyint(1) DEFAULT '0',
  `business_expense_insurance_covered` decimal(20,8) DEFAULT NULL,
  `policy_status` varchar(255) DEFAULT NULL,
  `severity_based_insurance` tinyint(1) DEFAULT '0',
  `severity_based_insurance_covered` decimal(20,8) DEFAULT NULL,
  `commencement_date` date DEFAULT NULL,
  `limit` decimal(20,8) DEFAULT NULL,
  `payment_amount` decimal(20,8) DEFAULT NULL,
  `payout_payment_account` varchar(255) DEFAULT NULL,
  `payout_details` varchar(255) DEFAULT NULL,
  `payout_waiting_period` int DEFAULT NULL,
  `payout_length` int DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `deactivated` datetime DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` varchar(50) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `account_subtype` enum('T','S','C','M','L','I','D','N','F','U') NOT NULL,
  `other_loan_type` varchar(255) DEFAULT NULL,
  `policy_end_date` date DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  KEY `ix_account_client_id` (`client_id`),
  KEY `ix_account_basiq_data_id` (`basiq_data_id`),
  KEY `ix_account_institution` (`institution`),
  KEY `ix_Account_external_id` (`external_id`,`external_system`),
  CONSTRAINT `Account_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Account_ibfk_2` FOREIGN KEY (`basiq_data_id`) REFERENCES `bq_data` (`basiq_data_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=889 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AccountValueNetInvestmentSnapshot`
--

DROP TABLE IF EXISTS `AccountValueNetInvestmentSnapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AccountValueNetInvestmentSnapshot` (
  `account_value_net_investment_snapshot_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `portfolio_id` int NOT NULL,
  `account_total` decimal(20,8) DEFAULT NULL,
  `net_investment` decimal(20,8) DEFAULT NULL,
  `snapshot_date` date NOT NULL,
  PRIMARY KEY (`account_value_net_investment_snapshot_id`),
  KEY `ix_AccountValueNetInvestmentSnapshot_household_id` (`household_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4766 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Address`
--

DROP TABLE IF EXISTS `Address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Address` (
  `address_id` int NOT NULL AUTO_INCREMENT,
  `address_line_1` varchar(255) NOT NULL,
  `address_line_2` varchar(255) DEFAULT NULL,
  `suburb` varchar(100) NOT NULL,
  `post_code` varchar(5) NOT NULL,
  `state` varchar(3) NOT NULL,
  `country` char(2) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`address_id`),
  KEY `ix_Address_external_id` (`external_id`,`external_system`)
) ENGINE=InnoDB AUTO_INCREMENT=937092 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Asset`
--

DROP TABLE IF EXISTS `Asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Asset` (
  `asset_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `legal_entity_id` int DEFAULT NULL,
  `beneficiary_client_id` int DEFAULT NULL,
  `beneficiary_legal_entity_id` int DEFAULT NULL,
  `other_beneficiary` varchar(100) DEFAULT NULL,
  `relationship_asset` varchar(100) DEFAULT NULL,
  `asset_type` enum('S','N','H','P','G','I','V','A','U','O') NOT NULL COMMENT 'S = Super, N = Pension, H = Home, P = Investment Property, G = Savings, I = Investment, V = Vehicle, A = Asset, U = Annuity, O = Other',
  `super_type` enum('A','D','P','E','F','G','H','I','J','K','L','M','U') DEFAULT NULL COMMENT 'AU [A = Accumulation, D = Defined Benefit, P = Pension], US [E = 401k, F = Roth 401k, G = 403b, H = 457b, I = IRA, J = Roth IRA, K = Simple IRA, L = Sep IRA, M = Inherited IRA], U = Superannuation',
  `pension_type` enum('A','T','R') DEFAULT NULL COMMENT 'A = Account Based, T = Term Allocated, R = Transition to Retirement',
  `annuity_type` enum('L','G','D','I') DEFAULT NULL COMMENT 'L = Life Annuity, G = Guaranteed Annuity, D = Deferred Annuity, I = Impaired Life Annuity',
  `description` varchar(200) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `provider_name` varchar(100) DEFAULT NULL,
  `member_number` varchar(50) DEFAULT NULL COMMENT 'Usually for Super / Account Based Pension',
  `balance` decimal(20,8) DEFAULT NULL,
  `defined_benefit_salary` decimal(15,2) DEFAULT NULL,
  `defined_benefit_multiple` decimal(5,2) DEFAULT NULL,
  `employee_contribution` decimal(12,2) DEFAULT NULL,
  `employee_contribution_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `employee_contribution_type` enum('P','X') DEFAULT NULL COMMENT 'P = Pre-Tax, X = Post-Tax',
  `employee_contribution_cap` decimal(12,2) DEFAULT NULL,
  `employee_contribution_cap_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `employer_contribution` decimal(12,2) DEFAULT NULL,
  `employer_contribution_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `employer_contribution_cap` decimal(12,2) DEFAULT NULL,
  `employer_contribution_cap_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `makes_personal_contribution` tinyint(1) DEFAULT NULL,
  `annual_contribution` decimal(12,2) DEFAULT NULL,
  `inherited_ira_type` varchar(100) DEFAULT NULL,
  `deceased_owner_date_of_birth` date DEFAULT NULL,
  `deceased_owner_date_of_death` date DEFAULT NULL,
  `rmd_taken_this_year` tinyint(1) DEFAULT NULL,
  `previous_year_balance` decimal(12,2) DEFAULT NULL,
  `annuity_term_date` date DEFAULT NULL,
  `death_benefit` decimal(12,2) DEFAULT NULL,
  `surrender_value` decimal(12,2) DEFAULT NULL,
  `centrelink_value` decimal(12,2) DEFAULT NULL,
  `is_used_loan_security` tinyint(1) DEFAULT NULL,
  `loan_secured_amount` decimal(12,2) DEFAULT NULL,
  `made_personal_contrib_past_3y` tinyint(1) DEFAULT NULL,
  `tax_free_component` decimal(12,2) DEFAULT NULL,
  `preservation_component` decimal(12,2) DEFAULT NULL,
  `makes_personal_super_contribution` tinyint(1) DEFAULT NULL,
  `is_salary_sacrifice` tinyint(1) DEFAULT NULL,
  `super_contribution_amount` decimal(12,2) DEFAULT NULL,
  `super_contribution_frequency` enum('W','F','M','B','Q','H','A') DEFAULT NULL COMMENT 'W = Weekly, F = Fortnightly, M = Monthly, B = Bi-Monthly, Q = Quarterly, H = Half-Yearly, A = Annually',
  `employer_pays_higher_than_minimum_super` tinyint(1) DEFAULT NULL,
  `higher_than_minimum_super_bps` decimal(5,4) DEFAULT NULL,
  `pre_retirement_ref_model` int DEFAULT NULL COMMENT '1 (Defensive) to 5 (High Growth)',
  `post_retirement_ref_model` int DEFAULT NULL COMMENT '1 (Defensive) to 5 (High Growth)',
  `fees_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `fees_dollar` decimal(15,2) DEFAULT NULL,
  `address_id` int DEFAULT NULL,
  `own_or_rent` enum('O','R','F') DEFAULT NULL COMMENT 'O = Own, R = Rent, F = Live at home (rent free)',
  `is_primary_home` tinyint(1) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `growth_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `current_value` decimal(15,2) DEFAULT NULL,
  `property_type` enum('H','U') DEFAULT NULL COMMENT 'H = House, U = Unit / Townhouse / Villa',
  `rent` decimal(15,2) DEFAULT NULL COMMENT 'Weekly rent',
  `saving_investment_type` enum('C','B','D','T','I','O','K','M','R','E','H','W','V','U','S','A','X') DEFAULT NULL COMMENT 'C = Cash, B = Bond, D = Certificate of Deposit, T = Term Deposit, I = Investment, O = Offset Account,K = Bank account, M = Managed fund, R = Share portfolio, E = Checking account, H = Health savings account, W = 529a, V = Trust, U = Superannuation, S = Savings account, A = Annuity, X = Other',
  `asset_use` enum('N','E') DEFAULT NULL COMMENT 'N = Normal Use, E = Emergency Use Only',
  `assessed` tinyint(1) DEFAULT NULL COMMENT 'True if assessed by Social Security / Centerlink',
  `make` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `last_valued` date DEFAULT NULL,
  `super_phase` enum('A','T','P') DEFAULT NULL COMMENT 'A = Accumulation, T = Non-Commutable Account Based Pension (TTR), P = Account Based Pension',
  `term` int DEFAULT NULL,
  `maturity_date` date DEFAULT NULL,
  `commuted_amount` decimal(15,2) DEFAULT NULL,
  `residual_value` decimal(15,2) DEFAULT NULL,
  `asset_exemption_bps` decimal(5,4) DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `display_ownership` int DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `external_load_id` varchar(50) DEFAULT NULL,
  `soft_deleted` tinyint(1) DEFAULT '0',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`asset_id`),
  UNIQUE KEY `ix_Asset_external_id_system` (`household_id`,`client_id`,`legal_entity_id`,`external_id`,`external_system`),
  KEY `fk_Asset_1_idx` (`household_id`),
  KEY `fk_Asset_2_idx` (`client_id`),
  KEY `fk_Asset_3_idx` (`address_id`),
  KEY `legal_entity_id` (`legal_entity_id`),
  KEY `ix_Asset_external_id` (`external_id`,`external_system`),
  CONSTRAINT `Asset_ibfk_1` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Asset_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Asset_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Asset_3` FOREIGN KEY (`address_id`) REFERENCES `Address` (`address_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=23165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AssetYodleeMapping`
--

DROP TABLE IF EXISTS `AssetYodleeMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AssetYodleeMapping` (
  `asset_yodlee_mapping_id` int NOT NULL AUTO_INCREMENT,
  `asset_id` int NOT NULL,
  `provider_account_id` varchar(32) DEFAULT NULL,
  `additional_status` varchar(100) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`asset_yodlee_mapping_id`),
  KEY `fk_AssetYodleeMapping_idx` (`asset_id`),
  CONSTRAINT `fk_AssetYodleeMapping` FOREIGN KEY (`asset_id`) REFERENCES `Asset` (`asset_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2579 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Beneficiary`
--

DROP TABLE IF EXISTS `Beneficiary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Beneficiary` (
  `beneficiary_id` int NOT NULL AUTO_INCREMENT,
  `estate_planning_id` int NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT '1',
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `relationship_type` enum('S','C','F','I','O') NOT NULL COMMENT 'S = Spouse, C = Child, F = Financial Dependent, I = Interdependent Relationship, O = Other',
  `nominated_percentage` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `age_entitlement` int DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`beneficiary_id`),
  KEY `fk_Executor_1_idx` (`estate_planning_id`),
  CONSTRAINT `fk_Beneficiary_1` FOREIGN KEY (`estate_planning_id`) REFERENCES `EstatePlanning` (`estate_planning_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `BestLifeScore`
--

DROP TABLE IF EXISTS `BestLifeScore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BestLifeScore` (
  `best_life_score_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `scenario_id` binary(16) NOT NULL,
  `best_life_score` decimal(7,4) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`best_life_score_id`),
  UNIQUE KEY `ix_BestLifeScore_household_id` (`household_id`),
  KEY `fk_BestLifeScore_1_idx` (`household_id`),
  CONSTRAINT `fk_BestLifeScore_1_idx` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `BestLifeScoreHistory`
--

DROP TABLE IF EXISTS `BestLifeScoreHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BestLifeScoreHistory` (
  `best_life_score_history_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `scenario_id` binary(16) NOT NULL,
  `best_life_score` decimal(7,4) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`best_life_score_history_id`),
  KEY `fk_BestLifeScoreHistory_1_idx` (`household_id`),
  CONSTRAINT `fk_BestLifeScoreHistory_1_idx` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `BusinessPlanning`
--

DROP TABLE IF EXISTS `BusinessPlanning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BusinessPlanning` (
  `business_planning_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `legal_entity_id` int DEFAULT NULL,
  `has_business_documents` tinyint(1) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`business_planning_id`),
  KEY `fk_BusinessPlanning_1_idx` (`household_id`),
  KEY `fk_BusinessPlanning_2_idx` (`client_id`),
  KEY `fk_BusinessPlanning_3_idx` (`legal_entity_id`),
  CONSTRAINT `fk_BusinessPlanning_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_BusinessPlanning_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_BusinessPlanning_3` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CharitablePlanning`
--

DROP TABLE IF EXISTS `CharitablePlanning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CharitablePlanning` (
  `charitable_planning_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `legal_entity_id` int DEFAULT NULL,
  `has_charitable_foundation` tinyint(1) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`charitable_planning_id`),
  KEY `fk_CharitablePlanning_1_idx` (`household_id`),
  KEY `fk_CharitablePlanning_2_idx` (`client_id`),
  KEY `fk_CharitablePlanning_3_idx` (`legal_entity_id`),
  CONSTRAINT `fk_CharitablePlanning_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_CharitablePlanning_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_CharitablePlanning_3` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Client`
--

DROP TABLE IF EXISTS `Client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Client` (
  `client_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int DEFAULT NULL,
  `address_id` int DEFAULT NULL,
  `iam_id` binary(16) DEFAULT NULL,
  `auth0_id` varchar(255) DEFAULT NULL,
  `type` enum('C','P','D','N') NOT NULL,
  `title` varchar(10) DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `preferred_name` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `sex` enum('M','F','U','O') DEFAULT NULL COMMENT 'M = Male, F = Female, U = Undisclosed, O = Other',
  `relationship_status` enum('S','F','E','M','P','D','W','X') DEFAULT NULL COMMENT 'S = Single, F = Defacto, E = Engaged, M = Married, S = Separated, D = Divorced, W = Widowed, X = Deceased',
  `country_code_birth` varchar(2) DEFAULT NULL COMMENT 'Country of Birth',
  `country_code_residency` varchar(2) DEFAULT NULL,
  `country_code_citizenship` varchar(2) DEFAULT NULL,
  `notes` varchar(10000) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `external_id_2` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system_2` varchar(15) DEFAULT NULL,
  `client_category` varchar(20) DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `last_user_agent` varchar(300) DEFAULT NULL,
  `billable_start` timestamp NULL DEFAULT NULL,
  `billable_trigger` enum('N','I','V','L','P','T','R','G','D') DEFAULT 'N',
  `billable_start_prev` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `last_ip` varchar(39) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `contact_details_id` int NOT NULL,
  `deleted_by` varchar(50) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  PRIMARY KEY (`client_id`),
  UNIQUE KEY `ix_Client_iam_id` (`iam_id`),
  KEY `fk_Client_1_idx` (`address_id`),
  KEY `contact_details_id` (`contact_details_id`),
  KEY `ix_Client_external_id` (`external_id`,`external_system`),
  KEY `ix_Client_external_id_2` (`external_id_2`,`external_system_2`),
  KEY `ix_Client_household_id` (`household_id`,`deleted`,`is_active`),
  CONSTRAINT `fk_Client_1` FOREIGN KEY (`address_id`) REFERENCES `Address` (`address_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Client_2` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=26271 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientConfidenceGoal`
--

DROP TABLE IF EXISTS `ClientConfidenceGoal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientConfidenceGoal` (
  `client_confidence_goal_id` int NOT NULL AUTO_INCREMENT,
  `goal_id` int NOT NULL,
  `client_id` int NOT NULL,
  `confidence_section_id` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_confidence_goal_id`),
  KEY `ix_ClientConfidenceGoal_client_id` (`client_id`),
  KEY `ix_ClientConfidenceGoal_goal_id` (`goal_id`),
  CONSTRAINT `ClientConfidenceGoal_ibfk_1` FOREIGN KEY (`goal_id`) REFERENCES `Goal` (`goal_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ClientConfidenceGoal_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=287 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientConfidenceNote`
--

DROP TABLE IF EXISTS `ClientConfidenceNote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientConfidenceNote` (
  `client_confidence_note_id` int NOT NULL AUTO_INCREMENT,
  `confidence_id` int NOT NULL,
  `confidence_section_key` enum('confidence','income','business','debt','investments','risk','retirement','estate','connectionsSection','household') NOT NULL,
  `confidence_section_note` varchar(5000) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_confidence_note_id`),
  KEY `ix_ClientConfidenceNote_confidence_id` (`confidence_id`),
  CONSTRAINT `ClientConfidenceNote_ibfk_1` FOREIGN KEY (`confidence_id`) REFERENCES `Confidence` (`confidence_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientConfig`
--

DROP TABLE IF EXISTS `ClientConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientConfig` (
  `client_config_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `dashboard` json DEFAULT NULL,
  `configuration` json DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_config_id`),
  KEY `fk_ClientConfig_1_idx` (`client_id`),
  CONSTRAINT `fk_ClientConfig_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=279 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientDiscovery`
--

DROP TABLE IF EXISTS `ClientDiscovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientDiscovery` (
  `client_discovery_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `home_loan_owing` decimal(12,2) DEFAULT NULL,
  `investment_debt` decimal(12,2) DEFAULT NULL,
  `other_debt` decimal(12,2) DEFAULT NULL,
  `income` decimal(12,2) DEFAULT NULL,
  `super` decimal(12,2) DEFAULT NULL,
  `savings` decimal(12,2) DEFAULT NULL,
  `other_assets` decimal(12,2) DEFAULT NULL,
  `life_insurance` tinyint(1) NOT NULL,
  `income_protection` tinyint(1) NOT NULL,
  `trauma_insurance` tinyint(1) NOT NULL,
  `tpd_insurance` tinyint(1) NOT NULL,
  `desired_retirement_age` int DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_discovery_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `ClientDiscovery_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1604 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientIntegration`
--

DROP TABLE IF EXISTS `ClientIntegration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientIntegration` (
  `client_integration_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `integration_type` enum('MG','RT','RA','SF','TM','XP','Y') NOT NULL,
  `integration_details` json NOT NULL,
  `status` varchar(1) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_integration_id`),
  KEY `fk_ClientIntegration_1_idx` (`client_id`),
  CONSTRAINT `fk_ClientIntegration_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=4207 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientRegret`
--

DROP TABLE IF EXISTS `ClientRegret`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientRegret` (
  `client_regret_id` int NOT NULL AUTO_INCREMENT,
  `client_values_id` int NOT NULL,
  `regret` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_regret_id`),
  KEY `fk_ClientRegret_1_idx` (`client_values_id`),
  CONSTRAINT `fk_ClientRegret_1` FOREIGN KEY (`client_values_id`) REFERENCES `ClientValues` (`client_values_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=17309 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientStrategyGoal`
--

DROP TABLE IF EXISTS `ClientStrategyGoal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientStrategyGoal` (
  `client_strategy_goal_id` int NOT NULL AUTO_INCREMENT,
  `goal_id` int NOT NULL,
  `strategy_value` varchar(500) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_strategy_goal_id`),
  KEY `ix_ClientStrategyGoal_goal_id` (`goal_id`),
  CONSTRAINT `ClientStrategyGoal_ibfk_1` FOREIGN KEY (`goal_id`) REFERENCES `Goal` (`goal_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ClientStrategyGoal_1` FOREIGN KEY (`goal_id`) REFERENCES `Goal` (`goal_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1564 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientValue`
--

DROP TABLE IF EXISTS `ClientValue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientValue` (
  `client_value_id` int NOT NULL AUTO_INCREMENT,
  `client_values_id` int NOT NULL,
  `card_id` int DEFAULT NULL,
  `value_rank` int DEFAULT NULL,
  `meaning_reason` varchar(10000) DEFAULT NULL,
  `progress_action` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_value_id`),
  KEY `fk_ClientValue_1_idx` (`client_values_id`),
  CONSTRAINT `fk_ClientValue_1` FOREIGN KEY (`client_values_id`) REFERENCES `ClientValues` (`client_values_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=41480 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientValueGoal`
--

DROP TABLE IF EXISTS `ClientValueGoal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientValueGoal` (
  `client_value_goal_id` int NOT NULL AUTO_INCREMENT,
  `goal_id` int NOT NULL,
  `card_id` int NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_value_goal_id`),
  KEY `ix_ClientValueGoal_client_value_id` (`card_id`),
  KEY `ix_ClientValueGoal_goal_id` (`goal_id`),
  CONSTRAINT `ClientValueGoal_ibfk_1` FOREIGN KEY (`goal_id`) REFERENCES `Goal` (`goal_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ClientValueGoal_1` FOREIGN KEY (`goal_id`) REFERENCES `Goal` (`goal_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientValues`
--

DROP TABLE IF EXISTS `ClientValues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientValues` (
  `client_values_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `household_values_id` int DEFAULT NULL,
  `status` enum('O','C') NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` varchar(50) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  PRIMARY KEY (`client_values_id`),
  KEY `fk_ClientValues_1_idx` (`client_id`),
  CONSTRAINT `fk_ClientValues_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=8346 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientWealthId`
--

DROP TABLE IF EXISTS `ClientWealthId`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientWealthId` (
  `client_wealth_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `ilcn` varchar(9) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_wealth_id`),
  KEY `fk_ClientWealthId_1_idx` (`client_id`),
  CONSTRAINT `fk_ClientWealthId_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientWellness`
--

DROP TABLE IF EXISTS `ClientWellness`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientWellness` (
  `client_wellness_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `wellness_score` decimal(7,4) DEFAULT NULL,
  `life_score` decimal(7,4) DEFAULT NULL,
  `values_score` decimal(7,4) DEFAULT NULL,
  `goals_score` decimal(7,4) DEFAULT NULL,
  `tasks_score` decimal(7,4) DEFAULT NULL,
  `kaa_score` decimal(7,4) DEFAULT NULL,
  `components` varchar(8) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_wellness_id`),
  UNIQUE KEY `ix_ClientWellness_client_id` (`client_id`),
  KEY `fk_ClientWellness_1_idx` (`client_id`),
  CONSTRAINT `fk_ClientWellness_1_idx` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=49216 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientWellnessHistory`
--

DROP TABLE IF EXISTS `ClientWellnessHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientWellnessHistory` (
  `client_wellness_history_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `wellness_score` decimal(7,4) DEFAULT NULL,
  `life_score` decimal(7,4) DEFAULT NULL,
  `values_score` decimal(7,4) DEFAULT NULL,
  `goals_score` decimal(7,4) DEFAULT NULL,
  `tasks_score` decimal(7,4) DEFAULT NULL,
  `kaa_score` decimal(7,4) DEFAULT NULL,
  `components` varchar(8) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_wellness_history_id`),
  KEY `fk_ClientWellnessHistory_1_idx` (`client_id`),
  CONSTRAINT `fk_ClientWellnessHistory_1_idx` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=94947 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Component`
--

DROP TABLE IF EXISTS `Component`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Component` (
  `component_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL COMMENT 'Unique code to identify this component',
  `name` varchar(200) NOT NULL COMMENT 'Name of this component',
  `description` varchar(1500) NOT NULL COMMENT 'Description of this component',
  `start_date` date DEFAULT NULL COMMENT 'Date from which this component is available - null = always',
  `end_date` date DEFAULT NULL COMMENT 'Date until this component is available - null = always',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`component_id`),
  UNIQUE KEY `ix_Component_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Confidence`
--

DROP TABLE IF EXISTS `Confidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Confidence` (
  `confidence_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `status` enum('O','C') NOT NULL,
  `overall_score` int DEFAULT NULL,
  `income_score` int DEFAULT NULL,
  `business_score` int DEFAULT NULL,
  `debt_score` int DEFAULT NULL,
  `investment_score` int DEFAULT NULL,
  `risk_score` int DEFAULT NULL,
  `retirement_score` int DEFAULT NULL,
  `estate_score` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`confidence_id`),
  KEY `fk_Confidence_1_idx` (`client_id`),
  CONSTRAINT `fk_Confidence_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ConfidenceConnection`
--

DROP TABLE IF EXISTS `ConfidenceConnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ConfidenceConnection` (
  `confidence_connection_id` int NOT NULL AUTO_INCREMENT,
  `confidence_id` int NOT NULL,
  `type` enum('L','C','G') NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`confidence_connection_id`),
  KEY `fk_ConfidenceConnection_1_idx` (`confidence_id`),
  CONSTRAINT `fk_ConfidenceConnection_1` FOREIGN KEY (`confidence_id`) REFERENCES `Confidence` (`confidence_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5893 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ConfidenceQuestionnaire`
--

DROP TABLE IF EXISTS `ConfidenceQuestionnaire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ConfidenceQuestionnaire` (
  `confidence_questionnaire_id` int NOT NULL AUTO_INCREMENT,
  `confidence_id` int NOT NULL,
  `question_id` int NOT NULL,
  `string_response` varchar(5000) DEFAULT NULL,
  `int_response` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`confidence_questionnaire_id`),
  KEY `fk_ConfidenceQuestionnaire_1_idx` (`confidence_id`),
  CONSTRAINT `fk_ConfidenceQuestionnaire_1` FOREIGN KEY (`confidence_id`) REFERENCES `Confidence` (`confidence_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=37876 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ContactDetails`
--

DROP TABLE IF EXISTS `ContactDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ContactDetails` (
  `contact_details_id` int NOT NULL AUTO_INCREMENT,
  `email_address` varchar(255) NOT NULL,
  `mobile_number` varchar(15) NOT NULL,
  `fax_number` varchar(15) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`contact_details_id`),
  UNIQUE KEY `uc_email_address` (`email_address`),
  KEY `ix_ContactDetails_external_id` (`external_id`,`external_system`)
) ENGINE=InnoDB AUTO_INCREMENT=28498 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DealerGroup`
--

DROP TABLE IF EXISTS `DealerGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DealerGroup` (
  `dealer_group_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `abn` varchar(13) DEFAULT NULL,
  `afsl` varchar(6) DEFAULT NULL,
  `afsl_name` varchar(255) DEFAULT NULL,
  `legal_name` varchar(255) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dealer_group_id`),
  KEY `ix_DealerGroup_abn` (`abn`),
  KEY `ix_DealerGroup_afsl` (`afsl`)
) ENGINE=InnoDB AUTO_INCREMENT=491 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DefaultBestLifeScenario`
--

DROP TABLE IF EXISTS `DefaultBestLifeScenario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DefaultBestLifeScenario` (
  `default_best_life_scenario_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `scenario_id` binary(16) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`default_best_life_scenario_id`),
  KEY `fk_DefaultBestLifeScenario_1_idx` (`household_id`),
  CONSTRAINT `fk_DefaultBestLifeScenario_1_idx` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Director`
--

DROP TABLE IF EXISTS `Director`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Director` (
  `director_id` int NOT NULL AUTO_INCREMENT,
  `legal_entity_id` int NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `date_appointed` date DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`director_id`),
  KEY `fk_Director_1_idx` (`legal_entity_id`),
  CONSTRAINT `fk_Director_1` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Discovery`
--

DROP TABLE IF EXISTS `Discovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Discovery` (
  `discovery_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `household_income` decimal(12,2) DEFAULT NULL,
  `additional_household_income` decimal(12,2) DEFAULT NULL,
  `household_savings` decimal(12,2) DEFAULT NULL,
  `household_total_assets` decimal(12,2) DEFAULT NULL,
  `household_total_debt` decimal(12,2) DEFAULT NULL,
  `super_contributions` enum('Y','N','NP','U') NOT NULL,
  `super_contributions_details` varchar(5000) DEFAULT NULL,
  `savings_regularity` enum('O','S','R','N') NOT NULL,
  `savings_amount` decimal(12,2) DEFAULT NULL,
  `home_value` decimal(12,2) DEFAULT NULL,
  `investment_properties_value` decimal(12,2) DEFAULT NULL,
  `reference_model` int DEFAULT NULL,
  `required_retirement_income` decimal(12,2) DEFAULT NULL,
  `investment_properties_debt` decimal(12,2) DEFAULT NULL,
  `external_id` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`discovery_id`),
  KEY `household_id` (`household_id`),
  CONSTRAINT `Discovery_ibfk_3` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1329 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EducationPlanning`
--

DROP TABLE IF EXISTS `EducationPlanning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EducationPlanning` (
  `education_planning_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `legal_entity_id` int DEFAULT NULL,
  `has_education_savings` tinyint(1) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`education_planning_id`),
  KEY `fk_EducationPlanning_1_idx` (`household_id`),
  KEY `fk_EducationPlanning_2_idx` (`client_id`),
  KEY `fk_EducationPlanning_3_idx` (`legal_entity_id`),
  CONSTRAINT `fk_EducationPlanning_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_EducationPlanning_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_EducationPlanning_3` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EmploymentDetails`
--

DROP TABLE IF EXISTS `EmploymentDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EmploymentDetails` (
  `employment_details_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `degree_qualified` tinyint(1) DEFAULT NULL,
  `qualifications` varchar(255) DEFAULT NULL,
  `recent_retrenched` tinyint(1) NOT NULL,
  `employment_status` enum('F','P','A','S','C','H','N','R','U','O','E','T') DEFAULT NULL COMMENT 'F = Full-time, P = Part-time, A = Casual, S = Self Employed, C = Contractor, H = Home duties, N = Not working, R = Retired, U = Unemployed, O = Other, E = Employed, T = Student',
  `planned_changes` tinyint(1) DEFAULT NULL COMMENT 'Any planned changes?',
  `planned_changes_description` varchar(255) DEFAULT NULL,
  `business_structure` varchar(255) DEFAULT NULL,
  `employed_by_own_company` tinyint(1) DEFAULT NULL,
  `occupation` varchar(80) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `employer` varchar(80) DEFAULT NULL,
  `secondary_occupation` varchar(80) DEFAULT NULL,
  `secondary_occupation_start_date` date DEFAULT NULL,
  `secondary_occupation_employer` varchar(80) DEFAULT NULL,
  `employment_hours_per_week` decimal(3,1) DEFAULT NULL,
  `unused_annual_leave` decimal(3,1) DEFAULT NULL,
  `unused_sick_leave` decimal(3,1) DEFAULT NULL,
  `unused_long_service_leave` decimal(3,1) DEFAULT NULL,
  `worked_overseas` tinyint(1) DEFAULT NULL,
  `worked_overseas_details` varchar(255) DEFAULT NULL,
  `salary_sacrifice_available` tinyint(1) DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`employment_details_id`),
  KEY `fk_EmploymentDetails_1_idx` (`client_id`),
  CONSTRAINT `fk_EmploymentDetails_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2565 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Equitise`
--

DROP TABLE IF EXISTS `Equitise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Equitise` (
  `equitise_id` int NOT NULL AUTO_INCREMENT,
  `raised` int NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`equitise_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EstatePlanning`
--

DROP TABLE IF EXISTS `EstatePlanning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EstatePlanning` (
  `estate_planning_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int NOT NULL,
  `solicitor_name` varchar(255) DEFAULT NULL,
  `will_in_place` tinyint(1) NOT NULL,
  `is_will_current` tinyint(1) DEFAULT NULL,
  `will_date` date DEFAULT NULL,
  `will_location` varchar(200) DEFAULT NULL,
  `will_provisions` enum('A','T','G') DEFAULT NULL COMMENT 'A = All, T = Testamentary Trust, G = Child Guardianship',
  `healthcare_directive` tinyint(1) DEFAULT NULL,
  `healthcare_directive_details` varchar(2000) DEFAULT NULL,
  `funeral_arrangement` enum('P','B','N') DEFAULT NULL COMMENT 'P = Funeral Plan, B = Funeral Bond, N = No',
  `funeral_details` varchar(200) DEFAULT NULL,
  `prepaid_funeral` tinyint(1) DEFAULT NULL,
  `funeral_expense_value` decimal(15,2) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `product_provider` varchar(100) DEFAULT NULL,
  `super_beneficiaries_nominated` tinyint(1) DEFAULT NULL,
  `beneficiaries_nominated` tinyint(1) DEFAULT NULL,
  `poa_granted` tinyint(1) DEFAULT NULL,
  `pog_granted` tinyint(1) DEFAULT NULL,
  `apoa_granted` tinyint(1) DEFAULT NULL,
  `letter_of_wishes` tinyint(1) DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(1500) DEFAULT NULL,
  `partner_notes` varchar(1500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`estate_planning_id`),
  KEY `fk_EstatePlanning_1_idx` (`household_id`),
  KEY `fk_EstatePlanning_2_idx` (`client_id`),
  CONSTRAINT `fk_EstatePlanning_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_EstatePlanning_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2293 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Executor`
--

DROP TABLE IF EXISTS `Executor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Executor` (
  `executor_id` int NOT NULL AUTO_INCREMENT,
  `estate_planning_id` int NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`executor_id`),
  KEY `fk_Executor_1_idx` (`estate_planning_id`),
  CONSTRAINT `fk_Executor_1` FOREIGN KEY (`estate_planning_id`) REFERENCES `EstatePlanning` (`estate_planning_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Expense`
--

DROP TABLE IF EXISTS `Expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Expense` (
  `expense_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `legal_entity_id` int DEFAULT NULL,
  `asset_id` int DEFAULT NULL,
  `household_member_id` int DEFAULT NULL,
  `expense_type` enum('L','E','S','M') NOT NULL COMMENT 'L = Living / Discretionary, E = Related Expense, S = Savings Plan, M = Simple Expense Breakdown',
  `expense_sub_type` enum('P','G','I','V','A','R','C','N','E','U','O') DEFAULT NULL COMMENT 'P = Investment Property, G = Savings, I = Investments, V = Vehicle, A = Other Asset, R = Carer Allowance, C = Child Care, N = Nanny Allowance, E = School Fees, U = University Support, O = Other Expense',
  `savings_plan_type` enum('C','O','I','S','T') DEFAULT NULL COMMENT 'C = Cash, O = Offset Account, I = Investments, S = Superannuation (Non Concessional Contribution), T = Term Deposit',
  `description` varchar(200) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL COMMENT 'This is Living Amount for Living / Discretionary',
  `amount_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `discretionary_amount` decimal(15,2) DEFAULT NULL,
  `frequency` enum('W','F','T','M','B','Q','S','A') DEFAULT NULL COMMENT 'W = Weekly, F = Fortnightly, T = Twice a Month, M = Monthly, B = Every 2 months, Q = Quarterly, S = Semi-Annually, A= Annually',
  `end_year` int DEFAULT NULL COMMENT 'Expense or Savings Plan End Year',
  `stop_allowance` enum('E','Y') DEFAULT NULL COMMENT 'E = Eldest child reaches age, Y = Youngest child reaches age',
  `stop_allowance_age` int DEFAULT NULL,
  `fee_increase_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `changes_expected` tinyint(1) DEFAULT NULL,
  `time_frame` enum('O','E','R','F','V','X','S','G','N','T','L','W') DEFAULT NULL COMMENT 'O = Next Month, E = Next 2 Months, R = Next 3 Months, F = Next 4 Months, V = Next 5 Months, X = Next 6 Months, S = Next 7 Months, G = Next 8 Months, N = Next 9 Months, T = Next 10 Months, L = Next 11 Months, W = Next 12 Months',
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `external_load_id` varchar(50) DEFAULT NULL,
  `soft_deleted` tinyint(1) DEFAULT '0',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`expense_id`),
  KEY `fk_Expense_1_idx` (`household_id`),
  KEY `fk_Expense_2_idx` (`client_id`),
  KEY `fk_Expense_3_idx` (`asset_id`),
  KEY `legal_entity_id` (`legal_entity_id`),
  KEY `ix_Expense_external_id` (`external_id`,`external_system`),
  CONSTRAINT `Expense_ibfk_1` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Expense_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Expense_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Expense_3` FOREIGN KEY (`asset_id`) REFERENCES `Asset` (`asset_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2281 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FHAQuestionnaire`
--

DROP TABLE IF EXISTS `FHAQuestionnaire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FHAQuestionnaire` (
  `fha_questionnaire_id` int NOT NULL AUTO_INCREMENT,
  `financial_health_assessment_id` int NOT NULL,
  `question_id` int NOT NULL,
  `string_response` varchar(5000) DEFAULT NULL,
  `int_response` int DEFAULT NULL,
  `section` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`fha_questionnaire_id`),
  KEY `fk_FHAQuestionnaire_1_idx` (`financial_health_assessment_id`),
  CONSTRAINT `fk_FHAQuestionnaire_1` FOREIGN KEY (`financial_health_assessment_id`) REFERENCES `FinancialHealthAssessment` (`financial_health_assessment_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FinancialHealthAssessment`
--

DROP TABLE IF EXISTS `FinancialHealthAssessment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FinancialHealthAssessment` (
  `financial_health_assessment_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `status` enum('O','C') NOT NULL,
  `vision_goals_score` int DEFAULT NULL,
  `retirement_planning_score` int DEFAULT NULL,
  `insurance_asset_protection_score` int DEFAULT NULL,
  `debt_cash_flow_management_score` int DEFAULT NULL,
  `education_planning_score` int DEFAULT NULL,
  `investment_planning_score` int DEFAULT NULL,
  `income_tax_planning_score` int DEFAULT NULL,
  `business_planning_score` int DEFAULT NULL,
  `charitable_planning_score` int DEFAULT NULL,
  `estate_planning_score` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`financial_health_assessment_id`),
  KEY `fk_FinancialHealthAssessment_1_idx` (`client_id`),
  CONSTRAINT `fk_FinancialHealthAssessment_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Goal`
--

DROP TABLE IF EXISTS `Goal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Goal` (
  `goal_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `description` varchar(3500) DEFAULT NULL,
  `success_looks_like` varchar(1500) DEFAULT NULL,
  `target_date` date DEFAULT NULL,
  `target_date_pa` date DEFAULT NULL,
  `target_date_pa_date` date DEFAULT NULL,
  `target_date_approval_status` varchar(50) DEFAULT NULL,
  `completed_date` date DEFAULT NULL,
  `rank` int DEFAULT NULL,
  `estimated_cost` int DEFAULT NULL,
  `estimated_cost_pa` int DEFAULT NULL,
  `estimated_cost_pa_date` date DEFAULT NULL,
  `estimated_cost_approval_status` varchar(50) DEFAULT NULL,
  `confidence` int DEFAULT NULL,
  `progress` int DEFAULT NULL,
  `importance` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `status_pa` int DEFAULT NULL,
  `status_pa_date` date DEFAULT NULL,
  `status_approval_status` varchar(50) DEFAULT NULL,
  `recurrence_type` enum('N','M','Q','S','A') NOT NULL DEFAULT 'N',
  `recurrence_type_pa` enum('N','M','Q','S','A') DEFAULT NULL,
  `recurrence_type_pa_date` date DEFAULT NULL,
  `recurrence_type_approval_status` varchar(50) DEFAULT NULL,
  `recurrence_interval` int NOT NULL DEFAULT '0',
  `recurrence_interval_pa` int DEFAULT NULL,
  `recurrence_interval_pa_date` date DEFAULT NULL,
  `recurrence_interval_approval_status` varchar(50) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `assigned_to_household_id` int DEFAULT NULL,
  `source_of_truth` varchar(50) NOT NULL DEFAULT 'L',
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `secondary_external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `tertiary_external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `for_approval` tinyint(1) DEFAULT NULL,
  `approval_status` varchar(255) DEFAULT NULL,
  `approval_change_date` date DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` varchar(50) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  PRIMARY KEY (`goal_id`),
  KEY `ix_Goal_assigned_to_client_id` (`client_id`),
  KEY `tertiary_external_id_index` (`tertiary_external_id`),
  KEY `ix_Goal_created_for_household_id` (`household_id`),
  KEY `ix_Goal_external_id` (`external_id`,`external_system`),
  KEY `ix_Goal_hh_client_deleted` (`household_id`,`client_id`,`deleted`),
  CONSTRAINT `Goal_ibfk_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=35197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HealthDetails`
--

DROP TABLE IF EXISTS `HealthDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HealthDetails` (
  `health_details_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `health_status` enum('E','G','F','P') DEFAULT NULL COMMENT 'E = Excellent, G = Good, F = Fair, P = Poor',
  `medical_history_issues` varchar(5000) DEFAULT NULL,
  `is_smoker` tinyint(1) DEFAULT NULL,
  `smoke_per_day` int DEFAULT NULL COMMENT 'If a smoker, how many per day?',
  `use_nicotine` tinyint(1) DEFAULT NULL,
  `nicotine_per_day` int DEFAULT NULL,
  `use_medication` tinyint(1) DEFAULT NULL,
  `medication_details` varchar(255) DEFAULT NULL,
  `medical_condition` tinyint(1) DEFAULT NULL,
  `medical_condition_details` varchar(255) DEFAULT NULL,
  `major_illness` tinyint(1) DEFAULT NULL,
  `major_illness_details` varchar(255) DEFAULT NULL,
  `private_health` tinyint(1) DEFAULT NULL,
  `private_health_details` varchar(255) DEFAULT NULL,
  `sports_interests_list` json DEFAULT NULL,
  `sports_interests` varchar(50) DEFAULT NULL,
  `sports_interests_frequency` enum('D','W','M','B','Q','S','A','O') DEFAULT NULL COMMENT 'D = Daily, W = Week, M = Monthly, Q = Quarterly, S = Semi-Annually, A = Annually, O = Other',
  `notes` varchar(5000) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`health_details_id`),
  KEY `fk_HealthDetails_1_idx` (`client_id`),
  CONSTRAINT `fk_HealthDetails_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2333 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Holding`
--

DROP TABLE IF EXISTS `Holding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Holding` (
  `holding_id` int NOT NULL AUTO_INCREMENT,
  `portfolio_id` int NOT NULL,
  `security_id` int DEFAULT NULL,
  `ticker` varchar(30) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `quantity` decimal(20,8) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `average_price` decimal(20,8) DEFAULT NULL,
  `total_cost` decimal(15,2) DEFAULT NULL,
  `market_price` decimal(20,8) DEFAULT NULL,
  `market_price_date` date DEFAULT NULL,
  `maturity_date` date DEFAULT NULL,
  `interest_rate` decimal(5,4) DEFAULT NULL,
  `payment_frequency` enum('D','O','W','F','T','M','I','L','E','B','Q','S','A','AT') DEFAULT NULL COMMENT 'D = Daily, O = One time, W = Weekly, F = Fortnightly, T = Twice a Month, M = Monthly, I = FIRST_DAY_MONTHLY, L = LAST_DAY_MONTHLY, E = EVERY_4_WEEKS, B = Every 2 months, Q = Quarterly, S = Semi-Annually, A = Annually, AT = At-Maturity',
  `currency_code` varchar(3) DEFAULT NULL,
  `override_asset_tree_id` int DEFAULT NULL,
  `override_security_group_id` int DEFAULT NULL,
  `override_security_type_id` int DEFAULT NULL,
  `override_security_style` varchar(50) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `external_load_id` varchar(50) DEFAULT NULL,
  `soft_deleted` tinyint(1) DEFAULT '0',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`holding_id`),
  UNIQUE KEY `ix_Holding_external_id_system` (`portfolio_id`,`external_id`,`external_system`),
  KEY `fk_Holding_1` (`portfolio_id`),
  KEY `fk_Holding_2` (`security_id`),
  KEY `ix_Holding_external_id` (`external_id`,`external_system`),
  CONSTRAINT `fk_Holding_1` FOREIGN KEY (`portfolio_id`) REFERENCES `Portfolio` (`portfolio_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Holding_2` FOREIGN KEY (`security_id`) REFERENCES `md_security` (`security_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=27226 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Household`
--

DROP TABLE IF EXISTS `Household`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Household` (
  `household_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `is_test` tinyint(1) NOT NULL DEFAULT '0',
  `household_package_id` int DEFAULT NULL COMMENT 'Package assigned to the household',
  `practice_segmentation_id` int DEFAULT NULL,
  `country_code` varchar(2) NOT NULL DEFAULT 'AU',
  `notes` varchar(10000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_id`),
  KEY `household_package_id` (`household_package_id`),
  KEY `practice_segmentation_id` (`practice_segmentation_id`),
  KEY `ix_Household_external_id` (`external_id`,`external_system`),
  KEY `ix_Household_name` (`name`),
  CONSTRAINT `Household_ibfk_1` FOREIGN KEY (`household_package_id`) REFERENCES `HouseholdPackage` (`household_package_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Household_ibfk_2` FOREIGN KEY (`practice_segmentation_id`) REFERENCES `PracticeSegmentation` (`practice_segmentation_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=22627 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdActivity`
--

DROP TABLE IF EXISTS `HouseholdActivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdActivity` (
  `household_activity_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `best_life_plan_last_exported` timestamp NULL DEFAULT NULL,
  `toe_last_exported` timestamp NULL DEFAULT NULL,
  `governance_last_exported` timestamp NULL DEFAULT NULL,
  `halo_cfo_last_sent` timestamp NULL DEFAULT NULL,
  `halo_cfo_last_completed` timestamp NULL DEFAULT NULL,
  `halo_non_cfo_last_sent` timestamp NULL DEFAULT NULL,
  `halo_non_cfo_last_completed` timestamp NULL DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_activity_id`),
  KEY `fk_HouseholdActivity_1_idx` (`household_id`),
  CONSTRAINT `fk_HouseholdActivity_1_idx` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1508 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdConfig`
--

DROP TABLE IF EXISTS `HouseholdConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdConfig` (
  `household_config_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `configuration` json DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_config_id`),
  KEY `fk_HouseholdConfig_1_idx` (`household_id`),
  CONSTRAINT `fk_HouseholdConfig_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdInvestmentPreferences`
--

DROP TABLE IF EXISTS `HouseholdInvestmentPreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdInvestmentPreferences` (
  `household_investment_preferences_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `customisation_notes` mediumtext,
  `customisation` enum('Y','N','NP','U') DEFAULT NULL,
  `ethical_notes` mediumtext,
  `ethical` enum('Y','N','NP','U') DEFAULT NULL,
  `asset_class_notes` mediumtext,
  `allocation_notes` mediumtext,
  `allocation_type` enum('S','D','NP','U') DEFAULT NULL,
  `risk_notes` mediumtext,
  `risk_group` int DEFAULT NULL,
  `cost_notes` mediumtext,
  `cost_driven` enum('Y','N') DEFAULT NULL,
  `prioritisation_notes` mediumtext,
  `comment_notes` mediumtext,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_investment_preferences_id`),
  KEY `household_id` (`household_id`),
  CONSTRAINT `HouseholdInvestmentPreferences_ibfk_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1385 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdMember`
--

DROP TABLE IF EXISTS `HouseholdMember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdMember` (
  `household_member_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `relation` varchar(40) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `dob` date DEFAULT NULL,
  `sex` enum('M','F','O','U') DEFAULT NULL COMMENT 'M = Male, F = Female, O = Other, U = Undisclosed',
  `living_at_home` tinyint(1) DEFAULT NULL,
  `financially_dependent` tinyint(1) NOT NULL,
  `financially_dependent_until` int DEFAULT NULL COMMENT 'If financially dependent, until what age?',
  `notes` varchar(5000) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_member_id`),
  KEY `fk_HouseholdMember_1_idx` (`household_id`),
  CONSTRAINT `fk_HouseholdMember_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=4112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdPackage`
--

DROP TABLE IF EXISTS `HouseholdPackage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdPackage` (
  `household_package_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL COMMENT 'Unique code to identify this household package',
  `name` varchar(200) NOT NULL COMMENT 'Name of this household package',
  `description` varchar(1500) NOT NULL COMMENT 'Description of this household package',
  `requires_license` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'True if this household package requires a license at the practice level. False if it does not.',
  `disabled_feature_flags` json NOT NULL COMMENT 'List of feature flags which should be disabled for a household in this subscription package.',
  `enabled_feature_flags` json NOT NULL COMMENT 'List of feature flags which should be enabled for a household in this subscription package.',
  `start_date` date DEFAULT NULL COMMENT 'Date from which this household package is available - null = always',
  `end_date` date DEFAULT NULL COMMENT 'Date until this household package is available - null = always',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_package_id`),
  UNIQUE KEY `ix_HouseholdPackage_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdPackageComponent`
--

DROP TABLE IF EXISTS `HouseholdPackageComponent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdPackageComponent` (
  `household_package_component_id` int NOT NULL AUTO_INCREMENT,
  `household_package_id` int NOT NULL,
  `component_id` int NOT NULL,
  `price` decimal(12,4) DEFAULT NULL COMMENT 'Component price ex GST to be charged per payment period.',
  `num_included` int DEFAULT NULL COMMENT 'For quantity based components this stipulates how many have been included in the package and therefore do not get charged.',
  `treat_included_as_min` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'True if num_included should be treated like a minimum, False if it should be based on actual usage',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_package_component_id`),
  KEY `fk_HouseholdPackageComponent_1_idx` (`household_package_id`),
  KEY `fk_HouseholdPackageComponent_2_idx` (`component_id`),
  CONSTRAINT `fk_HouseholdPackageComponent_1` FOREIGN KEY (`household_package_id`) REFERENCES `HouseholdPackage` (`household_package_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_HouseholdPackageComponent_2` FOREIGN KEY (`component_id`) REFERENCES `Component` (`component_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdStrategy`
--

DROP TABLE IF EXISTS `HouseholdStrategy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdStrategy` (
  `household_strategy_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `practice_strategy_category_id` int NOT NULL,
  `practice_strategy_id` int DEFAULT NULL COMMENT 'This can be null for custom / ad-hoc strategies',
  `strategy_name` varchar(1000) DEFAULT NULL,
  `details` varchar(10000) DEFAULT NULL,
  `progress` int NOT NULL DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `target_amount` decimal(15,2) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`household_strategy_id`),
  KEY `fk_HouseholdStrategy_1_idx` (`household_id`),
  KEY `fk_HouseholdStrategy_2_idx` (`practice_strategy_category_id`),
  KEY `fk_HouseholdStrategy_3_idx` (`practice_strategy_id`),
  KEY `ix_HouseholdStrategy_external_id` (`external_id`,`external_system`),
  CONSTRAINT `fk_HouseholdStrategy_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_HouseholdStrategy_2` FOREIGN KEY (`practice_strategy_category_id`) REFERENCES `PracticeStrategyCategory` (`practice_strategy_category_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_HouseholdStrategy_3` FOREIGN KEY (`practice_strategy_id`) REFERENCES `PracticeStrategy` (`practice_strategy_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=25027 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdStrategyCategory`
--

DROP TABLE IF EXISTS `HouseholdStrategyCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdStrategyCategory` (
  `household_strategy_category_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `practice_strategy_category_id` int NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `status` int DEFAULT '0',
  `status_migrated` tinyint(1) DEFAULT '0',
  `rank` int DEFAULT '0',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_strategy_category_id`),
  KEY `fk_HouseholdStratCategory_1_idx` (`household_id`),
  KEY `fk_HouseholdStratCategory_2_idx` (`practice_strategy_category_id`),
  CONSTRAINT `fk_HouseholdStratCategory_1_idx` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_HouseholdStratCategory_2_idx` FOREIGN KEY (`practice_strategy_category_id`) REFERENCES `PracticeStrategyCategory` (`practice_strategy_category_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=34767 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdStrategyGoal`
--

DROP TABLE IF EXISTS `HouseholdStrategyGoal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdStrategyGoal` (
  `household_strategy_goal_id` int NOT NULL AUTO_INCREMENT,
  `household_strategy_id` int NOT NULL,
  `goal_id` int NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_strategy_goal_id`),
  KEY `fk_HouseholdStrategyGoal_1_idx` (`household_strategy_id`),
  KEY `fk_HouseholdStrategyGoal_2_idx` (`goal_id`),
  CONSTRAINT `fk_HouseholdStrategyGoal_1` FOREIGN KEY (`household_strategy_id`) REFERENCES `HouseholdStrategy` (`household_strategy_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_HouseholdStrategyGoal_2` FOREIGN KEY (`goal_id`) REFERENCES `Goal` (`goal_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=9187 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdStrategyTask`
--

DROP TABLE IF EXISTS `HouseholdStrategyTask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdStrategyTask` (
  `household_strategy_task_id` int NOT NULL AUTO_INCREMENT,
  `household_strategy_id` int NOT NULL,
  `task_id` int NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_strategy_task_id`),
  KEY `fk_HouseholdStrategyTask_1_idx` (`household_strategy_id`),
  KEY `fk_HouseholdStrategyTask_2_idx` (`task_id`),
  CONSTRAINT `fk_HouseholdStrategyTask_1` FOREIGN KEY (`household_strategy_id`) REFERENCES `HouseholdStrategy` (`household_strategy_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_HouseholdStrategyTask_2` FOREIGN KEY (`task_id`) REFERENCES `Task` (`task_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdTeamMember`
--

DROP TABLE IF EXISTS `HouseholdTeamMember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdTeamMember` (
  `household_team_member_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `practice_id` int NOT NULL,
  `staff_id` int DEFAULT NULL,
  `practice_office_id` int DEFAULT NULL,
  `role` enum('P1','PR','PP','SU','VO') NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_team_member_id`),
  KEY `fk_HouseholdTeamMember_1_idx` (`household_id`),
  KEY `fk_HouseholdTeamMember_2_idx` (`practice_id`),
  KEY `fk_HouseholdTeamMember_3_idx` (`staff_id`),
  KEY `fk_HouseholdTeamMember_4_idx` (`practice_office_id`),
  KEY `ix_HouseholdTeamMember_practice_id` (`practice_id`),
  KEY `ix_HouseholdTeamMember_household_id` (`household_id`),
  KEY `ix_HouseholdTeamMember_staff_id` (`staff_id`),
  KEY `ix_HouseholdTeamMember_practice_office_id` (`practice_office_id`),
  KEY `ix_HouseholdTeamMember_practice_hh` (`practice_id`,`household_id`),
  KEY `ix_HouseholdTeamMember_practice_staff_hh` (`practice_id`,`staff_id`,`household_id`),
  CONSTRAINT `fk_HouseholdTeamMember_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_HouseholdTeamMember_2` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_HouseholdTeamMember_3` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`staff_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_HouseholdTeamMember_4` FOREIGN KEY (`practice_office_id`) REFERENCES `PracticeOffice` (`practice_office_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=50673 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdValue`
--

DROP TABLE IF EXISTS `HouseholdValue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdValue` (
  `household_value_id` int NOT NULL AUTO_INCREMENT,
  `household_values_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `card_id` int DEFAULT NULL,
  `value_rank` int DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `progress` int DEFAULT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_value_id`),
  KEY `fk_HouseholdValue_1_idx` (`household_values_id`),
  CONSTRAINT `fk_HouseholdValue_1` FOREIGN KEY (`household_values_id`) REFERENCES `HouseholdValues` (`household_values_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=25091 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdValueGoal`
--

DROP TABLE IF EXISTS `HouseholdValueGoal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdValueGoal` (
  `household_value_goal_id` int NOT NULL AUTO_INCREMENT,
  `goal_id` int NOT NULL,
  `card_id` int NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_value_goal_id`),
  KEY `ix_HouseholdValueGoal_goal_id` (`goal_id`),
  KEY `household_value_id` (`card_id`),
  CONSTRAINT `fk_HouseholdValueGoal_1` FOREIGN KEY (`goal_id`) REFERENCES `Goal` (`goal_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `HouseholdValueGoal_ibfk_1` FOREIGN KEY (`goal_id`) REFERENCES `Goal` (`goal_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=11345 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdValueHouseholdMemberProgress`
--

DROP TABLE IF EXISTS `HouseholdValueHouseholdMemberProgress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdValueHouseholdMemberProgress` (
  `household_value_household_member_progress_id` int NOT NULL AUTO_INCREMENT,
  `household_value_id` int NOT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `progress` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_value_household_member_progress_id`),
  KEY `fk_HouseholdValueHouseholdMemberProgress_1_idx` (`household_value_id`),
  KEY `fk_HouseholdValueHouseholdMemberProgress_2_idx` (`client_id`),
  CONSTRAINT `fk_HouseholdValueHouseholdMemberProgress_1` FOREIGN KEY (`household_value_id`) REFERENCES `HouseholdValue` (`household_value_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=20021 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdValueNextStep`
--

DROP TABLE IF EXISTS `HouseholdValueNextStep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdValueNextStep` (
  `household_value_next_step_id` int NOT NULL AUTO_INCREMENT,
  `household_value_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `title` varchar(500) DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_value_next_step_id`),
  KEY `fk_HouseholdValueNextStep_1_idx` (`household_value_id`),
  KEY `fk_HouseholdValueNextStep_2_idx` (`client_id`),
  CONSTRAINT `fk_HouseholdValueNextStep_1` FOREIGN KEY (`household_value_id`) REFERENCES `HouseholdValue` (`household_value_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdValues`
--

DROP TABLE IF EXISTS `HouseholdValues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdValues` (
  `household_values_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_values_id` int DEFAULT NULL,
  `status` enum('O','C') NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` varchar(50) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  PRIMARY KEY (`household_values_id`),
  KEY `fk_HouseholdValues_1_idx` (`household_id`),
  KEY `ix_HouseholdValues_household_id` (`household_id`,`updated`),
  CONSTRAINT `fk_HouseholdValues_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5034 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdWellness`
--

DROP TABLE IF EXISTS `HouseholdWellness`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdWellness` (
  `household_wellness_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `wellness_score` decimal(7,4) DEFAULT NULL,
  `life_score` decimal(7,4) DEFAULT NULL,
  `values_score` decimal(7,4) DEFAULT NULL,
  `goals_score` decimal(7,4) DEFAULT NULL,
  `tasks_score` decimal(7,4) DEFAULT NULL,
  `kaa_score` decimal(7,4) DEFAULT NULL,
  `components` varchar(8) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_wellness_id`),
  UNIQUE KEY `ix_HouseholdWellness_household_id` (`household_id`),
  KEY `fk_HouseholdWellness_1_idx` (`household_id`),
  CONSTRAINT `fk_HouseholdWellness_1_idx` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=43504 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HouseholdWellnessHistory`
--

DROP TABLE IF EXISTS `HouseholdWellnessHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HouseholdWellnessHistory` (
  `household_wellness_history_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `wellness_score` decimal(7,4) DEFAULT NULL,
  `life_score` decimal(7,4) DEFAULT NULL,
  `values_score` decimal(7,4) DEFAULT NULL,
  `goals_score` decimal(7,4) DEFAULT NULL,
  `tasks_score` decimal(7,4) DEFAULT NULL,
  `kaa_score` decimal(7,4) DEFAULT NULL,
  `components` varchar(8) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`household_wellness_history_id`),
  KEY `fk_HouseholdWellnessHistory_1_idx` (`household_id`),
  CONSTRAINT `fk_HouseholdWellnessHistory_1_idx` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=58633 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Income`
--

DROP TABLE IF EXISTS `Income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Income` (
  `income_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `income_type` enum('S','I','P','C') NOT NULL COMMENT 'S = Salary, I = Income, P = Pension, C = Social Security',
  `employer` varchar(100) DEFAULT NULL,
  `job_title` varchar(100) DEFAULT NULL,
  `salary` decimal(15,2) DEFAULT NULL,
  `super_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `salary_sacrifice` decimal(15,2) DEFAULT NULL,
  `income` decimal(15,2) DEFAULT NULL,
  `frequency` enum('W','F','T','M','B','Q','S','A') DEFAULT NULL COMMENT 'W = Weekly, F = Fortnightly, T = Twice a Month, M = Monthly, B = Every 2 months, Q = Quarterly, S = Semi-Annually, A= Annually',
  `income_sub_type` enum('GA','GD','GC','GP','GG','GI','GT','GV','GO','DP','DA','DS','DI','DT') DEFAULT NULL COMMENT 'Generated by: GA = Asset, GD = Company (dividends), GC = Company (salary), GP = Investment Property, GG = Savings, GI = Investment, GT = Trust, GV = Vehicle, GO = Other; Drawn down by: DP = Account Based Pension, DA = Annuity, DS = Savings, DI = Investment, DT = Trust',
  `asset_id` int DEFAULT NULL,
  `legal_entity_id` int DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `assessed` tinyint(1) DEFAULT NULL COMMENT 'True if assessed by Social Security / Centerlink',
  `tax_status` enum('T','N') DEFAULT NULL COMMENT 'T = Taxed, N = Not Taxed',
  `rate_change_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `bonus` decimal(12,2) DEFAULT NULL,
  `bonus_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `commission` decimal(15,2) DEFAULT NULL,
  `commission_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `planned_changes` tinyint(1) DEFAULT NULL,
  `planned_changes_description` varchar(255) DEFAULT NULL,
  `eligible_social_benefits` tinyint(1) DEFAULT NULL,
  `type_of_concession` varchar(100) DEFAULT NULL,
  `gifted_assets` tinyint(1) DEFAULT NULL,
  `gifted_assets_list` json DEFAULT NULL,
  `crn` varchar(100) DEFAULT NULL,
  `is_receiving_payments` tinyint(1) DEFAULT NULL,
  `payment_type` varchar(100) DEFAULT NULL,
  `benefit_amount` decimal(15,2) DEFAULT NULL,
  `retirement_benefit_amount` decimal(15,2) DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2000) DEFAULT NULL,
  `partner_notes` varchar(2000) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `external_id` varchar(20) DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`income_id`),
  KEY `fk_Income_1_idx` (`household_id`),
  KEY `fk_Income_2_idx` (`client_id`),
  KEY `fk_Income_3_idx` (`asset_id`),
  KEY `fk_Income_4_idx` (`legal_entity_id`),
  CONSTRAINT `fk_Income_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Income_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Income_3` FOREIGN KEY (`asset_id`) REFERENCES `Asset` (`asset_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Income_4` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=7032 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Insurance`
--

DROP TABLE IF EXISTS `Insurance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Insurance` (
  `insurance_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `legal_entity_id` int DEFAULT NULL,
  `asset_id` int DEFAULT NULL,
  `beneficiary_client_id` int DEFAULT NULL,
  `beneficiary_legal_entity_id` int DEFAULT NULL,
  `beneficiary_household_member_id` int DEFAULT NULL,
  `insurance_type` enum('L','G') NOT NULL COMMENT 'L = Life Insurance, G = General Insurance',
  `life_insurance_type` enum('LT','LO','TO','IP','TC','BE','AR','SB','DI','HE','LC','UM','PC') DEFAULT NULL COMMENT 'AU [LT = Life/TPD, LO = Life Only, TO = TPD Only, IP = Income Protection, TC = Trauma/Critical Illness, BE = Business Expense, AR = Additional Rider Benefit, SB = Severity Based] US [LO = Life Only, DI = Disability, HE = Health, LC = Long Term Care, UM = Umbrella, PC = Property & Casualty]',
  `general_insurance_type` enum('H','V','L','P','A','O') DEFAULT NULL COMMENT 'H = Home & Contents, V = Vehicle, L = Landlord, P = Private Health, A = Asset, O = Other',
  `insurer` varchar(100) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `excess` decimal(12,2) DEFAULT NULL,
  `cash_value` decimal(12,2) DEFAULT NULL,
  `cover` decimal(15,2) DEFAULT NULL,
  `inside_super` tinyint(1) DEFAULT NULL,
  `cover_bps` decimal(5,4) DEFAULT NULL,
  `ip_cover_type` enum('A','I') DEFAULT NULL COMMENT 'A = Agreed Value (Guaranteed), I = Indemnity',
  `ar_sub_type` enum('AC','CC','CO','DE','ED','FC','FB','FU','FD','FI','FL','GI','NC','OT','WP') DEFAULT NULL COMMENT 'AC = Accident Cover, CC = Child Cover, CO = Conversion Option, DE = Debility, ED = Education, FC = Family Cover, FB = Funeral Benefit, FC = Future Cover, FD = Future Cover Disability, FI = Future Cover Impairment, FL = Future Cover Life, GI = Guaranteed Insurability, NC = Needlestick Cover, OT = Other, WP = Waiver of Premium',
  `premium` decimal(15,2) DEFAULT NULL,
  `frequency` enum('D','O','W','F','T','M','I','L','E','B','Q','S','A') DEFAULT NULL COMMENT 'D = Daily, O = One time, W = Weekly, F = Fortnightly, T = Twice a Month, M = Monthly, I = FIRST_DAY_MONTHLY, L = LAST_DAY_MONTHLY, E = EVERY_4_WEEKS, B = Every 2 months, Q = Quarterly, S = Semi-Annually, A= Annually',
  `policy_number` varchar(50) DEFAULT NULL,
  `policy_status` enum('A','I','O') DEFAULT NULL COMMENT 'A = Active, I = Inactive, O = Other',
  `policy_to_date` date DEFAULT NULL,
  `premium_increase_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `payout_period` enum('LS','1Y','2Y','5Y','PE') DEFAULT NULL COMMENT 'LS = Lump Sum, 1Y = 1 year, 2Y = 2 years, 5Y = 5 years, PE = Until policy end date',
  `payout_period_end` date DEFAULT NULL,
  `payout_wait_period` int DEFAULT NULL COMMENT '0 - None, 30 = 30 days, 60 = 60 days, 90 = 90 days, 365 = 1 year, 730 = 2 years',
  `end_year` int DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2000) DEFAULT NULL,
  `partner_notes` varchar(2000) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `display_ownership` int DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `external_load_id` varchar(50) DEFAULT NULL,
  `soft_deleted` tinyint(1) DEFAULT '0',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`insurance_id`),
  KEY `fk_Insurance_1_idx` (`household_id`),
  KEY `fk_Insurance_2_idx` (`client_id`),
  KEY `fk_Insurance_3_idx` (`asset_id`),
  KEY `legal_entity_id` (`legal_entity_id`),
  KEY `ix_Insurance_external_id` (`external_id`,`external_system`),
  CONSTRAINT `fk_Insurance_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Insurance_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Insurance_3` FOREIGN KEY (`asset_id`) REFERENCES `Asset` (`asset_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Insurance_ibfk_1` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=35984 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `InsuranceCoverage`
--

DROP TABLE IF EXISTS `InsuranceCoverage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InsuranceCoverage` (
  `insurance_coverage_id` int NOT NULL AUTO_INCREMENT,
  `insurance_id` int NOT NULL,
  `life_insurance_type` enum('LT','LO','TO','IP','TC','BE','AR','SB','DI','HE','LC','UM','PC','OI') DEFAULT NULL COMMENT 'AU [LT = Life/TPD, LO = Life Only, TO = TPD Only, IP = Income Protection, TC = Trauma/Critical Illness, BE = Business Expense, AR = Additional Rider Benefit, SB = Severity Based] US [LO = Life Only, DI = Disability, HE = Health, LC = Long Term Care, UM = Umbrella, PC = Property & Casualty, OI = Other Insurance]',
  `general_insurance_type` enum('H','V','L','P','A','O') DEFAULT NULL COMMENT 'H = Home & Contents, V = Vehicle, L = Landlord, P = Private Health, A = Asset, O = Other',
  `life_insurance_sub_type` enum('TL','WL','UL','VL','VUL') DEFAULT NULL COMMENT 'TL = Term Life, WL = Whole Life, UL = Universal Life, VL = Variable Life, VUL = Variable Universal Life',
  `disability_sub_type` enum('P','EP') DEFAULT NULL COMMENT 'P = Private, EP = Employee Provided',
  `long_term_care_sub_type` enum('T','LTC','H') DEFAULT NULL COMMENT 'T = Traditional, LTC = Life Insurance with LTC, H = Hybrid',
  `other_insurance_sub_type` enum('P','ES') DEFAULT NULL COMMENT 'P = Private, EP = Employee Sponsored',
  `cover` decimal(15,2) DEFAULT NULL,
  `cover_bps` decimal(5,4) DEFAULT NULL,
  `cover_per_annum` decimal(15,2) DEFAULT NULL,
  `ip_cover_type` enum('A','I') DEFAULT NULL COMMENT 'A = Agreed Value (Guaranteed), I = Indemnity',
  `ar_sub_type` enum('AC','CC','CO','DE','ED','FC','FB','FU','FD','FI','FL','GI','NC','OT','WP') DEFAULT NULL COMMENT 'AC = Accident Cover, CC = Child Cover, CO = Conversion Option, DE = Debility, ED = Education, FC = Family Cover, FB = Funeral Benefit, FC = Future Cover, FD = Future Cover Disability, FI = Future Cover Impairment, FL = Future Cover Life, GI = Guaranteed Insurability, NC = Needlestick Cover, OT = Other, WP = Waiver of Premium',
  `payout_period` enum('LS','1Y','2Y','5Y','PE','65') DEFAULT NULL COMMENT 'LS = Lump Sum, 1Y = 1 year, 2Y = 2 years, 5Y = 5 years, PE = Until policy end date, 65 = Until age 65 ',
  `payout_period_end` date DEFAULT NULL,
  `payout_wait_period` int DEFAULT NULL COMMENT '0 - None, 30 = 30 days, 60 = 60 days, 90 = 90 days, 365 = 1 year, 730 = 2 years',
  `inside_super` tinyint(1) DEFAULT NULL,
  `end_year` int DEFAULT NULL,
  `death_benefit` decimal(15,2) DEFAULT NULL,
  `beneficiary_relation` varchar(255) DEFAULT NULL,
  `chronic_care_rider` tinyint(1) DEFAULT NULL,
  `other_beneficiary` varchar(255) DEFAULT NULL,
  `long_or_short` enum('L','S') DEFAULT NULL COMMENT 'L = Long, S = Short',
  `monthly_benefit_amount` decimal(15,2) DEFAULT NULL,
  `total_benefits` decimal(15,2) DEFAULT NULL,
  `payout_type` enum('AE','I') DEFAULT NULL COMMENT 'AE = Actual Expenses, I = Indemnity',
  `payout_period_text` varchar(255) DEFAULT NULL,
  `elimination_period` int DEFAULT NULL,
  `healthcare_source` enum('ES','E') DEFAULT NULL COMMENT 'ES = Employer Sponsored, E = Exchange',
  `premium_tax_credit` tinyint(1) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`insurance_coverage_id`),
  KEY `insurance_id` (`insurance_id`),
  CONSTRAINT `InsuranceCoverage_ibfk_1` FOREIGN KEY (`insurance_id`) REFERENCES `Insurance` (`insurance_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=30233 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `InsuranceYodleeMapping`
--

DROP TABLE IF EXISTS `InsuranceYodleeMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InsuranceYodleeMapping` (
  `insurance_yodlee_mapping_id` int NOT NULL AUTO_INCREMENT,
  `insurance_id` int NOT NULL,
  `provider_account_id` varchar(32) DEFAULT NULL,
  `additional_status` varchar(100) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`insurance_yodlee_mapping_id`),
  KEY `fk_InsuranceYodleeMapping_idx` (`insurance_id`),
  CONSTRAINT `fk_InsuranceYodleeMapping` FOREIGN KEY (`insurance_id`) REFERENCES `Insurance` (`insurance_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `InvestmentPreferences`
--

DROP TABLE IF EXISTS `InvestmentPreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InvestmentPreferences` (
  `investment_preferences_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `intro_video` varchar(255) DEFAULT NULL,
  `customisation_video` varchar(255) DEFAULT NULL,
  `customisation` enum('Y','N','NP','U') DEFAULT NULL,
  `ethical_video` varchar(255) DEFAULT NULL,
  `ethical` enum('Y','N','NP','U') DEFAULT NULL,
  `asset_class_video` varchar(255) DEFAULT NULL,
  `allocation_video` varchar(255) DEFAULT NULL,
  `allocation_type` enum('S','D','NP','U') DEFAULT NULL,
  `risk_video` varchar(255) DEFAULT NULL,
  `comfortable_with_downturn` varchar(255) DEFAULT NULL,
  `cost_video` varchar(255) DEFAULT NULL,
  `cost_driven` enum('Y','N') DEFAULT NULL,
  `comments` mediumtext,
  `customisation_video_help` tinyint(1) DEFAULT '1',
  `customisation_video_comments` mediumtext,
  `ethical_video_help` tinyint(1) DEFAULT '1',
  `ethical_video_comments` mediumtext,
  `asset_class_video_help` tinyint(1) DEFAULT '1',
  `asset_class_video_comments` mediumtext,
  `allocation_video_help` tinyint(1) DEFAULT '1',
  `allocation_video_comments` mediumtext,
  `risk_video_help` tinyint(1) DEFAULT '1',
  `risk_video_comments` mediumtext,
  `risk_diversification` int DEFAULT NULL,
  `risk_market_correction` int DEFAULT NULL,
  `risk_percentage_drop` int DEFAULT NULL,
  `risk_capital_protection` tinyint(1) DEFAULT '1',
  `risk_access_capital` int DEFAULT NULL,
  `risk_influenced_by_returns` int DEFAULT NULL,
  `risk_increase_to_meet_goal` int DEFAULT NULL,
  `risk_max_downside` int DEFAULT NULL,
  `risk_inflation` int DEFAULT NULL,
  `cost_video_help` tinyint(1) DEFAULT '1',
  `cost_video_comments` mediumtext,
  `asset_class_and_diversification_video_help` enum('Y','N','U') DEFAULT NULL,
  `asset_class_preferences` tinyint(1) DEFAULT '1',
  `asset_class_preferences_comments` varchar(1023) DEFAULT NULL,
  `asset_class_risk` tinyint(1) DEFAULT '1',
  `asset_class_risk_comments` varchar(1023) DEFAULT NULL,
  `ethical_preferences` tinyint(1) DEFAULT '1',
  `ethical_preferences_comments` varchar(1023) DEFAULT NULL,
  `active_passive_video_help` enum('Y','N','U') DEFAULT NULL,
  `cost_wealth_priorities` enum('A','B','C','D') DEFAULT NULL,
  `risk_timelines` enum('Y','N','U') DEFAULT NULL,
  `risk_experience` int DEFAULT NULL,
  `risk_knowledge` int DEFAULT NULL,
  `risk_past` int DEFAULT NULL,
  `risk_current` int DEFAULT NULL,
  `risk_timeframe` int DEFAULT NULL,
  `risk_variability` int DEFAULT NULL,
  `risk_volatility` int DEFAULT NULL,
  `risk_reaction` int DEFAULT NULL,
  `risk_tolerance` int DEFAULT NULL,
  `risk_future` int DEFAULT NULL,
  `risk_volatility_video_help` enum('Y','N','U') DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` varchar(50) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  PRIMARY KEY (`investment_preferences_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `InvestmentPreferences_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3725 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `InvestmentPreferencesRanking`
--

DROP TABLE IF EXISTS `InvestmentPreferencesRanking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InvestmentPreferencesRanking` (
  `investment_preferences_ranking_id` int NOT NULL AUTO_INCREMENT,
  `investment_preferences_id` int NOT NULL,
  `option_id` int NOT NULL,
  `rank` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`investment_preferences_ranking_id`),
  KEY `ix_InvestmentPreferencesRanking_investment_preferences_id` (`investment_preferences_id`),
  CONSTRAINT `InvestmentPreferencesRanking_ibfk_1` FOREIGN KEY (`investment_preferences_id`) REFERENCES `InvestmentPreferences` (`investment_preferences_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=15377 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LegalEntity`
--

DROP TABLE IF EXISTS `LegalEntity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LegalEntity` (
  `legal_entity_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `legal_entity_type` enum('C','S','T','E') NOT NULL COMMENT 'C = Company, S = SMSF, T = Trust, E = External Entity',
  `company_type` enum('T','N','I','O') DEFAULT NULL COMMENT 'T = Trading, N = Non-Trading, I = Investment, O = Other',
  `trustee_type` enum('I','C') DEFAULT NULL COMMENT 'I = Individual, C = Corporate',
  `trust_type` enum('D','U','H','C','T','S','F','E','O') DEFAULT NULL COMMENT 'Discretionary, Unit, Hybrid, Charitable, Testamentary, Special, Family, Estate, Other',
  `name` varchar(255) NOT NULL,
  `purpose` varchar(1000) DEFAULT NULL,
  `abn` varchar(13) DEFAULT NULL,
  `tfn` varchar(9) DEFAULT NULL COMMENT 'Tax File Number',
  `value` decimal(15,2) DEFAULT NULL,
  `growth_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `growth_dollar` decimal(15,2) DEFAULT NULL,
  `client_share` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `partner_share` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `client_super_phase` enum('A','T','P') DEFAULT NULL COMMENT 'A = Accumulation, T = Non-Commutable Account Based Pension (TTR), P = Account Based Pension',
  `partner_super_phase` enum('A','T','P') DEFAULT NULL COMMENT 'A = Accumulation, T = Non-Commutable Account Based Pension (TTR), P = Account Based Pension',
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2000) DEFAULT NULL,
  `partner_notes` varchar(2000) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`legal_entity_id`),
  KEY `fk_LegalEntity_1_idx` (`household_id`),
  CONSTRAINT `fk_LegalEntity_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1456 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Liability`
--

DROP TABLE IF EXISTS `Liability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Liability` (
  `liability_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `client_id_pa` int DEFAULT NULL,
  `client_id_approval_status` varchar(50) DEFAULT NULL,
  `client_id_pa_date` date DEFAULT NULL,
  `legal_entity_id` int DEFAULT NULL,
  `legal_entity_id_pa` int DEFAULT NULL,
  `legal_entity_id_approval_status` varchar(50) DEFAULT NULL,
  `legal_entity_id_pa_date` date DEFAULT NULL,
  `asset_id` int DEFAULT NULL,
  `liability_type` enum('C','L','T','O') NOT NULL COMMENT 'C = Credit Card, L = Loan, T = Tax Liability, O = Other',
  `loan_type` enum('H','I','V','E','M','A','P','O','T') DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `provider_name` varchar(100) DEFAULT NULL,
  `lender` varchar(100) DEFAULT NULL,
  `max_limit` decimal(15,2) DEFAULT NULL,
  `original_amount` decimal(12,2) DEFAULT NULL,
  `owing` decimal(15,2) DEFAULT NULL,
  `owing_pa` decimal(15,2) DEFAULT NULL,
  `owing_approval_status` varchar(50) DEFAULT NULL,
  `owing_pa_date` date DEFAULT NULL,
  `rate` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `rate_pa` decimal(5,4) DEFAULT NULL,
  `rate_approval_status` varchar(50) DEFAULT NULL,
  `rate_pa_date` date DEFAULT NULL,
  `interest_rate_type` enum('U','O','F','V') DEFAULT 'U' COMMENT 'U = Unknown, O = Other, F = Fixed, V = Variable',
  `repayment` decimal(15,2) DEFAULT NULL,
  `repayment_pa` decimal(15,2) DEFAULT NULL,
  `repayment_approval_status` varchar(50) DEFAULT NULL,
  `repayment_pa_date` date DEFAULT NULL,
  `repayment_frequency` enum('D','O','W','F','T','M','I','L','E','B','Q','S','A') DEFAULT NULL COMMENT 'D = Daily, O = One time, W = Weekly, F = Fortnightly, T = Twice a Month, M = Monthly, I = FIRST_DAY_MONTHLY, L = LAST_DAY_MONTHLY, E = EVERY_4_WEEKS, B = Every 2 months, Q = Quarterly, S = Semi-Annually, A= Annually',
  `repayment_frequency_pa` enum('D','O','W','F','T','M','I','L','E','B','Q','S','A') DEFAULT NULL,
  `repayment_frequency_approval_status` varchar(50) DEFAULT NULL,
  `repayment_frequency_pa_date` date DEFAULT NULL,
  `monthly_payment` decimal(15,2) DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `display_ownership` int DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `external_load_id` varchar(50) DEFAULT NULL,
  `soft_deleted` tinyint(1) DEFAULT '0',
  `for_approval` tinyint(1) DEFAULT NULL,
  `approval_status` varchar(255) DEFAULT NULL,
  `approval_change_date` date DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`liability_id`),
  KEY `fk_Liability_1_idx` (`household_id`),
  KEY `fk_Liability_2_idx` (`client_id`),
  KEY `fk_Liability_3_idx` (`asset_id`),
  KEY `legal_entity_id` (`legal_entity_id`),
  KEY `ix_Liability_external_id` (`external_id`,`external_system`),
  CONSTRAINT `fk_Liability_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Liability_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Liability_3` FOREIGN KEY (`asset_id`) REFERENCES `Asset` (`asset_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Liability_ibfk_1` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3519 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LiabilityYodleeMapping`
--

DROP TABLE IF EXISTS `LiabilityYodleeMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LiabilityYodleeMapping` (
  `liability_yodlee_mapping_id` int NOT NULL AUTO_INCREMENT,
  `liability_id` int NOT NULL,
  `provider_account_id` varchar(32) DEFAULT NULL,
  `additional_status` varchar(100) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`liability_yodlee_mapping_id`),
  KEY `fk_LiabilityYodleeMapping_idx` (`liability_id`),
  CONSTRAINT `fk_LiabilityYodleeMapping` FOREIGN KEY (`liability_id`) REFERENCES `Liability` (`liability_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=511 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Life`
--

DROP TABLE IF EXISTS `Life`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Life` (
  `life_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `status` enum('O','C') NOT NULL,
  `overall_score` decimal(7,4) DEFAULT NULL,
  `emotional_score` decimal(7,4) DEFAULT NULL,
  `environmental_score` decimal(7,4) DEFAULT NULL,
  `spiritual_score` decimal(7,4) DEFAULT NULL,
  `social_score` decimal(7,4) DEFAULT NULL,
  `education_score` decimal(7,4) DEFAULT NULL,
  `occupational_score` decimal(7,4) DEFAULT NULL,
  `physical_score` decimal(7,4) DEFAULT NULL,
  `financial_score` decimal(7,4) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` varchar(50) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  PRIMARY KEY (`life_id`),
  KEY `fk_Life_1_idx` (`client_id`),
  KEY `ix_Life_client_id` (`client_id`,`updated`),
  CONSTRAINT `fk_Life_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5055 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LifeConnection`
--

DROP TABLE IF EXISTS `LifeConnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LifeConnection` (
  `life_connection_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `type` enum('L','C','G') NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`life_connection_id`),
  KEY `fk_LifeConnection_1_idx` (`client_id`),
  CONSTRAINT `fk_LifeConnection_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=24528 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LifeGoal`
--

DROP TABLE IF EXISTS `LifeGoal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LifeGoal` (
  `life_goal_id` int NOT NULL AUTO_INCREMENT,
  `goal_id` int NOT NULL,
  `client_id` int NOT NULL,
  `value_group_id` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`life_goal_id`),
  KEY `ix_LifeGoal_client_id` (`client_id`),
  KEY `ix_LifeGoal_goal_id` (`goal_id`),
  CONSTRAINT `LifeGoal_ibfk_1` FOREIGN KEY (`goal_id`) REFERENCES `Goal` (`goal_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `LifeGoal_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=29403 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LifeNote`
--

DROP TABLE IF EXISTS `LifeNote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LifeNote` (
  `life_note_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `value_group_id` int DEFAULT NULL,
  `note` varchar(5000) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`life_note_id`),
  KEY `fk_LifeNote_1_idx` (`household_id`),
  CONSTRAINT `fk_LifeNote_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LifeQuestionnaire`
--

DROP TABLE IF EXISTS `LifeQuestionnaire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LifeQuestionnaire` (
  `life_questionnaire_id` int NOT NULL AUTO_INCREMENT,
  `life_id` int NOT NULL,
  `question_id` int NOT NULL,
  `string_response` varchar(5000) DEFAULT NULL,
  `int_response` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`life_questionnaire_id`),
  KEY `fk_LifeQuestionnaire_1_idx` (`life_id`),
  CONSTRAINT `fk_LifeQuestionnaire_1` FOREIGN KEY (`life_id`) REFERENCES `Life` (`life_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=153246 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LivingDiscretionaryExpense`
--

DROP TABLE IF EXISTS `LivingDiscretionaryExpense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LivingDiscretionaryExpense` (
  `living_discretionary_expense_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `alimony` decimal(15,2) DEFAULT NULL,
  `rates` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `water` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `gardening` decimal(15,2) DEFAULT NULL,
  `home_improvement` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `repairs` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `electricity` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `gas` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `groceries` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `home_phone` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `cable` decimal(15,2) DEFAULT NULL,
  `broadband` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `mobile` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `cleaning` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `personal_care` decimal(15,2) DEFAULT NULL,
  `pet_care` decimal(15,2) DEFAULT NULL,
  `appliances` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `home_other` decimal(15,2) DEFAULT NULL,
  `clothing` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `footwear` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `healthcare` decimal(15,2) DEFAULT NULL,
  `dental` decimal(15,2) DEFAULT NULL,
  `healthcare_other` decimal(15,2) DEFAULT NULL,
  `car_transport` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `public_transport` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `child_maintenance` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `child_care` decimal(15,2) DEFAULT NULL,
  `child` decimal(15,2) DEFAULT NULL,
  `care` decimal(15,2) DEFAULT NULL,
  `education` decimal(15,2) DEFAULT NULL,
  `rent` decimal(15,2) DEFAULT NULL,
  `association_fees` decimal(15,2) DEFAULT NULL,
  `living_other` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `memberships` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `streaming` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `alcohol` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `take_away` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `gifts` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `donations` decimal(15,2) DEFAULT NULL,
  `tobacco` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `entertainment` decimal(15,2) DEFAULT NULL,
  `hobbies` decimal(15,2) DEFAULT NULL,
  `vacations` decimal(15,2) DEFAULT NULL,
  `discretionary_other` decimal(15,2) DEFAULT NULL COMMENT 'This is stored as a weekly amount and converted to other frequencies on the frontend',
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`living_discretionary_expense_id`),
  KEY `fk_LivingDiscretionaryExpense_1_idx` (`household_id`),
  CONSTRAINT `fk_LivingDiscretionaryExpense_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=669 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ModuleState`
--

DROP TABLE IF EXISTS `ModuleState`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ModuleState` (
  `module_state_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `previously_completed` tinyint(1) NOT NULL,
  `module` varchar(255) NOT NULL,
  `module_state` varchar(255) NOT NULL,
  `sent_date` date DEFAULT NULL,
  `sent_reminders` int NOT NULL DEFAULT '0',
  `started_date` date DEFAULT NULL,
  `started_reminders` int NOT NULL DEFAULT '0',
  `finished_date` date DEFAULT NULL,
  `expired_date` date DEFAULT NULL,
  `number_of_staff_vault_uploads` int DEFAULT NULL,
  `number_of_client_vault_uploads` int DEFAULT NULL,
  `number_of_staff_vault_file_moves` int DEFAULT NULL,
  `number_of_client_vault_file_moves` int DEFAULT NULL,
  `number_of_staff_vault_file_renames` int DEFAULT NULL,
  `number_of_client_vault_file_renames` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`module_state_id`),
  KEY `ix_ModuleState_client_id` (`client_id`),
  CONSTRAINT `ModuleState_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=54472 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MoneyGuideProData`
--

DROP TABLE IF EXISTS `MoneyGuideProData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MoneyGuideProData` (
  `money_guide_pro_data_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `target_low` decimal(15,2) DEFAULT NULL,
  `target_high` decimal(15,2) DEFAULT NULL,
  `number_of_trials` decimal(15,2) DEFAULT NULL,
  `number_of_successful_trials` decimal(15,2) DEFAULT NULL,
  `probability_of_success` decimal(15,2) DEFAULT NULL,
  `probability_of_success_formatted` varchar(50) DEFAULT NULL,
  `confidence_zone_result` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `household_id` int NOT NULL,
  `practice_id` int NOT NULL,
  PRIMARY KEY (`money_guide_pro_data_id`),
  KEY `fk_MoneyGuideProData_idx` (`client_id`),
  CONSTRAINT `money_guide_pro_data_client` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `NetWorthTimeline`
--

DROP TABLE IF EXISTS `NetWorthTimeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NetWorthTimeline` (
  `net_worth_timeline_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `entity_id` int NOT NULL,
  `entity_type` enum('A','L') NOT NULL COMMENT 'A = Asset, L = Liability',
  `entity_value` decimal(20,8) DEFAULT NULL,
  `snapshot_date` date NOT NULL,
  PRIMARY KEY (`net_worth_timeline_id`),
  UNIQUE KEY `idx_unique_networthtimeline` (`household_id`,`entity_id`,`entity_type`,`snapshot_date`),
  KEY `ix_NetWorthTimeline_household_entity_type` (`household_id`,`entity_type`)
) ENGINE=InnoDB AUTO_INCREMENT=6612618 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Portfolio`
--

DROP TABLE IF EXISTS `Portfolio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Portfolio` (
  `portfolio_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `legal_entity_id` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` enum('I','S') DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `risk_score` decimal(15,2) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `external_load_id` varchar(50) DEFAULT NULL,
  `soft_deleted` tinyint(1) DEFAULT '0',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`portfolio_id`),
  UNIQUE KEY `ix_Portfolio_external_id_system` (`client_id`,`external_id`,`external_system`),
  KEY `fk_Portfolio_1` (`household_id`),
  KEY `fk_Portfolio_2` (`client_id`),
  KEY `fk_Portfolio_3` (`legal_entity_id`),
  KEY `ix_Portfolio_external_id` (`external_id`,`external_system`),
  CONSTRAINT `fk_Portfolio_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Portfolio_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_Portfolio_3` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2660 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PortfolioPerformance`
--

DROP TABLE IF EXISTS `PortfolioPerformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PortfolioPerformance` (
  `portfolio_performance_id` int NOT NULL AUTO_INCREMENT,
  `portfolio_id` int NOT NULL,
  `begin_market_val_mtd` decimal(20,8) DEFAULT NULL,
  `begin_market_val_ytd` decimal(20,8) DEFAULT NULL,
  `begin_market_val_1y` decimal(20,8) DEFAULT NULL,
  `begin_market_val_3y` decimal(20,8) DEFAULT NULL,
  `begin_market_val_5y` decimal(20,8) DEFAULT NULL,
  `begin_market_val_incept` decimal(20,8) DEFAULT NULL,
  `net_contrib_withdraw_mtd` decimal(20,8) DEFAULT NULL,
  `net_contrib_withdraw_ytd` decimal(20,8) DEFAULT NULL,
  `net_contrib_withdraw_1y` decimal(20,8) DEFAULT NULL,
  `net_contrib_withdraw_3y` decimal(20,8) DEFAULT NULL,
  `net_contrib_withdraw_5y` decimal(20,8) DEFAULT NULL,
  `net_contrib_withdraw_incept` decimal(20,8) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`portfolio_performance_id`),
  KEY `fk_Holding_1` (`portfolio_id`),
  KEY `ix_PortfolioPerformance_external_id` (`external_id`,`external_system`),
  CONSTRAINT `fk_PortfolioPerformance_1` FOREIGN KEY (`portfolio_id`) REFERENCES `Portfolio` (`portfolio_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PowerOf`
--

DROP TABLE IF EXISTS `PowerOf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PowerOf` (
  `power_of_id` int NOT NULL AUTO_INCREMENT,
  `estate_planning_id` int NOT NULL,
  `power_of_type` enum('A','G') NOT NULL COMMENT 'A = Power of Attorney, G = Power of Guardianship',
  `poa_type_enduring` tinyint(1) DEFAULT NULL,
  `poa_type_medical` tinyint(1) DEFAULT NULL,
  `poa_type_limited` tinyint(1) DEFAULT NULL,
  `poa_type_care` tinyint(1) DEFAULT NULL,
  `poa_type_other` tinyint(1) DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `is_alternate` tinyint(1) DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`power_of_id`),
  KEY `fk_PowerOf_1_idx` (`estate_planning_id`),
  CONSTRAINT `fk_PowerOf_1` FOREIGN KEY (`estate_planning_id`) REFERENCES `EstatePlanning` (`estate_planning_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1604 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Practice`
--

DROP TABLE IF EXISTS `Practice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Practice` (
  `practice_id` int NOT NULL AUTO_INCREMENT,
  `practice_code` binary(16) DEFAULT NULL,
  `dealer_group_id` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `abn` varchar(13) DEFAULT NULL,
  `afsl` varchar(10) DEFAULT NULL,
  `afsl_name` varchar(255) DEFAULT NULL,
  `legal_name` varchar(255) DEFAULT NULL,
  `status` enum('I','S','L','X','Q','R','A','T','C','O') NOT NULL,
  `original_status` enum('I','S','L','X','Q','R','A','T','C','O') NOT NULL DEFAULT 'O',
  `contract_start` date DEFAULT NULL,
  `contract_period` int DEFAULT NULL COMMENT 'Length of the contract. NULL if this is a PAYG package.',
  `ilgn` varchar(7) DEFAULT NULL,
  `practice_config_id` int DEFAULT NULL,
  `home_region` varchar(20) DEFAULT NULL,
  `home_locale` varchar(5) DEFAULT 'en-AU',
  `practice_billing_id` int DEFAULT NULL,
  `practice_package_id` int NOT NULL DEFAULT '1' COMMENT 'Package assigned to the practice',
  `package_discount` decimal(5,4) NOT NULL DEFAULT '0.0000' COMMENT 'Discount to apply to the practice and household packages.',
  `whitelabel_enabled` tinyint(1) DEFAULT '0',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `t_c_version` varchar(20) NOT NULL,
  `external_domain` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`practice_id`),
  KEY `practice_abn_id_index` (`abn`),
  KEY `practice_config_id` (`practice_config_id`),
  KEY `practice_package_id` (`practice_package_id`),
  KEY `dealer_group_id` (`dealer_group_id`),
  KEY `ix_Practice_abn` (`abn`),
  KEY `ix_Practice_afsl` (`afsl`),
  KEY `practice_billing_id` (`practice_billing_id`),
  CONSTRAINT `Practice_ibfk_1` FOREIGN KEY (`practice_config_id`) REFERENCES `PracticeConfig` (`practice_config_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Practice_ibfk_2` FOREIGN KEY (`practice_package_id`) REFERENCES `PracticePackage` (`practice_package_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Practice_ibfk_3` FOREIGN KEY (`dealer_group_id`) REFERENCES `DealerGroup` (`dealer_group_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Practice_ibfk_4` FOREIGN KEY (`practice_billing_id`) REFERENCES `PracticeBilling` (`practice_billing_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=648 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticeAssetAllocation`
--

DROP TABLE IF EXISTS `PracticeAssetAllocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticeAssetAllocation` (
  `practice_aa_id` int NOT NULL AUTO_INCREMENT,
  `practice_id` int NOT NULL,
  `risk_group` int NOT NULL,
  `asset_tree_id` int NOT NULL,
  `uses_styles` tinyint(1) NOT NULL DEFAULT '0',
  `saa_min` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `saa` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `saa_max` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `taa_min` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `taa` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `taa_max` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `style_top_left` decimal(5,4) DEFAULT NULL,
  `style_top_center` decimal(5,4) DEFAULT NULL,
  `style_top_right` decimal(5,4) DEFAULT NULL,
  `style_middle_left` decimal(5,4) DEFAULT NULL,
  `style_middle_center` decimal(5,4) DEFAULT NULL,
  `style_middle_right` decimal(5,4) DEFAULT NULL,
  `style_bottom_left` decimal(5,4) DEFAULT NULL,
  `style_bottom_center` decimal(5,4) DEFAULT NULL,
  `style_bottom_right` decimal(5,4) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`practice_aa_id`),
  UNIQUE KEY `ix_PracticeAssetAllocation_practice` (`practice_id`,`risk_group`,`asset_tree_id`),
  KEY `fk_PracticeAssetAllocation_idx` (`practice_id`),
  KEY `ix_PracticeAssetAllocation_external_id` (`external_id`,`external_system`),
  CONSTRAINT `practice_aa_practice` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=6064 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticeBilling`
--

DROP TABLE IF EXISTS `PracticeBilling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticeBilling` (
  `practice_billing_id` int NOT NULL AUTO_INCREMENT,
  `stripe_customer_id` varchar(40) DEFAULT NULL,
  `full_name` varchar(400) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `billing_address_id` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`practice_billing_id`),
  UNIQUE KEY `uc_stripe_customer_id` (`stripe_customer_id`),
  KEY `billing_address_id` (`billing_address_id`),
  CONSTRAINT `PracticeBilling_ibfk_1` FOREIGN KEY (`billing_address_id`) REFERENCES `Address` (`address_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=220 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticeConfig`
--

DROP TABLE IF EXISTS `PracticeConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticeConfig` (
  `practice_config_id` int NOT NULL AUTO_INCREMENT,
  `palette` json DEFAULT NULL,
  `typography` json DEFAULT NULL,
  `configuration` json DEFAULT NULL,
  `theme` json DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`practice_config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=601 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticeHouseholdPackage`
--

DROP TABLE IF EXISTS `PracticeHouseholdPackage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticeHouseholdPackage` (
  `practice_household_package_id` int NOT NULL AUTO_INCREMENT,
  `practice_package_id` int NOT NULL,
  `household_package_id` int NOT NULL,
  `default_hh_package` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`practice_household_package_id`),
  KEY `fk_PracticeHouseholdPackage_1_idx` (`practice_package_id`),
  KEY `fk_PracticeHouseholdPackage_2_idx` (`household_package_id`),
  CONSTRAINT `fk_PracticeHouseholdPackage_1` FOREIGN KEY (`practice_package_id`) REFERENCES `PracticePackage` (`practice_package_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_PracticeHouseholdPackage_2` FOREIGN KEY (`household_package_id`) REFERENCES `HouseholdPackage` (`household_package_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticeIntegration`
--

DROP TABLE IF EXISTS `PracticeIntegration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticeIntegration` (
  `practice_integration_id` int NOT NULL AUTO_INCREMENT,
  `practice_id` int NOT NULL,
  `integration_type` enum('IL','CD','MG','RT','RA','SF','TM','BX','XP','PR') NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(15000) DEFAULT NULL,
  `integration_details` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `secrets_manager_secret_name` varchar(512) NOT NULL,
  `last_synced` timestamp NULL DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`practice_integration_id`),
  KEY `fk_PracticeIntegration_idx` (`practice_id`),
  CONSTRAINT `practice_integration_practice` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticeLogo`
--

DROP TABLE IF EXISTS `PracticeLogo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticeLogo` (
  `practice_logo_id` int NOT NULL AUTO_INCREMENT,
  `practice_id` int NOT NULL,
  `type` enum('P','PI','R','RI','E','EI','S','SI') DEFAULT NULL,
  `s3_path` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`practice_logo_id`),
  KEY `fk_PracticeLogo_1_idx` (`practice_id`),
  CONSTRAINT `practice_logo_practice` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticeOffice`
--

DROP TABLE IF EXISTS `PracticeOffice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticeOffice` (
  `practice_office_id` int NOT NULL AUTO_INCREMENT,
  `practice_id` int NOT NULL,
  `address_id` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `contact_details_id` int DEFAULT NULL,
  PRIMARY KEY (`practice_office_id`),
  KEY `fk_PracticeOffice_1_idx` (`practice_id`),
  KEY `fk_PracticeOffice_2_idx` (`address_id`),
  KEY `contact_details_id` (`contact_details_id`),
  CONSTRAINT `fk_PracticeOffice_1` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_PracticeOffice_2` FOREIGN KEY (`address_id`) REFERENCES `Address` (`address_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `PracticeOffice_ibfk_1` FOREIGN KEY (`contact_details_id`) REFERENCES `ContactDetails` (`contact_details_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=736 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticePackage`
--

DROP TABLE IF EXISTS `PracticePackage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticePackage` (
  `practice_package_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL COMMENT 'Unique code to identify this practice package',
  `name` varchar(200) NOT NULL COMMENT 'Name of this practice package',
  `description` varchar(1500) NOT NULL COMMENT 'Description of this practice package',
  `uses_household_packages` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'True if access and fees should be based off household package (For PAYG). False if it does not use household packages.',
  `disabled_feature_flags` json NOT NULL COMMENT 'List of feature flags which should be disabled for a practice in this subscription package.',
  `enabled_feature_flags` json NOT NULL COMMENT 'List of feature flags which should be enabled for a practice in this subscription package.',
  `start_date` date DEFAULT NULL COMMENT 'Date from which this practice package is available - null = always',
  `end_date` date DEFAULT NULL COMMENT 'Date until this practice package is available - null = always',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`practice_package_id`),
  UNIQUE KEY `ix_PracticePackage_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticePackageComponent`
--

DROP TABLE IF EXISTS `PracticePackageComponent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticePackageComponent` (
  `practice_package_component_id` int NOT NULL AUTO_INCREMENT,
  `practice_package_id` int NOT NULL,
  `component_id` int NOT NULL,
  `price` decimal(12,4) DEFAULT NULL COMMENT 'Component price ex GST to be charged per payment period.',
  `num_included` int DEFAULT NULL COMMENT 'For quantity based components this stipulates how many have been included in the package and therefore do not get charged.',
  `treat_included_as_min` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'True if num_included should be treated like a minimum, False if it should be based on actual usage',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`practice_package_component_id`),
  KEY `fk_PracticePackageComponent_1_idx` (`practice_package_id`),
  KEY `fk_PracticePackageComponent_2_idx` (`component_id`),
  CONSTRAINT `fk_PracticePackageComponent_1` FOREIGN KEY (`practice_package_id`) REFERENCES `PracticePackage` (`practice_package_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_PracticePackageComponent_2` FOREIGN KEY (`component_id`) REFERENCES `Component` (`component_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticeRiskProfile`
--

DROP TABLE IF EXISTS `PracticeRiskProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticeRiskProfile` (
  `practice_risk_profile_id` int NOT NULL AUTO_INCREMENT,
  `practice_id` int NOT NULL,
  `risk_group` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(15000) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`practice_risk_profile_id`),
  KEY `fk_PracticeRiskProfile_idx` (`practice_id`),
  KEY `ix_PracticeRiskProfile_external_id` (`external_id`,`external_system`),
  CONSTRAINT `practice_risk_profile_practice` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=776 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticeSegmentation`
--

DROP TABLE IF EXISTS `PracticeSegmentation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticeSegmentation` (
  `practice_segmentation_id` int NOT NULL AUTO_INCREMENT,
  `practice_id` int NOT NULL,
  `segment_name` varchar(255) NOT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `rank` int DEFAULT '0',
  `configuration` json DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`practice_segmentation_id`),
  KEY `fk_PracticeSegmentation_1_idx` (`practice_id`),
  KEY `ix_PracticeSegmentation_external_id` (`external_id`,`external_system`),
  CONSTRAINT `fk_PracticeSegmentation_1` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticeStrategy`
--

DROP TABLE IF EXISTS `PracticeStrategy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticeStrategy` (
  `practice_strategy_id` int NOT NULL AUTO_INCREMENT,
  `practice_strategy_category_id` int NOT NULL,
  `strategy_name` varchar(1000) NOT NULL,
  `details` varchar(10000) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`practice_strategy_id`),
  KEY `fk_PracticeStrategy_1` (`practice_strategy_category_id`),
  KEY `ix_PracticeStrategy_external_id` (`external_id`,`external_system`),
  CONSTRAINT `fk_PracticeStrategy_1` FOREIGN KEY (`practice_strategy_category_id`) REFERENCES `PracticeStrategyCategory` (`practice_strategy_category_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PracticeStrategyCategory`
--

DROP TABLE IF EXISTS `PracticeStrategyCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PracticeStrategyCategory` (
  `practice_strategy_category_id` int NOT NULL AUTO_INCREMENT,
  `practice_id` int NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `rank` int DEFAULT '0',
  `mui_icon_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`practice_strategy_category_id`),
  KEY `fk_PracticeStrategyCategory_1_idx` (`practice_id`),
  KEY `ix_PracticeStrategyCategory_external_id` (`external_id`,`external_system`),
  CONSTRAINT `fk_PracticeStrategyCategory_1` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=8185 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ProfessionalContact`
--

DROP TABLE IF EXISTS `ProfessionalContact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProfessionalContact` (
  `professional_contact_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `contact_type` enum('S','A','I','B','M','D','O','K') NOT NULL COMMENT 'S = Solicitor, A = Accountant, I = Insurance Broker, B = Broker, M = Mortgage Broker, D = Doctor, O = Other, K = Banker',
  `contact_type_details` varchar(255) DEFAULT NULL COMMENT 'Details if Other',
  `name` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `authority_to_contact` tinyint(1) DEFAULT NULL,
  `relationship_quality` enum('E','G','P') DEFAULT NULL COMMENT 'E = Excellent, G = Good, P = Poor',
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2000) DEFAULT NULL,
  `partner_notes` varchar(2000) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`professional_contact_id`),
  KEY `fk_ProfessionalContact_1_idx` (`household_id`),
  CONSTRAINT `fk_ProfessionalContact_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=644 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ProviderSSOMapping`
--

DROP TABLE IF EXISTS `ProviderSSOMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProviderSSOMapping` (
  `provider_sso_mapping_id` int NOT NULL AUTO_INCREMENT,
  `provider_name` varchar(255) NOT NULL,
  `additional_lookup` varchar(1000) DEFAULT NULL,
  `practice_id` int NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`provider_sso_mapping_id`),
  KEY `fk_ProviderSSOMapping_1_idx` (`practice_id`),
  CONSTRAINT `fk_ProviderSSOMapping_1` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ProviderSSORoleMapping`
--

DROP TABLE IF EXISTS `ProviderSSORoleMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProviderSSORoleMapping` (
  `provider_sso_role_mapping_id` int NOT NULL AUTO_INCREMENT,
  `provider_sso_mapping_id` int NOT NULL,
  `provider_role` varchar(255) NOT NULL,
  `lumiant_group` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`provider_sso_role_mapping_id`),
  KEY `fk_ProviderSSORoleMapping_1_idx` (`provider_sso_mapping_id`),
  CONSTRAINT `fk_ProviderSSORoleMapping_1` FOREIGN KEY (`provider_sso_mapping_id`) REFERENCES `ProviderSSOMapping` (`provider_sso_mapping_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `QuickSurveys`
--

DROP TABLE IF EXISTS `QuickSurveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QuickSurveys` (
  `quick_surveys_id` int NOT NULL AUTO_INCREMENT,
  `practice_id` int NOT NULL,
  `quick_surveys_info` json DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`quick_surveys_id`),
  KEY `fk_QuickSurveys_1_idx` (`practice_id`),
  CONSTRAINT `fk_QuickSurveys_1_idx` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RetirementDetails`
--

DROP TABLE IF EXISTS `RetirementDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RetirementDetails` (
  `retirement_details_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `retirement_age` int DEFAULT NULL,
  `required_income` decimal(12,2) DEFAULT NULL,
  `retirement_lifestyle` enum('B','C','L') DEFAULT NULL COMMENT 'B = Basic, C = Comfortable, L = Luxury',
  `notes` varchar(5000) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`retirement_details_id`),
  KEY `fk_RetirementDetails_1_idx` (`client_id`),
  CONSTRAINT `fk_RetirementDetails_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2646 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RiskProfile`
--

DROP TABLE IF EXISTS `RiskProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RiskProfile` (
  `risk_profile_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `legal_entity_id` int DEFAULT NULL,
  `risk_profile_assessed` int DEFAULT NULL,
  `risk_profile_directed` int DEFAULT NULL,
  `risk_profile_directed_by` enum('E','C','P') DEFAULT NULL COMMENT 'E = Legal Entity, C = Client, P = Professional',
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`risk_profile_id`),
  KEY `fk_RiskProfile_1_idx` (`household_id`),
  KEY `fk_RiskProfile_2_idx` (`client_id`),
  KEY `legal_entity_id` (`legal_entity_id`),
  KEY `ix_RiskProfile_external_id` (`external_id`,`external_system`),
  CONSTRAINT `fk_RiskProfile_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_RiskProfile_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `RiskProfile_ibfk_1` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=6210 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RiskalyzeClientMapping`
--

DROP TABLE IF EXISTS `RiskalyzeClientMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RiskalyzeClientMapping` (
  `riskalyze_client_mapping_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `riskalyze_client_id` int NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`riskalyze_client_mapping_id`),
  KEY `fk_RiskalyzeClientMapping_idx` (`client_id`),
  CONSTRAINT `riskalyze_client_mapping_client` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RiskalyzePortfolioMapping`
--

DROP TABLE IF EXISTS `RiskalyzePortfolioMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RiskalyzePortfolioMapping` (
  `riskalyze_portfolio_mapping_id` int NOT NULL AUTO_INCREMENT,
  `portfolio_id` int NOT NULL,
  `riskalyze_portfolio_id` int NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `practice_id` int NOT NULL,
  PRIMARY KEY (`riskalyze_portfolio_mapping_id`),
  KEY `fk_RiskalyzePortfolioMapping_idx` (`portfolio_id`),
  KEY `riskalyze_portfolio_mapping_practice` (`practice_id`),
  CONSTRAINT `riskalyze_portfolio_mapping_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `Portfolio` (`portfolio_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `riskalyze_portfolio_mapping_practice` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RiskalyzeState`
--

DROP TABLE IF EXISTS `RiskalyzeState`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RiskalyzeState` (
  `riskalyze_state_id` int NOT NULL AUTO_INCREMENT,
  `practice_id` int NOT NULL,
  `riskalyze_state` varchar(50) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`riskalyze_state_id`),
  KEY `fk_RiskalyzeState_idx` (`practice_id`),
  CONSTRAINT `riskalyze_state_practice` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SensitiveDetails`
--

DROP TABLE IF EXISTS `SensitiveDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SensitiveDetails` (
  `sensitive_details_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `is_pep` tinyint(1) DEFAULT NULL COMMENT 'Is Politically Exposed Person?',
  `is_vulnerable` tinyint(1) DEFAULT NULL COMMENT 'Is Vulnerable Person?',
  `notes` varchar(5000) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sensitive_details_id`),
  KEY `fk_SensitiveDetails_1_idx` (`client_id`),
  CONSTRAINT `fk_SensitiveDetails_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2257 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Staff`
--

DROP TABLE IF EXISTS `Staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Staff` (
  `staff_id` int NOT NULL AUTO_INCREMENT,
  `practice_office_id` int NOT NULL,
  `iam_id` binary(16) DEFAULT NULL,
  `auth0_id` varchar(255) DEFAULT NULL,
  `ilan` varchar(7) DEFAULT NULL,
  `title` varchar(10) DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `role` varchar(10) NOT NULL,
  `digital_signature_s3_path` varchar(255) DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `last_user_agent` varchar(300) DEFAULT NULL,
  `completed_academy` tinyint(1) DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `last_ip` varchar(39) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `contact_details_id` int NOT NULL,
  `removed_iam_id` binary(16) DEFAULT NULL,
  `iam_id_removed_by` varchar(50) DEFAULT NULL,
  `iam_id_removed_date` datetime DEFAULT NULL,
  PRIMARY KEY (`staff_id`),
  UNIQUE KEY `ix_Staff_iam_id` (`iam_id`),
  KEY `fk_Staff_1_idx` (`practice_office_id`),
  KEY `contact_details_id` (`contact_details_id`),
  KEY `ilan` (`ilan`),
  KEY `ix_Staff_external_id` (`external_id`,`external_system`),
  CONSTRAINT `practice_office` FOREIGN KEY (`practice_office_id`) REFERENCES `PracticeOffice` (`practice_office_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Staff_ibfk_1` FOREIGN KEY (`contact_details_id`) REFERENCES `ContactDetails` (`contact_details_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1301 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `StaffClient`
--

DROP TABLE IF EXISTS `StaffClient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `StaffClient` (
  `staff_client_id` int NOT NULL AUTO_INCREMENT,
  `staff_id` int NOT NULL,
  `client_id` int NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`staff_client_id`),
  KEY `fk_StaffClient_1_idx` (`staff_id`),
  KEY `fk_StaffClient_2_idx` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `StaffConfig`
--

DROP TABLE IF EXISTS `StaffConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `StaffConfig` (
  `staff_config_id` int NOT NULL AUTO_INCREMENT,
  `staff_id` int NOT NULL,
  `dashboard` json DEFAULT NULL,
  `configuration` json DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`staff_config_id`),
  KEY `fk_StaffConfig_1_idx` (`staff_id`),
  CONSTRAINT `fk_StaffConfig_1` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`staff_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=259 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `StaffSharingConfig`
--

DROP TABLE IF EXISTS `StaffSharingConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `StaffSharingConfig` (
  `staff_sharing_config_id` int NOT NULL AUTO_INCREMENT,
  `staff_id` int NOT NULL,
  `household_id` int NOT NULL,
  `shared_with_staff_id` int NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`staff_sharing_config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SuperBeneficiary`
--

DROP TABLE IF EXISTS `SuperBeneficiary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SuperBeneficiary` (
  `super_beneficiary_id` int NOT NULL AUTO_INCREMENT,
  `legal_entity_id` int DEFAULT NULL,
  `asset_id` int DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(200) DEFAULT NULL,
  `relation` enum('M','P','C','O') DEFAULT NULL COMMENT 'M = Member, P = Partner, C = Children, O = Other',
  `nominated` tinyint(1) NOT NULL,
  `beneficiary_type` enum('N','B','P','L','R') NOT NULL COMMENT 'N = Not specified, B = Non-binding, P = Non-lapsing, L = Lapsing, R = Reversionary',
  `ends` date DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `percent` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `estate` enum('D','P','R') DEFAULT NULL COMMENT 'D = Dollar Amount, R = Percentage Amount, R = Remaining Balance',
  `estate_amount` decimal(15,2) DEFAULT NULL,
  `estate_bps` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `external_id` varchar(20) DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`super_beneficiary_id`),
  KEY `fk_SuperBeneficiary_1_idx` (`legal_entity_id`),
  KEY `fk_SuperBeneficiary_2_idx` (`asset_id`),
  CONSTRAINT `fk_SuperBeneficiary_1` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_SuperBeneficiary_2` FOREIGN KEY (`asset_id`) REFERENCES `Asset` (`asset_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=767 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SurveysSession`
--

DROP TABLE IF EXISTS `SurveysSession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SurveysSession` (
  `surveys_session_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int NOT NULL,
  `invite_code` varchar(50) DEFAULT NULL,
  `session_name` varchar(50) DEFAULT NULL,
  `surveys_info` json DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`surveys_session_id`),
  KEY `fk_SurveysSession_1_idx` (`household_id`),
  KEY `fk_SurveysSession_2_idx` (`client_id`),
  CONSTRAINT `fk_SurveysSession_1_idx` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_SurveysSession_2_idx` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TamaracPracticeMapping`
--

DROP TABLE IF EXISTS `TamaracPracticeMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TamaracPracticeMapping` (
  `tamarac_mapping_id` int NOT NULL AUTO_INCREMENT,
  `tamarac_practice_name` varchar(255) NOT NULL,
  `practice_id` int NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tamarac_mapping_id`),
  KEY `fk_TamaracPracticeMapping_1_idx` (`practice_id`),
  CONSTRAINT `fk_TamaracPracticeMapping_1` FOREIGN KEY (`practice_id`) REFERENCES `Practice` (`practice_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Task`
--

DROP TABLE IF EXISTS `Task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Task` (
  `task_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `title` varchar(1500) NOT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `completed_date` date DEFAULT NULL,
  `source_of_truth` varchar(50) NOT NULL DEFAULT 'L',
  `status` varchar(50) NOT NULL,
  `is_internal` tinyint(1) NOT NULL DEFAULT '0',
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `external_system` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` varchar(50) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  PRIMARY KEY (`task_id`),
  KEY `ix_ClientTask_assigned_to_client_id` (`client_id`),
  KEY `ix_HouseholdTask_created_for_household_id` (`household_id`),
  KEY `ix_Task_external_id` (`external_id`,`external_system`),
  KEY `ix_Task_hh_client_deleted` (`household_id`,`client_id`,`deleted`),
  CONSTRAINT `Task_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Task_ibfk_2` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5271 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TaxDetails`
--

DROP TABLE IF EXISTS `TaxDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TaxDetails` (
  `tax_details_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `tfn` varchar(9) DEFAULT NULL COMMENT 'Tax File Number',
  `country_code_tax` varchar(2) DEFAULT NULL COMMENT 'Country of Tax Residence',
  `state_code_tax` varchar(5) DEFAULT NULL COMMENT 'State of Tax Residence',
  `family_tax_benefit` tinyint(1) NOT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tax_details_id`),
  KEY `fk_TaxDetails_1_idx` (`client_id`),
  CONSTRAINT `fk_TaxDetails_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2341 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TaxPlanning`
--

DROP TABLE IF EXISTS `TaxPlanning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TaxPlanning` (
  `tax_planning_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `client_id` int DEFAULT NULL,
  `legal_entity_id` int DEFAULT NULL,
  `significant_changes_impact` tinyint(1) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tax_planning_id`),
  KEY `fk_TaxPlanning_1_idx` (`household_id`),
  KEY `fk_TaxPlanning_2_idx` (`client_id`),
  KEY `fk_TaxPlanning_3_idx` (`legal_entity_id`),
  CONSTRAINT `fk_TaxPlanning_1` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_TaxPlanning_2` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_TaxPlanning_3` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ToeFeeHistory`
--

DROP TABLE IF EXISTS `ToeFeeHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ToeFeeHistory` (
  `toe_fee_history_id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `toe_file_name` varchar(100) NOT NULL,
  `initial_fee` decimal(20,8) DEFAULT NULL,
  `deposit_payable` decimal(20,8) DEFAULT NULL,
  `all_assets_under_management` decimal(20,8) DEFAULT NULL,
  `minimum_annual_fee` decimal(20,8) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`toe_fee_history_id`),
  KEY `fk_ToeFeeHistory_1_idx` (`household_id`),
  CONSTRAINT `fk_ToeFeeHistory_1_idx` FOREIGN KEY (`household_id`) REFERENCES `Household` (`household_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TrustBeneficiary`
--

DROP TABLE IF EXISTS `TrustBeneficiary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TrustBeneficiary` (
  `trust_beneficiary_id` int NOT NULL AUTO_INCREMENT,
  `legal_entity_id` int NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT '1',
  `first_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `company_name` varchar(80) DEFAULT NULL,
  `nominated_percentage` decimal(5,4) DEFAULT NULL COMMENT 'This is a % so should be between 0.0 and 1.0',
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`trust_beneficiary_id`),
  KEY `fk_TrustBeneficiary_1_idx` (`legal_entity_id`),
  CONSTRAINT `fk_TrustBeneficiary_1` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Trustee`
--

DROP TABLE IF EXISTS `Trustee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Trustee` (
  `trustee_id` int NOT NULL AUTO_INCREMENT,
  `legal_entity_id` int NOT NULL,
  `trustee_type` enum('I','C') NOT NULL COMMENT 'I = Individual, C = Corporate',
  `first_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `company_name` varchar(80) DEFAULT NULL,
  `date_appointed` date DEFAULT NULL,
  `notes` varchar(5000) DEFAULT NULL,
  `client_notes` varchar(2500) DEFAULT NULL,
  `partner_notes` varchar(2500) DEFAULT NULL,
  `confidential_notes` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`trustee_id`),
  KEY `fk_Trustee_1_idx` (`legal_entity_id`),
  CONSTRAINT `fk_Trustee_1` FOREIGN KEY (`legal_entity_id`) REFERENCES `LegalEntity` (`legal_entity_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ValueCard`
--

DROP TABLE IF EXISTS `ValueCard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ValueCard` (
  `value_card_id` int NOT NULL AUTO_INCREMENT,
  `value_group_id` int NOT NULL,
  `card` varchar(500) NOT NULL COMMENT 'Name of this practice package',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`value_card_id`),
  KEY `fk_ValueCard_1_idx` (`value_group_id`),
  CONSTRAINT `fk_ValueCard_1` FOREIGN KEY (`value_group_id`) REFERENCES `ValueGroup` (`value_group_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ValueGroup`
--

DROP TABLE IF EXISTS `ValueGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ValueGroup` (
  `value_group_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT 'Name of this group',
  `color` char(6) NOT NULL COMMENT 'Hex Color of this group',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`value_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WhiteListMFA`
--

DROP TABLE IF EXISTS `WhiteListMFA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WhiteListMFA` (
  `whitelist_mfa_id` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) DEFAULT NULL,
  `confirmation_status` varchar(255) DEFAULT NULL,
  `email_domain` varchar(255) DEFAULT NULL,
  `sso_reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`whitelist_mfa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bq_data`
--

DROP TABLE IF EXISTS `bq_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bq_data` (
  `basiq_data_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `basiq_user_id` varchar(50) NOT NULL,
  `basiq_auth_token` varchar(1000) DEFAULT NULL,
  `basiq_last_error` varchar(5000) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` varchar(50) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  PRIMARY KEY (`basiq_data_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `bq_data_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `Client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=331 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bq_institution`
--

DROP TABLE IF EXISTS `bq_institution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bq_institution` (
  `basiq_institution_id` varchar(10) NOT NULL,
  `basiq_institution_type` varchar(255) DEFAULT NULL,
  `basiq_institution_name` varchar(500) NOT NULL,
  `basiq_institution_short_name` varchar(100) DEFAULT NULL,
  `basiq_institution_country` varchar(100) DEFAULT NULL,
  `basiq_institution_stat_retrieve_accounts` int DEFAULT NULL,
  `basiq_institution_stat_retrieve_transactions` int DEFAULT NULL,
  `basiq_institution_logo_url` varchar(500) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`basiq_institution_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_best_life_scores`
--

DROP TABLE IF EXISTS `load_best_life_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_best_life_scores` (
  `load_id` varchar(36) DEFAULT NULL,
  `household_id` int NOT NULL,
  `scenario_id` binary(16) NOT NULL,
  `best_life_score` decimal(7,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_client_wellness_scores`
--

DROP TABLE IF EXISTS `load_client_wellness_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_client_wellness_scores` (
  `client_id` int NOT NULL,
  `wellness_score` decimal(7,4) DEFAULT NULL,
  `life_score` decimal(7,4) DEFAULT NULL,
  `values_score` decimal(7,4) DEFAULT NULL,
  `goals_score` decimal(7,4) DEFAULT NULL,
  `tasks_score` decimal(7,4) DEFAULT NULL,
  `kaa_score` decimal(7,4) DEFAULT NULL,
  `components` varchar(8) DEFAULT NULL,
  `load_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_etf_md_price`
--

DROP TABLE IF EXISTS `load_etf_md_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_etf_md_price` (
  `ms_code` varchar(30) DEFAULT NULL,
  `date` date NOT NULL,
  `close_price` decimal(20,8) DEFAULT NULL,
  `currency_code` varchar(3) DEFAULT NULL,
  `market_cap` decimal(32,8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_etf_md_security`
--

DROP TABLE IF EXISTS `load_etf_md_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_etf_md_security` (
  `code` varchar(30) NOT NULL,
  `ms_code` varchar(30) DEFAULT NULL,
  `ticker` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs NOT NULL,
  `exchange` varchar(20) DEFAULT NULL,
  `isin` varchar(12) DEFAULT NULL,
  `sedol` varchar(7) DEFAULT NULL,
  `cusip` varchar(9) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `asset_tree_id` int NOT NULL,
  `security_group_id` int NOT NULL,
  `security_type_id` int NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `tcr` decimal(15,8) DEFAULT NULL,
  `icr` decimal(15,8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_fund_md_price`
--

DROP TABLE IF EXISTS `load_fund_md_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_fund_md_price` (
  `ms_code` varchar(30) DEFAULT NULL,
  `date` date NOT NULL,
  `close_price` decimal(20,8) DEFAULT NULL,
  `currency_code` varchar(3) DEFAULT NULL,
  `market_cap` decimal(32,8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_fund_md_security`
--

DROP TABLE IF EXISTS `load_fund_md_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_fund_md_security` (
  `code` varchar(30) NOT NULL,
  `ms_code` varchar(30) DEFAULT NULL,
  `ticker` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs NOT NULL,
  `isin` varchar(12) DEFAULT NULL,
  `sedol` varchar(7) DEFAULT NULL,
  `cusip` varchar(9) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `asset_tree_id` int NOT NULL,
  `security_group_id` int NOT NULL,
  `security_type_id` int NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `tcr` decimal(15,8) DEFAULT NULL,
  `icr` decimal(15,8) DEFAULT NULL,
  `buy_spread` decimal(15,8) DEFAULT NULL,
  `sell_spread` decimal(15,8) DEFAULT NULL,
  `switching_fee` decimal(15,8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_household_wellness_scores`
--

DROP TABLE IF EXISTS `load_household_wellness_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_household_wellness_scores` (
  `household_id` int NOT NULL,
  `wellness_score` decimal(7,4) DEFAULT NULL,
  `life_score` decimal(7,4) DEFAULT NULL,
  `values_score` decimal(7,4) DEFAULT NULL,
  `goals_score` decimal(7,4) DEFAULT NULL,
  `tasks_score` decimal(7,4) DEFAULT NULL,
  `kaa_score` decimal(7,4) DEFAULT NULL,
  `components` varchar(8) DEFAULT NULL,
  `load_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_md_fx_cross_rates`
--

DROP TABLE IF EXISTS `load_md_fx_cross_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_md_fx_cross_rates` (
  `from_currency_code_id` int NOT NULL,
  `to_currency_code_id` int NOT NULL,
  `date` date NOT NULL,
  `rate` decimal(20,8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_non_fund_md_price`
--

DROP TABLE IF EXISTS `load_non_fund_md_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_non_fund_md_price` (
  `ms_code` varchar(30) DEFAULT NULL,
  `date` date NOT NULL,
  `close_price` decimal(20,8) DEFAULT NULL,
  `currency_code` varchar(3) DEFAULT NULL,
  `market_cap` decimal(32,8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_non_fund_md_security`
--

DROP TABLE IF EXISTS `load_non_fund_md_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_non_fund_md_security` (
  `code` varchar(30) NOT NULL,
  `ms_code` varchar(30) DEFAULT NULL,
  `ms_non_fund_code` varchar(100) DEFAULT NULL,
  `ticker` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs NOT NULL,
  `exchange` varchar(20) DEFAULT NULL,
  `isin` varchar(12) DEFAULT NULL,
  `sedol` varchar(7) DEFAULT NULL,
  `cusip` varchar(9) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `asset_tree_id` int NOT NULL,
  `security_group_id` int NOT NULL,
  `security_type_id` int NOT NULL,
  `gics` varchar(8) DEFAULT NULL,
  `ms_industry_class_id` int DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_sma_md_price`
--

DROP TABLE IF EXISTS `load_sma_md_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_sma_md_price` (
  `ms_code` varchar(30) DEFAULT NULL,
  `date` date NOT NULL,
  `close_price` decimal(20,8) DEFAULT NULL,
  `currency_code` varchar(3) DEFAULT NULL,
  `market_cap` decimal(32,8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_sma_md_security`
--

DROP TABLE IF EXISTS `load_sma_md_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `load_sma_md_security` (
  `code` varchar(30) NOT NULL,
  `ms_code` varchar(30) DEFAULT NULL,
  `ticker` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs NOT NULL,
  `isin` varchar(12) DEFAULT NULL,
  `sedol` varchar(7) DEFAULT NULL,
  `cusip` varchar(9) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `asset_tree_id` int NOT NULL,
  `security_group_id` int NOT NULL,
  `security_type_id` int NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `tcr` decimal(15,8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_asset_class`
--

DROP TABLE IF EXISTS `md_asset_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_asset_class` (
  `asset_class_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`asset_class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_asset_tree`
--

DROP TABLE IF EXISTS `md_asset_tree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_asset_tree` (
  `asset_tree_id` int NOT NULL AUTO_INCREMENT,
  `inv_group_id` int NOT NULL,
  `region_id` int NOT NULL,
  `asset_class_id` int NOT NULL,
  `sector_id` int NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`asset_tree_id`),
  KEY `fk_md_asset_tree_inv_group_idx` (`inv_group_id`),
  KEY `fk_md_asset_tree_region_idx` (`region_id`),
  KEY `fk_md_asset_tree_asset_class_idx` (`asset_class_id`),
  KEY `fk_md_asset_tree_sector_idx` (`sector_id`),
  CONSTRAINT `fk_md_asset_tree_asset_class` FOREIGN KEY (`asset_class_id`) REFERENCES `md_asset_class` (`asset_class_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_md_asset_tree_inv_group` FOREIGN KEY (`inv_group_id`) REFERENCES `md_investment_group` (`inv_group_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_md_asset_tree_region` FOREIGN KEY (`region_id`) REFERENCES `md_region` (`region_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_md_asset_tree_sector` FOREIGN KEY (`sector_id`) REFERENCES `md_sector` (`sector_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=7007001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_currency_code`
--

DROP TABLE IF EXISTS `md_currency_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_currency_code` (
  `currency_code_id` int NOT NULL AUTO_INCREMENT,
  `currency_code` varchar(3) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`currency_code_id`),
  UNIQUE KEY `ix_md_currency_code` (`currency_code`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_fx_cross_rates`
--

DROP TABLE IF EXISTS `md_fx_cross_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_fx_cross_rates` (
  `from_currency_code_id` int NOT NULL,
  `to_currency_code_id` int NOT NULL,
  `date` date NOT NULL,
  `rate` decimal(20,8) NOT NULL,
  PRIMARY KEY (`from_currency_code_id`,`to_currency_code_id`,`date`),
  KEY `to_currency_code_id` (`to_currency_code_id`),
  CONSTRAINT `md_fx_cross_rates_ibfk_1` FOREIGN KEY (`from_currency_code_id`) REFERENCES `md_currency_code` (`currency_code_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `md_fx_cross_rates_ibfk_2` FOREIGN KEY (`to_currency_code_id`) REFERENCES `md_currency_code` (`currency_code_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_il_security_map`
--

DROP TABLE IF EXISTS `md_il_security_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_il_security_map` (
  `product_source` varchar(4) NOT NULL,
  `product_code` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs NOT NULL,
  `security_id` int DEFAULT NULL,
  `asset_tree_id` int DEFAULT NULL,
  `security_group_id` int DEFAULT NULL,
  `security_type_id` int DEFAULT NULL,
  `currency_code_id` int DEFAULT NULL,
  PRIMARY KEY (`product_source`,`product_code`),
  KEY `md_il_security_map_sec_id` (`security_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_investment_group`
--

DROP TABLE IF EXISTS `md_investment_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_investment_group` (
  `inv_group_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `is_growth` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`inv_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_price`
--

DROP TABLE IF EXISTS `md_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_price` (
  `price_id` int NOT NULL AUTO_INCREMENT,
  `security_id` int NOT NULL,
  `date` date NOT NULL,
  `close_price` decimal(20,8) DEFAULT NULL,
  `close_price_aud` decimal(20,8) DEFAULT NULL,
  `currency_code` varchar(3) DEFAULT NULL,
  `market_cap` decimal(32,8) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`price_id`),
  UNIQUE KEY `ix_md_price_security_id_date` (`security_id`,`date`),
  KEY `fk_md_price_security_idx` (`security_id`),
  CONSTRAINT `fk_md_price_security` FOREIGN KEY (`security_id`) REFERENCES `md_security` (`security_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=42359463 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_price_latest`
--

DROP TABLE IF EXISTS `md_price_latest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_price_latest` (
  `price_latest_id` int NOT NULL AUTO_INCREMENT,
  `security_id` int NOT NULL,
  `date` date NOT NULL,
  `close_price` decimal(20,8) DEFAULT NULL,
  `close_price_aud` decimal(20,8) DEFAULT NULL,
  `currency_code` varchar(3) DEFAULT NULL,
  `market_cap` decimal(32,8) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`price_latest_id`),
  UNIQUE KEY `ix_md_price_latest_security_id` (`security_id`),
  KEY `fk_md_price_latest_security_idx` (`security_id`),
  CONSTRAINT `fk_md_price_latest_security` FOREIGN KEY (`security_id`) REFERENCES `md_security` (`security_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=24355 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_price_latest_temp`
--

DROP TABLE IF EXISTS `md_price_latest_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_price_latest_temp` (
  `price_latest_id` int NOT NULL AUTO_INCREMENT,
  `security_id` int NOT NULL,
  `date` date NOT NULL,
  `close_price` decimal(20,8) DEFAULT NULL,
  `close_price_aud` decimal(20,8) DEFAULT NULL,
  `currency_code` varchar(3) DEFAULT NULL,
  `market_cap` decimal(32,8) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`price_latest_id`),
  UNIQUE KEY `ix_md_price_latest_t_security_id` (`security_id`),
  KEY `fk_md_price_latestt_security_idx` (`security_id`),
  CONSTRAINT `fk_md_price_latestt_security` FOREIGN KEY (`security_id`) REFERENCES `md_security` (`security_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=24355 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_region`
--

DROP TABLE IF EXISTS `md_region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_region` (
  `region_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alt_name` varchar(255) NOT NULL,
  `parent_region_id` int DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`region_id`),
  KEY `fk_md_region_parent_idx` (`parent_region_id`),
  CONSTRAINT `fk_md_region_parent` FOREIGN KEY (`parent_region_id`) REFERENCES `md_region` (`region_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2202 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_sector`
--

DROP TABLE IF EXISTS `md_sector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_sector` (
  `sector_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sector_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7008 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_security`
--

DROP TABLE IF EXISTS `md_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_security` (
  `security_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `ms_code` varchar(30) DEFAULT NULL,
  `ms_non_fund_code` varchar(100) DEFAULT NULL,
  `ticker` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs NOT NULL,
  `exchange` varchar(20) DEFAULT NULL,
  `isin` varchar(12) DEFAULT NULL,
  `sedol` varchar(7) DEFAULT NULL,
  `cusip` varchar(9) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `asset_tree_id` int NOT NULL,
  `security_group_id` int NOT NULL,
  `security_type_id` int NOT NULL,
  `gics` varchar(8) DEFAULT NULL,
  `ms_industry_class_id` int DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `is_held` tinyint(1) DEFAULT '0',
  `tcr` decimal(15,8) DEFAULT NULL,
  `icr` decimal(15,8) DEFAULT NULL,
  `buy_spread` decimal(15,8) DEFAULT NULL,
  `sell_spread` decimal(15,8) DEFAULT NULL,
  `switching_fee` decimal(15,8) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`security_id`),
  UNIQUE KEY `ix_md_security_code` (`code`),
  UNIQUE KEY `ix_md_security_ms_code` (`ms_code`),
  UNIQUE KEY `ix_md_security_ticker` (`ticker`,`exchange`),
  KEY `fk_md_security_asset_tree_idx` (`asset_tree_id`),
  KEY `fk_md_security_sec_group_idx` (`security_group_id`),
  KEY `fk_md_security_sec_type_idx` (`security_type_id`),
  KEY `ix_md_security_ms_industry_class` (`ms_industry_class_id`),
  KEY `ix_md_security_is_held` (`is_held`),
  KEY `ix_md_security_gics` (`gics`),
  KEY `ix_md_security_isin` (`isin`),
  KEY `ix_md_security_sedol` (`sedol`),
  KEY `ix_md_security_cusip` (`cusip`),
  CONSTRAINT `fk_md_security_asset_tree` FOREIGN KEY (`asset_tree_id`) REFERENCES `md_asset_tree` (`asset_tree_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_md_security_ms_ind_class_id` FOREIGN KEY (`ms_industry_class_id`) REFERENCES `ms_industry_class` (`ms_industry_class_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_md_security_sec_group` FOREIGN KEY (`security_group_id`) REFERENCES `md_security_group` (`security_group_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_md_security_sec_type` FOREIGN KEY (`security_type_id`) REFERENCES `md_security_type` (`security_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=4132885 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_security_group`
--

DROP TABLE IF EXISTS `md_security_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_security_group` (
  `security_group_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`security_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `md_security_type`
--

DROP TABLE IF EXISTS `md_security_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_security_type` (
  `security_type_id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`security_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ms_exchange`
--

DROP TABLE IF EXISTS `ms_exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ms_exchange` (
  `ms_exchange_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ms_exchange_id`),
  KEY `ix_ms_exchange_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ms_industry_class`
--

DROP TABLE IF EXISTS `ms_industry_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ms_industry_class` (
  `ms_industry_class_id` int NOT NULL AUTO_INCREMENT,
  `sector_id` char(3) NOT NULL,
  `sector` varchar(100) NOT NULL,
  `group_id` char(5) DEFAULT NULL,
  `group_name` varchar(100) DEFAULT NULL,
  `industry_id` char(8) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `gics` varchar(8) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ms_industry_class_id`),
  UNIQUE KEY `ix_ms_industry_class_industry` (`industry_id`),
  KEY `ix_ms_industry_class_sector` (`sector_id`),
  KEY `ix_ms_industry_class_group` (`group_id`),
  KEY `ix_ms_industry_class_gics` (`gics`)
) ENGINE=InnoDB AUTO_INCREMENT=31169149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ms_security_type`
--

DROP TABLE IF EXISTS `ms_security_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ms_security_type` (
  `ms_security_type_id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ms_security_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `msci_gics`
--

DROP TABLE IF EXISTS `msci_gics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `msci_gics` (
  `msci_gics_id` int NOT NULL AUTO_INCREMENT,
  `sector_id` char(2) NOT NULL,
  `sector` varchar(100) NOT NULL,
  `industry_group_id` char(4) DEFAULT NULL,
  `industry_group` varchar(100) DEFAULT NULL,
  `industry_id` char(6) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `subindustry_id` char(8) DEFAULT NULL,
  `subindustry` varchar(100) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`msci_gics_id`),
  UNIQUE KEY `ix_msci_gics_subindustry` (`subindustry_id`),
  KEY `ix_msci_gics_sector` (`sector_id`),
  KEY `ix_msci_gics_ind_group` (`industry_group_id`),
  KEY `ix_msci_gics_industry` (`industry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-03 11:03:42
