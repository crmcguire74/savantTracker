from datetime import datetime, UTC
from typing import Any
from boto3.session import Session as Boto3Session
import sqlalchemy.orm
from sqlalchemy import and_, func
from aws_lambda_powertools import Logger, Tracer

from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.database.schema.governance.beneficiary import Beneficiary as DBBeneficiary
from lumiant_api.abstraction_layer.common.database.schema.governance.estate_planning import (
    EstatePlanning as DBEstatePlanning,
)
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from lumiant_api.abstraction_layer.common.utils.bool_utils import BoolUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils


class BeneficiaryApiService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Beneficiary API
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(child=True, service="BeneficiaryApi")
    tracer = Tracer(service="BeneficiaryApi")

    lumiant_rds_session: sqlalchemy.orm.Session
    boto3_session: Boto3Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Boto3Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def get_beneficiary(self, beneficiary_id: int) -> dict[str, Any] | None:
        """
        Get a single beneficiary by ID in API format.
        Uses practice-scoped _get_db_beneficiary then converts to API dict.
        """
        db_beneficiary = self._get_db_beneficiary(beneficiary_id)
        if db_beneficiary is None:
            return None
        return self._convert_db_beneficiary_to_api_format(db_beneficiary)

    def get_beneficiaries(
        self,
        household_id: int | None,
        estate_planning_id: int | None,
        page: int | None,
        page_size: int | None,
        updated_after: datetime | None = None,
        include_deleted: bool = False,
    ) -> tuple[list[dict[str, Any]], int]:
        """
        Get paginated list of beneficiaries
        """
        page = page if page is not None and page > 0 else 1
        page_size = page_size if page_size is not None and page_size > 0 else 200

        offset = (page - 1) * page_size

        filters = []

        if estate_planning_id is not None:
            filters.append(DBBeneficiary.estate_planning_id == estate_planning_id)

        if household_id is not None:
            filters.append(DBEstatePlanning.household_id == household_id)

        if updated_after is not None:
            filters.append(DBBeneficiary.updated >= updated_after)

        if not include_deleted:
            filters.append(DBBeneficiary.soft_deleted.is_(False))

        # Always join to HouseholdTeamMember first to enforce practice scoping
        base_query = (
            self.lumiant_rds_session.query(DBBeneficiary)
            .join(DBEstatePlanning, DBBeneficiary.estate_planning_id == DBEstatePlanning.estate_planning_id)
            .join(DBHouseholdTeamMember, DBEstatePlanning.household_id == DBHouseholdTeamMember.household_id)
            .distinct()
        )

        # Add practice filter to the filters list
        filters.append(DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id)

        # Apply all filters
        for filter_condition in filters:
            base_query = base_query.filter(filter_condition)

        beneficiaries = (
            base_query.with_entities(*BeneficiaryApiService._get_beneficiary_fields())
            .offset(offset)
            .limit(page_size)
            .all()
        )

        # Count query - needs the same joins as the main query
        count_query = (
            self.lumiant_rds_session.query(func.count(DBBeneficiary.beneficiary_id.distinct()))
            .join(DBEstatePlanning, DBBeneficiary.estate_planning_id == DBEstatePlanning.estate_planning_id)
            .join(DBHouseholdTeamMember, DBEstatePlanning.household_id == DBHouseholdTeamMember.household_id)
        )

        for filter_condition in filters:
            count_query = count_query.filter(filter_condition)

        total_count = count_query.scalar()

        # Convert to API format
        api_beneficiaries = self._convert_to_api_format(beneficiaries)

        return api_beneficiaries, total_count

    def _get_db_beneficiary(self, beneficiary_id: int) -> DBBeneficiary | None:
        """
        Get a single DBBeneficiary by ID with practice scoping.
        Returns the ORM object for use in save/delete, or None if not found/not in practice.
        """
        beneficiary = (
            self.lumiant_rds_session.query(DBBeneficiary)
            .join(DBEstatePlanning, DBEstatePlanning.estate_planning_id == DBBeneficiary.estate_planning_id)
            .join(DBHouseholdTeamMember, DBHouseholdTeamMember.household_id == DBEstatePlanning.household_id)
            .filter(
                and_(
                    DBBeneficiary.beneficiary_id == beneficiary_id,
                    DBBeneficiary.soft_deleted.is_not(True),
                    DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id,
                )
            )
            .first()
        )
        return beneficiary

    def save(
        self,
        beneficiary_id: int | None,
        estate_planning_id: int,
        first_name: str,
        last_name: str,
        middle_name: str | None = None,
        relationship_type: str | None = None,
        nominated_percentage: float | None = None,
        age_entitlement: int | None = None,
        notes: str | None = None,
        confidential_notes: str | None = None,
    ) -> dict[str, Any] | None:
        """
        Save (create or update) a beneficiary.
        All logic is in the abstraction layer; no dependency on legacy BeneficiaryService.
        Note: client_notes, partner_notes, is_primary, and company_name are NOT exposed in the API.
        """
        db_relationship_type = self._map_api_relationship_type_to_db(relationship_type)
        is_primary = True
        company_name = None

        if beneficiary_id is not None:
            beneficiary = self._get_db_beneficiary(beneficiary_id)
            if beneficiary is None:
                return None
        else:
            beneficiary = DBBeneficiary()
            beneficiary.estate_planning_id = estate_planning_id
            beneficiary.is_primary = is_primary
            beneficiary.soft_deleted = False
            beneficiary.created = datetime.now(UTC)
            beneficiary.created_by = self.auth_metadata.iam_id
            self.lumiant_rds_session.add(beneficiary)

        beneficiary.is_primary = is_primary
        beneficiary.first_name = StringUtils.trim_to_empty(first_name)
        beneficiary.last_name = StringUtils.trim_to_empty(last_name)
        beneficiary.company_name = StringUtils.trim_to_empty(company_name)
        if middle_name is not None:
            beneficiary.middle_name = StringUtils.trim_to_empty(middle_name)
        if relationship_type is not None:
            beneficiary.relationship_type = db_relationship_type
        if nominated_percentage is not None:
            beneficiary.nominated_percentage = nominated_percentage
        if age_entitlement is not None:
            beneficiary.age_entitlement = age_entitlement
        if notes is not None:
            beneficiary.notes = StringUtils.trim_to_empty(notes)
        if confidential_notes is not None:
            beneficiary.confidential_notes = StringUtils.trim_to_empty(confidential_notes)
        beneficiary.updated = datetime.now(UTC)
        beneficiary.updated_by = self.auth_metadata.iam_id

        self.lumiant_rds_session.commit()
        return self._convert_db_beneficiary_to_api_format(beneficiary)

    def delete(self, beneficiary_id: int) -> tuple[bool, bool]:
        """
        Soft-delete a beneficiary. Uses practice-scoped lookup; no legacy BeneficiaryService.
        Returns (success, found).
        """
        beneficiary = self._get_db_beneficiary(beneficiary_id)
        if beneficiary is None:
            return False, False

        try:
            beneficiary.soft_deleted = True
            beneficiary.updated = datetime.now(UTC)
            beneficiary.updated_by = self.auth_metadata.iam_id
            self.lumiant_rds_session.commit()
            return True, True
        except Exception as e:
            self.logger.error(f"Failed to delete beneficiary: {e}")
            return False, True

    @staticmethod
    def _get_beneficiary_fields():
        """
        Get field list for beneficiary
        Note: client_notes, partner_notes, is_primary, and company_name are NOT exposed in the API
        """
        return [
            DBBeneficiary.beneficiary_id,
            DBBeneficiary.estate_planning_id,
            DBBeneficiary.first_name,
            DBBeneficiary.middle_name,
            DBBeneficiary.last_name,
            DBBeneficiary.relationship_type,
            DBBeneficiary.nominated_percentage,
            DBBeneficiary.age_entitlement,
            DBBeneficiary.notes,
            DBBeneficiary.confidential_notes,
            DBBeneficiary.created,
            DBBeneficiary.updated,
            DBBeneficiary.soft_deleted,
        ]

    def _convert_to_api_format(self, raw_results: list[tuple]) -> list[dict[str, Any]]:
        """
        Convert raw database results to API format
        """
        if not raw_results:
            return []

        api_results = []
        field_names = [field.key for field in self._get_beneficiary_fields()]

        for row in raw_results:
            # Convert tuple to dict
            row_dict = dict(zip(field_names, row, strict=False))

            # Map relationship_type enum to API format
            api_relationship_type = self._map_db_relationship_type_to_api(row_dict.get("relationship_type"))
            if api_relationship_type is not None:
                row_dict["relationship_type"] = api_relationship_type

            # Cast numeric fields to float to prevent Decimal serialization issues
            if row_dict.get("nominated_percentage") is not None:
                row_dict["nominated_percentage"] = float(row_dict["nominated_percentage"])

            # Apply serialization to datetime fields
            row_dict["created"] = SerializationUtils.convert_value_to_string(row_dict["created"])
            row_dict["updated"] = SerializationUtils.convert_value_to_string(row_dict["updated"])

            # Apply serialization to soft_deleted field
            row_dict["soft_deleted"] = BoolUtils.parse(row_dict["soft_deleted"])

            api_results.append(row_dict)

        return api_results

    def _convert_db_beneficiary_to_api_format(self, db_beneficiary: DBBeneficiary) -> dict[str, Any]:
        """
        Convert a single DB Beneficiary object to API format
        """
        result = {
            "beneficiary_id": db_beneficiary.beneficiary_id,
            "estate_planning_id": db_beneficiary.estate_planning_id,
            "first_name": db_beneficiary.first_name,
            "middle_name": db_beneficiary.middle_name,
            "last_name": db_beneficiary.last_name,
            "nominated_percentage": float(db_beneficiary.nominated_percentage)
            if db_beneficiary.nominated_percentage is not None
            else None,
            "age_entitlement": db_beneficiary.age_entitlement,
            "notes": db_beneficiary.notes,
            "confidential_notes": db_beneficiary.confidential_notes,
            "created": SerializationUtils.convert_value_to_string(db_beneficiary.created),
            "updated": SerializationUtils.convert_value_to_string(db_beneficiary.updated),
            "soft_deleted": BoolUtils.parse(db_beneficiary.soft_deleted),
        }

        # Map relationship_type enum to API format
        api_relationship_type = self._map_db_relationship_type_to_api(db_beneficiary.relationship_type)
        if api_relationship_type is not None:
            result["relationship_type"] = api_relationship_type

        return result

    # ==================== Enum Mapping Methods ====================

    @staticmethod
    def _map_db_relationship_type_to_api(db_relationship_type: str | None) -> str | None:
        """Map database relationship_type to API enum"""
        if db_relationship_type is None:
            return None

        mapping = {
            "S": "SPOUSE",
            "C": "CHILD",
            "F": "FINANCIAL_DEPENDENT",
            "I": "INDEPENDENT_RELATIONSHIP",
            "O": "OTHER",
        }

        if db_relationship_type not in mapping:
            raise ValueError(f"Unknown database relationship type: {db_relationship_type}")

        return mapping[db_relationship_type]

    @staticmethod
    def _map_api_relationship_type_to_db(api_relationship_type: str | None) -> str | None:
        """Map API relationship_type enum to database char code"""
        if api_relationship_type is None:
            return None

        mapping = {
            "SPOUSE": "S",
            "CHILD": "C",
            "FINANCIAL_DEPENDENT": "F",
            "INDEPENDENT_RELATIONSHIP": "I",
            "OTHER": "O",
        }

        if api_relationship_type not in mapping:
            raise ValueError(f"Unknown API relationship type: {api_relationship_type}")

        return mapping[api_relationship_type]
