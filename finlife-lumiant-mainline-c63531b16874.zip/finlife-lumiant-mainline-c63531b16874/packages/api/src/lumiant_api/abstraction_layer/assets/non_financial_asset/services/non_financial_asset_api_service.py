import datetime
from typing import Any

import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from sqlalchemy import and_, func, or_

from lumiant_api.abstraction_layer.common.constants.aws_region import AP_SOUTHEAST_2
from lumiant_api.abstraction_layer.common.database.schema.address import Address as DBAddress
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset as DBAsset
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.utils.bool_utils import BoolUtils
from lumiant_api.abstraction_layer.common.utils.date_utils import DateUtils
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils
from lumiant_api.abstraction_layer.assets.utils.asset_utils import (
    convert_row_to_dict,
    finalize_asset_save,
    find_or_create_asset,
    soft_delete_asset,
)


class NonFinancialAssetApiService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Non-Financial Asset API
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(child=True, service="NonFinancialAssetApi")
    tracer = Tracer(service="NonFinancialAssetApi")

    lumiant_rds_session: sqlalchemy.orm.Session
    boto3_session: Boto3Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Boto3Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def get_non_financial_asset(self, asset_id: int, household_id: int) -> dict[str, Any] | None:
        """
        Get a single non-financial asset by ID
        Query joins to HouseholdTeamMember to verify that asset is within practice.
        """
        asset = (
            self.lumiant_rds_session.query(DBAsset)
            .join(DBHouseholdTeamMember, DBHouseholdTeamMember.household_id == DBAsset.household_id)
            .outerjoin(DBAddress, DBAddress.address_id == DBAsset.address_id)
            .filter(
                and_(
                    DBAsset.asset_id == asset_id,
                    DBAsset.household_id == household_id,
                    DBAsset.soft_deleted.is_not(True),
                    DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id,
                    self._get_non_financial_asset_filters(self.auth_metadata.region),
                )
            )
            .with_entities(*NonFinancialAssetApiService._get_non_financial_asset_fields(self.auth_metadata.region))
            .first()
        )

        if asset is None:
            return None

        # Convert to API format
        api_assets = self._convert_to_api_format([asset], self.auth_metadata.region)
        return api_assets[0] if api_assets else None

    def get_non_financial_assets(
        self,
        household_id: int | None,
        page: int | None,
        page_size: int | None,
        client_id: int | None = None,
        updated_after: datetime.datetime | None = None,
        include_deleted: bool = False,
    ) -> tuple[list[dict[str, Any]], int]:
        """
        Get paginated list of non-financial assets
        """
        page = page if page is not None and page > 0 else 1
        page_size = page_size if page_size is not None and page_size > 0 else 200

        offset = (page - 1) * page_size

        filters = []

        if household_id is not None:
            filters.append(DBAsset.household_id == household_id)

        if client_id is not None:
            filters.append(DBAsset.client_id == client_id)

        if updated_after is not None:
            filters.append(DBAsset.updated >= updated_after)

        if not include_deleted:
            filters.append(DBAsset.soft_deleted.is_(False))

        # Only include non-financial assets that we have mappings for
        non_financial_asset_filters = NonFinancialAssetApiService._get_non_financial_asset_filters(
            self.auth_metadata.region
        )
        filters.append(non_financial_asset_filters)

        # Always join to HouseholdTeamMember first to enforce practice scoping
        base_query = (
            self.lumiant_rds_session.query(DBAsset)
            .join(DBHouseholdTeamMember, DBAsset.household_id == DBHouseholdTeamMember.household_id)
            .outerjoin(DBAddress, DBAddress.address_id == DBAsset.address_id)
            .distinct()
        )

        # Add practice filter to the filters list
        filters.append(DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id)

        # Apply all filters
        for filter_condition in filters:
            base_query = base_query.filter(filter_condition)

        assets = (
            base_query.with_entities(
                *NonFinancialAssetApiService._get_non_financial_asset_fields(self.auth_metadata.region)
            )
            .offset(offset)
            .limit(page_size)
            .all()
        )

        # Count query - needs the same joins as the main query
        count_query = self.lumiant_rds_session.query(func.count(DBAsset.asset_id.distinct())).join(
            DBHouseholdTeamMember, DBAsset.household_id == DBHouseholdTeamMember.household_id
        )

        for filter_condition in filters:
            count_query = count_query.filter(filter_condition)

        total_count = count_query.scalar()

        # Convert to API format
        api_assets = self._convert_to_api_format(assets, self.auth_metadata.region)

        return api_assets, total_count

    def save(
        self,
        non_financial_asset_id: int | None,
        asset_type: str,
        household_id: int,
        client_id: int | None = None,
        legal_entity_id: int | None = None,
        make: str | None = None,
        model: str | None = None,
        current_value: float | None = None,
        last_valued_date: datetime.date | None = None,
        purchase_price: float | None = None,
        purchase_date: datetime.date | None = None,
        is_primary_home: bool | None = None,
        constructed_address: str | None = None,
        address_line_1: str | None = None,
        address_line_2: str | None = None,
        suburb: str | None = None,
        post_code: str | None = None,
        state: str | None = None,
        country: str | None = None,
        centrelink_value: float | None = None,
        is_used_loan_security: bool | None = None,
        loan_secured_amount: float | None = None,
        assessed: bool | None = None,
        description: str | None = None,
        notes: str | None = None,
        confidential_notes: str | None = None,
        client_notes: str | None = None,
        partner_notes: str | None = None,
    ) -> dict[str, Any] | None:
        """
        Save (create or update) a non-financial asset
        """
        # Map API asset type to database asset type
        db_asset_type = self.map_api_asset_type_to_db(asset_type)

        db_asset = self._save_asset(
            asset_id=non_financial_asset_id,
            household_id=household_id,
            client_id=client_id,
            legal_entity_id=legal_entity_id,
            asset_type=db_asset_type,
            description=description,
            make=make,
            model=model,
            current_value=current_value,
            last_valued=last_valued_date,
            purchase_price=purchase_price,
            purchase_date=purchase_date,
            is_primary_home=is_primary_home,
            centrelink_value=centrelink_value,
            is_used_loan_security=is_used_loan_security,
            loan_secured_amount=loan_secured_amount,
            assessed=assessed,
            notes=notes,
            client_notes=client_notes,
            partner_notes=partner_notes,
            confidential_notes=confidential_notes,
            constructed_address=constructed_address,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            suburb=suburb,
            post_code=post_code,
            state=state,
            country=country,
        )

        if db_asset is None:
            return None

        return self._convert_db_asset_to_api_format(db_asset)

    def delete(self, non_financial_asset_id: int) -> bool:
        """
        Soft Delete a non-financial asset
        """
        return soft_delete_asset(self.lumiant_rds_session, self.auth_metadata, non_financial_asset_id)

    def _save_asset(
        self,
        asset_id: int | None,
        household_id: int,
        client_id: int | None,
        legal_entity_id: int | None,
        asset_type: str,
        description: str | None,
        make: str | None,
        model: str | None,
        current_value: float | None,
        last_valued: datetime.date | None,
        purchase_price: float | None,
        purchase_date: datetime.date | None,
        is_primary_home: bool | None,
        centrelink_value: float | None,
        is_used_loan_security: bool | None,
        loan_secured_amount: float | None,
        assessed: bool | None,
        notes: str | None,
        client_notes: str | None,
        partner_notes: str | None,
        confidential_notes: str | None,
        constructed_address: str | None,
        address_line_1: str | None,
        address_line_2: str | None,
        suburb: str | None,
        post_code: str | None,
        state: str | None,
        country: str | None,
    ) -> DBAsset | None:
        """Create or update a non-financial asset record via direct ORM operations."""
        asset, is_create = find_or_create_asset(self.lumiant_rds_session, self.auth_metadata, asset_id, household_id)
        if asset is None:
            return None

        # Ownership
        asset.client_id = client_id
        asset.legal_entity_id = legal_entity_id
        asset.beneficiary_client_id = None
        asset.beneficiary_legal_entity_id = None
        asset.relationship_asset = None

        # Type fields
        asset.asset_type = asset_type
        asset.super_type = None
        asset.pension_type = None
        asset.saving_investment_type = None

        # Basic fields
        asset.description = StringUtils.trim_to_empty(description)
        asset.account_number = None
        asset.provider_name = None
        asset.member_number = None
        asset.balance = None

        # Not applicable for non-financial assets
        asset.defined_benefit_salary = None
        asset.defined_benefit_multiple = None
        asset.employee_contribution = None
        asset.employee_contribution_bps = None
        asset.employee_contribution_type = None
        asset.employee_contribution_cap = None
        asset.employee_contribution_cap_bps = None
        asset.employer_contribution = None
        asset.employer_contribution_bps = None
        asset.employer_contribution_cap = None
        asset.employer_contribution_cap_bps = None
        asset.makes_personal_contribution = None
        asset.annual_contribution = None
        asset.inherited_ira_type = None
        asset.deceased_owner_date_of_birth = None
        asset.deceased_owner_date_of_death = None
        asset.rmd_taken_this_year = None
        asset.previous_year_balance = None
        asset.annuity_term_date = None
        asset.death_benefit = None
        asset.surrender_value = None
        asset.centrelink_value = centrelink_value
        asset.is_used_loan_security = is_used_loan_security
        asset.loan_secured_amount = loan_secured_amount
        asset.made_personal_contrib_past_3y = None
        asset.tax_free_component = None
        asset.preservation_component = None
        asset.makes_personal_super_contribution = None
        asset.is_salary_sacrifice = None
        asset.super_contribution_amount = None
        asset.super_contribution_frequency = None
        asset.employer_pays_higher_than_minimum_super = None
        asset.higher_than_minimum_super_bps = None
        asset.pre_retirement_ref_model = None
        asset.post_retirement_ref_model = None
        asset.fees_bps = None
        asset.fees_dollar = None

        # Property fields
        asset.own_or_rent = None
        asset.is_primary_home = is_primary_home
        asset.purchase_price = purchase_price

        if purchase_date is not None:
            if isinstance(purchase_date, datetime.date):
                asset.purchase_date = DateUtils.validate_date(purchase_date)
        else:
            asset.purchase_date = None

        asset.growth_bps = None
        asset.current_value = current_value
        asset.property_type = None
        asset.rent = None
        asset.asset_use = None
        asset.assessed = assessed
        asset.make = StringUtils.trim_to_empty(make)
        asset.model = StringUtils.trim_to_empty(model)

        if last_valued is not None:
            if isinstance(last_valued, datetime.date):
                asset.last_valued = DateUtils.validate_date(last_valued)
        else:
            asset.last_valued = None

        asset.super_phase = None
        asset.annuity_type = None
        asset.term = None
        asset.maturity_date = None
        asset.commuted_amount = None
        asset.residual_value = None
        asset.asset_exemption_bps = None

        return finalize_asset_save(
            asset=asset,
            is_create=is_create,
            lumiant_rds_session=self.lumiant_rds_session,
            boto3_session=self.boto3_session,
            auth_metadata=self.auth_metadata,
            logger=self.logger,
            notes=notes,
            client_notes=client_notes,
            partner_notes=partner_notes,
            confidential_notes=confidential_notes,
            constructed_address=constructed_address,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            suburb=suburb,
            post_code=post_code,
            state=state,
            country=country,
        )

    @staticmethod
    def _get_non_financial_asset_filters(region: str):
        """
        Get SQLAlchemy filter for non-financial assets based on region mappings
        """
        # Non-financial asset types are Home (H), Vehicle (V) and Other (O)
        non_financial_conditions = [
            DBAsset.asset_type == "H",  # HOME
            DBAsset.asset_type == "V",  # VEHICLE
            DBAsset.asset_type == "O",  # OTHER
        ]
        return or_(*non_financial_conditions)

    @staticmethod
    def _get_non_financial_asset_fields(region: str):
        """
        Get region-specific field list for non-financial assets
        """
        base_fields = [
            DBAsset.asset_id,
            DBAsset.household_id,
            DBAsset.client_id,
            DBAsset.legal_entity_id,
            DBAsset.asset_type,
            DBAsset.make,
            DBAsset.model,
            DBAsset.current_value,
            DBAsset.last_valued,
            DBAsset.purchase_price,
            DBAsset.purchase_date,
            DBAsset.is_primary_home,
            DBAddress.constructed_address,
            DBAddress.address_line_1,
            DBAddress.address_line_2,
            DBAddress.suburb,
            DBAddress.post_code,
            DBAddress.state,
            DBAddress.country,
            DBAsset.description,
            DBAsset.notes,
            DBAsset.confidential_notes,
            DBAsset.client_notes,
            DBAsset.partner_notes,
            DBAsset.created,
            DBAsset.updated,
            DBAsset.soft_deleted,
        ]

        if region == AP_SOUTHEAST_2:  # AU region
            base_fields.extend(
                [
                    DBAsset.centrelink_value,
                    DBAsset.is_used_loan_security,
                    DBAsset.loan_secured_amount,
                    DBAsset.assessed,
                ]
            )

        return base_fields

    def _convert_to_api_format(self, raw_results: list[tuple[Any, ...]], region: str):
        """
        Convert raw database results to API format
        """
        if not raw_results:
            return []

        api_results = []
        field_names = [field.key for field in self._get_non_financial_asset_fields(region)]

        for row in raw_results:
            row_dict = convert_row_to_dict(row, field_names, "non_financial_asset_id")

            # Map internal asset type to API asset type
            db_asset_type = row_dict.get("asset_type")
            if db_asset_type is None or not isinstance(db_asset_type, str):
                continue  # Skip rows without valid asset_type
            api_asset_type = self.map_db_asset_type_to_api(db_asset_type)

            # Remove internal type fields
            row_dict.pop("asset_type", None)

            # Add API asset type
            row_dict["asset_type"] = api_asset_type

            # Apply serialization to date fields
            row_dict["last_valued_date"] = SerializationUtils.convert_value_to_string(row_dict.get("last_valued"))
            row_dict.pop("last_valued", None)
            row_dict["purchase_date"] = SerializationUtils.convert_value_to_string(row_dict["purchase_date"])

            api_results.append(row_dict)

        return api_results

    def _convert_db_asset_to_api_format(self, db_asset: DBAsset) -> dict[str, Any]:
        """
        Convert a single DB Asset object to API format
        """
        # Map internal asset type to API asset type
        api_asset_type = self.map_db_asset_type_to_api(db_asset.asset_type)

        result = {
            "non_financial_asset_id": db_asset.asset_id,
            "asset_type": api_asset_type,
            "household_id": db_asset.household_id,
            "client_id": db_asset.client_id,
            "legal_entity_id": db_asset.legal_entity_id,
            "make": db_asset.make,
            "model": db_asset.model,
            "current_value": float(db_asset.current_value) if db_asset.current_value is not None else None,
            "last_valued_date": SerializationUtils.convert_value_to_string(db_asset.last_valued),
            "purchase_price": float(db_asset.purchase_price) if db_asset.purchase_price else None,
            "purchase_date": SerializationUtils.convert_value_to_string(db_asset.purchase_date),
            "is_primary_home": db_asset.is_primary_home,
            "constructed_address": db_asset.address.constructed_address if db_asset.address else None,
            "address_line_1": db_asset.address.address_line_1 if db_asset.address else None,
            "address_line_2": db_asset.address.address_line_2 if db_asset.address else None,
            "suburb": db_asset.address.suburb if db_asset.address else None,
            "post_code": db_asset.address.post_code if db_asset.address else None,
            "state": db_asset.address.state if db_asset.address else None,
            "country": db_asset.address.country if db_asset.address else None,
            "centrelink_value": float(db_asset.centrelink_value) if db_asset.centrelink_value else None,
            "is_used_loan_security": db_asset.is_used_loan_security,
            "loan_secured_amount": float(db_asset.loan_secured_amount) if db_asset.loan_secured_amount else None,
            "assessed": db_asset.assessed,
            "description": db_asset.description,
            "notes": db_asset.notes,
            "confidential_notes": db_asset.confidential_notes,
            "client_notes": db_asset.client_notes,
            "partner_notes": db_asset.partner_notes,
            "created": SerializationUtils.convert_value_to_string(db_asset.created),
            "updated": SerializationUtils.convert_value_to_string(db_asset.updated),
            "soft_deleted": BoolUtils.parse(db_asset.soft_deleted),
        }

        return result

    @staticmethod
    def map_api_asset_type_to_db(api_asset_type: str) -> str:
        """
        Map API asset type to database asset_type
        """
        api_to_db_mapping = {
            "HOME": "H",  # Home
            "VEHICLE": "V",  # Vehicle
            "OTHER": "O",  # Other
        }

        if api_asset_type not in api_to_db_mapping:
            raise ValueError(f"Unknown API asset type: {api_asset_type}")

        return api_to_db_mapping[api_asset_type]

    @staticmethod
    def map_db_asset_type_to_api(db_asset_type: str) -> str:
        """
        Map database asset_type back to API asset type
        """
        db_to_api_mapping = {
            "H": "HOME",
            "V": "VEHICLE",
            "O": "OTHER",
        }

        if db_asset_type not in db_to_api_mapping:
            raise ValueError(f"Unknown database asset type: {db_asset_type}")

        return db_to_api_mapping[db_asset_type]
