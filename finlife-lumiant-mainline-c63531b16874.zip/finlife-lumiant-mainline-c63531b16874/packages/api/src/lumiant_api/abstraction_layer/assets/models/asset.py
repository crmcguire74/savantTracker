from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING

from aws_lambda_powertools import Logger

from lumiant_api.abstraction_layer.common.models.governance.yodlee_mapping import YodleeMapping
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils
from lumiant_api.abstraction_layer.common.services.address_service import AddressService

if TYPE_CHECKING:
    import sqlalchemy.orm

    from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset as DBAsset
    from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
        LambdaAuthorisationMetadata,
    )


@dataclass
class Asset(object):
    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    assetId: int
    householdId: int
    clientId: int | None
    clientFirstName: str | None
    clientLastName: str | None
    clientPreferredName: str | None
    legalEntityId: int | None
    legalEntityName: str | None
    beneficiaryClientId: int | None
    beneficiaryLegalEntityId: int | None
    otherBeneficiary: str | None
    relationshipAsset: str | None
    assetType: str
    superType: str | None
    pensionType: str | None
    description: str | None
    accountNumber: str | None
    providerName: str | None
    memberNumber: str | None
    balance: float | None
    definedBenefitSalary: float | None
    definedBenefitMultiple: float | None
    employeeContribution: float | None
    employeeContributionBps: float | None
    employeeContributionType: str | None
    employeeContributionCap: float | None
    employeeContributionCapBps: float | None
    employerContribution: float | None
    employerContributionBps: float | None
    employerContributionCap: float | None
    employerContributionCapBps: float | None
    makesPersonalContribution: bool | None
    annualContribution: float | None
    inheritedIraType: str | None
    deceasedOwnerDateOfBirth: str | None
    deceasedOwnerDateOfDeath: str | None
    rmdTakenThisYear: bool | None
    previousYearBalance: float | None
    annuityTermDate: str | None
    deathBenefit: float | None
    surrenderValue: float | None
    centrelinkValue: float | None
    isUsedLoanSecurity: bool | None
    loanSecuredAmount: float | None
    madePersonalContribPast3y: bool | None
    taxFreeComponent: float | None
    preservationComponent: float | None
    makesPersonalSuperContribution: bool | None
    isSalarySacrifice: bool | None
    superContributionAmount: float | None
    superContributionFrequency: str | None
    employerPaysHigherThanMinimumSuper: bool | None
    higherThanMinimumSuperBps: float | None
    preRetirementRefModel: int | None
    postRetirementRefModel: int | None
    feesBps: float | None
    feesDollar: float | None
    addressId: int | None
    ownOrRent: str | None
    isPrimaryHome: bool | None
    purchasePrice: float | None
    purchaseDate: str | None
    growthBps: float | None
    currentValue: float | None
    propertyType: str | None
    rent: float | None
    savingInvestmentType: str | None
    assetUse: str | None
    assessed: bool | None
    make: str | None
    model: str | None
    lastValued: str | None
    superPhase: str | None
    annuityType: str | None
    term: int | None
    maturityDate: str | None
    commutedAmount: float | None
    residualValue: float | None
    assetExemptionBps: float | None
    notes: str | None
    clientNotes: str | None
    partnerNotes: str | None
    confidentialNotes: str | None
    displayName: str | None
    displayOwnership: int | None
    externalId: str
    externalSystem: str
    createdBy: str
    created: str
    updatedBy: str
    updated: str
    addressLine1: str | None
    addressLine2: str | None
    suburb: str | None
    postCode: str | None
    state: str | None
    country: str | None
    assetYodleeMapping: YodleeMapping | None

    def __init__(self) -> None:
        self.assetId = 0
        self.householdId = 0
        self.clientId = None
        self.clientFirstName = None
        self.clientLastName = None
        self.clientPreferredName = None
        self.legalEntityId = None
        self.legalEntityName = None
        self.beneficiaryClientId = None
        self.beneficiaryLegalEntityId = None
        self.otherBeneficiary = None
        self.relationshipAsset = None
        self.assetType = ""
        self.superType = None
        self.pensionType = None
        self.description = None
        self.accountNumber = None
        self.providerName = None
        self.memberNumber = None
        self.balance = None
        self.definedBenefitSalary = None
        self.definedBenefitMultiple = None
        self.employeeContribution = None
        self.employeeContributionBps = None
        self.employeeContributionType = None
        self.employeeContributionCap = None
        self.employeeContributionCapBps = None
        self.employerContribution = None
        self.employerContributionBps = None
        self.employerContributionCap = None
        self.employerContributionCapBps = None
        self.makesPersonalContribution = None
        self.annualContribution = None
        self.inheritedIraType = None
        self.deceasedOwnerDateOfBirth = None
        self.deceasedOwnerDateOfDeath = None
        self.rmdTakenThisYear = None
        self.previousYearBalance = None
        self.annuityTermDate = None
        self.deathBenefit = None
        self.surrenderValue = None
        self.centrelinkValue = None
        self.isUsedLoanSecurity = None
        self.loanSecuredAmount = None
        self.madePersonalContribPast3y = None
        self.taxFreeComponent = None
        self.preservationComponent = None
        self.makesPersonalSuperContribution = None
        self.isSalarySacrifice = None
        self.superContributionAmount = None
        self.superContributionFrequency = None
        self.employerPaysHigherThanMinimumSuper = None
        self.higherThanMinimumSuperBps = None
        self.preRetirementRefModel = None
        self.postRetirementRefModel = None
        self.feesBps = None
        self.feesDollar = None
        self.addressId = None
        self.ownOrRent = None
        self.isPrimaryHome = None
        self.purchasePrice = None
        self.purchaseDate = None
        self.growthBps = None
        self.currentValue = None
        self.propertyType = None
        self.rent = None
        self.savingInvestmentType = None
        self.assetUse = None
        self.assessed = None
        self.make = None
        self.model = None
        self.lastValued = None
        self.superPhase = None
        self.annuityType = None
        self.term = None
        self.maturityDate = None
        self.commutedAmount = None
        self.residualValue = None
        self.assetExemptionBps = None
        self.notes = None
        self.clientNotes = None
        self.partnerNotes = None
        self.confidentialNotes = None
        self.displayName = None
        self.displayOwnership = None
        self.externalId = ""
        self.externalSystem = ""
        self.createdBy = ""
        self.created = ""
        self.updatedBy = ""
        self.updated = ""
        self.addressLine1 = ""
        self.addressLine2 = ""
        self.suburb = ""
        self.postCode = ""
        self.state = ""
        self.country = ""
        self.assetYodleeMapping = None

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)

    @staticmethod
    def convert_from_db_model(
        db_asset: DBAsset | None,
        lumiant_rds_session: sqlalchemy.orm.Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> Asset | None:
        if db_asset is None:
            return None

        asset = Asset()
        asset.assetId = db_asset.asset_id
        asset.householdId = db_asset.household_id
        asset.clientId = db_asset.client_id
        if asset.clientId is not None:
            asset.clientFirstName = db_asset.client.first_name
            asset.clientLastName = db_asset.client.last_name
            asset.clientPreferredName = db_asset.client.preferred_name
        asset.legalEntityId = db_asset.legal_entity_id
        if asset.legalEntityId is not None:
            asset.legalEntityName = db_asset.legal_entity.name  # type: ignore
        asset.beneficiaryClientId = db_asset.beneficiary_client_id
        asset.beneficiaryLegalEntityId = db_asset.beneficiary_legal_entity_id
        asset.otherBeneficiary = db_asset.other_beneficiary
        asset.relationshipAsset = db_asset.relationship_asset
        asset.assetType = StringUtils.trim_to_empty(db_asset.asset_type)
        asset.superType = db_asset.super_type
        asset.pensionType = db_asset.pension_type
        asset.description = db_asset.description
        asset.accountNumber = db_asset.account_number
        asset.providerName = db_asset.provider_name
        asset.memberNumber = db_asset.member_number
        asset.balance = db_asset.balance
        asset.definedBenefitSalary = db_asset.defined_benefit_salary
        asset.definedBenefitMultiple = db_asset.defined_benefit_multiple
        asset.employeeContribution = db_asset.employee_contribution
        asset.employeeContributionBps = db_asset.employee_contribution_bps
        asset.employeeContributionType = db_asset.employee_contribution_type
        asset.employeeContributionCap = db_asset.employee_contribution_cap
        asset.employeeContributionCapBps = db_asset.employee_contribution_cap_bps
        asset.employerContribution = db_asset.employer_contribution
        asset.employerContributionBps = db_asset.employer_contribution_bps
        asset.employerContributionCap = db_asset.employer_contribution_cap
        asset.employerContributionCapBps = db_asset.employer_contribution_cap_bps
        asset.makesPersonalContribution = db_asset.makes_personal_contribution
        asset.annualContribution = db_asset.annual_contribution
        asset.inheritedIraType = db_asset.inherited_ira_type
        asset.deceasedOwnerDateOfBirth = SerializationUtils.convert_value_to_string(
            db_asset.deceased_owner_date_of_birth
        )
        asset.deceasedOwnerDateOfDeath = SerializationUtils.convert_value_to_string(
            db_asset.deceased_owner_date_of_death
        )
        asset.rmdTakenThisYear = db_asset.rmd_taken_this_year
        asset.previousYearBalance = db_asset.previous_year_balance
        asset.annuityTermDate = SerializationUtils.convert_value_to_string(db_asset.annuity_term_date)
        asset.deathBenefit = db_asset.death_benefit
        asset.surrenderValue = db_asset.surrender_value
        asset.centrelinkValue = db_asset.centrelink_value
        asset.isUsedLoanSecurity = db_asset.is_used_loan_security
        asset.loanSecuredAmount = db_asset.loan_secured_amount
        asset.madePersonalContribPast3y = db_asset.made_personal_contrib_past_3y
        asset.taxFreeComponent = db_asset.tax_free_component
        asset.preservationComponent = db_asset.preservation_component
        asset.makesPersonalSuperContribution = db_asset.makes_personal_super_contribution
        asset.isSalarySacrifice = db_asset.is_salary_sacrifice
        asset.superContributionAmount = db_asset.super_contribution_amount
        asset.superContributionFrequency = db_asset.super_contribution_frequency
        asset.employerPaysHigherThanMinimumSuper = db_asset.employer_pays_higher_than_minimum_super
        asset.higherThanMinimumSuperBps = db_asset.higher_than_minimum_super_bps
        asset.preRetirementRefModel = db_asset.pre_retirement_ref_model
        asset.postRetirementRefModel = db_asset.post_retirement_ref_model
        asset.feesBps = db_asset.fees_bps
        asset.feesDollar = db_asset.fees_dollar
        asset.addressId = db_asset.address_id

        if db_asset.address_id is not None:
            address_service = AddressService(lumiant_rds_session=lumiant_rds_session, auth_metadata=auth_metadata)
            address = address_service.get_address(db_asset.address_id)
            if address is not None:
                asset.addressLine1 = address.address_line_1
                asset.addressLine2 = address.address_line_2
                asset.suburb = address.suburb
                asset.postCode = address.post_code
                asset.state = address.state
                asset.country = address.country

        asset.ownOrRent = db_asset.own_or_rent
        asset.isPrimaryHome = db_asset.is_primary_home
        asset.purchasePrice = db_asset.purchase_price
        asset.purchaseDate = SerializationUtils.convert_value_to_string(db_asset.purchase_date)
        asset.growthBps = db_asset.growth_bps
        asset.currentValue = db_asset.current_value
        asset.propertyType = db_asset.property_type
        asset.rent = db_asset.rent
        asset.savingInvestmentType = db_asset.saving_investment_type
        asset.assetUse = db_asset.asset_use
        asset.assessed = db_asset.assessed
        asset.make = db_asset.make
        asset.model = db_asset.model
        asset.lastValued = SerializationUtils.convert_value_to_string(db_asset.last_valued)
        asset.superPhase = db_asset.super_phase
        asset.annuityType = db_asset.annuity_type
        asset.term = db_asset.term
        asset.maturityDate = SerializationUtils.convert_value_to_string(db_asset.maturity_date)
        asset.commutedAmount = db_asset.commuted_amount
        asset.residualValue = db_asset.residual_value
        asset.assetExemptionBps = db_asset.asset_exemption_bps
        asset.notes = db_asset.notes
        asset.clientNotes = db_asset.client_notes
        asset.partnerNotes = db_asset.partner_notes
        asset.confidentialNotes = (
            db_asset.confidential_notes if auth_metadata.is_staff() or auth_metadata.is_lumiant_elevated_user() else ""
        )
        asset.displayName = db_asset.display_name
        asset.displayOwnership = db_asset.display_ownership
        asset.externalId = db_asset.external_id  # type: ignore
        asset.externalSystem = db_asset.external_system  # type: ignore

        asset.assetYodleeMapping = (
            YodleeMapping.convert_from_db_model(db_asset.asset_yodlee_mapping)
            if db_asset.asset_yodlee_mapping is not None
            else None
        )

        asset.createdBy = db_asset.created_by
        asset.created = SerializationUtils.convert_value_to_string(db_asset.created)
        asset.updatedBy = db_asset.updated_by
        asset.updated = SerializationUtils.convert_value_to_string(db_asset.updated)

        return asset
