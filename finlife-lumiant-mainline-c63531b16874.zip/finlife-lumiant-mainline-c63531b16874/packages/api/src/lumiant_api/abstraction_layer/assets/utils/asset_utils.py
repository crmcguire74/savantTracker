import datetime
from typing import Any

import sqlalchemy.orm
from aws_lambda_powertools import Logger
from boto3.session import Session as Boto3Session
from sqlalchemy import and_

from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset as DBAsset
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.services.address_service import AddressService
from lumiant_api.abstraction_layer.common.utils.bool_utils import BoolUtils
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils
from lumiant_api.abstraction_layer.common.services.asset_event_publisher import publish_asset_event


def soft_delete_asset(
    lumiant_rds_session: sqlalchemy.orm.Session,
    auth_metadata: LambdaAuthorisationMetadata,
    asset_id: int,
) -> bool:
    """Soft delete an asset by ID, scoped to practice."""
    asset = (
        lumiant_rds_session.query(DBAsset)
        .join(DBHouseholdTeamMember, DBHouseholdTeamMember.household_id == DBAsset.household_id)
        .filter(
            and_(
                DBAsset.asset_id == asset_id,
                DBAsset.soft_deleted.is_not(True),
                DBHouseholdTeamMember.practice_id == auth_metadata.practice_id,
            )
        )
        .first()
    )
    if asset is None:
        return False

    asset.soft_deleted = True
    asset.updated = datetime.datetime.now(datetime.UTC)
    asset.updated_by = auth_metadata.iam_id
    lumiant_rds_session.commit()

    return True


def find_or_create_asset(
    lumiant_rds_session: sqlalchemy.orm.Session,
    auth_metadata: LambdaAuthorisationMetadata,
    asset_id: int | None,
    household_id: int,
) -> tuple[DBAsset | None, bool]:
    """
    Find existing asset by ID (with practice scoping) or create a new one.
    Returns (asset, is_create). Returns (None, False) if asset_id was given but not found.
    """
    if asset_id is not None:
        asset = (
            lumiant_rds_session.query(DBAsset)
            .join(DBHouseholdTeamMember, DBHouseholdTeamMember.household_id == DBAsset.household_id)
            .filter(
                and_(
                    DBAsset.asset_id == asset_id,
                    DBAsset.soft_deleted.is_not(True),
                    DBHouseholdTeamMember.practice_id == auth_metadata.practice_id,
                )
            )
            .first()
        )
        if asset is None:
            return None, False
        return asset, False

    asset = DBAsset()
    asset.household_id = household_id
    asset.soft_deleted = False
    asset.created = datetime.datetime.now(datetime.UTC)
    asset.created_by = auth_metadata.iam_id
    asset.updated = datetime.datetime.now(datetime.UTC)
    asset.updated_by = auth_metadata.iam_id
    lumiant_rds_session.add(asset)
    return asset, True


def finalize_asset_save(
    asset: DBAsset,
    is_create: bool,
    lumiant_rds_session: sqlalchemy.orm.Session,
    boto3_session: Boto3Session,
    auth_metadata: LambdaAuthorisationMetadata,
    logger: Logger,
    notes: str | None,
    client_notes: str | None,
    partner_notes: str | None,
    confidential_notes: str | None,
    constructed_address: str | None = None,
    address_line_1: str | None = None,
    address_line_2: str | None = None,
    suburb: str | None = None,
    post_code: str | None = None,
    state: str | None = None,
    country: str | None = None,
) -> DBAsset:
    """
    Handle the common tail of _save_asset: address creation, notes, timestamps, commit, event publishing.
    """
    # Address handling
    address_service = AddressService(lumiant_rds_session=lumiant_rds_session, auth_metadata=auth_metadata)
    if asset.address_id is not None:
        address_service.update_address(
            address_id=asset.address_id,
            constructed_address=constructed_address,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            suburb=suburb,
            post_code=post_code,
            state=state,
            country=country,
        )
    else:
        new_address_id = address_service.create_address(
            constructed_address=constructed_address,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            suburb=suburb,
            post_code=post_code,
            state=state,
            country=country,
        )
        asset.address_id = new_address_id

    # Notes (conditional assignment)
    if notes is not None:
        asset.notes = StringUtils.trim_to_empty(notes)
    if client_notes is not None:
        asset.client_notes = StringUtils.trim_to_empty(client_notes)
    if partner_notes is not None:
        asset.partner_notes = StringUtils.trim_to_empty(partner_notes)
    if confidential_notes is not None and (
        auth_metadata.is_staff() or auth_metadata.is_lumiant_elevated_user() or auth_metadata.is_api_read_write_user()
    ):
        asset.confidential_notes = StringUtils.trim_to_empty(confidential_notes)

    asset.display_ownership = None

    asset.updated = datetime.datetime.now(datetime.UTC)
    asset.updated_by = auth_metadata.iam_id

    lumiant_rds_session.commit()

    # Publish asset event
    publish_asset_event(
        asset=asset,
        is_create=is_create,
        lumiant_rds_session=lumiant_rds_session,
        boto3_session=boto3_session,
        auth_metadata=auth_metadata,
        logger=logger,
    )

    return asset


def convert_row_to_dict(
    row: tuple[Any, ...],
    field_names: list[str],
    id_field_name: str,
) -> dict[str, Any]:
    """
    Convert a raw DB tuple to a dict with common transformations:
    - Rename asset_id to service-specific ID field
    - Serialize created/updated timestamps
    - Parse soft_deleted as bool
    """
    row_dict = dict(zip(field_names, row, strict=False))

    # Rename asset_id to service-specific ID
    row_dict[id_field_name] = row_dict.get("asset_id")
    row_dict.pop("asset_id", None)

    # Serialize timestamps
    row_dict["created"] = SerializationUtils.convert_value_to_string(row_dict["created"])
    row_dict["updated"] = SerializationUtils.convert_value_to_string(row_dict["updated"])

    # Parse soft_deleted
    row_dict["soft_deleted"] = BoolUtils.parse(row_dict.get("soft_deleted"))

    return row_dict
