import datetime
from typing import Any

import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from sqlalchemy import and_, func

from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset as DBAsset
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.utils.bool_utils import BoolUtils
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils
from lumiant_api.abstraction_layer.assets.utils.asset_utils import (
    convert_row_to_dict,
    finalize_asset_save,
    find_or_create_asset,
    soft_delete_asset,
)


class SuperannuationApiService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Superannuation API (For AU only)
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(child=True, service="SuperannuationApi")
    tracer = Tracer(service="SuperannuationApi")

    lumiant_rds_session: sqlalchemy.orm.Session
    boto3_session: Boto3Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Boto3Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def get_superannuation_asset(self, superannuation_id: int, household_id: int) -> dict[str, Any] | None:
        """
        Get a single financial asset of type Superannuation by ID
        Query joins to HouseholdTeamMember to verify that asset is within practice.
        """
        asset = (
            self.lumiant_rds_session.query(DBAsset)
            .join(DBHouseholdTeamMember, DBHouseholdTeamMember.household_id == DBAsset.household_id)
            .filter(
                and_(
                    DBAsset.asset_id == superannuation_id,
                    DBAsset.household_id == household_id,
                    DBAsset.asset_type == "S",
                    DBAsset.soft_deleted.is_not(True),
                    DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id,
                )
            )
            .with_entities(*SuperannuationApiService._get_superannuation_asset_fields())
            .first()
        )

        if asset is None:
            return None

        # Convert to API format with api_asset_type
        api_assets = self._convert_to_api_format([asset])
        return api_assets[0] if api_assets else None

    def get_superannuation_assets(
        self,
        household_id: int | None,
        page: int | None,
        page_size: int | None,
        client_id: int | None = None,
        updated_after: datetime.datetime | None = None,
        include_deleted: bool = False,
    ) -> tuple[list[dict[str, Any]], int]:
        """
        Get paginated list of superannuation assets
        """
        page = page if page is not None and page > 0 else 1
        page_size = page_size if page_size is not None and page_size > 0 else 200

        offset = (page - 1) * page_size

        filters = []

        if household_id is not None:
            filters.append(DBAsset.household_id == household_id)

        if client_id is not None:
            filters.append(DBAsset.client_id == client_id)

        if updated_after is not None:
            filters.append(DBAsset.updated >= updated_after)

        if not include_deleted:
            filters.append(DBAsset.soft_deleted.is_(False))

        # Filter Superannuation assets only.
        filters.append(DBAsset.asset_type == "S")

        # Always join to HouseholdTeamMember first to enforce practice scoping
        base_query = (
            self.lumiant_rds_session.query(DBAsset)
            .join(DBHouseholdTeamMember, DBAsset.household_id == DBHouseholdTeamMember.household_id)
            .distinct()
        )

        # Add practice filter to the filters list
        filters.append(DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id)

        # Apply all filters
        for filter_condition in filters:
            base_query = base_query.filter(filter_condition)

        assets = (
            base_query.with_entities(*SuperannuationApiService._get_superannuation_asset_fields())
            .offset(offset)
            .limit(page_size)
            .all()
        )

        # Count query - needs the same joins as the main query
        count_query = self.lumiant_rds_session.query(func.count(DBAsset.asset_id.distinct())).join(
            DBHouseholdTeamMember, DBAsset.household_id == DBHouseholdTeamMember.household_id
        )
        for filter_condition in filters:
            count_query = count_query.filter(filter_condition)

        total_count = count_query.scalar()

        # Convert to API format with api_asset_type
        api_assets = self._convert_to_api_format(assets)

        return api_assets, total_count

    def save(
        self,
        superannuation_id: int | None,
        super_type: str,
        household_id: int,
        client_id: int | None = None,
        legal_entity_id: int | None = None,
        display_name: str | None = None,
        balance: float | None = None,
        centrelink_value: float | None = None,
        fees_dollar: float | None = None,
        fees_bps: float | None = None,
        employee_contribution_type: str | None = None,
        employee_contribution: float | None = None,
        employee_contribution_bps: float | None = None,
        employee_contribution_cap: float | None = None,
        employee_contribution_cap_bps: float | None = None,
        employer_contribution: float | None = None,
        employer_contribution_bps: float | None = None,
        employer_contribution_cap: float | None = None,
        employer_contribution_cap_bps: float | None = None,
        defined_benefit_multiple: float | None = None,
        defined_benefit_salary: float | None = None,
        provider_name: str | None = None,
        member_number: str | None = None,
        made_personal_contrib_past_3y: bool | None = None,
        description: str | None = None,
        tax_free_component: float | None = None,
        preservation_component: float | None = None,
        makes_personal_super_contribution: bool | None = None,
        is_salary_sacrifice: bool | None = None,
        super_contribution_amount: float | None = None,
        super_contribution_frequency: str | None = None,
        employer_pays_higher_than_minimum_super: bool | None = None,
        is_used_loan_security: bool | None = None,
        loan_secured_amount: float | None = None,
        notes: str | None = None,
        confidential_notes: str | None = None,
        client_notes: str | None = None,
        partner_notes: str | None = None,
    ) -> dict[str, Any] | None:
        """
        Save (create or update) a superannuation asset
        """
        # Map API enum values to database char codes
        db_super_type = self._map_api_super_type_to_db(super_type)
        db_employee_contribution_type = self._map_api_employee_contribution_type_to_db(employee_contribution_type)
        db_super_contribution_frequency = self._map_api_super_contribution_frequency_to_db(super_contribution_frequency)

        db_asset = self._save_asset(
            asset_id=superannuation_id,
            household_id=household_id,
            client_id=client_id,
            legal_entity_id=legal_entity_id,
            super_type=db_super_type,
            description=description,
            provider_name=provider_name,
            member_number=member_number,
            balance=balance,
            defined_benefit_salary=defined_benefit_salary,
            defined_benefit_multiple=defined_benefit_multiple,
            employee_contribution=employee_contribution,
            employee_contribution_bps=employee_contribution_bps,
            employee_contribution_type=db_employee_contribution_type,
            employee_contribution_cap=employee_contribution_cap,
            employee_contribution_cap_bps=employee_contribution_cap_bps,
            employer_contribution=employer_contribution,
            employer_contribution_bps=employer_contribution_bps,
            employer_contribution_cap=employer_contribution_cap,
            employer_contribution_cap_bps=employer_contribution_cap_bps,
            centrelink_value=centrelink_value,
            is_used_loan_security=is_used_loan_security,
            loan_secured_amount=loan_secured_amount,
            made_personal_contrib_past_3y=made_personal_contrib_past_3y,
            tax_free_component=tax_free_component,
            preservation_component=preservation_component,
            makes_personal_super_contribution=makes_personal_super_contribution,
            is_salary_sacrifice=is_salary_sacrifice,
            super_contribution_amount=super_contribution_amount,
            super_contribution_frequency=db_super_contribution_frequency,
            employer_pays_higher_than_minimum_super=employer_pays_higher_than_minimum_super,
            fees_bps=fees_bps,
            fees_dollar=fees_dollar,
            display_name=display_name,
            notes=notes,
            client_notes=client_notes,
            partner_notes=partner_notes,
            confidential_notes=confidential_notes,
        )

        if db_asset is None:
            return None

        return self._convert_db_superannuation_asset_to_api_format(db_asset)

    def delete(self, superannuation_id: int) -> bool:
        """
        Soft Delete a superannuation asset
        """
        return soft_delete_asset(self.lumiant_rds_session, self.auth_metadata, superannuation_id)

    def _save_asset(
        self,
        asset_id: int | None,
        household_id: int,
        client_id: int | None,
        legal_entity_id: int | None,
        super_type: str | None,
        description: str | None,
        provider_name: str | None,
        member_number: str | None,
        balance: float | None,
        defined_benefit_salary: float | None,
        defined_benefit_multiple: float | None,
        employee_contribution: float | None,
        employee_contribution_bps: float | None,
        employee_contribution_type: str | None,
        employee_contribution_cap: float | None,
        employee_contribution_cap_bps: float | None,
        employer_contribution: float | None,
        employer_contribution_bps: float | None,
        employer_contribution_cap: float | None,
        employer_contribution_cap_bps: float | None,
        centrelink_value: float | None,
        is_used_loan_security: bool | None,
        loan_secured_amount: float | None,
        made_personal_contrib_past_3y: bool | None,
        tax_free_component: float | None,
        preservation_component: float | None,
        makes_personal_super_contribution: bool | None,
        is_salary_sacrifice: bool | None,
        super_contribution_amount: float | None,
        super_contribution_frequency: str | None,
        employer_pays_higher_than_minimum_super: bool | None,
        fees_bps: float | None,
        fees_dollar: float | None,
        display_name: str | None,
        notes: str | None,
        client_notes: str | None,
        partner_notes: str | None,
        confidential_notes: str | None,
    ) -> DBAsset | None:
        """Create or update a superannuation asset record via direct ORM operations."""
        asset, is_create = find_or_create_asset(self.lumiant_rds_session, self.auth_metadata, asset_id, household_id)
        if asset is None:
            return None

        # Ownership
        asset.client_id = client_id
        asset.legal_entity_id = legal_entity_id
        asset.beneficiary_client_id = None
        asset.beneficiary_legal_entity_id = None
        asset.relationship_asset = None

        # Type fields
        asset.asset_type = "S"
        asset.super_type = super_type
        asset.pension_type = None
        asset.saving_investment_type = None

        # Basic fields
        asset.description = StringUtils.trim_to_empty(description)
        asset.account_number = None
        asset.provider_name = StringUtils.trim_to_empty(provider_name)
        asset.member_number = member_number
        asset.balance = balance

        # Superannuation-specific fields
        asset.defined_benefit_salary = defined_benefit_salary
        asset.defined_benefit_multiple = defined_benefit_multiple
        asset.employee_contribution = employee_contribution
        asset.employee_contribution_bps = employee_contribution_bps
        asset.employee_contribution_type = employee_contribution_type
        asset.employee_contribution_cap = employee_contribution_cap
        asset.employee_contribution_cap_bps = employee_contribution_cap_bps
        asset.employer_contribution = employer_contribution
        asset.employer_contribution_bps = employer_contribution_bps
        asset.employer_contribution_cap = employer_contribution_cap
        asset.employer_contribution_cap_bps = employer_contribution_cap_bps
        asset.makes_personal_contribution = None
        asset.annual_contribution = None
        asset.inherited_ira_type = None
        asset.deceased_owner_date_of_birth = None
        asset.deceased_owner_date_of_death = None
        asset.rmd_taken_this_year = None
        asset.previous_year_balance = None
        asset.annuity_term_date = None
        asset.death_benefit = None
        asset.surrender_value = None
        asset.centrelink_value = centrelink_value
        asset.is_used_loan_security = is_used_loan_security
        asset.loan_secured_amount = loan_secured_amount
        asset.made_personal_contrib_past_3y = made_personal_contrib_past_3y
        asset.tax_free_component = tax_free_component
        asset.preservation_component = preservation_component
        asset.makes_personal_super_contribution = makes_personal_super_contribution
        asset.is_salary_sacrifice = is_salary_sacrifice
        asset.super_contribution_amount = super_contribution_amount
        asset.super_contribution_frequency = super_contribution_frequency
        asset.employer_pays_higher_than_minimum_super = employer_pays_higher_than_minimum_super
        asset.higher_than_minimum_super_bps = None
        asset.pre_retirement_ref_model = None
        asset.post_retirement_ref_model = None
        asset.fees_bps = fees_bps
        asset.fees_dollar = fees_dollar

        # Property fields - not applicable
        asset.own_or_rent = None
        asset.is_primary_home = None
        asset.purchase_price = None
        asset.purchase_date = None
        asset.growth_bps = None
        asset.current_value = None
        asset.property_type = None
        asset.rent = None
        asset.asset_use = None
        asset.assessed = None
        asset.make = None
        asset.model = None
        asset.last_valued = None
        asset.super_phase = None
        asset.annuity_type = None
        asset.term = None
        asset.maturity_date = None
        asset.commuted_amount = None
        asset.residual_value = None
        asset.asset_exemption_bps = None

        # display_name is conditionally set (only when not None)
        if display_name is not None:
            asset.display_name = StringUtils.trim_to_empty(display_name)

        return finalize_asset_save(
            asset=asset,
            is_create=is_create,
            lumiant_rds_session=self.lumiant_rds_session,
            boto3_session=self.boto3_session,
            auth_metadata=self.auth_metadata,
            logger=self.logger,
            notes=notes,
            client_notes=client_notes,
            partner_notes=partner_notes,
            confidential_notes=confidential_notes,
        )

    @staticmethod
    def _get_superannuation_asset_fields():
        """
        Get field list for superannuation assets (AU only)
        """
        return [
            DBAsset.asset_id,
            DBAsset.household_id,
            DBAsset.client_id,
            DBAsset.legal_entity_id,
            DBAsset.super_type,
            DBAsset.display_name,
            DBAsset.balance,
            DBAsset.centrelink_value,
            DBAsset.fees_dollar,
            DBAsset.fees_bps,
            DBAsset.employee_contribution_type,
            DBAsset.employee_contribution,
            DBAsset.employee_contribution_bps,
            DBAsset.employee_contribution_cap,
            DBAsset.employee_contribution_cap_bps,
            DBAsset.employer_contribution,
            DBAsset.employer_contribution_bps,
            DBAsset.employer_contribution_cap,
            DBAsset.employer_contribution_cap_bps,
            DBAsset.defined_benefit_multiple,
            DBAsset.defined_benefit_salary,
            DBAsset.provider_name,
            DBAsset.member_number,
            DBAsset.made_personal_contrib_past_3y,
            DBAsset.description,
            DBAsset.tax_free_component,
            DBAsset.preservation_component,
            DBAsset.makes_personal_super_contribution,
            DBAsset.is_salary_sacrifice,
            DBAsset.super_contribution_amount,
            DBAsset.super_contribution_frequency,
            DBAsset.employer_pays_higher_than_minimum_super,
            DBAsset.is_used_loan_security,
            DBAsset.loan_secured_amount,
            DBAsset.notes,
            DBAsset.confidential_notes,
            DBAsset.client_notes,
            DBAsset.partner_notes,
            DBAsset.created,
            DBAsset.updated,
            DBAsset.soft_deleted,
        ]

    def _convert_to_api_format(self, raw_results: list[tuple]) -> list[dict[str, Any]]:
        """
        Convert raw database results to API format with api_asset_type
        Removes internal type fields and adds api_asset_type
        """
        if not raw_results:
            return []

        api_results = []
        field_names = [field.key for field in self._get_superannuation_asset_fields()]

        for row in raw_results:
            row_dict = convert_row_to_dict(row, field_names, "superannuation_id")

            # Map internal types to API enums
            api_super_type = self._map_db_super_type_to_api(row_dict.get("super_type"))
            api_employee_contribution_type = self._map_db_employee_contribution_type_to_api(
                row_dict.get("employee_contribution_type")
            )
            api_super_contribution_frequency = self._map_db_super_contribution_frequency_to_api(
                row_dict.get("super_contribution_frequency")
            )

            # Remove internal type fields
            row_dict.pop("super_type", None)

            # Update row_dict with API enum values
            if api_super_type is not None:
                row_dict["super_type"] = api_super_type
            if api_employee_contribution_type is not None:
                row_dict["employee_contribution_type"] = api_employee_contribution_type
            if api_super_contribution_frequency is not None:
                row_dict["super_contribution_frequency"] = api_super_contribution_frequency

            api_results.append(row_dict)

        return api_results

    def _convert_db_superannuation_asset_to_api_format(self, db_asset: DBAsset) -> dict[str, Any]:
        """
        Convert a single DB Asset object to API format for superannuation
        """
        # Map internal enums to API enums
        api_super_type = self._map_db_super_type_to_api(db_asset.super_type)
        api_employee_contribution_type = self._map_db_employee_contribution_type_to_api(
            db_asset.employee_contribution_type
        )
        api_super_contribution_frequency = self._map_db_super_contribution_frequency_to_api(
            db_asset.super_contribution_frequency
        )

        result = {
            "superannuation_id": db_asset.asset_id,
            "household_id": db_asset.household_id,
            "client_id": db_asset.client_id,
            "legal_entity_id": db_asset.legal_entity_id,
            "display_name": db_asset.display_name,
            "balance": float(db_asset.balance) if db_asset.balance is not None else None,
            "centrelink_value": float(db_asset.centrelink_value) if db_asset.centrelink_value else None,
            "fees_dollar": float(db_asset.fees_dollar) if db_asset.fees_dollar else None,
            "fees_bps": float(db_asset.fees_bps) if db_asset.fees_bps else None,
            "employee_contribution": float(db_asset.employee_contribution) if db_asset.employee_contribution else None,
            "employee_contribution_bps": float(db_asset.employee_contribution_bps)
            if db_asset.employee_contribution_bps
            else None,
            "employee_contribution_cap": float(db_asset.employee_contribution_cap)
            if db_asset.employee_contribution_cap
            else None,
            "employee_contribution_cap_bps": float(db_asset.employee_contribution_cap_bps)
            if db_asset.employee_contribution_cap_bps
            else None,
            "employer_contribution": float(db_asset.employer_contribution) if db_asset.employer_contribution else None,
            "employer_contribution_bps": float(db_asset.employer_contribution_bps)
            if db_asset.employer_contribution_bps
            else None,
            "employer_contribution_cap": float(db_asset.employer_contribution_cap)
            if db_asset.employer_contribution_cap
            else None,
            "employer_contribution_cap_bps": float(db_asset.employer_contribution_cap_bps)
            if db_asset.employer_contribution_cap_bps
            else None,
            "defined_benefit_multiple": float(db_asset.defined_benefit_multiple)
            if db_asset.defined_benefit_multiple
            else None,
            "defined_benefit_salary": float(db_asset.defined_benefit_salary)
            if db_asset.defined_benefit_salary
            else None,
            "provider_name": db_asset.provider_name,
            "member_number": db_asset.member_number,
            "made_personal_contrib_past_3y": db_asset.made_personal_contrib_past_3y,
            "description": db_asset.description,
            "tax_free_component": float(db_asset.tax_free_component) if db_asset.tax_free_component else None,
            "preservation_component": float(db_asset.preservation_component)
            if db_asset.preservation_component
            else None,
            "makes_personal_super_contribution": db_asset.makes_personal_super_contribution,
            "is_salary_sacrifice": db_asset.is_salary_sacrifice,
            "super_contribution_amount": float(db_asset.super_contribution_amount)
            if db_asset.super_contribution_amount
            else None,
            "employer_pays_higher_than_minimum_super": db_asset.employer_pays_higher_than_minimum_super,
            "is_used_loan_security": db_asset.is_used_loan_security,
            "loan_secured_amount": float(db_asset.loan_secured_amount) if db_asset.loan_secured_amount else None,
            "notes": db_asset.notes if db_asset.notes is not None else None,
            "confidential_notes": db_asset.confidential_notes if db_asset.confidential_notes is not None else None,
            "client_notes": db_asset.client_notes if db_asset.client_notes is not None else None,
            "partner_notes": db_asset.partner_notes if db_asset.partner_notes is not None else None,
            "created": SerializationUtils.convert_value_to_string(db_asset.created),
            "updated": SerializationUtils.convert_value_to_string(db_asset.updated),
            "soft_deleted": BoolUtils.parse(db_asset.soft_deleted),
        }

        # Add mapped enum values
        if api_super_type is not None:
            result["super_type"] = api_super_type
        if api_employee_contribution_type is not None:
            result["employee_contribution_type"] = api_employee_contribution_type
        if api_super_contribution_frequency is not None:
            result["super_contribution_frequency"] = api_super_contribution_frequency

        return result

    @staticmethod
    def _map_db_super_type_to_api(db_super_type: str | None) -> str | None:
        """
        Map database super_type single char code to API enum
        A=ACCUMULATION, D=DEFINED_BENEFIT, P=PENSION, S=SUPERANNUATION
        """
        if db_super_type is None:
            return None

        super_type_mapping = {"A": "ACCUMULATION", "D": "DEFINED_BENEFIT", "P": "PENSION", "U": "SUPERANNUATION"}

        if db_super_type not in super_type_mapping:
            raise ValueError(f"Unknown database super type: {db_super_type}")

        return super_type_mapping[db_super_type]

    @staticmethod
    def _map_db_employee_contribution_type_to_api(db_contribution_type: str | None) -> str | None:
        """
        Map database employee_contribution_type to API enum
        P=PRE_TAX, X=POST_TAX
        """
        if db_contribution_type is None:
            return None

        contribution_type_mapping = {"P": "PRE_TAX", "X": "POST_TAX"}

        if db_contribution_type not in contribution_type_mapping:
            raise ValueError(f"Unknown database employee contribution type: {db_contribution_type}")

        return contribution_type_mapping[db_contribution_type]

    @staticmethod
    def _map_db_super_contribution_frequency_to_api(db_frequency: str | None) -> str | None:
        """
        Map database super_contribution_frequency to API enum
        W=WEEKLY, F=BI_WEEKLY, M=MONTHLY, B=BI_MONTHLY, Q=QUARTERLY, H=HALF_YEARLY, A=ANNUALLY
        """
        if db_frequency is None:
            return None

        frequency_mapping = {
            "W": "WEEKLY",
            "F": "BI_WEEKLY",
            "M": "MONTHLY",
            "B": "BI_MONTHLY",
            "Q": "QUARTERLY",
            "H": "HALF_YEARLY",
            "A": "ANNUALLY",
        }

        if db_frequency not in frequency_mapping:
            raise ValueError(f"Unknown database super contribution frequency: {db_frequency}")

        return frequency_mapping[db_frequency]

    @staticmethod
    def _map_api_super_type_to_db(api_super_type: str | None) -> str | None:
        """
        Map API super_type enum to database single char code
        ACCUMULATION=A, DEFINED_BENEFIT=D, PENSION=P, SUPERANNUATION=S
        """
        if api_super_type is None:
            return None

        api_to_db_mapping = {"ACCUMULATION": "A", "DEFINED_BENEFIT": "D", "PENSION": "P", "SUPERANNUATION": "U"}

        if api_super_type not in api_to_db_mapping:
            raise ValueError(f"Unknown API super type: {api_super_type}")

        return api_to_db_mapping[api_super_type]

    @staticmethod
    def _map_api_employee_contribution_type_to_db(api_contribution_type: str | None) -> str | None:
        """
        Map API employee_contribution_type enum to database char code
        PRE_TAX=P, POST_TAX=X
        """
        if api_contribution_type is None:
            return None

        api_to_db_mapping = {"PRE_TAX": "P", "POST_TAX": "X"}

        if api_contribution_type not in api_to_db_mapping:
            raise ValueError(f"Unknown API employee contribution type: {api_contribution_type}")

        return api_to_db_mapping[api_contribution_type]

    @staticmethod
    def _map_api_super_contribution_frequency_to_db(api_frequency: str | None) -> str | None:
        """
        Map API super_contribution_frequency enum to database char code
        WEEKLY=W, BI_WEEKLY=F, MONTHLY=M, BI_MONTHLY=B, QUARTERLY=Q, HALF_YEARLY=H, ANNUALLY=A
        """
        if api_frequency is None:
            return None

        api_to_db_mapping = {
            "WEEKLY": "W",
            "BI_WEEKLY": "F",
            "MONTHLY": "M",
            "BI_MONTHLY": "B",
            "QUARTERLY": "Q",
            "HALF_YEARLY": "H",
            "ANNUALLY": "A",
        }

        if api_frequency not in api_to_db_mapping:
            raise ValueError(f"Unknown API super contribution frequency: {api_frequency}")

        return api_to_db_mapping[api_frequency]
