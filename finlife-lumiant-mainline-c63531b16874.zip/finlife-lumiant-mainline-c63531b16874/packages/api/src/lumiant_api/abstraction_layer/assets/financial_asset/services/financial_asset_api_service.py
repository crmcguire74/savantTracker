import datetime
from typing import Any

import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from sqlalchemy import and_, func, or_

from lumiant_api.abstraction_layer.common.constants.aws_region import AP_SOUTHEAST_2, US_EAST_1
from lumiant_api.abstraction_layer.common.database.schema.address import Address as DBAddress
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset as DBAsset
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.utils.bool_utils import BoolUtils
from lumiant_api.abstraction_layer.common.utils.date_utils import DateUtils
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils
from lumiant_api.abstraction_layer.assets.utils.asset_utils import (
    convert_row_to_dict,
    finalize_asset_save,
    find_or_create_asset,
    soft_delete_asset,
)


class FinancialAssetApiService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Financial Asset
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(child=True, service="FinancialAssetApi")
    tracer = Tracer(service="FinancialAssetApi")

    lumiant_rds_session: sqlalchemy.orm.Session
    boto3_session: Boto3Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Boto3Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def get_financial_asset(self, asset_id: int, household_id: int) -> dict[str, Any] | None:
        """
        Get a single financial asset by ID
        Query joins to HouseholdTeamMember to verify that asset is within practice.
        """
        asset = (
            self.lumiant_rds_session.query(DBAsset)
            .join(DBHouseholdTeamMember, DBHouseholdTeamMember.household_id == DBAsset.household_id)
            .outerjoin(DBAddress, DBAddress.address_id == DBAsset.address_id)
            .filter(
                and_(
                    DBAsset.asset_id == asset_id,
                    DBAsset.household_id == household_id,
                    DBAsset.soft_deleted.is_not(True),
                    DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id,
                )
            )
            .with_entities(*FinancialAssetApiService._get_financial_asset_fields(self.auth_metadata.region))
            .first()
        )

        if asset is None:
            return None

        # Convert to API format with api_asset_type
        api_assets = self._convert_to_api_format([asset], self.auth_metadata.region)
        return api_assets[0] if api_assets else None

    def get_financial_assets(
        self,
        household_id: int | None,
        page: int | None,
        page_size: int | None,
        client_id: int | None = None,
        updated_after: datetime.datetime | None = None,
        include_deleted: bool = False,
    ) -> tuple[list[dict[str, Any]], int]:
        """
        Get paginated list of financial assets
        """
        page = page if page is not None and page > 0 else 1
        page_size = page_size if page_size is not None and page_size > 0 else 200

        offset = (page - 1) * page_size

        filters = []

        if household_id is not None:
            filters.append(DBAsset.household_id == household_id)

        if client_id is not None:
            filters.append(DBAsset.client_id == client_id)

        if updated_after is not None:
            filters.append(DBAsset.updated >= updated_after)

        if not include_deleted:
            filters.append(DBAsset.soft_deleted.is_(False))

        # Only include financial assets that we have mappings for
        financial_asset_filters = FinancialAssetApiService._get_financial_asset_filters(self.auth_metadata.region)
        filters.append(financial_asset_filters)

        # Always join to HouseholdTeamMember first to enforce practice scoping
        base_query = (
            self.lumiant_rds_session.query(DBAsset)
            .join(DBHouseholdTeamMember, DBAsset.household_id == DBHouseholdTeamMember.household_id)
            .outerjoin(DBAddress, DBAddress.address_id == DBAsset.address_id)
            .distinct()
        )

        # Add practice filter to the filters list
        filters.append(DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id)

        # Apply all filters
        for filter_condition in filters:
            base_query = base_query.filter(filter_condition)

        assets = (
            base_query.with_entities(*FinancialAssetApiService._get_financial_asset_fields(self.auth_metadata.region))
            .offset(offset)
            .limit(page_size)
            .all()
        )

        # Count query - needs the same joins as the main query
        count_query = self.lumiant_rds_session.query(func.count(DBAsset.asset_id.distinct())).join(
            DBHouseholdTeamMember, DBAsset.household_id == DBHouseholdTeamMember.household_id
        )
        for filter_condition in filters:
            count_query = count_query.filter(filter_condition)
        total_count = count_query.scalar()

        # Convert to API format with api_asset_type
        api_assets = self._convert_to_api_format(assets, self.auth_metadata.region)

        return api_assets, total_count

    def save(
        self,
        financial_asset_id: int | None,
        api_asset_type: str,
        household_id: int,
        client_id: int | None = None,
        legal_entity_id: int | None = None,
        provider_name: str | None = None,
        account_number: str | None = None,
        balance: float | None = None,
        current_value: float | None = None,
        description: str | None = None,
        constructed_address: str | None = None,
        address_line_1: str | None = None,
        address_line_2: str | None = None,
        suburb: str | None = None,
        post_code: str | None = None,
        state: str | None = None,
        country: str | None = None,
        # US specific fields
        makes_personal_contribution: bool | None = None,
        beneficiary_client_id: int | None = None,
        fees_bps: float | None = None,
        relationship_asset: str | None = None,
        # AU specific fields
        centrelink_value: float | None = None,
        is_used_loan_security: bool | None = None,
        loan_secured_amount: float | None = None,
        annuity_type: str | None = None,
        purchase_price: float | None = None,
        purchase_date: datetime.date | None = None,
        term: int | None = None,
        asset_exemption_bps: float | None = None,
        commuted_amount: float | None = None,
        residual_value: float | None = None,
        member_number: str | None = None,
        # Common fields
        notes: str | None = None,
        confidential_notes: str | None = None,
        client_notes: str | None = None,
        partner_notes: str | None = None,
    ) -> dict[str, Any] | None:
        """
        Save (create or update) a financial asset
        """
        # (asset_type, saving_investment_type, super_type, annuity_type)
        asset_type_tuple = FinancialAssetApiService.map_asset_type_inbound(
            api_asset_type=api_asset_type, region=self.auth_metadata.region
        )

        # Map annuity_type enum to database char code
        db_annuity_type = FinancialAssetApiService._map_annuity_type_to_db(annuity_type)

        db_asset = self._save_asset(
            asset_id=financial_asset_id,
            household_id=household_id,
            client_id=client_id,
            legal_entity_id=legal_entity_id,
            beneficiary_client_id=beneficiary_client_id,
            relationship_asset=relationship_asset,
            asset_type=asset_type_tuple[0],
            super_type=asset_type_tuple[2],
            saving_investment_type=asset_type_tuple[1],
            description=description,
            account_number=account_number,
            provider_name=provider_name,
            member_number=member_number,
            balance=balance,
            makes_personal_contribution=makes_personal_contribution,
            centrelink_value=centrelink_value,
            is_used_loan_security=is_used_loan_security,
            loan_secured_amount=loan_secured_amount,
            fees_bps=fees_bps,
            purchase_price=purchase_price,
            purchase_date=purchase_date,
            current_value=current_value,
            annuity_type=db_annuity_type,
            term=term,
            commuted_amount=commuted_amount,
            residual_value=residual_value,
            asset_exemption_bps=asset_exemption_bps,
            notes=notes,
            client_notes=client_notes,
            partner_notes=partner_notes,
            confidential_notes=confidential_notes,
            constructed_address=constructed_address,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            suburb=suburb,
            post_code=post_code,
            state=state,
            country=country,
        )

        if db_asset is None:
            return None

        return self._convert_db_asset_to_api_format(db_asset)

    def delete(self, financial_asset_id: int) -> bool:
        """
        Soft Delete a financial asset
        """
        return soft_delete_asset(self.lumiant_rds_session, self.auth_metadata, financial_asset_id)

    def _save_asset(
        self,
        asset_id: int | None,
        household_id: int,
        client_id: int | None,
        legal_entity_id: int | None,
        beneficiary_client_id: int | None,
        relationship_asset: str | None,
        asset_type: str,
        super_type: str | None,
        saving_investment_type: str | None,
        description: str | None,
        account_number: str | None,
        provider_name: str | None,
        member_number: str | None,
        balance: float | None,
        makes_personal_contribution: bool | None,
        centrelink_value: float | None,
        is_used_loan_security: bool | None,
        loan_secured_amount: float | None,
        fees_bps: float | None,
        purchase_price: float | None,
        purchase_date: datetime.date | None,
        current_value: float | None,
        annuity_type: str | None,
        term: int | None,
        commuted_amount: float | None,
        residual_value: float | None,
        asset_exemption_bps: float | None,
        notes: str | None,
        client_notes: str | None,
        partner_notes: str | None,
        confidential_notes: str | None,
        constructed_address: str | None,
        address_line_1: str | None,
        address_line_2: str | None,
        suburb: str | None,
        post_code: str | None,
        state: str | None,
        country: str | None,
    ) -> DBAsset | None:
        """Create or update a financial asset record via direct ORM operations."""
        asset, is_create = find_or_create_asset(self.lumiant_rds_session, self.auth_metadata, asset_id, household_id)
        if asset is None:
            return None

        # Ownership
        asset.client_id = client_id
        asset.legal_entity_id = legal_entity_id
        asset.beneficiary_client_id = beneficiary_client_id
        asset.beneficiary_legal_entity_id = None
        asset.relationship_asset = relationship_asset

        # Type fields
        asset.asset_type = asset_type
        asset.super_type = super_type
        asset.pension_type = None
        asset.saving_investment_type = saving_investment_type

        # Basic fields
        asset.description = StringUtils.trim_to_empty(description)
        asset.account_number = StringUtils.trim_to_empty(account_number)
        asset.provider_name = StringUtils.trim_to_empty(provider_name)
        asset.member_number = member_number
        asset.balance = balance

        # Not applicable for financial assets
        asset.defined_benefit_salary = None
        asset.defined_benefit_multiple = None
        asset.employee_contribution = None
        asset.employee_contribution_bps = None
        asset.employee_contribution_type = None
        asset.employee_contribution_cap = None
        asset.employee_contribution_cap_bps = None
        asset.employer_contribution = None
        asset.employer_contribution_bps = None
        asset.employer_contribution_cap = None
        asset.employer_contribution_cap_bps = None
        asset.makes_personal_contribution = makes_personal_contribution
        asset.annual_contribution = None
        asset.inherited_ira_type = None
        asset.deceased_owner_date_of_birth = None
        asset.deceased_owner_date_of_death = None
        asset.rmd_taken_this_year = None
        asset.previous_year_balance = None
        asset.annuity_term_date = None
        asset.death_benefit = None
        asset.surrender_value = None
        asset.centrelink_value = centrelink_value
        asset.is_used_loan_security = is_used_loan_security
        asset.loan_secured_amount = loan_secured_amount
        asset.made_personal_contrib_past_3y = None
        asset.tax_free_component = None
        asset.preservation_component = None
        asset.makes_personal_super_contribution = None
        asset.is_salary_sacrifice = None
        asset.super_contribution_amount = None
        asset.super_contribution_frequency = None
        asset.employer_pays_higher_than_minimum_super = None
        asset.higher_than_minimum_super_bps = None
        asset.pre_retirement_ref_model = None
        asset.post_retirement_ref_model = None
        asset.fees_bps = fees_bps
        asset.fees_dollar = None

        # Property fields - not applicable
        asset.own_or_rent = None
        asset.is_primary_home = None
        asset.purchase_price = purchase_price

        if purchase_date is not None:
            if isinstance(purchase_date, datetime.date):
                asset.purchase_date = DateUtils.validate_date(purchase_date)
        else:
            asset.purchase_date = None

        asset.growth_bps = None
        asset.current_value = current_value
        asset.property_type = None
        asset.rent = None
        asset.asset_use = None
        asset.assessed = None
        asset.make = None
        asset.model = None
        asset.last_valued = None
        asset.super_phase = None
        asset.annuity_type = annuity_type
        asset.term = term
        asset.maturity_date = None
        asset.commuted_amount = commuted_amount
        asset.residual_value = residual_value
        asset.asset_exemption_bps = asset_exemption_bps

        return finalize_asset_save(
            asset=asset,
            is_create=is_create,
            lumiant_rds_session=self.lumiant_rds_session,
            boto3_session=self.boto3_session,
            auth_metadata=self.auth_metadata,
            logger=self.logger,
            notes=notes,
            client_notes=client_notes,
            partner_notes=partner_notes,
            confidential_notes=confidential_notes,
            constructed_address=constructed_address,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            suburb=suburb,
            post_code=post_code,
            state=state,
            country=country,
        )

    @staticmethod
    def _get_financial_asset_filters(region: str):
        """
        Get SQLAlchemy filter for financial assets based on region mappings
        """
        if region == US_EAST_1:
            # US financial asset combinations
            us_conditions = [
                # Investment type assets
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "S"),  # SAVINGS_ACCOUNT
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "E"),  # CHECKING_ACCOUNT
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "H"),  # HEALTH_SAVINGS_ACCOUNT
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "I"),  # INVESTMENT_ACCOUNT
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "D"),  # CERTIFICATE_OF_DEPOSIT
                and_(DBAsset.asset_type == "I", DBAsset.super_type == "E"),  # 401K
                and_(DBAsset.asset_type == "I", DBAsset.super_type == "F"),  # ROTH_401K
                and_(DBAsset.asset_type == "I", DBAsset.super_type == "G"),  # 403B
                and_(DBAsset.asset_type == "I", DBAsset.super_type == "H"),  # 457B
                and_(DBAsset.asset_type == "I", DBAsset.super_type == "I"),  # TRADITIONAL_IRA
                and_(DBAsset.asset_type == "I", DBAsset.super_type == "J"),  # ROTH_IRA
                and_(DBAsset.asset_type == "I", DBAsset.super_type == "K"),  # SIMPLE_IRA
                and_(DBAsset.asset_type == "I", DBAsset.super_type == "M"),  # INHERITED_IRA
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "A"),  # ANNUITY
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "W"),  # 529
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "X"),  # OTHER
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "V"),  # TRUST
                # Property assets
                DBAsset.asset_type == "P",  # INVESTMENT_PROPERTY
            ]
            return or_(*us_conditions)

        elif region == AP_SOUTHEAST_2:  # AU region
            au_conditions = [
                # Investment type assets
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "K"),  # BANK_ACCOUNT
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "C"),  # CASH
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "B"),  # GOVERNMENT_BOND
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "T"),  # TERM_DEPOSIT
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "O"),  # OFFSET_ACCOUNT
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "D"),  # CERTIFICATE_OF_DEPOSIT
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "I"),  # INVESTMENT_ACCOUNT
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "M"),  # MANAGED_FUND
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "R"),  # SHARE_PORTFOLIO
                and_(DBAsset.asset_type == "I", DBAsset.saving_investment_type == "V"),  # TRUST
                # Property assets
                DBAsset.asset_type == "P",  # INVESTMENT_PROPERTY
                # Annuity assets
                DBAsset.asset_type == "U",  # ANNUITY
            ]
            return or_(*au_conditions)

        else:
            raise ValueError(f"Financial asset filtering not implemented for region: {region}")

    @staticmethod
    def _get_financial_asset_fields(region: str):
        """
        Get region-specific field list for financial assets
        """
        if region == US_EAST_1:
            return [
                DBAsset.asset_id,
                DBAsset.household_id,
                DBAsset.client_id,
                DBAsset.legal_entity_id,
                DBAsset.asset_type,
                DBAsset.saving_investment_type,
                DBAsset.super_type,
                DBAsset.provider_name,
                DBAsset.account_number,
                DBAsset.balance,
                DBAsset.current_value,
                DBAsset.description,
                DBAddress.constructed_address,
                DBAddress.address_line_1,
                DBAddress.address_line_2,
                DBAddress.suburb,
                DBAddress.post_code,
                DBAddress.state,
                DBAddress.country,
                DBAsset.makes_personal_contribution,
                DBAsset.beneficiary_client_id,
                DBAsset.fees_bps,
                DBAsset.relationship_asset,
                DBAsset.notes,
                DBAsset.confidential_notes,
                DBAsset.client_notes,
                DBAsset.partner_notes,
                DBAsset.created,
                DBAsset.updated,
                DBAsset.soft_deleted,
            ]

        elif region == AP_SOUTHEAST_2:  # AU region
            return [
                DBAsset.asset_id,
                DBAsset.household_id,
                DBAsset.client_id,
                DBAsset.legal_entity_id,
                DBAsset.provider_name,
                DBAsset.account_number,
                DBAsset.balance,
                DBAsset.centrelink_value,
                DBAsset.is_used_loan_security,
                DBAsset.loan_secured_amount,
                DBAsset.current_value,
                DBAsset.description,
                DBAddress.constructed_address,
                DBAddress.address_line_1,
                DBAddress.address_line_2,
                DBAddress.suburb,
                DBAddress.post_code,
                DBAddress.state,
                DBAddress.country,
                DBAsset.annuity_type,
                DBAsset.purchase_price,
                DBAsset.purchase_date,
                DBAsset.term,
                DBAsset.asset_exemption_bps,
                DBAsset.commuted_amount,
                DBAsset.residual_value,
                DBAsset.member_number,
                DBAsset.asset_type,
                DBAsset.saving_investment_type,
                DBAsset.super_type,
                DBAsset.notes,
                DBAsset.confidential_notes,
                DBAsset.client_notes,
                DBAsset.partner_notes,
                DBAsset.created,
                DBAsset.updated,
                DBAsset.soft_deleted,
            ]

        else:
            raise ValueError(f"Financial asset fields not defined for region: {region}")

    def _convert_to_api_format(self, raw_results: list[tuple[Any, ...]], region: str):
        """
        Convert raw database results to API format with api_asset_type
        Removes internal type fields and adds api_asset_type
        """
        if not raw_results:
            return []

        api_results = []
        field_names = [field.key for field in self._get_financial_asset_fields(region)]

        for row in raw_results:
            row_dict = convert_row_to_dict(row, field_names, "financial_asset_id")

            # Map internal types to api_asset_type
            asset_type_value = row_dict.get("asset_type")
            if asset_type_value is None:
                continue  # Skip rows without asset_type
            api_asset_type = self.map_asset_type_outbound(
                asset_type=asset_type_value,
                saving_investment_type=row_dict.get("saving_investment_type"),
                super_type=row_dict.get("super_type"),
                annuity_type=row_dict.get("annuity_type"),
                region=region,
            )

            # Map database annuity_type to API enum
            db_annuity_type = row_dict.get("annuity_type")
            api_annuity_type = self._map_db_annuity_type_to_api(db_annuity_type)

            # Remove internal type fields
            row_dict.pop("asset_type", None)
            row_dict.pop("saving_investment_type", None)
            row_dict.pop("super_type", None)
            row_dict.pop("annuity_type", None)

            # Add api_asset_type and api annuity_type
            row_dict["api_asset_type"] = api_asset_type
            if api_annuity_type is not None:
                row_dict["annuity_type"] = api_annuity_type

            # apply serialisation to date and datetime fields
            if self.auth_metadata.region == AP_SOUTHEAST_2:
                row_dict["purchase_date"] = SerializationUtils.convert_value_to_string(row_dict["purchase_date"])

            row_dict["created"] = SerializationUtils.convert_value_to_string(row_dict["created"])
            row_dict["updated"] = SerializationUtils.convert_value_to_string(row_dict["updated"])

            row_dict["soft_deleted"] = BoolUtils.parse(row_dict.get("soft_deleted"))

            api_results.append(row_dict)

        return api_results

    def _convert_db_asset_to_api_format(self, db_asset: DBAsset) -> dict[str, Any]:
        """
        Convert a single DB Asset object to API format
        """
        # Map internal types to api_asset_type
        api_asset_type = self.map_asset_type_outbound(
            asset_type=db_asset.asset_type,
            saving_investment_type=db_asset.saving_investment_type,
            super_type=db_asset.super_type,
            annuity_type=db_asset.annuity_type,
            region=self.auth_metadata.region,
        )

        # Map database annuity_type to API enum
        api_annuity_type = self._map_db_annuity_type_to_api(db_asset.annuity_type)

        return {
            "financial_asset_id": db_asset.asset_id,
            "api_asset_type": api_asset_type,
            "household_id": db_asset.household_id,
            "client_id": db_asset.client_id,
            "legal_entity_id": db_asset.legal_entity_id,
            "provider_name": db_asset.provider_name,
            "account_number": db_asset.account_number,
            "balance": float(db_asset.balance) if db_asset.balance is not None else None,
            "current_value": float(db_asset.current_value) if db_asset.current_value is not None else None,
            "description": db_asset.description,
            "constructed_address": db_asset.address.constructed_address if db_asset.address else None,
            "address_line_1": db_asset.address.address_line_1 if db_asset.address else None,
            "address_line_2": db_asset.address.address_line_2 if db_asset.address else None,
            "suburb": db_asset.address.suburb if db_asset.address else None,
            "post_code": db_asset.address.post_code if db_asset.address else None,
            "state": db_asset.address.state if db_asset.address else None,
            "country": db_asset.address.country if db_asset.address else None,
            "makes_personal_contribution": db_asset.makes_personal_contribution,
            "beneficiary_client_id": db_asset.beneficiary_client_id,
            "fees_bps": float(db_asset.fees_bps) if db_asset.fees_bps else None,
            "relationship_asset": db_asset.relationship_asset,
            "centrelink_value": float(db_asset.centrelink_value) if db_asset.centrelink_value else None,
            "is_used_loan_security": db_asset.is_used_loan_security,
            "loan_secured_amount": float(db_asset.loan_secured_amount) if db_asset.loan_secured_amount else None,
            "annuity_type": api_annuity_type,
            "purchase_price": float(db_asset.purchase_price) if db_asset.purchase_price else None,
            "purchase_date": SerializationUtils.convert_value_to_string(db_asset.purchase_date),
            "term": db_asset.term,
            "asset_exemption_bps": float(db_asset.asset_exemption_bps) if db_asset.asset_exemption_bps else None,
            "commuted_amount": float(db_asset.commuted_amount) if db_asset.commuted_amount else None,
            "residual_value": float(db_asset.residual_value) if db_asset.residual_value else None,
            "member_number": db_asset.member_number,
            "notes": db_asset.notes,
            "confidential_notes": db_asset.confidential_notes,
            "client_notes": db_asset.client_notes,
            "partner_notes": db_asset.partner_notes,
            "created": SerializationUtils.convert_value_to_string(db_asset.created),
            "updated": SerializationUtils.convert_value_to_string(db_asset.updated),
            "soft_deleted": BoolUtils.parse(db_asset.soft_deleted),
        }

    @staticmethod
    def map_asset_type_inbound(api_asset_type: str, region: str) -> tuple[str, str | None, str | None, str | None]:
        """
        Map API asset type to internal asset_type, saving_investment_type, super_type, and annuity_type
        Returns: (asset_type, saving_investment_type, super_type, annuity_type)
        """
        if region == US_EAST_1:
            us_mappings = {
                "SAVINGS_ACCOUNT": ("I", "S", None, None),
                "CHECKING_ACCOUNT": ("I", "E", None, None),
                "HEALTH_SAVINGS_ACCOUNT": ("I", "H", None, None),
                "INVESTMENT_ACCOUNT": ("I", "I", None, None),
                "CERTIFICATE_OF_DEPOSIT": ("I", "D", None, None),
                "401K": ("I", None, "E", None),
                "ROTH_401K": ("I", None, "F", None),
                "403B": ("I", None, "G", None),
                "457B": ("I", None, "H", None),
                "TRADITIONAL_IRA": ("I", None, "I", None),
                "ROTH_IRA": ("I", None, "J", None),
                "SIMPLE_IRA": ("I", None, "K", None),
                "INHERITED_IRA": ("I", None, "M", None),
                "ANNUITY": ("I", "A", None, None),
                "529": ("I", "W", None, None),
                "OTHER": ("I", "X", None, None),
                "TRUST": ("I", "V", None, None),
                "INVESTMENT_PROPERTY": ("P", None, None, None),
            }
            if api_asset_type not in us_mappings:
                raise ValueError(f"Unknown US API asset type: {api_asset_type}")
            return us_mappings[api_asset_type]

        elif region == AP_SOUTHEAST_2:  # AU region
            au_mappings = {
                "BANK_ACCOUNT": ("I", "K", None, None),
                "CASH": ("I", "C", None, None),
                "GOVERNMENT_BOND": ("I", "B", None, None),
                "TERM_DEPOSIT": ("I", "T", None, None),
                "OFFSET_ACCOUNT": ("I", "O", None, None),
                "CERTIFICATE_OF_DEPOSIT": ("I", "D", None, None),
                "INVESTMENT_ACCOUNT": ("I", "I", None, None),
                "MANAGED_FUND": ("I", "M", None, None),
                "SHARE_PORTFOLIO": ("I", "R", None, None),
                "TRUST": ("I", "V", None, None),
                "INVESTMENT_PROPERTY": ("P", None, None, None),
                "ANNUITY": ("U", None, None, None),
            }
            if api_asset_type not in au_mappings:
                raise ValueError(f"Unknown AU API asset type: {api_asset_type}")
            return au_mappings[api_asset_type]

        else:
            raise ValueError(f"Asset type mapping not implemented for region: {region}")

    @staticmethod
    def map_asset_type_outbound(
        asset_type: str,
        saving_investment_type: str | None,
        super_type: str | None,
        annuity_type: str | None,
        region: str,
    ) -> str:
        """
        Map internal types back to API asset type
        """
        if region == US_EAST_1:
            # US mappings
            if asset_type == "P":
                return "INVESTMENT_PROPERTY"
            elif asset_type == "I":
                if super_type == "E":
                    return "401K"
                elif super_type == "F":
                    return "ROTH_401K"
                elif super_type == "G":
                    return "403B"
                elif super_type == "H":
                    return "457B"
                elif super_type == "I":
                    return "TRADITIONAL_IRA"
                elif super_type == "J":
                    return "ROTH_IRA"
                elif super_type == "K":
                    return "SIMPLE_IRA"
                elif super_type == "M":
                    return "INHERITED_IRA"
                elif saving_investment_type == "S":
                    return "SAVINGS_ACCOUNT"
                elif saving_investment_type == "E":
                    return "CHECKING_ACCOUNT"
                elif saving_investment_type == "H":
                    return "HEALTH_SAVINGS_ACCOUNT"
                elif saving_investment_type == "I":
                    return "INVESTMENT_ACCOUNT"
                elif saving_investment_type == "D":
                    return "CERTIFICATE_OF_DEPOSIT"
                elif saving_investment_type == "A":
                    return "ANNUITY"
                elif saving_investment_type == "W":
                    return "529"
                elif saving_investment_type == "X":
                    return "OTHER"
                elif saving_investment_type == "V":
                    return "TRUST"

        elif region == AP_SOUTHEAST_2:  # AU region
            if asset_type == "P":
                return "INVESTMENT_PROPERTY"
            elif asset_type == "I":
                if saving_investment_type == "K":
                    return "BANK_ACCOUNT"
                elif saving_investment_type == "C":
                    return "CASH"
                elif saving_investment_type == "B":
                    return "GOVERNMENT_BOND"
                elif saving_investment_type == "T":
                    return "TERM_DEPOSIT"
                elif saving_investment_type == "O":
                    return "OFFSET_ACCOUNT"
                elif saving_investment_type == "D":
                    return "CERTIFICATE_OF_DEPOSIT"
                elif saving_investment_type == "I":
                    return "INVESTMENT_ACCOUNT"
                elif saving_investment_type == "M":
                    return "MANAGED_FUND"
                elif saving_investment_type == "R":
                    return "SHARE_PORTFOLIO"
                elif saving_investment_type == "V":
                    return "TRUST"
            elif asset_type == "U":
                return "ANNUITY"

        raise ValueError(
            f"Cannot map asset_type={asset_type}, "
            f"saving_investment_type={saving_investment_type}, "
            f"super_type={super_type} for region {region}"
        )

    @staticmethod
    def _map_annuity_type_to_db(annuity_type: str | None) -> str | None:
        """
        Map API annuity type enum to database single char code
        VARIABLE=L, FIXED=G, OTHER=D
        """
        if annuity_type is None:
            return None

        annuity_mapping = {"VARIABLE": "L", "FIXED": "G", "OTHER": "D"}

        if annuity_type not in annuity_mapping:
            raise ValueError(f"Unknown annuity type: {annuity_type}")

        return annuity_mapping[annuity_type]

    @staticmethod
    def _map_db_annuity_type_to_api(db_annuity_type: str | None) -> str | None:
        """
        Map database single char code back to API annuity type enum
        L=VARIABLE, G=FIXED, D=OTHER
        """
        if db_annuity_type is None:
            return None

        db_to_api_mapping = {"L": "VARIABLE", "G": "FIXED", "D": "OTHER"}

        if db_annuity_type not in db_to_api_mapping:
            raise ValueError(f"Unknown database annuity type: {db_annuity_type}")

        return db_to_api_mapping[db_annuity_type]
