from typing import Any
from lumiant_api.abstraction_layer.common.database.schema.governance.business_planning import (
    BusinessPlanning as DBBusinessPlanning,
)
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from lumiant_api.abstraction_layer.common.utils.bool_utils import BoolUtils


def transform_db_business_planning_to_api_format(db_business_planning: DBBusinessPlanning) -> dict[str, Any]:
    return {
        "business_planning_id": db_business_planning.business_planning_id,
        "household_id": db_business_planning.household_id,
        "has_business_documents": db_business_planning.has_business_documents,
        "created": SerializationUtils.convert_value_to_string(db_business_planning.created),
        "updated": SerializationUtils.convert_value_to_string(db_business_planning.updated),
        "soft_deleted": BoolUtils.parse(db_business_planning.soft_deleted),
    }
