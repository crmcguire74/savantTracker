import datetime

from aws_lambda_powertools import Tracer, Logger
from lumiant_api.abstraction_layer.common.database.schema.governance.business_planning import (
    BusinessPlanning as DBBusinessPlanning,
)
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.business_planning.models.business_planning import (
    transform_db_business_planning_to_api_format,
)
from sqlalchemy.orm import Session
from typing import Any
from boto3.session import Session as Boto3Session
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from sqlalchemy import and_
from lumiant_core.momentum.apps.api_gateway_restapi.exceptions import NotFoundException
from lumiant_api.abstraction_layer.common.utils.bool_utils import BoolUtils


class BusinessPlanningApiService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Business Planning
    -------------------------------------------------------------------------------------------------
    """

    logger = Logger(child=True, service="BusinessPlanningApi")
    tracer = Tracer(service="BusinessPlanningApi")

    lumiant_rds_session: Session
    boto3_session: Boto3Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self, lumiant_rds_session: Session, boto3_session: Boto3Session, auth_metadata: LambdaAuthorisationMetadata
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def _get_db_business_planning(
        self, business_planning_id: int, household_id: int | None = None
    ) -> DBBusinessPlanning | None:
        """
        Practice-scoped DB lookup for a single business planning record.
        Joins through HouseholdTeamMember to enforce practice scoping.
        Filters out soft-deleted records. Returns the full ORM object or None.
        """
        filters = [
            DBBusinessPlanning.business_planning_id == business_planning_id,
            DBBusinessPlanning.soft_deleted.is_not(True),
            DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id,
        ]

        if household_id is not None:
            filters.append(DBBusinessPlanning.household_id == household_id)

        return (
            self.lumiant_rds_session.query(DBBusinessPlanning)
            .join(DBHouseholdTeamMember, DBHouseholdTeamMember.household_id == DBBusinessPlanning.household_id)
            .filter(and_(*filters))
            .first()
        )

    def get(self, business_planning_id: int, household_id: int) -> dict[str, Any] | None:
        db_business_planning = self._get_db_business_planning(business_planning_id, household_id)

        if db_business_planning is None:
            return None

        return transform_db_business_planning_to_api_format(db_business_planning=db_business_planning)

    def list(self, household_id: int, include_deleted: bool = False) -> list[dict[str, Any]]:
        if household_id is None:
            return []

        query = (
            self.lumiant_rds_session.query(DBBusinessPlanning)
            .join(DBHouseholdTeamMember, DBHouseholdTeamMember.household_id == DBBusinessPlanning.household_id)
            .filter(
                and_(
                    DBBusinessPlanning.household_id == household_id,
                    DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id,
                )
            )
            .distinct()
        )

        if not include_deleted:
            query = query.filter(DBBusinessPlanning.soft_deleted.is_not(True))

        return [transform_db_business_planning_to_api_format(x) for x in query.all()]

    def save(self, business_planning_id: int | None, household_id: int, has_business_documents: bool) -> dict[str, Any]:
        if business_planning_id is not None:
            business_planning = self._get_db_business_planning(business_planning_id, household_id)

            if business_planning is None:
                raise NotFoundException(
                    message=f"Business Planning with id {business_planning_id} as it could not be found"
                )
        else:
            business_planning = DBBusinessPlanning()
            business_planning.household_id = household_id
            business_planning.created = datetime.datetime.now(datetime.UTC)
            business_planning.created_by = self.auth_metadata.iam_id
            business_planning.soft_deleted = False
            self.lumiant_rds_session.add(business_planning)

        business_planning.client_id = None
        business_planning.legal_entity_id = None
        business_planning.has_business_documents = BoolUtils.parse(has_business_documents)
        business_planning.updated = datetime.datetime.now(datetime.UTC)
        business_planning.updated_by = self.auth_metadata.iam_id

        self.lumiant_rds_session.commit()

        return transform_db_business_planning_to_api_format(business_planning)

    def delete(self, business_planning_id: int, household_id: int) -> bool:
        business_planning = self._get_db_business_planning(business_planning_id, household_id)

        if business_planning is not None:
            business_planning.soft_deleted = True
            business_planning.updated_by = self.auth_metadata.iam_id
            business_planning.updated = datetime.datetime.now(datetime.UTC)
            self.lumiant_rds_session.commit()
            return True
        else:
            return False
