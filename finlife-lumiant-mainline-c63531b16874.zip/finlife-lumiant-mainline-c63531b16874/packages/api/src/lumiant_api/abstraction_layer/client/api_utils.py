from lumiant_api.resources.client import RelationshipStatusEnum, SexEnum


def normalize_title(title: str | None) -> str | None:
    """Normalize title to valid enum values or return None."""
    if title is None:
        return None
    normalized = title.replace(".", "").strip().title()
    return normalized if normalized in {"Mr", "Mrs", "Ms", "Miss", "Dr"} else None


def normalize_relationship_status(status: str | None) -> RelationshipStatusEnum | None:
    """Normalize relationship status to a valid enum value or return None."""
    if status is None:
        return None
    try:
        return RelationshipStatusEnum(status)
    except ValueError:
        return None


def normalize_sex(sex: str | None) -> SexEnum | None:
    """Normalize sex to a valid enum value or return None. Avoids response validation errors from legacy DB data."""
    if sex is None:
        return None
    try:
        return SexEnum(sex)
    except ValueError:
        return None
