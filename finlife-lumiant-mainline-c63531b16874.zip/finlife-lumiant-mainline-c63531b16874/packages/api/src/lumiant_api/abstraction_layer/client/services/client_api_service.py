import datetime
from datetime import date
from typing import Any

import sqlalchemy.orm
from aws_lambda_powertools import Logger, Tracer
from boto3.session import Session as Boto3Session
from lumiant_api.abstraction_layer.common.database.schema.client import Client as DBClient
from lumiant_api.abstraction_layer.common.database.schema.governance.tax_details import TaxDetails as DBTaxDetails
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import (
    HouseholdTeamMember as DBHouseholdTeamMember,
)
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice as DBPractice
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.models.country import Country
from lumiant_api.abstraction_layer.common.services.address_service import AddressService
from lumiant_api.abstraction_layer.contact_details.services.contact_details_api_service import ContactDetailsApiService
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from lumiant_api.abstraction_layer.common.utils.string_utils import StringUtils
from lumiant_api.abstraction_layer.client.models.client import Client
from lumiant_api.abstraction_layer.client.api_utils import normalize_relationship_status, normalize_sex, normalize_title
from lumiant_api.abstraction_layer.common.utils.normalizers import normalize_email
from sqlalchemy import and_, exists, func, text


class ClientApiService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Client
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(child=True, service="ClientApi")
    tracer = Tracer(service="ClientApi")

    lumiant_rds_session: sqlalchemy.orm.Session
    boto3_session: Boto3Session
    auth_metadata: LambdaAuthorisationMetadata

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Boto3Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ) -> None:
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def _get_db_client(self, client_id: int) -> DBClient | None:
        """Practice-scoped lookup for a single client. Returns full ORM object or None."""
        with self.lumiant_rds_session.no_autoflush:
            client = (
                self.lumiant_rds_session.query(DBClient)
                .join(DBHouseholdTeamMember, DBHouseholdTeamMember.household_id == DBClient.household_id)
                .filter(
                    and_(
                        DBClient.client_id == client_id,
                        DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id,
                        DBClient.deleted.is_(None),
                    )
                )
                .first()
            )
        return client

    def check_household_capacity(self, household_id: int) -> bool:
        # Check that members in the household is less than 2.
        with self.lumiant_rds_session.no_autoflush:
            count_client_in_household = (
                self.lumiant_rds_session.query(func.count(DBClient.client_id))
                .filter(DBClient.household_id == household_id)
                .scalar()
            )

        return bool((count_client_in_household or 0) < 2)

    def resolve_country_code_tax(self, tax_residency: str | None) -> str | None:
        """
        Resolve the stored country_code_tax value from tax residency (R or N).
        R -> practice country code (AU, NZ, US) from practice.home_locale.
        N -> N. Stored in DB as VARCHAR(2).
        """
        if tax_residency is None:
            return None
        val = tax_residency.upper() if tax_residency else None
        if val == "N":
            return "N"
        if val == "R":
            practice = (
                self.lumiant_rds_session.query(DBPractice)
                .filter(DBPractice.practice_id == self.auth_metadata.practice_id)
                .first()
            )
            if practice and practice.home_locale:
                country = Country.get_from_locale(locale=practice.home_locale)
                if country:
                    return str(country.country_code)
            return "R"  # fallback if practice locale unknown
        return None

    def get(self, client_id: int) -> Client | None:
        db_client = self._get_db_client(client_id)
        return Client.convert_from_db_object(db_client)

    def get_clients(
        self,
        page: int,
        page_size: int,
        household_id: int | None = None,
        staff_id: int | None = None,
        practice_office_id: int | None = None,
        updated_after: datetime.datetime | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        offset = (page - 1) * page_size

        # Base SQL
        count_sql = """
            SELECT COUNT(DISTINCT c.client_id)
            FROM Client c
            JOIN HouseholdTeamMember htm ON htm.household_id = c.household_id
                AND htm.practice_id = :practice_id
                AND htm.role = 'P1'
            {staff_filter}
            {practice_office_join}
            {practice_office_filter}
            {household_filter}
            WHERE c.deleted is NULL
            {updated_after_filter}
        """

        data_sql = """
            WITH SelectedClients AS (
                SELECT
                    c.client_id
                FROM Client c
                JOIN HouseholdTeamMember htm ON htm.household_id = c.household_id
                {practice_office_join}
                WHERE htm.practice_id = :practice_id AND htm.role = 'P1' and c.deleted is NULL
                {staff_filter}
                {practice_office_filter}
                {household_filter}
                {updated_after_filter}
                GROUP BY c.client_id
            )
            SELECT DISTINCT
                c.household_id,
                c.client_id,
                c.type,
                c.title,
                c.first_name,
                c.middle_name,
                c.last_name,
                c.preferred_name,
                c.dob,
                c.sex,
                c.relationship_status,
                cd.email_address,
                cd.mobile_number,
                cd.phone_number,
                c.country_code_citizenship,
                c.country_code_residency,
                t.country_code_tax,
                t.tfn,
                c.created,
                c.updated,
                c.external_id,
                c.external_system,
                a.constructed_address,
                a.address_line_1,
                a.address_line_2,
                a.suburb,
                a.post_code,
                a.state,
                a.country,
                postal_a.constructed_address AS postal_constructed_address,
                postal_a.address_line_1 AS postal_address_line_1,
                postal_a.address_line_2 AS postal_address_line_2,
                postal_a.suburb AS postal_suburb,
                postal_a.post_code AS postal_post_code,
                postal_a.state AS postal_state,
                postal_a.country AS postal_country
            FROM Client c
            JOIN ContactDetails cd ON cd.contact_details_id = c.contact_details_id
            LEFT JOIN TaxDetails t ON t.client_id = c.client_id
            LEFT JOIN Address a ON a.address_id = c.address_id
            LEFT JOIN Address postal_a ON postal_a.address_id = c.postal_address_id
            WHERE c.client_id IN (SELECT client_id FROM SelectedClients)
            ORDER BY c.client_id
            LIMIT :limit OFFSET :offset
        """

        # Dynamic joins/filters
        staff_filter = ""
        practice_office_join = ""
        practice_office_filter = ""
        updated_after_filter = ""
        household_filter = ""

        params: dict[str, Any] = {
            "practice_id": self.auth_metadata.practice_id,
            "limit": page_size,
            "offset": offset,
        }

        if staff_id:
            staff_filter += " AND htm.staff_id = :staff_id"
            params["staff_id"] = staff_id

        elif practice_office_id:
            practice_office_join += """
                JOIN Staff s ON s.staff_id = htm.staff_id
            """
            practice_office_filter += """
                AND s.practice_office_id = :practice_office_id
            """
            params["practice_office_id"] = practice_office_id

        if updated_after is not None:
            updated_after_filter += "AND c.updated >= :updated_after"
            params["updated_after"] = updated_after

        if household_id is not None:
            household_filter += "AND c.household_id = :household_id"
            params["household_id"] = household_id

        # Format SQL with dynamic parts
        count_sql_formatted = count_sql.format(
            staff_filter=staff_filter,
            practice_office_filter=practice_office_filter,
            practice_office_join=practice_office_join,
            updated_after_filter=updated_after_filter,
            household_filter=household_filter,
        )
        count_query = text(count_sql_formatted)

        data_query_formatted = data_sql.format(
            staff_filter=staff_filter,
            practice_office_filter=practice_office_filter,
            practice_office_join=practice_office_join,
            updated_after_filter=updated_after_filter,
            household_filter=household_filter,
        )
        data_query = text(data_query_formatted)

        with self.lumiant_rds_session.no_autoflush:
            # Execute total count
            total_count = self.lumiant_rds_session.execute(count_query, params).scalar()

            # Execute paginated query
            clients = self.lumiant_rds_session.execute(data_query, params).fetchall()

        total_count_int = total_count if total_count is not None else 0

        return [self._row_to_client_dict(row) for row in clients], total_count_int

    @staticmethod
    def _row_to_client_dict(row: Any) -> dict[str, Any]:
        """Convert a raw SQL row to a dict matching ClientDetails field names."""
        return {
            "household_id": row[0],
            "client_id": row[1],
            "cfo": row[2] == "C",
            "title": normalize_title(row[3]),
            "first_name": row[4],
            "middle_name": row[5],
            "last_name": row[6],
            "preferred_name": row[7],
            "dob": SerializationUtils.convert_value_to_string(row[8]),
            "sex": normalize_sex(row[9]),
            "relationship_status": normalize_relationship_status(row[10]),
            "email_address": normalize_email(row[11]),
            "mobile_number": row[12],
            "phone_number": row[13],
            "country_code_citizenship": row[14],
            "country_code_residency": row[15],
            "country_code_tax": row[16],
            "ssn": row[17],
            "created": SerializationUtils.convert_value_to_string(row[18]),
            "updated": SerializationUtils.convert_value_to_string(row[19]),
            "external_id": row[20],
            "external_system": row[21],
            "constructed_address": row[22],
            "address_line_1": row[23],
            "address_line_2": row[24],
            "suburb": row[25],
            "post_code": row[26],
            "state": row[27],
            "country": row[28],
            "postal_constructed_address": row[29],
            "postal_address_line_1": row[30],
            "postal_address_line_2": row[31],
            "postal_suburb": row[32],
            "postal_post_code": row[33],
            "postal_state": row[34],
            "postal_country": row[35],
        }

    @staticmethod
    def _set_optional_client_fields(
        client: DBClient,
        *,
        cfo: bool | None = None,
        title: str | None = None,
        middle_name: str | None = None,
        preferred_name: str | None = None,
        dob: str | date | None = None,
        sex: str | None = None,
        relationship_status: str | None = None,
        country_code_residency: str | None = None,
        country_code_citizenship: str | None = None,
        external_id: str | None = None,
        external_system: str | None = None,
    ) -> None:
        """Set optional fields on the client only when the value is not None."""
        if cfo is not None:
            client.type = "C" if cfo else "P"
        if title is not None:
            client.title = StringUtils.trim_to_none(title)
        if middle_name is not None:
            client.middle_name = StringUtils.trim_to_empty(middle_name)
        if preferred_name is not None:
            client.preferred_name = StringUtils.trim_to_empty(preferred_name)
        if dob is not None:
            if isinstance(dob, date):
                client.dob = dob
            elif isinstance(dob, str):
                client.dob = datetime.datetime.strptime(dob, "%Y-%m-%d").date()
            else:
                client.dob = None
        if sex is not None:
            client.sex = sex
        if relationship_status is not None:
            client.relationship_status = relationship_status
        if country_code_residency is not None:
            client.country_code_residency = country_code_residency
        if country_code_citizenship is not None:
            client.country_code_citizenship = country_code_citizenship
        if external_id is not None:
            client.external_id = StringUtils.trim_to_empty(external_id)
        if external_system is not None:
            client.external_system = StringUtils.trim_to_empty(external_system)

    def _save_address(
        self,
        client: DBClient,
        address_service: AddressService,
        constructed_address: str | None,
        address_line_1: str | None,
        address_line_2: str | None,
        suburb: str | None,
        post_code: str | None,
        state: str | None,
        country: str | None,
        address_type: str,
    ) -> None:
        """Create or update the regular address for the client."""
        address_id = None
        if address_type == "home":
            address_id = client.address_id
        else:
            address_id = client.postal_address_id

        if address_id is not None:
            address_service.update_address(
                address_id=address_id,
                constructed_address=constructed_address,
                address_line_1=address_line_1,
                address_line_2=address_line_2,
                suburb=suburb,
                post_code=post_code,
                state=state,
                country=country,
            )
        else:
            address_id = address_service.create_address(
                constructed_address=constructed_address,
                address_line_1=address_line_1,
                address_line_2=address_line_2,
                suburb=suburb,
                post_code=post_code,
                state=state,
                country=country,
            )
            if address_type == "home":
                client.address_id = address_id
            else:
                client.postal_address_id = address_id

    def _save_tax_details(
        self,
        client: DBClient,
        country_code_tax: str | None,
        ssn: str | None,
        now: datetime.datetime,
        iam_id: str,
    ) -> None:
        """Create or update tax details for the client."""
        tax_details = client.tax_details

        if tax_details is None:
            # Relationship may not be loaded for new clients — check DB directly
            tax_details = (
                self.lumiant_rds_session.query(DBTaxDetails).filter(DBTaxDetails.client_id == client.client_id).first()
            )

        if tax_details is None:
            tax_details = DBTaxDetails()
            tax_details.client_id = client.client_id
            tax_details.created = now
            tax_details.created_by = iam_id
            self.lumiant_rds_session.add(tax_details)

        if country_code_tax is not None:
            tax_details.country_code_tax = country_code_tax
        if ssn is not None:
            tax_details.tfn = ssn
        tax_details.updated = now
        tax_details.updated_by = iam_id

    def save(
        self,
        client_id: int | None,
        practice_id: int,
        household_id: int,
        cfo: bool,
        title: str | None = None,
        first_name: str | None = None,
        middle_name: str | None = None,
        last_name: str | None = None,
        preferred_name: str | None = None,
        dob: str | date | None = None,
        sex: str | None = None,
        relationship_status: str | None = None,
        country_code_birth: str | None = None,
        country_code_residency: str | None = None,
        country_code_citizenship: str | None = None,
        client_category: str | None = None,
        external_id: str | None = None,
        external_system: str | None = None,
        external_id_2: str | None = None,
        external_system_2: str | None = None,
        address_external_id: str | None = None,
        address_external_system: str | None = None,
        email_address: str | None = None,
        mobile_number: str | None = None,
        fax_number: str | None = None,
        phone_number: str | None = None,
        contact_details_external_id: str | None = None,
        contact_details_external_system: str | None = None,
        is_active: bool | None = None,
        auth0_id: str | None = None,
        country_code_tax: str | None = None,
        ssn: str | None = None,
        constructed_address: str | None = None,
        address_line_1: str | None = None,
        address_line_2: str | None = None,
        suburb: str | None = None,
        post_code: str | None = None,
        state: str | None = None,
        country: str | None = None,
        postal_constructed_address: str | None = None,
        postal_address_line_1: str | None = None,
        postal_address_line_2: str | None = None,
        postal_suburb: str | None = None,
        postal_post_code: str | None = None,
        postal_state: str | None = None,
        postal_country: str | None = None,
    ) -> tuple[DBClient | None, bool]:
        contact_details_service = ContactDetailsApiService(
            lumiant_rds_session=self.lumiant_rds_session,
            boto3_session=self.boto3_session,
            auth_metadata=self.auth_metadata,
        )

        now = datetime.datetime.now(datetime.UTC)
        iam_id = self.auth_metadata.iam_id

        try:
            if client_id is not None:
                client = self._update_client(
                    client_id,
                    contact_details_service,
                    cfo=cfo,
                    title=title,
                    first_name=first_name,
                    middle_name=middle_name,
                    last_name=last_name,
                    preferred_name=preferred_name,
                    dob=dob,
                    sex=sex,
                    relationship_status=relationship_status,
                    country_code_residency=country_code_residency,
                    country_code_citizenship=country_code_citizenship,
                    external_id=external_id,
                    external_system=external_system,
                    email_address=email_address,
                    mobile_number=mobile_number,
                    phone_number=phone_number,
                    now=now,
                    iam_id=iam_id,
                )
                if client is None:
                    return None, False
            else:
                client = self._create_client(
                    contact_details_service,
                    household_id=household_id,
                    cfo=cfo,
                    title=title,
                    first_name=first_name,
                    middle_name=middle_name,
                    last_name=last_name,
                    preferred_name=preferred_name,
                    dob=dob,
                    sex=sex,
                    relationship_status=relationship_status,
                    country_code_residency=country_code_residency,
                    country_code_citizenship=country_code_citizenship,
                    external_id=external_id,
                    external_system=external_system,
                    email_address=email_address,
                    mobile_number=mobile_number,
                    phone_number=phone_number,
                    now=now,
                    iam_id=iam_id,
                )

            if country_code_tax is not None or ssn is not None:
                self._save_tax_details(client, country_code_tax, ssn, now, iam_id)

            address_service = AddressService(
                lumiant_rds_session=self.lumiant_rds_session,
                auth_metadata=self.auth_metadata,
            )

            has_address = any(
                v is not None
                for v in [constructed_address, address_line_1, address_line_2, suburb, post_code, state, country]
            )
            if has_address:
                self._save_address(
                    client,
                    address_service,
                    constructed_address=constructed_address,
                    address_line_1=address_line_1,
                    address_line_2=address_line_2,
                    suburb=suburb,
                    post_code=post_code,
                    state=state,
                    country=country,
                    address_type="home",
                )

            has_postal_address = any(
                v is not None
                for v in [
                    postal_constructed_address,
                    postal_address_line_1,
                    postal_address_line_2,
                    postal_suburb,
                    postal_post_code,
                    postal_state,
                    postal_country,
                ]
            )
            if has_postal_address:
                self._save_address(
                    client,
                    address_service,
                    constructed_address=postal_constructed_address,
                    address_line_1=postal_address_line_1,
                    address_line_2=postal_address_line_2,
                    suburb=postal_suburb,
                    post_code=postal_post_code,
                    state=postal_state,
                    country=postal_country,
                    address_type="postal",
                )

            self.lumiant_rds_session.commit()

        except Exception:
            self.lumiant_rds_session.rollback()
            raise

        return client, True

    def _update_client(
        self,
        client_id: int,
        contact_details_service: ContactDetailsApiService,
        *,
        cfo: bool | None,
        title: str | None,
        first_name: str | None,
        middle_name: str | None,
        last_name: str | None,
        preferred_name: str | None,
        dob: str | date | None,
        sex: str | None,
        relationship_status: str | None,
        country_code_residency: str | None,
        country_code_citizenship: str | None,
        external_id: str | None,
        external_system: str | None,
        email_address: str | None,
        mobile_number: str | None,
        phone_number: str | None,
        now: datetime.datetime,
        iam_id: str,
    ) -> DBClient | None:
        client = self._get_db_client(client_id)
        if client is None:
            return None

        previous_email = (
            StringUtils.trim_to_empty(client.contact_details.email_address).lower()
            if client.contact_details is not None
            else ""
        )
        new_email = StringUtils.trim_to_empty(email_address).lower()

        contact_details_service.update_contact_details(
            contact_details_id=client.contact_details_id,
            email_address=new_email,
            mobile_number=StringUtils.trim_to_empty(mobile_number),
            fax_number=None,
            phone_number=StringUtils.trim_to_empty(phone_number),
            skip_duplicate_checks=previous_email == new_email,
            execute_commit=False,
        )
        self.lumiant_rds_session.flush()

        # Required fields
        client.first_name = StringUtils.trim_to_empty(first_name)
        client.last_name = StringUtils.trim_to_empty(last_name)

        self._set_optional_client_fields(
            client,
            cfo=cfo,
            title=title,
            middle_name=middle_name,
            preferred_name=preferred_name,
            dob=dob,
            sex=sex,
            relationship_status=relationship_status,
            country_code_residency=country_code_residency,
            country_code_citizenship=country_code_citizenship,
            external_id=external_id,
            external_system=external_system,
        )

        client.updated = now
        client.updated_by = iam_id
        return client

    def _create_client(
        self,
        contact_details_service: ContactDetailsApiService,
        *,
        household_id: int,
        cfo: bool,
        title: str | None,
        first_name: str | None,
        middle_name: str | None,
        last_name: str | None,
        preferred_name: str | None,
        dob: str | date | None,
        sex: str | None,
        relationship_status: str | None,
        country_code_residency: str | None,
        country_code_citizenship: str | None,
        external_id: str | None,
        external_system: str | None,
        email_address: str | None,
        mobile_number: str | None,
        phone_number: str | None,
        now: datetime.datetime,
        iam_id: str,
    ) -> DBClient:
        contact_details_id = contact_details_service.create_contact_details(
            email_address=StringUtils.trim_to_empty(email_address).lower(),
            mobile_number=StringUtils.trim_to_empty(mobile_number),
            fax_number=None,
            phone_number=StringUtils.trim_to_empty(phone_number),
            skip_duplicate_checks=False,
            execute_commit=False,
        )
        self.lumiant_rds_session.flush()

        client = DBClient()
        client.household_id = household_id
        client.contact_details_id = contact_details_id
        client.type = "C" if cfo else "P"
        client.first_name = StringUtils.trim_to_empty(first_name)
        client.last_name = StringUtils.trim_to_empty(last_name)

        self._set_optional_client_fields(
            client,
            title=title,
            middle_name=middle_name,
            preferred_name=preferred_name,
            dob=dob,
            sex=sex,
            relationship_status=relationship_status,
            country_code_residency=country_code_residency,
            country_code_citizenship=country_code_citizenship,
            external_id=external_id,
            external_system=external_system,
        )

        client.created = now
        client.created_by = iam_id
        client.updated = now
        client.updated_by = iam_id

        self.lumiant_rds_session.add(client)
        self.lumiant_rds_session.flush()
        return client

    def client_within_practice(self, practice_id: int, client_id: int) -> bool:
        """
        This method is used for Lumiant API calls only. We verify that the provided client_id is in the practice
        """
        with self.lumiant_rds_session.no_autoflush:
            return self.lumiant_rds_session.query(
                exists().where(
                    and_(
                        DBClient.client_id == client_id,
                        DBClient.household_id == DBHouseholdTeamMember.household_id,
                        DBHouseholdTeamMember.practice_id == practice_id,
                    )
                )
            ).scalar()

    def delete(self, client_id: int) -> tuple[bool, bool]:
        # This should check for all clients in the household and do the following:
        # 1. Update the email to .deleted (delete+1, 2, etc if done many times) in RDS and Cognito.
        # 2. Set client as soft deleted.
        # 3. if it was the only member disable household
        # 4. if there is another member, set as the CFO (in case it was non-CFO)
        # 5. Ask product people what should happen with existing Data. transfer to other member or leave it there.

        return True, True

    def get_client_and_partner_ids_for_household_id(self, household_id: int) -> tuple[int | None, int | None]:
        clients_tuple = (
            self.lumiant_rds_session.query(DBClient.client_id, DBClient.type)
            .join(DBHouseholdTeamMember, DBHouseholdTeamMember.household_id == DBClient.household_id)
            .filter(
                and_(
                    DBClient.household_id == household_id,
                    DBHouseholdTeamMember.practice_id == self.auth_metadata.practice_id,
                    DBClient.deleted.is_(None),
                )
            )
            .all()
        )

        client_id: int | None = None
        partner_id: int | None = None

        for client_tuple in clients_tuple:
            if client_tuple[1] == "C":
                client_id = client_tuple[0]
            else:
                partner_id = client_tuple[0]

        return client_id, partner_id
