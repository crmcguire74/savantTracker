from __future__ import annotations
import json
from dataclasses import dataclass

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lumiant_api.abstraction_layer.common.database.schema.client import Client as DBClient
    from datetime import date, datetime


@dataclass
class Client(object):
    logger = Logger(service=__name__)

    householdId: int
    clientId: int
    cfo: bool
    title: str | None
    firstName: str
    middleName: str | None
    lastName: str
    preferredName: str | None
    dob: str | None
    sex: str | None
    relationshipStatus: str | None
    email: str
    mobile: str | None
    phone: str | None
    countryCodeCitizenship: str | None
    countryCodeResidency: str | None
    countryCodeTax: str | None
    ssn: str | None
    externalId: str | None
    externalSystem: str | None
    constructedAddress: str | None
    addressLine1: str | None
    addressLine2: str | None
    suburb: str | None
    postCode: str | None
    state: str | None
    country: str | None
    postalConstructedAddress: str | None
    postalAddressLine1: str | None
    postalAddressLine2: str | None
    postalSuburb: str | None
    postalPostCode: str | None
    postalState: str | None
    postalCountry: str | None
    created: str
    updated: str

    def __init__(self) -> None:
        self.householdId = 0
        self.clientId = 0
        self.cfo = False
        self.title = None
        self.firstName = ""
        self.middleName = None
        self.lastName = ""
        self.preferredName = None
        self.dob = None
        self.sex = None
        self.relationshipStatus = None
        self.email = ""
        self.mobile = None
        self.phone = None
        self.countryCodeCitizenship = None
        self.countryCodeResidency = None
        self.countryCodeTax = None
        self.ssn = None
        self.externalId = None
        self.externalSystem = None
        self.constructedAddress = None
        self.addressLine1 = None
        self.addressLine2 = None
        self.suburb = None
        self.postCode = None
        self.state = None
        self.country = None
        self.postalConstructedAddress = None
        self.postalAddressLine1 = None
        self.postalAddressLine2 = None
        self.postalSuburb = None
        self.postalPostCode = None
        self.postalState = None
        self.postalCountry = None
        self.created = ""
        self.updated = ""

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)

    @staticmethod
    def convert_from_db_tuple(
        client_tuple: tuple[
            int,
            int,
            str,
            str,
            str,
            str,
            str,
            str,
            date,
            str,
            str,
            str,
            str,
            str,
            str,
            str,
            str,
            str,
            datetime,
            datetime,
            str | None,
            str | None,
        ]
        | None,
    ) -> Client | None:
        if client_tuple is None:
            return None

        client = Client()

        client.householdId = client_tuple[0]
        client.clientId = client_tuple[1]
        client.cfo = client_tuple[2] == "C"
        client.title = client_tuple[3]
        client.firstName = client_tuple[4]
        client.middleName = client_tuple[5]
        client.lastName = client_tuple[6]
        client.preferredName = client_tuple[7]
        client.dob = SerializationUtils.convert_value_to_string(client_tuple[8])
        client.sex = client_tuple[9]
        client.relationshipStatus = client_tuple[10]
        client.email = client_tuple[11]
        client.mobile = client_tuple[12]
        client.phone = client_tuple[13]
        client.countryCodeCitizenship = client_tuple[14]
        client.countryCodeResidency = client_tuple[15]
        client.countryCodeTax = client_tuple[16]
        client.ssn = client_tuple[17]
        client.created = SerializationUtils.convert_value_to_string(client_tuple[18])
        client.updated = SerializationUtils.convert_value_to_string(client_tuple[19])
        client.externalId = client_tuple[20]
        client.externalSystem = client_tuple[21]

        return client

    @staticmethod
    def convert_from_db_object(db_client: DBClient | None) -> Client | None:
        if db_client is None:
            return None

        client = Client()

        client.householdId = db_client.household_id
        client.clientId = db_client.client_id
        client.cfo = db_client.type == "C"
        client.title = db_client.title
        client.firstName = db_client.first_name
        client.middleName = db_client.middle_name
        client.lastName = db_client.last_name
        client.preferredName = db_client.preferred_name
        client.dob = SerializationUtils.convert_value_to_string(db_client.dob)
        client.sex = db_client.sex
        client.relationshipStatus = db_client.relationship_status

        if db_client.contact_details is not None:
            client.email = db_client.contact_details.email_address
            client.mobile = db_client.contact_details.mobile_number
            client.phone = db_client.contact_details.phone_number

        client.countryCodeCitizenship = db_client.country_code_citizenship
        client.countryCodeResidency = db_client.country_code_residency

        if db_client.tax_details is not None:
            client.countryCodeTax = db_client.tax_details.country_code_tax
            client.ssn = db_client.tax_details.tfn

        client.externalId = db_client.external_id
        client.externalSystem = db_client.external_system

        if db_client.address is not None:
            client.constructedAddress = db_client.address.constructed_address
            client.addressLine1 = db_client.address.address_line_1
            client.addressLine2 = db_client.address.address_line_2
            client.suburb = db_client.address.suburb
            client.postCode = db_client.address.post_code
            client.state = db_client.address.state
            client.country = db_client.address.country

        if db_client.postal_address is not None:
            client.postalConstructedAddress = db_client.postal_address.constructed_address
            client.postalAddressLine1 = db_client.postal_address.address_line_1
            client.postalAddressLine2 = db_client.postal_address.address_line_2
            client.postalSuburb = db_client.postal_address.suburb
            client.postalPostCode = db_client.postal_address.post_code
            client.postalState = db_client.postal_address.state
            client.postalCountry = db_client.postal_address.country

        client.created = SerializationUtils.convert_value_to_string(db_client.created)
        client.updated = SerializationUtils.convert_value_to_string(db_client.updated)

        return client
