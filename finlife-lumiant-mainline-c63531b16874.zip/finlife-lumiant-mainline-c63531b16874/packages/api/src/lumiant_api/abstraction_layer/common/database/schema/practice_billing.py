import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, String, ForeignKey, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class PracticeBilling(Base):
    __tablename__ = "PracticeBilling"

    practice_billing_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stripe_customer_id: Mapped[str | None] = mapped_column(String(40))
    full_name: Mapped[str] = mapped_column(String(400), nullable=False)
    email_address: Mapped[str | None] = mapped_column(String(255), nullable=False)
    business_name: Mapped[str | None] = mapped_column(String(255), nullable=False)
    billing_address_id: Mapped[int | None] = mapped_column(ForeignKey("Address.address_id"), nullable=True, index=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationship
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    practice: Mapped["Practice"] = relationship("Practice", back_populates="practice_billing", lazy="select")
    address: Mapped["Address"] = relationship("Address", back_populates="practice_billing", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.address import Address  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice  # pylint: disable=C0413,R0401
