import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Boolean, String, Date, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class ModuleState(Base):
    __tablename__ = "ModuleState"

    module_state_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("Client.client_id"), nullable=False, index=True)
    previously_completed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    module: Mapped[str] = mapped_column(String(255), nullable=False)
    module_state: Mapped[str] = mapped_column(String(255), nullable=False)
    sent_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    sent_reminders: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    started_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    started_reminders: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    finished_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    expired_date: Mapped[datetime.date | None] = mapped_column(Date, nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    number_of_staff_vault_uploads: Mapped[int] = mapped_column(Integer, default=0)
    number_of_client_vault_uploads: Mapped[int] = mapped_column(Integer, default=0)
    number_of_staff_vault_file_moves: Mapped[int] = mapped_column(Integer, default=0)
    number_of_client_vault_file_moves: Mapped[int] = mapped_column(Integer, default=0)
    number_of_staff_vault_file_renames: Mapped[int] = mapped_column(Integer, default=0)
    number_of_client_vault_file_renames: Mapped[int] = mapped_column(Integer, default=0)
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    client: Mapped["Client"] = relationship("Client", back_populates="module_state", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
