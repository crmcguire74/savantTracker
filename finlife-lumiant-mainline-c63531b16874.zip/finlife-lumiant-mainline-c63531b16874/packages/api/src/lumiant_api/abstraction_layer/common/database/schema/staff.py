import datetime
import uuid

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from lumiant_api.abstraction_layer.common.database.types.mysql_uuid import MySQLUUID
from sqlalchemy import Integer, ForeignKey, String, DateTime, Boolean, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Staff(Base):
    __tablename__ = "Staff"

    staff_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    contact_details_id: Mapped[int] = mapped_column(
        ForeignKey("ContactDetails.contact_details_id"), nullable=False, index=True
    )
    practice_office_id: Mapped[int] = mapped_column(
        ForeignKey("PracticeOffice.practice_office_id"), nullable=False, index=True
    )
    iam_id: Mapped[uuid.UUID | None] = mapped_column(MySQLUUID(swap_flag=True))
    auth0_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    ilan: Mapped[str | None] = mapped_column(String(7))
    title: Mapped[str | None] = mapped_column(String(10))
    first_name: Mapped[str] = mapped_column(String(255), nullable=False)
    middle_name: Mapped[str | None] = mapped_column(String(255))
    last_name: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(10), nullable=False)
    digital_signature_s3_path: Mapped[str | None] = mapped_column(String(255))
    last_login: Mapped[datetime.datetime | None] = mapped_column(DateTime, nullable=True)
    completed_academy: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    # The plan is to truncate this at 255 characters. There is no definitive answer as to the maximum size
    # However, some sources are saying between 150 / 200.
    last_user_agent: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    removed_iam_id: Mapped[uuid.UUID | None] = mapped_column(MySQLUUID(swap_flag=True))
    iam_id_removed_by: Mapped[str | None] = mapped_column(String(50), nullable=True)
    iam_id_removed_date: Mapped[datetime.datetime | None] = mapped_column(
        DateTime, nullable=True, server_default=text("CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    contact_details: Mapped["ContactDetails"] = relationship(
        "ContactDetails", back_populates="staff_contact_details", lazy="select"
    )
    practice_office: Mapped["PracticeOffice"] = relationship("PracticeOffice", back_populates="staff", lazy="select")

    household_team_members: Mapped[list["HouseholdTeamMember"]] = relationship(
        "HouseholdTeamMember", back_populates="staff", lazy="select"
    )

    staff_config: Mapped["StaffConfig"] = relationship(
        "StaffConfig", back_populates="staff", uselist=False, lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.contact_details import ContactDetails  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_office import PracticeOffice  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.config.staff_config import StaffConfig  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import HouseholdTeamMember  # pylint: disable=C0413,R0401
