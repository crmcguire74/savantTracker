import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class HouseholdTeamMember(Base):
    """
        | HouseholdId | Practice Id | Practice Office Id | Staff Id | Role |
        |-------------|-------------|--------------------|----------|------|
    #1  |    123      |     79      |        null        |   null   |  VO  |
    #2  |    123      |     79      |         77         |   null   |  SU  |
    #3  |    123      |     79      |        null        |    45    |  P1  |

    #1 - Everyone in practice 79 has view access to household 123
    #2 - Everyone in practice office 77 in practice 79 has support access to household 123
    #3 - Staff member with id 45 in practice 79 is the primary professional for household 123
    """

    __tablename__ = "HouseholdTeamMember"

    household_team_member_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    practice_id: Mapped[int] = mapped_column(ForeignKey("Practice.practice_id"), nullable=False, index=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    staff_id: Mapped[int | None] = mapped_column(ForeignKey("Staff.staff_id"), nullable=True, index=True)
    practice_office_id: Mapped[int | None] = mapped_column(
        ForeignKey("PracticeOffice.practice_office_id"), nullable=True, index=True
    )
    role: Mapped[str] = mapped_column(
        # P1 = Primary Professional, PR = Professional, PP = Paraplanner, SU = Support, VO = View Only
        ENUM("P1", "PR", "PP", "SU", "VO"),
        nullable=False,
    )
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    practice: Mapped["Practice"] = relationship("Practice", back_populates="household_team_members", lazy="select")
    household: Mapped["Household"] = relationship("Household", back_populates="household_team_members", lazy="select")
    staff: Mapped["Staff"] = relationship("Staff", back_populates="household_team_members", lazy="select")
    practice_office: Mapped["PracticeOffice"] = relationship(
        "PracticeOffice", back_populates="household_team_members", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_office import PracticeOffice  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.staff import Staff  # pylint: disable=C0413,R0401
