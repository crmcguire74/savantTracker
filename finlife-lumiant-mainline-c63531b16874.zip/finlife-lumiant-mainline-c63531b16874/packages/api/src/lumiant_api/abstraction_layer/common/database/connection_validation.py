from sqlalchemy import event
from sqlalchemy import exc
from sqlalchemy import select
from sqlalchemy.engine.base import Connection
from sqlalchemy.engine.base import Engine


class ConnectionValidation(object):
    """
    -------------------------------------------------------------------------------------------------
    Connection validation to ensure stale connections are removed from the pool.
    -------------------------------------------------------------------------------------------------
    """

    def __init__(self) -> None:
        pass

    @staticmethod
    def add_connection_validation(engine: Engine) -> None:
        @event.listens_for(engine, "engine_connect")  # type: ignore
        def _ping_connection(connection: Connection, branch: bool) -> None:  # type: ignore[reportUnusedFunction]
            if branch:
                return

            save_should_close_with_result = connection.should_close_with_result
            connection.should_close_with_result = False

            try:
                connection.scalar(select(1))
            except exc.DBAPIError as err:
                if err.connection_invalidated:
                    connection.scalar(select(1))
                else:
                    raise
            finally:
                connection.should_close_with_result = save_should_close_with_result
