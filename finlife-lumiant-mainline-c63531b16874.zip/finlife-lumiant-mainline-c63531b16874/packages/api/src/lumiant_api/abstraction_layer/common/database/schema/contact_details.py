import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class ContactDetails(Base):
    __tablename__ = "ContactDetails"

    contact_details_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email_address: Mapped[str] = mapped_column(String(255), nullable=False)
    mobile_number: Mapped[str | None] = mapped_column(String(15))
    fax_number: Mapped[str | None] = mapped_column(String(15))
    phone_number: Mapped[str | None] = mapped_column(String(15))
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client_contact_details: Mapped["Client"] = relationship("Client", back_populates="contact_details", lazy="select")
    practice_office_contact_details: Mapped["PracticeOffice"] = relationship(
        "PracticeOffice", back_populates="contact_details", lazy="select"
    )
    staff_contact_details: Mapped["Staff"] = relationship("Staff", back_populates="contact_details", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_office import PracticeOffice  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.staff import Staff  # pylint: disable=C0413,R0401
