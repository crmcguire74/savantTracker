# -------------------------------------------------------------------------------------------------
# IAM - Public Level - Roles
# -------------------------------------------------------------------------------------------------
IAM_ROLE_PUBLIC: str = "Public"
IAM_ROLE_MGP: str = "MGP"
IAM_ROLE_SAVANT: str = "Savant"

# -------------------------------------------------------------------------------------------------
# Cognito - Practice Level - Client Roles
# -------------------------------------------------------------------------------------------------
COGNITO_ROLE_CLIENT: str = "Client"

# -------------------------------------------------------------------------------------------------
# Cognito - Practice Level - Staff Roles
# -------------------------------------------------------------------------------------------------
COGNITO_ROLE_STAFF_PRACTICE_MANAGER: str = "PracticeManager"
COGNITO_ROLE_STAFF_PROFESSIONAL: str = "Adviser"
COGNITO_ROLE_STAFF_PARAPLANNER: str = "Paraplanner"  # We do not use this anymore
COGNITO_ROLE_STAFF_SUPPORT: str = "Support"
COGNITO_ROLE_STAFF_UNLICENSED: str = "Unlicensed"

COGNITO_STAFF_ROLES: list[str] = [
    COGNITO_ROLE_STAFF_PRACTICE_MANAGER,
    COGNITO_ROLE_STAFF_PROFESSIONAL,
    COGNITO_ROLE_STAFF_PARAPLANNER,
    COGNITO_ROLE_STAFF_SUPPORT,
]

# -------------------------------------------------------------------------------------------------
# Lumiant - Limited Roles
#
# The following need to have an additional check implemented to ensure that only a user in
# practice_id 1 (i.e. Lumiant) can be assigned to these roles.
# -------------------------------------------------------------------------------------------------
COGNITO_ROLE_LUMIANT_ADMIN: str = "LumiantAdmin"
COGNITO_ROLE_LUMIANT_REPORTING: str = "LumiantReporting"
COGNITO_ROLE_LUMIANT_SUPPORT: str = "LumiantSupport"

# In addition, the following role should be for *internal use only* (e.g. EventBridge -> Lambda etc.)
COGNITO_ROLE_LUMIANT_INTEGRATION: str = "LumiantIntegration"

COGNITO_LUMIANT_ROLES: list[str] = [
    COGNITO_ROLE_LUMIANT_ADMIN,
    COGNITO_ROLE_LUMIANT_REPORTING,
    COGNITO_ROLE_LUMIANT_SUPPORT,
    COGNITO_ROLE_LUMIANT_INTEGRATION,
]

# -------------------------------------------------------------------------------------------------
# Shortcuts for LambdaAuthorisationService -> validate_rbac
# -------------------------------------------------------------------------------------------------
RBAC_PUBLIC_AND_CLIENT_STAFF_LUMIANT: list[str] = [
    IAM_ROLE_PUBLIC,
    COGNITO_ROLE_CLIENT,
    *COGNITO_STAFF_ROLES,
    *COGNITO_LUMIANT_ROLES,
]

RBAC_CLIENT_STAFF_LUMIANT: list[str] = [COGNITO_ROLE_CLIENT, *COGNITO_STAFF_ROLES, *COGNITO_LUMIANT_ROLES]

RBAC_STAFF_LUMIANT: list[str] = COGNITO_STAFF_ROLES + COGNITO_LUMIANT_ROLES

RBAC_PRACTICE_MANAGER_LUMIANT: list[str] = [COGNITO_ROLE_STAFF_PRACTICE_MANAGER, *COGNITO_LUMIANT_ROLES]

RBAC_LUMIANT_ONLY: list[str] = COGNITO_LUMIANT_ROLES

# -------------------------------------------------------------------------------------------------
# Staff - Roles
# -------------------------------------------------------------------------------------------------
STAFF_ROLE_PRACTICE_MANAGER: str = "M"
STAFF_ROLE_PROFESSIONAL: str = "A"
STAFF_ROLE_PARAPLANNER: str = "P"
STAFF_ROLE_SUPPORT: str = "S"
STAFF_ROLE_UNLICENSED: str = "U"  # Default role for new staff that do not have a license assigned

STAFF_ROLES: list[str] = [
    STAFF_ROLE_PRACTICE_MANAGER,
    STAFF_ROLE_PROFESSIONAL,
    STAFF_ROLE_PARAPLANNER,
    STAFF_ROLE_SUPPORT,
    STAFF_ROLE_UNLICENSED,
]

# -------------------------------------------------------------------------------------------------
# Household Team Member - Roles
# -------------------------------------------------------------------------------------------------
TEAM_ROLE_PRIMARY_PROFESSIONAL: str = "P1"
TEAM_ROLE_PROFESSIONAL: str = "PR"
TEAM_ROLE_PARAPLANNER: str = "PP"
TEAM_ROLE_SUPPORT: str = "SU"
# This is for sharing
TEAM_ROLE_VIEW_ONLY: str = "VO"

TEAM_ROLES: list[str] = [
    TEAM_ROLE_PRIMARY_PROFESSIONAL,
    TEAM_ROLE_PROFESSIONAL,
    TEAM_ROLE_PARAPLANNER,
    TEAM_ROLE_SUPPORT,
    TEAM_ROLE_VIEW_ONLY,
]

# -------------------------------------------------------------------------------------------------
# Lumiant API - Roles
# -------------------------------------------------------------------------------------------------
LUMIANT_API_READ_ONLY: str = "LumiantAPIReadOnly"
LUMIANT_API_READ_WRITE: str = "LumiantAPIReadWrite"
