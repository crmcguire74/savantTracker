import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class PracticeOffice(Base):
    __tablename__ = "PracticeOffice"

    practice_office_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    practice_id: Mapped[int] = mapped_column(ForeignKey("Practice.practice_id"), nullable=False, index=True)
    contact_details_id: Mapped[int | None] = mapped_column(
        ForeignKey("ContactDetails.contact_details_id"), nullable=True, index=True
    )
    address_id: Mapped[int | None] = mapped_column(ForeignKey("Address.address_id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    practice: Mapped["Practice"] = relationship("Practice", back_populates="practice_offices", lazy="select")
    contact_details: Mapped["ContactDetails"] = relationship(
        "ContactDetails", back_populates="practice_office_contact_details", lazy="select"
    )
    address: Mapped["Address"] = relationship("Address", back_populates="practice_office", lazy="select")

    staff: Mapped[list["Staff"]] = relationship("Staff", back_populates="practice_office", lazy="select")
    household_team_members: Mapped[list["HouseholdTeamMember"]] = relationship(
        "HouseholdTeamMember", back_populates="practice_office", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import HouseholdTeamMember  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.staff import Staff  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.address import Address  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.contact_details import ContactDetails  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice  # pylint: disable=C0413,R0401
