# This is for both ap-southeast-2 and us-east-1
LUMIANT_PRACTICE_ID = 1

# This is for ap-southeast-2 only at this stage
LUMIANT_DEMO_PRACTICE_ID = 8
LUMIANT_ADVISER_DEMO_PRACTICE_ID = 246
LUMIANT_OPERATIONS_AU = 9

# This is for us-east-1 only at this stage
LUMIANT_ADVISER_DEMO_US_PRACTICE_ID = 3
LUMIANT_OPERATIONS_US = 2
