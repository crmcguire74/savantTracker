import datetime
import uuid

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from lumiant_api.abstraction_layer.common.database.types.mysql_uuid import MySQLUUID
from sqlalchemy import Integer, ForeignKey, String, Date, DateTime, Boolean, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Client(Base):
    __tablename__ = "Client"

    client_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    contact_details_id: Mapped[int] = mapped_column(
        ForeignKey("ContactDetails.contact_details_id"), nullable=False, index=True
    )
    address_id: Mapped[int | None] = mapped_column(ForeignKey("Address.address_id"), nullable=True, index=True)
    postal_address_id: Mapped[int | None] = mapped_column(ForeignKey("Address.address_id"), nullable=True, index=True)
    iam_id: Mapped[uuid.UUID | None] = mapped_column(MySQLUUID(swap_flag=True))
    auth0_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    type: Mapped[str] = mapped_column(ENUM("C", "P", "D", "N"), nullable=False)
    title: Mapped[str | None] = mapped_column(String(10))
    first_name: Mapped[str] = mapped_column(String(255), nullable=False)
    middle_name: Mapped[str | None] = mapped_column(String(255))
    last_name: Mapped[str] = mapped_column(String(255), nullable=False)
    preferred_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    dob: Mapped[datetime.date | None] = mapped_column(Date)
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    external_id_2: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system_2: Mapped[str | None] = mapped_column(String(15), nullable=True)
    client_category: Mapped[str | None] = mapped_column(String(20), nullable=True)
    last_login: Mapped[datetime.datetime | None] = mapped_column(DateTime, nullable=True)
    # The plan is to truncate this at 255 characters. There is no definitive answer as to the maximum size
    # However, some sources are saying between 150 / 200.
    last_user_agent: Mapped[str | None] = mapped_column(String(255), nullable=True)
    billable_start: Mapped[datetime.datetime | None] = mapped_column(DateTime, nullable=True)
    billable_trigger: Mapped[str] = mapped_column(
        ENUM("N", "I", "V", "L", "P", "T", "R", "G", "D"), default="N", nullable=False
    )
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=1)
    sex: Mapped[str | None] = mapped_column(ENUM("M", "F", "O", "U"), nullable=True)
    relationship_status: Mapped[str | None] = mapped_column(ENUM("S", "F", "E", "M", "P", "D", "W", "X"), nullable=True)
    country_code_birth: Mapped[str | None] = mapped_column(String(2), nullable=True)
    country_code_residency: Mapped[str | None] = mapped_column(String(2), nullable=True)
    country_code_citizenship: Mapped[str | None] = mapped_column(String(2), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(10000))
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    deleted_by: Mapped[str | None] = mapped_column(String(50), nullable=True)
    deleted: Mapped[datetime.datetime | None] = mapped_column(DateTime, nullable=True)

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="clients", lazy="select")
    contact_details: Mapped["ContactDetails"] = relationship(
        "ContactDetails", back_populates="client_contact_details", lazy="select"
    )
    address: Mapped["Address"] = relationship(
        "Address", foreign_keys="[Client.address_id]", back_populates="client", lazy="select"
    )
    postal_address: Mapped["Address"] = relationship(
        "Address", foreign_keys="[Client.postal_address_id]", back_populates="postal_address_client", lazy="select"
    )

    client_discovery: Mapped["ClientDiscovery"] = relationship(
        "ClientDiscovery", back_populates="client", uselist=False, lazy="select"
    )
    module_state: Mapped[list["ModuleState"]] = relationship("ModuleState", back_populates="client", lazy="select")
    client_values: Mapped[list["ClientValues"]] = relationship("ClientValues", back_populates="client", lazy="select")
    client_wealth_ids: Mapped[list["ClientWealthId"]] = relationship(
        "ClientWealthId", back_populates="client", lazy="select"
    )
    connections: Mapped[list["LifeConnection"]] = relationship("LifeConnection", back_populates="client", lazy="select")
    investment_preferences: Mapped[list["InvestmentPreferences"]] = relationship(
        "InvestmentPreferences", back_populates="client", lazy="select"
    )
    life_goals: Mapped[list["LifeGoal"]] = relationship("LifeGoal", back_populates="client", lazy="select")
    lives: Mapped[list["Life"]] = relationship("Life", back_populates="client", lazy="select")
    financial_health_assessments: Mapped[list["FinancialHealthAssessment"]] = relationship(
        "FinancialHealthAssessment", back_populates="client", lazy="select"
    )
    wellness: Mapped["ClientWellness"] = relationship(
        "ClientWellness", back_populates="client", uselist=False, lazy="select"
    )
    wellness_history: Mapped[list["ClientWellnessHistory"]] = relationship(
        "ClientWellnessHistory", back_populates="client", lazy="select"
    )

    risk_profile: Mapped["RiskProfile"] = relationship(
        "RiskProfile", back_populates="client", uselist=False, lazy="select"
    )
    tax_details: Mapped["TaxDetails"] = relationship(
        "TaxDetails", back_populates="client", uselist=False, lazy="select"
    )
    health_details: Mapped["HealthDetails"] = relationship(
        "HealthDetails", back_populates="client", uselist=False, lazy="select"
    )
    employment_details: Mapped["EmploymentDetails"] = relationship(
        "EmploymentDetails", back_populates="client", uselist=False, lazy="select"
    )
    sensitive_details: Mapped["SensitiveDetails"] = relationship(
        "SensitiveDetails", back_populates="client", uselist=False, lazy="select"
    )
    assets: Mapped[list["Asset"]] = relationship("Asset", back_populates="client", lazy="select")
    liabilities: Mapped[list["Liability"]] = relationship("Liability", back_populates="client", lazy="select")
    income: Mapped[list["Income"]] = relationship("Income", back_populates="client", lazy="select")
    expenses: Mapped[list["Expense"]] = relationship("Expense", back_populates="client", lazy="select")
    insurances: Mapped[list["Insurance"]] = relationship("Insurance", back_populates="client", lazy="select")
    estate_planning: Mapped["EstatePlanning"] = relationship(
        "EstatePlanning", back_populates="client", uselist=False, lazy="select"
    )
    tax_plannings: Mapped[list["TaxPlanning"]] = relationship("TaxPlanning", back_populates="client", lazy="select")
    education_plannings: Mapped[list["EducationPlanning"]] = relationship(
        "EducationPlanning", back_populates="client", lazy="select"
    )
    charitable_plannings: Mapped[list["CharitablePlanning"]] = relationship(
        "CharitablePlanning", back_populates="client", lazy="select"
    )
    business_plannings: Mapped[list["BusinessPlanning"]] = relationship(
        "BusinessPlanning", back_populates="client", lazy="select"
    )
    portfolios: Mapped[list["Portfolio"]] = relationship("Portfolio", back_populates="client", lazy="select")
    retirement_details: Mapped["RetirementDetails"] = relationship(
        "RetirementDetails", back_populates="client", uselist=False, lazy="select"
    )

    goals: Mapped[list["Goal"]] = relationship("Goal", back_populates="client", lazy="select")
    tasks: Mapped[list["Task"]] = relationship("Task", back_populates="client", lazy="select")

    client_config: Mapped["ClientConfig"] = relationship(
        "ClientConfig", back_populates="client", uselist=False, lazy="select"
    )

    riskalyze_client_mapping: Mapped["RiskalyzeClientMapping"] = relationship(
        "RiskalyzeClientMapping", back_populates="client", lazy="select"
    )
    money_guide_pro_data_client_mapping: Mapped["MoneyGuideProData"] = relationship(
        "MoneyGuideProData", back_populates="client", lazy="select"
    )
    surveys_session: Mapped["SurveysSession"] = relationship("SurveysSession", back_populates="client", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.address import Address  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.contact_details import ContactDetails  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.client_wealth_id import ClientWealthId  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.config.client_config import ClientConfig  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.discovery.client_discovery import ClientDiscovery  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.financial_health_assessment.financial_health_assessment import (
    FinancialHealthAssessment,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.goals.goal import Goal  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.business_planning import BusinessPlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.charitable_planning import CharitablePlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.education_planning import EducationPlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.employment_details import EmploymentDetails  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.estate_planning import EstatePlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.expense import Expense  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.health_details import HealthDetails  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.income import Income  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance import Insurance  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.liability import Liability  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.portfolio import Portfolio  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.retirement_details import RetirementDetails  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.risk_profile import RiskProfile  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.sensitive_details import SensitiveDetails  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.tax_details import TaxDetails  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.tax_planning import TaxPlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.investment_preferences.investment_preferences import (
    InvestmentPreferences,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.life.life import Life  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.life.life_connection import LifeConnection  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.life.life_goal import LifeGoal  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.module_state import ModuleState  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.money_guide_pro.money_guide_pro_data import MoneyGuideProData  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.riskalyze.riskalyze_client_mapping import (
    RiskalyzeClientMapping,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.tasks.task import Task  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.values.client_values import ClientValues  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.wellbeing.client_wellness import ClientWellness  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.wellbeing.client_wellness_history import ClientWellnessHistory  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.surveys.surveys_session import SurveysSession  # pylint: disable=C0413,R0401
