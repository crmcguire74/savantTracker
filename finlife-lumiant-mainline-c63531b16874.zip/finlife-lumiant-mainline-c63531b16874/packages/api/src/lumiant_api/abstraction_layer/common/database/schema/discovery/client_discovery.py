import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Numeric, Boolean, Date, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class ClientDiscovery(Base):
    __tablename__ = "ClientDiscovery"

    client_discovery_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("Client.client_id"), nullable=False, index=True)
    home_loan_owing: Mapped[float | None] = mapped_column(Numeric(12, 2))
    investment_debt: Mapped[float | None] = mapped_column(Numeric(12, 2))
    other_debt: Mapped[float | None] = mapped_column(Numeric(12, 2))
    income: Mapped[float | None] = mapped_column(Numeric(12, 2))
    super: Mapped[float | None] = mapped_column(Numeric(12, 2))
    savings: Mapped[float | None] = mapped_column(Numeric(12, 2))
    other_assets: Mapped[float | None] = mapped_column(Numeric(12, 2))
    life_insurance: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    income_protection: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    trauma_insurance: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    tpd_insurance: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    desired_retirement_age: Mapped[int | None] = mapped_column(Integer)
    dob: Mapped[datetime.date | None] = mapped_column(Date)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client: Mapped["Client"] = relationship("Client", back_populates="client_discovery", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
