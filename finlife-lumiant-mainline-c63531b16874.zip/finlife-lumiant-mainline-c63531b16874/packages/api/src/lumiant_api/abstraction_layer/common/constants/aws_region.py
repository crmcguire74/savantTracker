AP_SOUTHEAST_2 = "ap-southeast-2"
US_EAST_1 = "us-east-1"
