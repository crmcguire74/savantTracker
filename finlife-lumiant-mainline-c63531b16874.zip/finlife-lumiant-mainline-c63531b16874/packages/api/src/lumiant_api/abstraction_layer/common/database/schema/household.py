import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from lumiant_api.abstraction_layer.common.models import country
from sqlalchemy import Integer, String, Boolean, ForeignKey, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Household(Base):
    __tablename__ = "Household"

    household_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    is_test: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    household_package_id: Mapped[int | None] = mapped_column(
        ForeignKey("HouseholdPackage.household_package_id"), nullable=True, index=True
    )
    practice_segmentation_id: Mapped[int | None] = mapped_column(
        ForeignKey("PracticeSegmentation.practice_segmentation_id"), nullable=True, index=True
    )
    country_code: Mapped[str] = mapped_column(String(2), nullable=False, default=country.AU.country_code)
    notes: Mapped[str | None] = mapped_column(String(10000))
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    clients: Mapped[list["Client"]] = relationship("Client", back_populates="household", lazy="select")
    household_values: Mapped[list["HouseholdValues"]] = relationship(
        "HouseholdValues", back_populates="household", lazy="select"
    )
    life_notes: Mapped[list["LifeNote"]] = relationship("LifeNote", back_populates="household", lazy="select")
    wellness: Mapped["HouseholdWellness"] = relationship(
        "HouseholdWellness", back_populates="household", uselist=False, lazy="select"
    )
    wellness_history: Mapped[list["HouseholdWellnessHistory"]] = relationship(
        "HouseholdWellnessHistory", back_populates="household", lazy="select"
    )
    best_life_score: Mapped["BestLifeScore"] = relationship(
        "BestLifeScore", back_populates="household", uselist=False, lazy="select"
    )
    best_life_score_history: Mapped[list["BestLifeScoreHistory"]] = relationship(
        "BestLifeScoreHistory", back_populates="household", lazy="select"
    )
    default_best_life_scenario: Mapped["DefaultBestLifeScenario"] = relationship(
        "DefaultBestLifeScenario", back_populates="household", uselist=False, lazy="select"
    )
    discovery: Mapped["Discovery"] = relationship("Discovery", back_populates="household", uselist=False, lazy="select")
    household_team_members: Mapped[list["HouseholdTeamMember"]] = relationship(
        "HouseholdTeamMember", back_populates="household", lazy="select"
    )

    risk_profile: Mapped["RiskProfile"] = relationship(
        "RiskProfile", back_populates="household", uselist=False, lazy="select"
    )
    professional_contacts: Mapped[list["ProfessionalContact"]] = relationship(
        "ProfessionalContact", back_populates="household", lazy="select"
    )
    household_members: Mapped[list["HouseholdMember"]] = relationship(
        "HouseholdMember", back_populates="household", lazy="select"
    )
    legal_entities: Mapped[list["LegalEntity"]] = relationship("LegalEntity", back_populates="household", lazy="select")
    assets: Mapped[list["Asset"]] = relationship("Asset", back_populates="household", lazy="select")
    liabilities: Mapped[list["Liability"]] = relationship("Liability", back_populates="household", lazy="select")
    income: Mapped[list["Income"]] = relationship("Income", back_populates="household", lazy="select")
    expenses: Mapped[list["Expense"]] = relationship("Expense", back_populates="household", lazy="select")
    living_discretionary_expenses: Mapped["LivingDiscretionaryExpense"] = relationship(
        "LivingDiscretionaryExpense", back_populates="household", uselist=False, lazy="select"
    )
    insurances: Mapped[list["Insurance"]] = relationship("Insurance", back_populates="household", lazy="select")
    estate_planning: Mapped[list["EstatePlanning"]] = relationship(
        "EstatePlanning", back_populates="household", uselist=False, lazy="select"
    )
    tax_plannings: Mapped[list["TaxPlanning"]] = relationship("TaxPlanning", back_populates="household", lazy="select")
    education_plannings: Mapped[list["EducationPlanning"]] = relationship(
        "EducationPlanning", back_populates="household", lazy="select"
    )
    charitable_plannings: Mapped[list["CharitablePlanning"]] = relationship(
        "CharitablePlanning", back_populates="household", lazy="select"
    )
    business_plannings: Mapped[list["BusinessPlanning"]] = relationship(
        "BusinessPlanning", back_populates="household", lazy="select"
    )
    portfolios: Mapped[list["Portfolio"]] = relationship("Portfolio", back_populates="household", lazy="select")
    household_strategy_categories: Mapped[list["HouseholdStrategyCategory"]] = relationship(
        "HouseholdStrategyCategory", back_populates="household", lazy="select"
    )
    household_strategies: Mapped[list["HouseholdStrategy"]] = relationship(
        "HouseholdStrategy", back_populates="household", lazy="select"
    )
    practice_segmentation: Mapped["PracticeSegmentation"] = relationship(
        "PracticeSegmentation", back_populates="household", uselist=False, lazy="select"
    )

    goals: Mapped[list["Goal"]] = relationship("Goal", back_populates="household", lazy="select")
    tasks: Mapped[list["Task"]] = relationship("Task", back_populates="household", lazy="select")

    household_config: Mapped["HouseholdConfig"] = relationship(
        "HouseholdConfig", back_populates="household", uselist=False, lazy="select"
    )
    money_guide_pro_data_household_mapping: Mapped["MoneyGuideProData"] = relationship(
        "MoneyGuideProData", back_populates="household", lazy="select"
    )

    toe_fee_history: Mapped[list["ToeFeeHistory"]] = relationship(
        "ToeFeeHistory", back_populates="household", lazy="select"
    )
    surveys_session: Mapped["SurveysSession"] = relationship(
        "SurveysSession", back_populates="household", lazy="select"
    )

    # One-Way Relationships
    household_package: Mapped["HouseholdPackage"] = relationship("HouseholdPackage", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.best_life.best_life_score import BestLifeScore  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.best_life.best_life_score_history import BestLifeScoreHistory  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.best_life.default_best_life_scenario import (
    DefaultBestLifeScenario,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.discovery.discovery import Discovery  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.risk_profile import RiskProfile  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.packages.household_package import HouseholdPackage  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_segmentation import PracticeSegmentation  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.wellbeing.household_wellness import HouseholdWellness  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.wellbeing.household_wellness_history import (
    HouseholdWellnessHistory,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.life.life_note import LifeNote  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.config.household_config import HouseholdConfig  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.goals.goal import Goal  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.business_planning import BusinessPlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.charitable_planning import CharitablePlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.education_planning import EducationPlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.estate_planning import EstatePlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.expense import Expense  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.household_member import HouseholdMember  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.income import Income  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.insurance import Insurance  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.legal_entity import LegalEntity  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.liability import Liability  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.living_discretionary_expense import (
    LivingDiscretionaryExpense,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.portfolio import Portfolio  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.professional_contact import ProfessionalContact  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.tax_planning import TaxPlanning  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import HouseholdTeamMember  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.money_guide_pro.money_guide_pro_data import MoneyGuideProData  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy import HouseholdStrategy  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.household_strategy_category import (
    HouseholdStrategyCategory,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.tasks.task import Task  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.values.household_values import HouseholdValues  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.lifebook.toe_fee_history import ToeFeeHistory  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.surveys.surveys_session import SurveysSession  # pylint: disable=C0413,R0401
