import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class FinancialHealthAssessment(Base):
    __tablename__ = "FinancialHealthAssessment"

    financial_health_assessment_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("Client.client_id"), nullable=False, index=True)
    status: Mapped[str] = mapped_column(ENUM("O", "C"), nullable=False)
    vision_goals_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    retirement_planning_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    insurance_asset_protection_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    debt_cash_flow_management_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    education_planning_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    investment_planning_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    income_tax_planning_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    business_planning_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    charitable_planning_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    estate_planning_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client: Mapped["Client"] = relationship("Client", back_populates="financial_health_assessments", lazy="select")

    responses: Mapped[list["FHAQuestionnaire"]] = relationship(
        "FHAQuestionnaire", back_populates="financial_health_assessment", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.financial_health_assessment.financial_health_assessment_questionnaire import (
    FHAQuestionnaire,
)  # pylint: disable=C0413,R0401
