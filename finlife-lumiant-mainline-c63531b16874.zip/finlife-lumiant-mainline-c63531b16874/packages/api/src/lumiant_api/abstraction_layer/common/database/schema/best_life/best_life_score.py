import datetime
import uuid

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from lumiant_api.abstraction_layer.common.database.types.mysql_uuid import MySQLUUID
from sqlalchemy import Integer, ForeignKey, Numeric, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class BestLifeScore(Base):
    __tablename__ = "BestLifeScore"

    best_life_score_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    scenario_id: Mapped[uuid.UUID | None] = mapped_column(MySQLUUID(swap_flag=True), nullable=False)
    best_life_score: Mapped[float | None] = mapped_column(Numeric(7, 4), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="best_life_score", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
