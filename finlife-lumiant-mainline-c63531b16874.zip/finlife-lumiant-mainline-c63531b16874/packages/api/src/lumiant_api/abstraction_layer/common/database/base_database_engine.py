from aws_lambda_powertools import Logger
from sqlalchemy.engine.base import Engine
from sqlalchemy.orm import Session
from sqlalchemy_aurora_data_api import register_dialects

register_dialects()


class BaseDatabaseEngine:
    """
    -------------------------------------------------------------------------------------------------
    Abstract class for all database engines.
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    # SQLAlchemy Engine - Single instance to be able to utilise connection pooling
    engine: Engine | None = None
    use_pooling: bool = False

    def create_orm_session(self) -> Session:
        from sqlalchemy.orm import sessionmaker

        # noinspection PyPep8Naming
        Session = sessionmaker(bind=self.engine)
        return Session()
