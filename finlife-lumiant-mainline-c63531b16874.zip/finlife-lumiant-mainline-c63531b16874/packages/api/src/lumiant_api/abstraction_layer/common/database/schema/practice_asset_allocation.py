import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Boolean, Numeric, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class PracticeAssetAllocation(Base):
    __tablename__ = "PracticeAssetAllocation"

    practice_aa_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    practice_id: Mapped[int] = mapped_column(ForeignKey("Practice.practice_id"), nullable=False, index=True)
    risk_group: Mapped[int] = mapped_column(Integer, nullable=False)
    asset_tree_id: Mapped[int] = mapped_column(Integer, nullable=False)
    uses_styles: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    saa_min: Mapped[float | None] = mapped_column(Numeric(5, 4))
    saa: Mapped[float | None] = mapped_column(Numeric(5, 4))
    saa_max: Mapped[float | None] = mapped_column(Numeric(5, 4))
    taa_min: Mapped[float | None] = mapped_column(Numeric(5, 4))
    taa: Mapped[float | None] = mapped_column(Numeric(5, 4))
    taa_max: Mapped[float | None] = mapped_column(Numeric(5, 4))
    style_top_left: Mapped[float | None] = mapped_column(Numeric(5, 4))
    style_top_center: Mapped[float | None] = mapped_column(Numeric(5, 4))
    style_top_right: Mapped[float | None] = mapped_column(Numeric(5, 4))
    style_middle_left: Mapped[float | None] = mapped_column(Numeric(5, 4))
    style_middle_center: Mapped[float | None] = mapped_column(Numeric(5, 4))
    style_middle_right: Mapped[float | None] = mapped_column(Numeric(5, 4))
    style_bottom_left: Mapped[float | None] = mapped_column(Numeric(5, 4))
    style_bottom_center: Mapped[float | None] = mapped_column(Numeric(5, 4))
    style_bottom_right: Mapped[float | None] = mapped_column(Numeric(5, 4))
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    practice: Mapped["Practice"] = relationship("Practice", back_populates="practice_asset_allocations", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice  # pylint: disable=C0413,R0401
