INVPREFS = "investmentpreferences.com.au"
LUMIANT = "lumiant.com.au"
INTERNATIONAL = "lumiant.io"
