import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, String, DateTime, text
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Address(Base):
    __tablename__ = "Address"

    address_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    constructed_address: Mapped[str | None] = mapped_column(String(255), nullable=True)
    address_line_1: Mapped[str] = mapped_column(String(255), nullable=False)
    address_line_2: Mapped[str | None] = mapped_column(String(255))
    suburb: Mapped[str] = mapped_column(String(100), nullable=False)
    post_code: Mapped[str] = mapped_column(String(5), nullable=False)
    state: Mapped[str] = mapped_column(String(3), nullable=False)
    country: Mapped[str] = mapped_column(String(2), nullable=False)
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    client: Mapped["Client"] = relationship(
        "Client", foreign_keys="[Client.address_id]", back_populates="address", lazy="select"
    )
    postal_address_client: Mapped["Client"] = relationship(
        "Client", foreign_keys="[Client.postal_address_id]", back_populates="postal_address", lazy="select"
    )
    practice_office: Mapped["PracticeOffice"] = relationship("PracticeOffice", back_populates="address", lazy="select")
    practice_billing: Mapped["PracticeBilling"] = relationship(
        "PracticeBilling", back_populates="address", lazy="select"
    )
    asset: Mapped["Asset"] = relationship("Asset", back_populates="address", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.client import Client  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.governance.asset import Asset  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_office import PracticeOffice  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_billing import PracticeBilling  # pylint: disable=C0413,R0401
