import os
from pathlib import Path
from typing import Any

from aws_lambda_powertools import Logger

from lumiant_api.abstraction_layer.common.constants import aws_region
from lumiant_api.abstraction_layer.common.database.base_database_engine import BaseDatabaseEngine


class RDSDatabase(BaseDatabaseEngine):
    """
    -------------------------------------------------------------------------------------------------
    Handy class for connecting to and utilising the databased in AWS RDS.
    Currently, `lumiant` and `echo`.
    -------------------------------------------------------------------------------------------------
    """

    # Create a logger for this class - note we're not creating child loggers as this is a shared layer
    logger = Logger(service=__name__)

    def __init__(
        self,
        aurora_cluster_arn: str,
        secret_arn: str,
        database_name: str,
        use_pooling: bool = False,
        pool_size: int = 10,
        pool_recycle: int = 3600,
        pool_max_overflow: int = 10,
        debug: bool = False,
        rds_data_client: Any | None = None,
        init_via_rds_proxy: bool = False,
        username: str | None = None,
        password: str | None = None,
        rds_proxy: str | None = None,
        port: str | None = None,
        region: str | None = None,
    ) -> None:
        if init_via_rds_proxy:
            if os.environ.get("AWS_LAMBDA_FUNCTION_NAME") or os.environ.get("PYTHON_TESTING") == "True":
                self._initiate_via_rds_proxy(
                    database_name=database_name,
                    debug=debug,
                    username=username,
                    password=password,
                    rds_proxy=rds_proxy,
                    port=port,
                    region=region,
                )
            else:
                self._initiate_via_local(database_name=database_name)
        else:
            self._initiate_via_data_api(
                aurora_cluster_arn=aurora_cluster_arn,
                secret_arn=secret_arn,
                database_name=database_name,
                use_pooling=use_pooling,
                pool_size=pool_size,
                pool_recycle=pool_recycle,
                pool_max_overflow=pool_max_overflow,
                debug=debug,
                rds_data_client=rds_data_client,
            )

    def _initiate_via_local(
        self,
        database_name: str,
        host: str = "host.docker.internal",
        port: int = 3306,
        username: str = "root",
        password: str = "root",
        debug: bool = False,
    ) -> None:
        print("Initiate via local MySQL")

        from sqlalchemy import engine
        from sqlalchemy.pool import NullPool

        connection_string = f"mysql+pymysql://{username}:{password}@{host}:{port}/{database_name}"

        self.engine = engine.create_engine(
            connection_string, echo=debug, pool=None, poolclass=NullPool, execution_options={"compiled_cache": None}
        )

    def _initiate_via_data_api(
        self,
        aurora_cluster_arn: str,
        secret_arn: str,
        database_name: str,
        use_pooling: bool = False,
        pool_size: int = 10,
        pool_recycle: int = 3600,
        pool_max_overflow: int = 10,
        debug: bool = False,
        rds_data_client: Any | None = None,
    ) -> None:
        print("Initiate via data api")

        from sqlalchemy import engine

        self.use_pooling = use_pooling

        if use_pooling:
            self.engine = engine.create_engine(
                "mysql+auroradataapi://:@/{0}".format(database_name),
                echo=debug,
                connect_args={
                    "aurora_cluster_arn": aurora_cluster_arn,
                    "secret_arn": secret_arn,
                    "rds_data_client": rds_data_client,
                },
                pool_size=pool_size,
                pool_recycle=pool_recycle,
                max_overflow=pool_max_overflow,
                execution_options={"compiled_cache": None},
            )
        else:
            from sqlalchemy.pool import NullPool

            self.engine = engine.create_engine(
                "mysql+auroradataapi://:@/{0}".format(database_name),
                echo=debug,
                connect_args={
                    "aurora_cluster_arn": aurora_cluster_arn,
                    "secret_arn": secret_arn,
                    "rds_data_client": rds_data_client,
                },
                pool=None,
                poolclass=NullPool,
                execution_options={"compiled_cache": None},
            )

        if use_pooling:
            from lumiant_api.abstraction_layer.common.database.connection_validation import ConnectionValidation

            ConnectionValidation.add_connection_validation(self.engine)

    def _initiate_via_rds_proxy(
        self,
        database_name: str,
        debug: bool = False,
        username: str | None = None,
        password: str | None = None,
        rds_proxy: str | None = None,
        port: str | None = None,
        region: str | None = None,
    ) -> None:
        print("Initiate via proxy")
        print(username)
        print(rds_proxy)
        print(port)

        from sqlalchemy import engine
        from sqlalchemy.pool import NullPool

        pem_file_name = "ap-southeast-2-bundle.pem"
        if region == aws_region.US_EAST_1:
            pem_file_name = "us-east-1-bundle.pem"

        ca_path = os.path.join(os.path.dirname(Path(__file__).absolute()), f"ca/{pem_file_name}")
        ssl_args = {"ssl_ca": ca_path}
        connection_string = f"mysql+pymysql://{username}:{password}@{rds_proxy}:{port}/{database_name}?ssl=true"

        self.engine = engine.create_engine(
            connection_string,
            echo=debug,
            connect_args=ssl_args,
            pool=None,
            poolclass=NullPool,
            execution_options={"compiled_cache": None},
        )
