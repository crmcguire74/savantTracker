import datetime

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, Numeric, String, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Discovery(Base):
    __tablename__ = "Discovery"

    discovery_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    household_id: Mapped[int] = mapped_column(ForeignKey("Household.household_id"), nullable=False, index=True)
    household_income: Mapped[float | None] = mapped_column(Numeric(12, 2))
    additional_household_income: Mapped[float | None] = mapped_column(Numeric(12, 2))
    household_savings: Mapped[float | None] = mapped_column(Numeric(12, 2))
    household_total_assets: Mapped[float | None] = mapped_column(Numeric(12, 2))
    household_total_debt: Mapped[float | None] = mapped_column(Numeric(12, 2))
    super_contributions: Mapped[str] = mapped_column(ENUM("Y", "N", "NP", "U"), nullable=False)
    super_contributions_details: Mapped[str | None] = mapped_column(String(5000), nullable=True)
    savings_regularity: Mapped[str] = mapped_column(ENUM("O", "S", "R", "N"), nullable=False)
    savings_amount: Mapped[float | None] = mapped_column(Numeric(12, 2))
    home_value: Mapped[float | None] = mapped_column(Numeric(12, 2))
    investment_properties_value: Mapped[float | None] = mapped_column(Numeric(12, 2))
    investment_properties_debt: Mapped[float | None] = mapped_column(Numeric(12, 2))
    required_retirement_income: Mapped[float | None] = mapped_column(Numeric(12, 2))
    reference_model: Mapped[int | None] = mapped_column(Integer)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    household: Mapped["Household"] = relationship("Household", back_populates="discovery", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
