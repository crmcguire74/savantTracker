import datetime
import uuid

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from lumiant_api.abstraction_layer.common.database.types.mysql_uuid import MySQLUUID
from sqlalchemy import Integer, ForeignKey, String, Date, Numeric, Boolean, DateTime, text
from sqlalchemy.dialects.mysql import ENUM
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Practice(Base):
    __tablename__ = "Practice"

    practice_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    practice_code: Mapped[uuid.UUID | None] = mapped_column(MySQLUUID(swap_flag=True))
    dealer_group_id: Mapped[int] = mapped_column(ForeignKey("DealerGroup.dealer_group_id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    abn: Mapped[str | None] = mapped_column(String(13))
    afsl: Mapped[str | None] = mapped_column(String(10))
    afsl_name: Mapped[str | None] = mapped_column(String(255))
    legal_name: Mapped[str | None] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(ENUM("I", "S", "L", "X", "Q", "R", "A", "T", "C", "O"), nullable=False)
    original_status: Mapped[str] = mapped_column(ENUM("I", "S", "L", "X", "Q", "R", "A", "T", "C", "O"), nullable=False)
    contract_start: Mapped[datetime.date | None] = mapped_column(Date)
    contract_period: Mapped[int | None] = mapped_column(Integer)
    ilgn: Mapped[str | None] = mapped_column(String(7))
    practice_config_id: Mapped[int | None] = mapped_column(
        ForeignKey("PracticeConfig.practice_config_id"), nullable=True, index=True
    )
    practice_billing_id: Mapped[int | None] = mapped_column(
        ForeignKey("PracticeBilling.practice_billing_id"), nullable=True, index=True
    )
    external_domain: Mapped[str | None] = mapped_column(String(50))
    home_region: Mapped[str | None] = mapped_column(String(20))
    home_locale: Mapped[str | None] = mapped_column(String(5), default="en-AU")
    practice_package_id: Mapped[int] = mapped_column(
        ForeignKey("PracticePackage.practice_package_id"), nullable=False, index=True
    )
    package_discount: Mapped[float] = mapped_column(Numeric(5, 4), nullable=False, default=0.0)
    whitelabel_enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=0)
    t_c_version: Mapped[str | None] = mapped_column(String(20))
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationships
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    dealer_group: Mapped["DealerGroup"] = relationship("DealerGroup", back_populates="practices", lazy="select")

    practice_logos: Mapped[list["PracticeLogo"]] = relationship(
        "PracticeLogo", back_populates="practice", lazy="select"
    )
    practice_risk_profiles: Mapped[list["PracticeRiskProfile"]] = relationship(
        "PracticeRiskProfile", back_populates="practice", lazy="select"
    )
    practice_integrations: Mapped[list["PracticeIntegration"]] = relationship(
        "PracticeIntegration", back_populates="practice", lazy="select"
    )
    riskalyze_state: Mapped["RiskalyzeState"] = relationship(
        "RiskalyzeState", back_populates="practice", uselist=False, lazy="select"
    )
    practice_asset_allocations: Mapped[list["PracticeAssetAllocation"]] = relationship(
        "PracticeAssetAllocation", back_populates="practice", lazy="select"
    )
    practice_offices: Mapped[list["PracticeOffice"]] = relationship(
        "PracticeOffice", back_populates="practice", lazy="select"
    )
    practice_config: Mapped["PracticeConfig"] = relationship(
        "PracticeConfig", back_populates="practice", uselist=False, lazy="select"
    )
    practice_billing: Mapped["PracticeBilling"] = relationship(
        "PracticeBilling", back_populates="practice", uselist=False, lazy="select"
    )
    practice_strategy_category: Mapped[list["PracticeStrategyCategory"]] = relationship(
        "PracticeStrategyCategory", back_populates="practice", lazy="select"
    )
    household_team_members: Mapped[list["HouseholdTeamMember"]] = relationship(
        "HouseholdTeamMember", back_populates="practice", lazy="select"
    )
    practice_provider_sso_mapping: Mapped[list["ProviderSSOMapping"]] = relationship(
        "ProviderSSOMapping", back_populates="practice", lazy="select"
    )
    practice_tamarac_mapping: Mapped[list["TamaracPracticeMapping"]] = relationship(
        "TamaracPracticeMapping", back_populates="practice", lazy="select"
    )
    practice_segmentation: Mapped[list["PracticeSegmentation"]] = relationship(
        "PracticeSegmentation", back_populates="practice", lazy="select"
    )
    riskalyze_portfolio_mapping: Mapped[list["RiskalyzePortfolioMapping"]] = relationship(
        "RiskalyzePortfolioMapping", back_populates="practice", lazy="select"
    )
    money_guide_pro_data_practice_mapping: Mapped["MoneyGuideProData"] = relationship(
        "MoneyGuideProData", back_populates="practice", lazy="select"
    )

    # One-Way Relationships
    practice_package: Mapped["PracticePackage"] = relationship("PracticePackage", lazy="select")


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.dealer_group import DealerGroup  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.packages.practice_package import PracticePackage  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.config.practice_config import PracticeConfig  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_billing import PracticeBilling  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.household_team_member import HouseholdTeamMember  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.integrations.practice_integration import PracticeIntegration  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.money_guide_pro.money_guide_pro_data import MoneyGuideProData  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_asset_allocation import PracticeAssetAllocation  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_logo import PracticeLogo  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_office import PracticeOffice  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_risk_profile import PracticeRiskProfile  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice_segmentation import PracticeSegmentation  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.riskalyze.riskalyze_portfolio_mapping import (
    RiskalyzePortfolioMapping,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.riskalyze.riskalyze_state import RiskalyzeState  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.sso.provider_sso_mapping import ProviderSSOMapping  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.strategies.practice_strategy_category import (
    PracticeStrategyCategory,
)  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.tamarac.practice_mapping import TamaracPracticeMapping  # pylint: disable=C0413,R0401
