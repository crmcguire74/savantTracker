import datetime
from typing import Any

from lumiant_api.abstraction_layer.common.database.schema.base import Base
from sqlalchemy import Integer, ForeignKey, String, DateTime, text
from sqlalchemy.dialects.mysql import JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship


class PracticeSegmentation(Base):
    __tablename__ = "PracticeSegmentation"

    practice_segmentation_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    practice_id: Mapped[int] = mapped_column(ForeignKey("Practice.practice_id"), nullable=False, index=True)
    segment_name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(String(5000))
    rank: Mapped[int | None] = mapped_column(Integer, default=0)
    configuration: Mapped[dict[str, Any] | None] = mapped_column(JSON)
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    external_system: Mapped[str | None] = mapped_column(String(15), nullable=True)
    created_by: Mapped[str] = mapped_column(String(50), nullable=False)
    created: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )
    updated_by: Mapped[str] = mapped_column(String(50), nullable=False)
    updated: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )

    # Two-Way Relationship
    # See https://docs.sqlalchemy.org/en/14/orm/basic_relationships.html
    practice: Mapped["Practice"] = relationship("Practice", back_populates="practice_segmentation", lazy="select")

    household: Mapped[list["Household"]] = relationship(
        "Household", back_populates="practice_segmentation", lazy="select"
    )


# NOTE: See base.py for an explanation behind these imports
from lumiant_api.abstraction_layer.common.database.schema.household import Household  # pylint: disable=C0413,R0401
from lumiant_api.abstraction_layer.common.database.schema.practice import Practice  # pylint: disable=C0413,R0401
