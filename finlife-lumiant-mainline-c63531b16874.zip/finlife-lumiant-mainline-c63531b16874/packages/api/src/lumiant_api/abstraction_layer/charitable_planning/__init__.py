# Charitable Planning abstraction layer

