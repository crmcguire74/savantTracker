import datetime
import sqlalchemy.orm
from boto3.session import Session
from lumiant_api.abstraction_layer.common.database.schema.governance.charitable_planning import (
    CharitablePlanning as DBCharitablePlanning,
)
from lumiant_api.abstraction_layer.common.models.authorisation.lambda_authorisation_metadata import (
    LambdaAuthorisationMetadata,
)
from lumiant_api.abstraction_layer.common.utils.bool_utils import BoolUtils
from lumiant_core.momentum.apps.api_gateway_restapi.exceptions import NotFoundException


class CharitablePlanningApiService(object):
    """
    -------------------------------------------------------------------------------------------------
    SERVICE: Charitable Planning API
    -------------------------------------------------------------------------------------------------
    """

    def __init__(
        self,
        lumiant_rds_session: sqlalchemy.orm.Session,
        boto3_session: Session,
        auth_metadata: LambdaAuthorisationMetadata,
    ):
        self.lumiant_rds_session = lumiant_rds_session
        self.boto3_session = boto3_session
        self.auth_metadata = auth_metadata

    def get(self, charitable_planning_id: int, household_id: int) -> DBCharitablePlanning | None:
        """
        Get a single charitable planning record by ID
        """
        return (
            self.lumiant_rds_session.query(DBCharitablePlanning)
            .filter(DBCharitablePlanning.charitable_planning_id == charitable_planning_id)
            .filter(DBCharitablePlanning.household_id == household_id)
            .filter(DBCharitablePlanning.soft_deleted.is_not(True))
            .first()
        )

    def list(self, household_id: int, include_deleted: bool = False) -> list[DBCharitablePlanning] | None:
        """
        Get all charitable planning records for a household
        """
        if household_id is None:
            return []

        query = self.lumiant_rds_session.query(DBCharitablePlanning).filter(
            DBCharitablePlanning.household_id == household_id
        )

        if not include_deleted:
            query = query.filter(DBCharitablePlanning.soft_deleted.is_not(True))

        return query.all()

    def save(
        self,
        charitable_planning_id: int | None,
        household_id: int,
        has_charitable_foundation: bool | None,
    ) -> DBCharitablePlanning | None:
        """
        Create or update a charitable planning record
        """
        if charitable_planning_id is not None:
            charitable_planning = self.get(charitable_planning_id=charitable_planning_id, household_id=household_id)
            if charitable_planning is None:
                raise NotFoundException(message=f"Charitable Planning with id {charitable_planning_id} not found")

            # prevent updating soft-deleted items (defensive check - get() already filters these)
            if charitable_planning.soft_deleted is True:
                raise NotFoundException(
                    message=f"Charitable Planning with id {charitable_planning_id} is soft \
                     deleted and cannot be updated"
                )
        else:
            charitable_planning = DBCharitablePlanning()
            charitable_planning.household_id = household_id
            charitable_planning.created = datetime.datetime.now(datetime.UTC)
            charitable_planning.created_by = self.auth_metadata.iam_id
            self.lumiant_rds_session.add(charitable_planning)

        charitable_planning.client_id = None
        charitable_planning.legal_entity_id = None
        charitable_planning.has_charitable_foundation = BoolUtils.parse(has_charitable_foundation)
        charitable_planning.updated = datetime.datetime.now(datetime.UTC)
        charitable_planning.updated_by = self.auth_metadata.iam_id

        self.lumiant_rds_session.commit()

        return charitable_planning

    def delete(self, charitable_planning_id: int, household_id: int) -> bool:
        """
        Soft delete a charitable planning record
        """
        charitable_planning = self.get(charitable_planning_id=charitable_planning_id, household_id=household_id)

        if charitable_planning is not None:
            charitable_planning.soft_deleted = True
            charitable_planning.updated_by = self.auth_metadata.iam_id
            charitable_planning.updated = datetime.datetime.now(datetime.UTC)
            self.lumiant_rds_session.commit()
            return True
        else:
            return False
