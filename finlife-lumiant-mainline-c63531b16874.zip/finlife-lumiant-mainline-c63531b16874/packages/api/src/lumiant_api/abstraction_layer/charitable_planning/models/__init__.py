# Charitable Planning models

