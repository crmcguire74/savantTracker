from __future__ import annotations

import json
from dataclasses import dataclass

from aws_lambda_powertools import Logger
from lumiant_api.abstraction_layer.common.utils.bool_utils import BoolUtils
from lumiant_api.abstraction_layer.common.utils.serialization_utils import SerializationUtils
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lumiant_api.abstraction_layer.common.database.schema.governance.charitable_planning import (
        CharitablePlanning as DBCharitablePlanning,
    )


@dataclass
class CharitablePlanning(object):
    logger = Logger(service=__name__)

    charitablePlanningId: int
    householdId: int
    hasCharitableFoundation: bool | None
    created: str
    updated: str
    softDeleted: bool | None

    def __init__(self) -> None:
        self.charitablePlanningId = 0
        self.householdId = 0
        self.hasCharitableFoundation = None
        self.created = ""
        self.updated = ""
        self.softDeleted = None

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        return json.dumps(self.__dict__, default=SerializationUtils.convert_value_to_json_dict)

    @staticmethod
    def convert_from_db_object(db_charitable_planning: DBCharitablePlanning | None) -> CharitablePlanning | None:
        if db_charitable_planning is None:
            return None

        charitable_planning = CharitablePlanning()

        charitable_planning.charitablePlanningId = db_charitable_planning.charitable_planning_id
        charitable_planning.householdId = db_charitable_planning.household_id
        charitable_planning.hasCharitableFoundation = db_charitable_planning.has_charitable_foundation
        charitable_planning.created = SerializationUtils.convert_value_to_string(db_charitable_planning.created)
        charitable_planning.updated = SerializationUtils.convert_value_to_string(db_charitable_planning.updated)
        charitable_planning.softDeleted = BoolUtils.parse(db_charitable_planning.soft_deleted)

        return charitable_planning
