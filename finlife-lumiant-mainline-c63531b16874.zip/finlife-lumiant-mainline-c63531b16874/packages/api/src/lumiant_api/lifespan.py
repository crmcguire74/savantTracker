import os
from typing import TYPE_CHECKING

from lumiant_api.abstraction_layer.common.utils.lambda_global_init_utils import LambdaGlobalInitUtils
from lumiant_core.momentum.apps.api_gateway_restapi.lifespan import RestApiLifespan

if TYPE_CHECKING:
    from lumiant_api.abstraction_layer.common.database.rds_database import RDSDatabase


class LumiantApiLifespan(RestApiLifespan):
    def __init__(self):
        super().__init__()
        # Don't create database connections during initialization - they'll be created lazily on first access
        # This avoids Lambda initialization timeout (10-second hard limit)
        self._rds_database: "RDSDatabase | None" = None

    @property
    def boto3_session(self):
        return self.boto_clients.session

    @property
    def rds_database(self) -> "RDSDatabase | None":
        """Lazy initialization of RDS database connection to avoid Lambda init timeout.

        The database connection is cached for the lifetime of the Lambda container to avoid
        expensive re-initialization. Sessions are created per-request by the DatabaseSession
        middleware to ensure transaction isolation.
        """
        if self._rds_database is None:
            if os.environ.get("AWS_REGION"):
                self._rds_database = self.create_rds_database()
        return self._rds_database

    def create_rds_database(self):
        if os.environ.get("AWS_REGION"):
            return LambdaGlobalInitUtils.create_rds_database(
                boto3_session=self.boto3_session, database_name="lumiant", use_pooling=False
            )
