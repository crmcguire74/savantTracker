from lumiant_core.momentum.apps.api_gateway_restapi import ApiGatewayRestApi
from lumiant_core.momentum.apps.api_gateway_restapi.exceptions import (
    ForbiddenException,
    InternalServerError,
    InvalidParameterException,
    OperationNotFoundException,
)
from lumiant_core.momentum.apps.api_gateway_restapi.middleware.default_middleware_stack import RestApiMiddlewareStack
from lumiant_core.momentum.specifications.openapi.x_amazon_api_gateway.cors import AmazonApiGatewayCors as Cors

from .config import get_current_region, get_resources_for_region
from .lifespan import LumiantApiLifespan
from .middleware.database_session import DatabaseSession
from .middleware.track_api_key_usage import TrackApiKeyUsage
from .middleware.warmup import WarmupMiddleware
from .operations import *  # noqa: F403


class LumiantRestApi(ApiGatewayRestApi):
    lifespan: LumiantApiLifespan


# Get current region and load appropriate resources
region_resources = get_resources_for_region(get_current_region())

app = LumiantRestApi(
    title="API",
    debug=True,
    version="2025-01-06",
    resources=region_resources,
    cors=Cors(
        allowOrigins=["*"],
        allowHeaders=["Accept", "Accept-Language", "Content-Language", "Content-Type", "Authorization"],
        allowMethods=["GET", "HEAD", "POST", "OPTIONS", "DELETE"],
    ),
    lifespan=LumiantApiLifespan(),
    exceptions=[
        InternalServerError,
        InvalidParameterException,
        ForbiddenException,
        OperationNotFoundException,
    ],
)

# Insert request-scoped DB session middleware early, after logging and init
# WarmupMiddleware detects EventBridge warmup calls and short-circuits after DB init
# TrackApiKeyUsage runs after identity is set to track API key usage
current_stack = app.middleware_stack
app.middleware_stack = RestApiMiddlewareStack(
    init=[*current_stack.init],
    verify=[DatabaseSession(), WarmupMiddleware(), TrackApiKeyUsage(), *current_stack.verify],
    validate=[*current_stack.validate],
    invoke=[*current_stack.invoke],
    respond=[*current_stack.respond],
    exception=current_stack.exception,
)
