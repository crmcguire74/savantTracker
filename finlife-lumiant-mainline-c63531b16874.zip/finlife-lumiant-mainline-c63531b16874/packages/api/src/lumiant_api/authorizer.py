from lumiant_core.momentum.apps.api_gateway_authorizer.app import ApiGatewayAuthorizer

authorizer = ApiGatewayAuthorizer()
