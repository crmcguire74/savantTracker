#!/usr/bin/env bash
# Download OpenAPI baseline and release notes history from S3 for an environment.
# Called before release notes generation so the diff has a baseline to compare against.
#
# Usage: bash deployment/download-baseline.sh <env> <region>
# Example: bash deployment/download-baseline.sh dev au
#
# Downloads:
#   s3://<bucket>/openapi.baseline.json -> docs/openapi.baseline.<env>.json
#   s3://<bucket>/release-notes/*.md    -> docs/release-notes/<env>/

set -e

ENV="${1:-}"
REGION="${2:-au}"

if [[ -z "$ENV" ]]; then
    echo "Usage: $0 <env> <region>" >&2
    echo "  env: dev | qa | staging | prod" >&2
    echo "  region: au | us (default: au)" >&2
    exit 1
fi

ENV=$(echo "$ENV" | tr '[:upper:]' '[:lower:]')
REGION=$(echo "$REGION" | tr '[:upper:]' '[:lower:]')

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
CONFIG_FILE="$SCRIPT_DIR/config.json"
DOCS_DIR="$PROJECT_DIR/docs"

# Build bucket name from config
BUCKET_TEMPLATE=$(jq -r '.bucket_template' "$CONFIG_FILE")
POSTFIX=$(jq -r ".region_postfix.\"$REGION\"" "$CONFIG_FILE")
BUCKET_NAME=$(echo "$BUCKET_TEMPLATE" | sed "s/{environment}/$ENV/g" | sed "s/{region}/$REGION/g" | sed "s/{postfix}/$POSTFIX/g")

BASELINE_FILE="$DOCS_DIR/openapi.baseline.${ENV}.json"
RELEASE_NOTES_DIR="$DOCS_DIR/release-notes/${ENV}"

mkdir -p "$DOCS_DIR"
mkdir -p "$RELEASE_NOTES_DIR"

# Download baseline
echo "[INFO] Downloading baseline from s3://$BUCKET_NAME/openapi.baseline.json"
if aws s3 cp "s3://$BUCKET_NAME/openapi.baseline.json" "$BASELINE_FILE" 2>/dev/null; then
    echo "[INFO] Downloaded baseline to $BASELINE_FILE"
else
    echo "[WARN] No baseline found in S3 (first deploy?). Continuing without baseline."
fi

# Download existing release notes history (for index rebuild)
echo "[INFO] Downloading release notes history from s3://$BUCKET_NAME/release-notes/"
if aws s3 sync "s3://$BUCKET_NAME/release-notes/" "$RELEASE_NOTES_DIR/" --exclude "*" --include "*.md" 2>/dev/null; then
    count=$(find "$RELEASE_NOTES_DIR" -name "*.md" 2>/dev/null | wc -l | tr -d ' ')
    echo "[INFO] Downloaded $count release note(s) to $RELEASE_NOTES_DIR/"
else
    echo "[WARN] No release notes history found in S3. Continuing."
fi
