#!/usr/bin/env bash
# Deploy API documentation to S3 buckets per region

set -e

# Helper function to convert to uppercase
to_upper() {
    echo "$1" | tr '[:lower:]' '[:upper:]'
}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
CONFIG_FILE="$SCRIPT_DIR/config.json"

# Use package-local build folder (packages/api/build)
BUILD_DIR="$PROJECT_DIR/build"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_info() {
    echo -e "${GREEN}ℹ ${NC}$1"
}

print_error() {
    echo -e "${RED}✗ ${NC}$1"
}

print_success() {
    echo -e "${GREEN}✓ ${NC}$1"
}

print_warning() {
    echo -e "${YELLOW}⚠ ${NC}$1"
}

# Check if jq is installed
if ! command -v jq &> /dev/null; then
    print_error "jq is required but not installed. Install with: brew install jq"
    exit 1
fi

# Parse arguments
ENVIRONMENT="${1:-dev}"
REGION="${2:-au}"
DRY_RUN="${3:-false}"

# Normalize inputs
ENVIRONMENT=$(echo "$ENVIRONMENT" | tr '[:upper:]' '[:lower:]')
REGION=$(echo "$REGION" | tr '[:upper:]' '[:lower:]')

print_info "Deployment Configuration:"
echo "  Environment: $ENVIRONMENT"
echo "  Region: $REGION"
echo "  Build Dir: $BUILD_DIR"
echo "  Dry Run: $DRY_RUN"
echo ""

# Read bucket template from config
BUCKET_TEMPLATE=$(jq -r '.bucket_template' "$CONFIG_FILE")

# Function to deploy to a specific region
deploy_region() {
    local region=$1
    local region_upper=$(to_upper "$region")
    
    # Get region-specific postfix
    local postfix=$(jq -r ".region_postfix.\"$region\"" "$CONFIG_FILE")
    
    # Construct bucket name
    local bucket_name=$(echo "$BUCKET_TEMPLATE" | sed "s/{environment}/$ENVIRONMENT/g" | sed "s/{region}/$region/g" | sed "s/{postfix}/$postfix/g")
    
    # Source files
    local openapi_file="$BUILD_DIR/openapi.$region.docs.json"
    local index_file="$BUILD_DIR/index.html"
    local release_notes_index="$BUILD_DIR/release-notes.html"
    local release_notes_dir="$BUILD_DIR/release-notes"
    
    print_info "Deploying $region_upper docs to: $bucket_name"
    
    # Check if files exist
    if [ ! -f "$openapi_file" ]; then
        print_error "OpenAPI file not found: $openapi_file"
        print_warning "Run 'npm run build' first to generate documentation"
        return 1
    fi
    
    if [ ! -f "$index_file" ]; then
        print_error "Index file not found: $index_file"
        return 1
    fi
    
    # Deploy commands
    if [ "$DRY_RUN" = "true" ]; then
        print_info "[DRY RUN] Would upload:"
        echo "  $openapi_file -> s3://$bucket_name/openapi.json"
        echo "  $index_file -> s3://$bucket_name/index.html"
        [ -f "$release_notes_index" ] && echo "  $release_notes_index -> s3://$bucket_name/release-notes.html"
        if [ -d "$release_notes_dir" ]; then
            for f in "$release_notes_dir"/*.md "$release_notes_dir"/*.html; do
                [ -f "$f" ] && echo "  $f -> s3://$bucket_name/release-notes/$(basename "$f")"
            done
        fi
    else
        # Stamp the deploy date into info.version before uploading
        local deploy_version
        deploy_version=$(date -u +%Y-%m-%d-%H%M%S)
        print_info "Stamping info.version = $deploy_version"
        local stamped_file="${openapi_file%.json}.stamped.json"
        jq --arg v "$deploy_version" '.info.version = $v' "$openapi_file" > "$stamped_file"

        print_info "Uploading OpenAPI spec..."
        aws s3 cp "$stamped_file" "s3://$bucket_name/openapi.json" --content-type "application/json"
        
        print_info "Uploading index.html..."
        aws s3 cp "$index_file" "s3://$bucket_name/index.html" --content-type "text/html"
        
        if [ -f "$release_notes_index" ]; then
            print_info "Uploading release-notes.html (index)..."
            aws s3 cp "$release_notes_index" "s3://$bucket_name/release-notes.html" --content-type "text/html"
        fi
        if [ -d "$release_notes_dir" ]; then
            print_info "Uploading release notes history..."
            aws s3 sync "$release_notes_dir" "s3://$bucket_name/release-notes/" --content-type "text/markdown" --exclude "*" --include "*.md"
            aws s3 sync "$release_notes_dir" "s3://$bucket_name/release-notes/" --content-type "text/html" --exclude "*" --include "*.html"
        fi
        
        print_success "Deployed $region_upper docs to $bucket_name"
    fi
}

# Deploy based on region parameter
if [ "$REGION" = "all" ]; then
    print_info "Deploying to all regions..."
    deploy_region "au"
    echo ""
    deploy_region "us"
else
    deploy_region "$REGION"
fi

if [ "$DRY_RUN" = "false" ]; then
    echo ""
    print_success "Deployment complete!"
    print_info "View docs at:"
    
    if [ "$REGION" = "all" ]; then
        AU_POSTFIX=$(jq -r '.region_postfix.au' "$CONFIG_FILE")
        US_POSTFIX=$(jq -r '.region_postfix.us' "$CONFIG_FILE")
        echo "  AU: https://$(echo "$BUCKET_TEMPLATE" | sed "s/{environment}/$ENVIRONMENT/g" | sed "s/{region}/au/g" | sed "s/{postfix}/$AU_POSTFIX/g").s3.amazonaws.com/index.html"
        echo "  US: https://$(echo "$BUCKET_TEMPLATE" | sed "s/{environment}/$ENVIRONMENT/g" | sed "s/{region}/us/g" | sed "s/{postfix}/$US_POSTFIX/g").s3.amazonaws.com/index.html"
    else
        POSTFIX=$(jq -r ".region_postfix.\"$REGION\"" "$CONFIG_FILE")
        BUCKET=$(echo "$BUCKET_TEMPLATE" | sed "s/{environment}/$ENVIRONMENT/g" | sed "s/{region}/$REGION/g" | sed "s/{postfix}/$POSTFIX/g")
        echo "  https://$BUCKET.s3.amazonaws.com/index.html"
    fi
else
    echo ""
    print_info "Dry run complete. No files were uploaded."
fi

