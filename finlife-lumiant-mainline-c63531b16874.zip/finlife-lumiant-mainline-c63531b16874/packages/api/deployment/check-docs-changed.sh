#!/usr/bin/env bash
# Check if OpenAPI docs have changed compared to the baseline.
# Uses the release notes generator for semantic comparison (added/removed
# endpoints, schemas, documentation updates) rather than raw JSON diffing.
#
# Usage: bash deployment/check-docs-changed.sh <env>
# Exit 0 = changes detected (or no baseline = first deploy)
# Exit 1 = no changes

set -e

ENV="${1:-}"
if [[ -z "$ENV" ]]; then
    echo "Usage: $0 <env>" >&2
    exit 1
fi

ENV=$(echo "$ENV" | tr '[:upper:]' '[:lower:]')

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
REPO_ROOT="$(cd "$PROJECT_DIR/../.." && pwd)"
MERGED_SPEC="$PROJECT_DIR/build/openapi.merged.json"
BASELINE_FILE="$PROJECT_DIR/docs/openapi.baseline.${ENV}.json"

if [[ ! -f "$MERGED_SPEC" ]]; then
    echo "[ERROR] Merged spec not found: $MERGED_SPEC" >&2
    echo "[ERROR] Run build first." >&2
    exit 0  # Treat as changed to be safe
fi

if [[ ! -f "$BASELINE_FILE" ]]; then
    echo "[INFO] No baseline found for $ENV (first deploy). Treating as changed."
    exit 0
fi

# Use the release notes generator for semantic change detection.
# Exit 0 = changes found, exit 2 = no changes, other = error.
GENERATOR="$REPO_ROOT/tools/cli/generate_api_release_notes.py"

STATUS=0
(cd "$PROJECT_DIR" && uv run python "$GENERATOR" --env "$ENV") || STATUS=$?

case $STATUS in
    0)
        echo "[INFO] Changes detected in OpenAPI spec for $ENV."
        exit 0
        ;;
    2)
        echo "[INFO] No changes detected in OpenAPI spec for $ENV."
        exit 1
        ;;
    *)
        echo "[WARN] Release notes generator exited with $STATUS; treating as changed."
        exit 0
        ;;
esac
