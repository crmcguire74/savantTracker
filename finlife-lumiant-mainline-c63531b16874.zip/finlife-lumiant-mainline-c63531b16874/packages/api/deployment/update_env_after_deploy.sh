#!/usr/bin/env bash
# Update per-env baseline after a successful deploy: copy locally and upload to S3.
#
# Usage: bash deployment/update_env_after_deploy.sh <env> <region>
# Example: bash deployment/update_env_after_deploy.sh qa au

set -e

ENV="${1:-}"
REGION="${2:-au}"

if [[ -z "$ENV" ]]; then
    echo "Usage: $0 <env> <region>" >&2
    echo "  env: dev | qa | staging | prod" >&2
    echo "  region: au | us (default: au)" >&2
    exit 1
fi

ENV=$(echo "$ENV" | tr '[:upper:]' '[:lower:]')
REGION=$(echo "$REGION" | tr '[:upper:]' '[:lower:]')

case "$ENV" in
    dev|qa|staging|prod) ;;
    *)
        echo "Invalid env: $ENV" >&2
        exit 1
        ;;
esac

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
CONFIG_FILE="$SCRIPT_DIR/config.json"
API_BUILD_DIR="$PROJECT_DIR/build"
DOCS_DIR="$PROJECT_DIR/docs"
MERGED_SPEC="$API_BUILD_DIR/openapi.merged.json"
BASELINE_FILE="$DOCS_DIR/openapi.baseline.$ENV.json"

if [[ ! -f "$MERGED_SPEC" ]]; then
    echo "OpenAPI merged spec not found: $MERGED_SPEC" >&2
    echo "Run build (openapi:generate + openapi:overlay) first." >&2
    exit 1
fi

# Copy locally (used as reference during this build)
mkdir -p "$DOCS_DIR"
cp "$MERGED_SPEC" "$BASELINE_FILE"

# Build bucket name from config and upload to S3
BUCKET_TEMPLATE=$(jq -r '.bucket_template' "$CONFIG_FILE")
POSTFIX=$(jq -r ".region_postfix.\"$REGION\"" "$CONFIG_FILE")
BUCKET_NAME=$(echo "$BUCKET_TEMPLATE" | sed "s/{environment}/$ENV/g" | sed "s/{region}/$REGION/g" | sed "s/{postfix}/$POSTFIX/g")

echo "[INFO] Uploading baseline to s3://$BUCKET_NAME/openapi.baseline.json"
aws s3 cp "$BASELINE_FILE" "s3://$BUCKET_NAME/openapi.baseline.json" --content-type "application/json"
echo "[INFO] Updated baseline for $ENV in S3"
