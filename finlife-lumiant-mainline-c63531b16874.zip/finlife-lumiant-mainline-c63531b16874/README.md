# Lumiant Workspace

A modern monorepo containing all Lumiant packages and services, including Python backend APIs, TypeScript SDKs, CDK infrastructure, and Astro-based frontend applications.

## What is a Monorepo?

A monorepo (monolithic repository) is a software development strategy where multiple related projects are stored in a single repository. This approach offers several benefits:

- **Shared dependencies**: Common libraries and tools are managed centrally
- **Consistent tooling**: Same build, test, and lint configurations across all packages
- **Atomic changes**: Cross-package changes can be made in a single commit
- **Simplified dependency management**: Internal packages can reference each other easily
- **Better collaboration**: All code is visible and searchable in one place

## Key Tools & Technologies

### Development Tools

- **[mise](https://mise.jdx.dev/)**: Development environment manager that handles tool versions (Python, Node.js, pnpm, etc.) and project tasks
- **[pnpm](https://pnpm.io/)**: Fast, disk space efficient package manager for Node.js with excellent monorepo support
- **[uv](https://docs.astral.sh/uv/)**: Ultra-fast Python package installer and resolver, replacing pip/poetry with significant speed improvements
- **[Turborepo](https://turbo.build/)**: High-performance build system for monorepos with intelligent caching and parallel execution
- **[lefthook](https://github.com/evilmartians/lefthook)**: Fast Git hooks manager for enforcing quality checks before commits

### Python Ecosystem

- **[Ruff](https://docs.astral.sh/ruff/)**: Extremely fast Python linter and formatter, replacing multiple tools (flake8, black, isort)
- **[pytest](https://pytest.org/)**: Python testing framework with powerful fixtures and plugins
- **[mypy](https://mypy.readthedocs.io/)**: Static type checker for Python
- **[FastAPI](https://fastapi.tiangolo.com/)**: Modern, fast web framework for building APIs with Python
- **[Pylance](https://marketplace.visualstudio.com/items?itemName=ms-python.python)**: Microsoft's Python language server for VS Code

### Frontend & Infrastructure

- **[Astro](https://astro.build/)**: Modern static site builder for content-focused websites
- **[Sanity](https://www.sanity.io/)**: Headless CMS for structured content
- **[AWS CDK](https://aws.amazon.com/cdk/)**: Infrastructure as Code using TypeScript
- **[Biome](https://biomejs.dev/)**: One toolchain for your web project
- **[VS Code](https://code.visualstudio.com/)**: Primary development environment with multi-root workspace support

## Prerequisites

### macOS Setup

#### 1. Install Homebrew

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

#### 2. Install mise

```bash
brew install mise
```

This repository currently enforces **mise `2026.4.0`**.

Verify your version:

```bash
mise --version
```

If you are on a different version:

```bash
brew upgrade mise
```

#### 3. Configure mise in your shell

Add to your shell profile (`.zshrc`, `.bashrc`, etc.):

```bash
eval "$(mise activate zsh)"  # or bash/fish
```

Restart your shell or run:

```bash
source ~/.zshrc
```

## Getting Started

### Initial Setup

```bash
# Clone the repository
git clone git@bitbucket.org:finlife/lumiant.git
cd lumiant

# Run full setup (installs tools, dependencies, and builds everything)
mise run setup

# Open the workspace in VS Code
code lumiant-workspace.code-workspace
```

The `mise run setup` command will:

1. Clean all previous build artifacts and caches
2. Install Python 3.12, Node.js 24.14.1, pnpm 10.33.0, and other tools
3. Install all package dependencies (both Python and Node.js)
4. Build all packages in dependency order with Turborepo caching
5. Set up Python virtual environments for each package
6. Install Git hooks via lefthook for pre-commit quality checks

## Development Workflow

### Common Commands

All development tasks are managed through `mise`:

```bash
# Quick sync when dependencies change
mise run sync           # Install deps + build everything (cached)

# Build all packages
mise run build          # Runs: turbo build

# Run all tests
mise run test           # Runs: turbo test

# Lint all code
mise run lint           # Runs: turbo lint

# Format all code
mise run format         # Runs: turbo format

# Type-check all packages (Python + TypeScript)
mise run typecheck      # Runs: turbo typecheck

# Run development servers (parallel)
mise run dev            # Runs: turbo dev --parallel

# Clean build artifacts (keeps dependencies)
mise run clean          # Fast clean

# Nuclear clean (removes all dependencies and caches)
mise run clean:full     # Slow, forces complete reinstall

# Full reset (clean + setup)
mise run reset          # When things break

# Validate enforced mise version
mise run check:mise
```

### Tool Versions

All tool versions are managed in `mise.toml`:

- **mise (required binary version)**: 2026.4.0
- **Python**: 3.12
- **Node.js**: 24.14.1
- **pnpm**: 10.33.0
- **Biome**: 2.4.9
- **uv**: 0.8.11
- **ruff**: 0.12.9
- **AWS SAM CLI**: latest
- **LocalStack**: 4.7.0

### Import Path Conventions (ESM + TypeScript)

Current alias strategy is intentionally split between internal and external imports:

- **Internal imports (within an app/package):** `#app/*`
- **External imports (cross-package):** `@local/...`

Examples:

```ts
import { Section } from '#app/components/section/section';
import { Button } from '@local/ui/components/ui/button';
import type { PageBuilder } from '@local/sanity-studio/sanity.types';
```

TypeScript note:

- We keep **minimal `tsconfig.paths`** entries where TypeScript still needs help resolving workspace source directly.
- `package.json` `imports`/`exports` are still the primary ESM contract, but in this monorepo TypeScript resolution is not yet fully self-sufficient for all cross-package source paths.

### Working with Individual Packages

#### Python Packages (API, Core, Legacy)

```bash
# Navigate to a Python package
cd packages/api

# Python-first workflow
uv sync                # Install/update dependencies
uv run pytest          # Run tests
uv run ruff check .    # Lint
uv run ruff format .   # Format
uv build --out-dir dist

# Or use package scripts if you prefer
pnpm build
pnpm lint
pnpm format
```

Most package scripts use the `lumina` wrapper internally, which detects whether a package is Python or Node and dispatches to the right tools.

- **Python**: Uses `uv` for dependency management, `uv build` for packaging
- **Node**: Calls build tools directly (tsc, vite, etc.)

#### TypeScript Packages (UI, SDKs, CDK)

```bash
# Navigate to a TypeScript package
cd packages/ui

# Use package scripts
pnpm build
pnpm test
pnpm lint
pnpm format
```

#### Frontend Apps (Astro, Sanity Studio)

```bash
# Navigate to an app
cd apps/astro

# Development
pnpm dev               # Start dev server (http://localhost:4321)
pnpm build             # Build for production
pnpm preview           # Preview production build
pnpm lint              # Lint with Biome
pnpm format            # Format with Biome
```

### VS Code Workspace

The repository includes a multi-root workspace file (`lumiant-workspace.code-workspace`) that organizes all packages and apps for easy navigation in VS Code.

**To open the workspace:**

```bash
code lumiant-workspace.code-workspace
```

This will load all packages and apps as separate folders in VS Code, allowing you to:

- Navigate between packages easily
- Use package-specific settings
- Run tasks from any package
- Search across specific packages

**Workspace features:**

- Each package has its own folder in the VS Code sidebar
- Python packages automatically detect their `.venv` interpreters
- TypeScript packages use workspace-wide `tsconfig.json` settings
- Recommended extensions are suggested on first open
- Workspace tasks available via `Tasks: Run Task`

## Turborepo Configuration

The monorepo uses **Turborepo** for intelligent build orchestration with caching.

### Global Configuration (`turbo.json`)

The root `turbo.json` defines **default task configurations** for all packages:

- **Common inputs**: `src/**`, `lib/**`, `package.json`, `tsconfig.json`, `pyproject.toml`
- **Common outputs**: `dist/**`
- **Common exclusions**: `__pycache__`, `*.pyc`, `*.d.ts`, build directories
- **Task defaults**: `build`, `test`, `lint`, `format`, `typecheck`, `dev`, `clean`

### Package-Level Configuration

Packages only need a `turbo.json` if they have **special requirements**:

#### Packages with Custom turbo.json

- **`@local/api`**: Has OpenAPI generation, Python builds, deploy tasks
- **`@local/ui`**: Has Tailwind CSS builds, separate style/component tasks
- **`@local/lumiant-cdk`**: Has CDK synth outputs to `cdk.out/**`
- **`@local/sanity-studio`**: Has Sanity type generation and deploy tasks
- **`@local/website`** (Astro): Has Astro-specific configs and `.astro/**` cache

#### Packages Using Defaults

Most packages inherit from root and need no `turbo.json`:

- `@local/lumiant-core`
- `@local/lumiant-legacy`
- `@local/lumiant-python-sdk`
- `@local/lumiant-typescript-sdk`
- `@local/momentum-cdk-constructs`
- `@local/shared-config`

### Turborepo Benefits

```bash
# First build: Everything builds
mise run build
# → Takes ~2-3 minutes

# Second build: Everything cached
mise run build
# → Takes ~5 seconds (all cache hits!)

# Change one file in @local/api
echo "# comment" >> packages/api/src/main.py

# Incremental build: Only affected packages rebuild
mise run build
# → Rebuilds: @local/api, @local/lumiant-cdk (depends on api)
# → Cached: All other packages
```

## Local Development & Testing

### Prerequisites

Before running the local stack, ensure you have:

- **Docker Desktop** running (for the local MySQL database)
- **mise** installed and configured
- Initial setup completed: `mise run setup`

### Starting the Local Stack

#### 1. Start the Local Database

```bash
cd packages/api
pnpm run rds:start
```

This starts a MySQL 8.0 container with:

- **Host**: `127.0.0.1`
- **Port**: `3306`
- **User**: `root`
- **Password**: `root`
- **Database**: `lumiant`

**Verify the database:**

```bash
docker ps | grep mysql
# Should show: 0.0.0.0:3306->3306/tcp
```

#### 2. Start the Local API Server

```bash
cd packages/api
pnpm run start
```

This will:

1. Build the API bundle (OpenAPI spec, Python packages)
2. Start SAM Local with hot-reload at `http://127.0.0.1:3000`
3. Connect to your local MySQL database

### Testing the API

**Important**: SAM Local requires an `Authorization` header, but any value works locally (e.g., `Bearer fake-token`).

#### Using curl

```bash
# List clients
curl -X GET http://127.0.0.1:3000/clients \
  -H "Authorization: Bearer fake-token"

# Create a client
curl -X POST http://127.0.0.1:3000/clients \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer fake-token" \
  -d '{"name": "Test Client"}'
```

#### Using Postman

1. **Base URL**: `http://127.0.0.1:3000`
2. Add header: `Authorization: Bearer fake-token`
3. Make requests to any endpoint in your OpenAPI spec

#### Running Tests

```bash
# Test all packages (with Turbo caching)
mise run test

# Test unit tests with code coverage - BE
mise run test:unit_test

# Test API only
cd packages/api
uv run pytest

# Or use pytest directly
uv run pytest test/
```

### Stopping the Local Stack

```bash
# Stop API (Ctrl+C in terminal)

# Stop database
cd packages/api
pnpm run rds:stop
```

## Deployment

### Pipeline Helper Scripts

The deployment pipeline uses reusable helper scripts to reduce duplication and ensure consistency across environments. All deployment logic is centralized in three shell scripts and orchestrated through mise tasks.

#### Architecture Overview

```
bitbucket-pipelines.yml
    │
    ├─> mise run deploy:dev
    │       │
    │       └─> [tasks."deploy:dev"] (mise.toml)
    │               │
    │               └─> DEPLOY_ENV=dev DEPLOY_REGION=au mise run _deploy
    │                       │
    │                       └─> [tasks."_deploy"] (mise.toml)
    │                               │
    │                               ├─> source pipeline-helpers.sh
    │                               ├─> source pipeline-config.sh
    │                               ├─> get_env_config()
    │                               ├─> deploy_environment()
    │                               └─> cleanup_aws_temp() [via trap EXIT]
```

**Key Benefits:**

- **Single source of truth**: Environment configs in `scripts/pipeline-config.sh`
- **Automatic cleanup**: `trap EXIT` ensures cleanup even on deployment failure
- **No duplication**: Helper scripts sourced once per deployment
- **Easy to extend**: Add new environments in ~10 minutes

---

#### Local Testing

Before pushing pipeline changes, validate your configuration locally:

```bash
# Test pipeline configuration
./scripts/pipelines-test-local.sh
```

**First-time setup:**

The pipeline uses AWS account IDs that are **not stored in the repository** for security. Set them locally:

**Option 1: Using mise (Recommended)**

```bash
# Get AWS account IDs from your team lead, then:
mise set AWS_ACCOUNT_ID="<dev-account-id>"
mise set PRE_PROD_AWS_ACCOUNT_ID="<qa-account-id>"
mise set STAGING_AWS_ACCOUNT_ID="<staging-account-id>"
mise set PROD_AWS_ACCOUNT_ID="<prod-account-id>"

# Reload shell to activate mise environment
exec zsh

# Verify they're set
mise env | grep AWS_ACCOUNT_ID
```

**Option 2: Using a local `.env` file**

```bash
# Create .env file (already in .gitignore)
cat > .env << 'EOF'
AWS_ACCOUNT_ID="<dev-account-id>"
PRE_PROD_AWS_ACCOUNT_ID="<qa-account-id>"
STAGING_AWS_ACCOUNT_ID="<staging-account-id>"
PROD_AWS_ACCOUNT_ID="<prod-account-id>"
EOF

# Configure mise to load it
cat > .mise.toml << 'EOF'
[env]
_.file = ".env"
EOF

# Test
./scripts/pipelines-test-local.sh
```

**What the test validates:**

- ✅ Helper scripts exist and are executable
- ✅ Environment variables are configured correctly
- ✅ All environment configurations are valid
- ✅ Helper functions are defined
- ✅ Mise deployment tasks are available

**Expected output:**

```
=== Testing Pipeline Scripts Locally ===

1. Checking scripts...
✓ scripts/pipeline-helpers.sh
✓ scripts/pipeline-config.sh

2. Checking environment variables...
✓ AWS_ACCOUNT_ID is set
✓ PRE_PROD_AWS_ACCOUNT_ID is set
✓ STAGING_AWS_ACCOUNT_ID is set
✓ PROD_AWS_ACCOUNT_ID is set

3. Testing pipeline-config.sh...
   Listing environments:
     Configured environments:
       - dev:au
       - qa:au
       - qa:us
       - staging:au
       - staging:us
       - prod:au
       - prod:us

   ✓ dev:au → lumiant-dev (ap-southeast-2, Account: 1234...)
   ✓ qa:au → lumiant-qa (ap-southeast-2, Account: 2345...)
   ✓ qa:us → lumiant-qa-us (us-east-1, Account: 2345...)
   ✓ staging:au → lumiant-staging (ap-southeast-2, Account: 3456...)
   ✓ staging:us → lumiant-staging-us (us-east-1, Account: 3456...)
   ✓ prod:au → lumiant-prod (ap-southeast-2, Account: 4567...)
   ✓ prod:us → lumiant-prod-us (us-east-1, Account: 4567...)

4. Testing pipeline-helpers.sh functions...
   ✓ Function exists: setup_aws_oidc
   ✓ Function exists: cleanup_aws_temp
   ✓ Function exists: deploy_api_docs
   ✓ Function exists: deploy_cdk
   ✓ Function exists: deploy_environment

5. Checking mise deployment tasks...
  ✓ deploy:list         List all deployment targets
   ✓ deploy:dev          Deploy to Dev environment (AU)
   ✓ deploy:qa:au        Deploy to QA AU
   ✓ deploy:qa:us        Deploy to QA US
   ✓ deploy:staging:au   Deploy to Staging AU
   ✓ deploy:staging:us   Deploy to Staging US
   ✓ deploy:prod:au      Deploy to Prod AU
   ✓ deploy:prod:us      Deploy to Prod US
  ✓ deploy:website:dev      Deploy website only to Dev (AU)
  ✓ deploy:website:prod:au  Deploy website only to Prod (AU)

=== All Tests Passed! ===
```

---

#### Helper Scripts Overview

**`scripts/pipeline-helpers.sh`**

Reusable functions for AWS authentication and deployments:

| Function               | Purpose                            |
| ---------------------- | ---------------------------------- |
| `setup_aws_oidc()`     | Configure AWS credentials via OIDC |
| `deploy_api_docs()`    | Deploy API documentation to S3     |
| `deploy_cdk()`         | Deploy CDK infrastructure stacks   |
| `deploy_environment()` | Full deployment workflow           |
| `cleanup_aws_temp()`   | Clean up temporary AWS files       |

**`scripts/pipeline-config.sh`**

Single source of truth for all deployment targets:

| Function              | Purpose                                                      |
| --------------------- | ------------------------------------------------------------ |
| `get_env_config()`    | Retrieve AWS account, profile, and region for an environment |
| `list_environments()` | List all configured environments                             |

Maps environments to AWS configuration:

```bash
# Example: get_env_config "qa" "au"
# Returns: "234567890123 lumiant-qa ap-southeast-2"
```

**`scripts/pipelines-test-local.sh`**

Validation script for local testing:

- Checks scripts exist and are executable
- Validates environment variables are set
- Tests configuration for all environments
- Verifies helper functions are defined
- Confirms mise tasks are available

**Does not require AWS credentials or OIDC tokens** - safe to run locally anytime.

---

#### Deployment Workflow

**In Bitbucket Pipeline:**

```yaml
# bitbucket-pipelines.yml
- step: &deploy-dev
    name: Deploy to DEV (AU)
    deployment: dev
    oidc: true
    script:
      - mise install
      - mise run deploy:dev # ← Single command triggers entire deployment
```

**Mise Task Orchestration:**

```toml
# mise.toml
[tasks."deploy:dev"]
description = "Deploy to Dev environment (AU)"
run = "DEPLOY_ENV=dev DEPLOY_REGION=au mise run _deploy"

[tasks."_deploy"]
description = "Internal: Generic deployment wrapper with cleanup"
run = '''
source ./scripts/pipeline-helpers.sh
source ./scripts/pipeline-config.sh

# Automatic cleanup on exit (success or failure)
trap cleanup_aws_temp EXIT

CONFIG=$(get_env_config "$DEPLOY_ENV" "$DEPLOY_REGION")
read -r ACCOUNT_ID PROFILE REGION <<< "$CONFIG"

deploy_environment "$DEPLOY_ENV" "$ACCOUNT_ID" "$REGION" "$PROFILE"
'''
```

**What happens during deployment:**

1. **Setup AWS OIDC** - Authenticate to AWS using Bitbucket's OIDC token
2. **Validate credentials** - Verify AWS access and account ID
3. **Build packages** - Run `mise run build`
4. **Deploy API docs** - Upload to S3 bucket for the environment
5. **Deploy CDK stacks** - Deploy infrastructure matching the environment pattern
6. **Cleanup** - Remove temporary AWS credential files (runs even on failure)

---

#### Environment Configuration Reference

Current configured environments:

| Environment | Region | AWS Profile          | AWS Region       | Account ID Variable       |
| ----------- | ------ | -------------------- | ---------------- | ------------------------- |
| **dev**     | AU     | `lumiant-dev`        | `ap-southeast-2` | `AWS_ACCOUNT_ID`          |
| **qa**      | AU     | `lumiant-qa`         | `ap-southeast-2` | `PRE_PROD_AWS_ACCOUNT_ID` |
| **qa**      | US     | `lumiant-qa-us`      | `us-east-1`      | `PRE_PROD_AWS_ACCOUNT_ID` |
| **staging** | AU     | `lumiant-staging`    | `ap-southeast-2` | `STAGING_AWS_ACCOUNT_ID`  |
| **staging** | US     | `lumiant-staging-us` | `us-east-1`      | `STAGING_AWS_ACCOUNT_ID`  |
| **prod**    | AU     | `lumiant-prod`       | `ap-southeast-2` | `PROD_AWS_ACCOUNT_ID`     |
| **prod**    | US     | `lumiant-prod-us`    | `us-east-1`      | `PROD_AWS_ACCOUNT_ID`     |

**Branch to environment mapping:**

| Branch             | Deployment                                   |
| ------------------ | -------------------------------------------- |
| `mainline`         | Dev AU                                       |
| `qa-mainline`      | QA AU + QA US (parallel)                     |
| `staging-mainline` | Staging AU + Staging US (parallel)           |
| `prod-mainline`    | Prod AU + Prod US (parallel, manual trigger) |

---

#### Troubleshooting

**"Permission denied" when running scripts:**

```bash
chmod +x scripts/*.sh
```

**"Environment variable not set" in pipeline:**

Check that environment variables are configured in **Repository Settings → Repository Variables**:

- `AWS_ACCOUNT_ID`
- `PRE_PROD_AWS_ACCOUNT_ID`
- `STAGING_AWS_ACCOUNT_ID`
- `PROD_AWS_ACCOUNT_ID`

**"BITBUCKET_STEP_OIDC_TOKEN not found":**

Ensure `oidc: true` is set in the pipeline step definition.

**"Unknown environment/region combination":**

The requested environment doesn't exist in `scripts/pipeline-config.sh`. Check spelling or add the new environment.

**Deployment fails but cleanup doesn't run:**

The `trap cleanup_aws_temp EXIT` in `mise.toml` ensures cleanup runs on both success and failure. If it's not running, check that the `_deploy` task is being used.

**Local testing shows "bad substitution":**

You're running in `sh` instead of `bash`. Run explicitly:

```bash
bash scripts/pipelines-test-local.sh
```

Or ensure shebang uses `#!/usr/bin/env bash` (not `#!/bin/bash`).

---

#### Mac Mini Infrastructure

The pipeline runs on **self-hosted macOS runners** (4x Mac Minis) for faster builds and better Apple Silicon support.

**Runner Labels:**

| Runner     | Labels                                | Purpose                              | Notes  |
| ---------- | ------------------------------------- | ------------------------------------ | ------ |
| Build/Test + deploy AU | `self.hosted`, `macos`, `mainline.au` | AU deployment steps | Active |
| Build/Test + deploy US | `self.hosted`, `macos`, `mainline.us` | US deployment steps | Active |
| Build/Test shared | `self.hosted`, `macos`, `mainline` | Build-and-test steps | Active |
| Build machine setup (custom) | `self.hosted`, `macos`, `amplify`, `mm1|mm2|mm3` and `self.hosted`, `macos`, `mainline`, `mm4` | One-time runner provisioning | Active |

**One-time setup per runner:**

Each Mac Mini needs to be configured once to install mise and development tools:

```bash
# In Bitbucket Pipelines UI
Pipelines → Run Pipeline → Custom
# Select one: configure-build-machine-mm1 / configure-build-machine-mm2 / configure-build-machine-mm3 / configure-build-machine-mm4

# This installs:
# - mise to ~/.local/bin/mise
# - All tools to ~/.local/share/mise/
# - Shell activation in ~/.bashrc
# - AWS CLI, jq, and other utilities
```

**What gets installed:**

- **mise**: Development environment manager
- **Node.js 22.19.0**: Via mise
- **Python 3.12**: Via mise
- **pnpm 10.25.0**: Via mise
- **uv, ruff**: Python tools via mise
- **AWS CLI**: Via Homebrew
- **jq**: JSON processor for AWS scripts

**Persistent on runners (not re-installed each build):**

- ✅ `~/.local/share/mise/` - Tool installations
- ✅ `~/.local/bin/mise` - Mise binary
- ✅ Homebrew packages (awscli, jq)

**Re-synced each build (fast):**

- `mise install` - Checks tool versions, only installs if missing
- `mise run sync` - Syncs dependencies using Turbo cache

**When to re-run setup:**

- Adding a new Mac Mini to the runner pool
- Upgrading tool versions in `mise.toml`
- After macOS updates that break mise installation
- When `mise doctor` shows issues

---

### API Documentation Deployment

Deploy API documentation to S3 (automatically handled by deployment tasks):

```bash
# Standalone deployment (if needed)
cd packages/api

# Dev
pnpm run deploy-docs:dev:au

# QA
pnpm run deploy-docs:qa:au
pnpm run deploy-docs:qa:us

# Staging
pnpm run deploy-docs:staging:au
pnpm run deploy-docs:staging:us

# Production
pnpm run deploy-docs:prod:au
pnpm run deploy-docs:prod:us
```

**Note:** These are automatically called by `deploy_environment()` in the pipeline helper scripts.

### Project Structure

```
.
├── mise.toml                        # Tool versions and workspace tasks
├── turbo.json                       # Global Turborepo configuration
├── pnpm-workspace.yaml              # pnpm workspace configuration
├── package.json                     # Root package.json
├── lumiant-workspace.code-workspace # VS Code multi-root workspace
├── bitbucket-pipelines.yml          # CI/CD pipeline configuration
├── scripts/
│   ├── pipeline-helpers.sh          # Reusable deployment functions
│   ├── pipeline-config.sh           # Environment configuration
│   └── pipelines-test-local.sh      # Local validation script
│
├── apps/
│   ├── astro/                      # Public website (Astro)
│   │   ├── src/
│   │   ├── public/
│   │   ├── astro.config.mjs
│   │   ├── turbo.json              # Astro-specific build config
│   │   └── package.json
│   │
│   └── sanity-studio/              # Content management (Sanity)
│       ├── src/
│       │   ├── schemaTypes/
│       │   ├── presentation/
│       │   ├── queries/
│       │   └── structure/
│       ├── sanity.config.ts
│       ├── turbo.json              # Sanity-specific tasks
│       └── package.json
│
├── packages/
│   ├── api/                        # FastAPI backend
│   │   ├── src/lumiant_api/
│   │   ├── test/
│   │   ├── templates/              # OpenAPI templates
│   │   ├── pyproject.toml
│   │   ├── turbo.json              # API-specific build pipeline
│   │   └── package.json
│   │
│   ├── core/                       # Shared Python libraries
│   │   ├── src/lumiant_core/
│   │   ├── test/
│   │   └── pyproject.toml
│   │
│   ├── lumiant-legacy/             # Legacy Python code
│   │   ├── src/
│   │   └── pyproject.toml
│   │
│   ├── lumiant-python-sdk/         # Python SDK
│   │   ├── src/
│   │   └── pyproject.toml
│   │
│   ├── lumiant-typescript-sdk/     # TypeScript SDK
│   │   ├── src/
│   │   └── package.json
│   │
│   ├── lumiant-cdk/                # Infrastructure as Code (AWS CDK)
│   │   ├── lib/
│   │   │   ├── api-stack.ts
│   │   │   ├── website-stack.ts
│   │   │   └── app.ts
│   │   ├── turbo.json              # CDK-specific outputs
│   │   └── package.json
│   │
│   ├── momentum-cdk-constructs/    # Reusable CDK constructs
│   │   ├── lib/
│   │   └── package.json
│   │
│   ├── pipelines-api/              # Pipelines backend/API package
│   │   ├── src/
│   │   └── package.json
│   │
│   ├── pipelines-cdk/              # Pipelines infrastructure (CDK)
│   │   ├── lib/
│   │   └── package.json
│   │
│   ├── pipelines-typescript-sdk/   # Pipelines TypeScript SDK
│   │   ├── src/
│   │   └── package.json
│   │
│   ├── ui/                         # Shared UI components
│   │   ├── src/
│   │   ├── turbo.json              # UI-specific build tasks
│   │   └── package.json
│   │
│   └── shared-config/              # Shared configs (TypeScript, Tailwind)
│       ├── typescript/
│       ├── tailwind/
│       └── package.json
│
└── tools/
    └── bin/
        └── lumina                   # Unified package-level script
```

## CI/CD Pipeline

The project uses **Bitbucket Pipelines** with **self-hosted macOS runners** (Mac Minis).

### Pipeline Flow

1. **Build & Test** - Runs on every PR and commit to mainline branches
2. **Deploy** - Automatic deployment based on branch:
  - `mainline` → Dev environment (AU)
   - `qa-mainline` → QA environment (AU + US)
   - `staging-mainline` → Staging environment (AU + US)
   - `prod-mainline` → Production environment (AU + US, **manual trigger**)

### Mac Mini Setup

**One-time setup per Mac Mini:**

Run the configuration pipeline once per runner to install mise and tools:

```bash
# In Bitbucket Pipelines UI
Pipelines → Run Pipeline → Custom
# Select: configure-build-machine-mm1 (repeat for mm2, mm3, mm4)
```

This installs:

- mise to `~/.local/bin/mise`
- All tools to `~/.local/share/mise/`
- Shell activation in `~/.bashrc`

### Pipeline Commands

Every pipeline step runs:

```bash
# Activate mise (already installed on runners)
eval "$(~/.local/bin/mise activate bash --shims)"

# Ensure tools are up-to-date (fast if already installed)
mise install

# Sync dependencies and build (with Turbo caching)
mise run sync
```

### Caching Strategy

**Cached:**

- ✅ `.pnpm-store` (~100-500 MB) - pnpm package cache
- ✅ `.turbo` (~10-100 MB) - Turborepo build cache

**Not Cached:**

- ❌ `~/.local/share/mise` - Tools persist on self-hosted runners
- ❌ `node_modules` - pnpm-store is more efficient
- ❌ `.venv` - Per-package, recreated quickly with uv

### Deployment Triggers

Current branch-triggered behavior in `bitbucket-pipelines.yml`:

- `mainline`: build/test + deploy `dev:au`
- `qa-mainline`: build/test + parallel deploy `qa:au` and `qa:us` (manual steps)
- `staging-mainline`: build/test + parallel deploy `staging:au` and `staging:us` (manual steps)
- `prod-mainline`: build/test + parallel deploy `prod:au` and `prod:us` (manual steps)

Website-only deployments are available as custom pipelines:

- `website-deploy-dev`
- `website-deploy-prod-au`

### Environment Variables

Each deployment step uses AWS OIDC for secure credentials:

```yaml
deployment: dev # or qa, staging, prod
oidc: true
# Required in Bitbucket step/runtime:
# - BITBUCKET_STEP_OIDC_TOKEN
# - AWS_ACCOUNT_ID
# - PRE_PROD_AWS_ACCOUNT_ID
# - STAGING_AWS_ACCOUNT_ID
# - PROD_AWS_ACCOUNT_ID
```

No AWS credentials stored in repository or Bitbucket settings.

## Troubleshooting

### Tools not found in PATH

```bash
# Reinstall mise tools
mise install

# Check mise status
mise doctor

# Verify mise activation
which mise
# Should show: /Users/<you>/.local/bin/mise

# Check tool installations
mise list
```

### VS Code doesn't recognize Python environments

```bash
# Refresh Python environments in VS Code
Cmd+Shift+P → "Python: Select Interpreter"
# Choose the .venv/bin/python for each package

# Or restart VS Code
Cmd+Q → Reopen workspace
```

### Python import errors or missing dependencies

**Symptoms:**
- VS Code shows "Import could not be resolved" errors
- Pylance reports missing modules like `lumiant_core` or `lumiant`
- Python tests fail with `ModuleNotFoundError`

**Common causes:**
1. **Python version mismatch** - Virtual environment created with wrong Python version
2. **Missing workspace dependencies** - Workspace packages not installed in editable mode
3. **Stale virtual environment** - Environment not synced after dependency changes

**Solution:**

```bash
# Run the diagnostic tool to identify issues
mise run doctor

# The doctor task will check:
# - Python version matches between mise and venvs
# - All workspace dependencies are configured
# - Dependencies are importable
# - Provides specific fix commands

# Common fixes based on doctor output:

# Fix 1: Python version mismatch
cd packages/api  # or affected package
rm -rf .venv
uv venv --python $(mise which python)
uv sync --all-groups

# Fix 2: Missing workspace dependencies
# Edit pyproject.toml and add to [tool.uv.sources]:
# lumiant-core = {workspace = true}
# lumiant = {workspace = true}
# Then run:
uv sync --all-groups

# Fix 3: Quick resync (if versions are correct)
mise run sync
```

**Prevention:**
- Always use `mise run setup` for initial installation
- Run `mise run sync` after pulling changes
- Never manually create venvs - let mise/uv handle it
- Check `mise run doctor` if anything feels off

### Package dependency issues

```bash
# Quick resync (usually fixes issues)
mise run sync

# Full reset when things are really broken
mise run reset

# Or manually clean and reinstall
mise run clean:full
mise run setup
```

### Turbo cache issues

```bash
# Force rebuild (ignore cache)
mise run build --force

# Or clear Turbo cache
rm -rf .turbo
mise run build
```

### Database connection issues

```bash
# Check Docker is running
docker ps

# Check MySQL container
docker ps | grep mysql

# Restart database
cd packages/api
pnpm run rds:stop
pnpm run rds:start

# Check logs
docker logs lumiant-local-db
```

### Build failures in CI/CD

**Common causes:**

1. **Missing tool on runner** - Run configure pipeline again
2. **Stale cache** - Clear in Bitbucket Pipeline settings
3. **Missing environment variable** - Check deployment environment settings
4. **AWS credentials expired** - Check OIDC configuration

**Debug steps:**

```bash
# Check what changed
git diff origin/mainline --name-only

# Run the same commands locally
mise run sync
mise run build
mise run test

# Check Turbo cache status
pnpm exec turbo build --dry-run
```

### pnpm store corruption

```bash
# Clean pnpm store
rm -rf .pnpm-store

# Reinstall
pnpm install --no-frozen-lockfile
```

### Python virtual environment issues

```bash
# Remove all venvs
find . -type d -name ".venv" -exec rm -rf {} +

# Recreate
uv sync --all-packages
```

## Adding New Packages

### TypeScript Package

```bash
# Create package directory
mkdir -p packages/my-package/src

# Add package.json
cd packages/my-package
cat > package.json << 'EOF'
{
  "name": "@local/my-package",
  "version": "0.1.0",
  "type": "module",
  "main": "./dist/index.js",
  "types": "./dist/index.d.ts",
  "scripts": {
    "build": "tsup",
    "test": "vitest",
    "lint": "biome check .",
    "format": "biome format --write .",
    "typecheck": "tsc --noEmit"
  },
  "devDependencies": {
    "@local/shared-config": "workspace:*",
    "typescript": "^5.0.0",
    "vitest": "^1.0.0"
  }
}
EOF

# Add TypeScript config
cat > tsconfig.json << 'EOF'
{
  "extends": "@local/shared-config/typescript/base.json",
  "compilerOptions": {
    "outDir": "./dist",
    "rootDir": "./src"
  },
  "include": ["src/**/*"]
}
EOF

# Only add turbo.json if you need custom config
# Otherwise, it inherits from root turbo.json

# Install and build
cd ../..
pnpm install
mise run build
```

### Python Package

```bash
# Create package directory
mkdir -p packages/my-package/src/my_package
mkdir -p packages/my-package/test

# Add pyproject.toml
cd packages/my-package
cat > pyproject.toml << 'EOF'
[project]
name = "my-package"
version = "0.1.0"
requires-python = ">=3.12"
dependencies = []

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.uv]
dev-dependencies = [
    "pytest>=8.0.0",
    "pytest-cov>=4.1.0",
    "ruff>=0.12.0",
    "mypy>=1.8.0"
]

[tool.ruff]
line-length = 120
target-version = "py312"

[tool.ruff.lint]
select = ["E", "F", "I", "N", "W"]

[tool.mypy]
python_version = "3.12"
strict = true
EOF

# Add package.json for npm scripts
cat > package.json << 'EOF'
{
  "name": "@local/my-package",
  "scripts": {
    "build": "lumina build",
    "test": "lumina test",
    "lint": "lumina lint",
    "format": "lumina format",
    "clean": "lumina clean"
  }
}
EOF

# Add to pnpm workspace (already configured)
# Only add turbo.json if you need custom outputs

# Sync and build
cd ../..
mise run sync
```

### Adding to pnpm Workspace

The workspace is already configured to include all packages:

```yaml
# pnpm-workspace.yaml
packages:
  - 'apps/*'
  - 'packages/*'
```

New packages are automatically detected!

## Best Practices

### Code Style

- **Python**: Ruff for linting and formatting
  - Run: `mise run lint` and `mise run format` (repo-wide), or package-local `uv run ruff check .` / `uv run ruff format .`
- **TypeScript/JavaScript**: Biome for linting and formatting
  - Run: `mise run lint` and `mise run format` (repo-wide), or package-local `pnpm lint` / `pnpm format`
- **Commits**: Use conventional commits for clarity
  - `feat:`, `fix:`, `docs:`, `chore:`, etc.
- **Testing**: Write tests for all new features
  - Python: pytest with coverage > 80%
  - TypeScript: vitest for unit tests

### Git Hooks

The repository uses **lefthook** for automatic git quality checks. When you commit (from VS Code or terminal), the following checks run automatically:

- **Linting**: Ruff for Python, Biome for TypeScript/JavaScript
- **Formatting**: Check that code is properly formatted
- **Type checking**: Pyright for Python, tsc for TypeScript (fast check, skips mypy)
- **Tests**: Runs the test suite before commit
- **Commit message validation**: commitlint validates conventional commit format via `commit-msg` hook

These checks run **in parallel** for speed and will block the commit if any fail.

**Configuration:**

```yaml
# lefthook.yml
pre-commit:
  parallel: true
  commands:
    lint:
      run: mise run lint
    format-check:
      run: mise run format:check
    typecheck:
      run: mise run typecheck
    tests:
      run: mise run test

commit-msg:
  commands:
    commitlint:
      run: pnpm exec commitlint --edit {1}
```

**Bypassing hooks (use sparingly):**

```bash
# Skip pre-commit checks
git commit --no-verify -m "fix: urgent hotfix"

# Or set environment variable
LEFTHOOK=0 git commit -m "skip hooks"
```

### Git Workflow

1. **Create feature branch** from appropriate mainline:

   ```bash
   git checkout mainline
   git pull
   git checkout -b feature/my-feature
   ```

2. **Make changes and test locally**:

   ```bash
   mise run build
   mise run test
   mise run lint
   ```

3. **Commit with descriptive messages**:

   ```bash
   git add .
   git commit -m "feat(api): add new endpoint for client data"
   ```

4. **Push and create pull request**:

   ```bash
   git push -u origin feature/my-feature
   # Create PR in Bitbucket
   ```

5. **Pipeline runs tests automatically** - Fix any failures

6. **Merge to mainline** for automatic deployment to dev

### Turborepo Best Practices

```bash
# Build specific package and its dependencies
turbo build --filter=@local/api

# Build everything that depends on a package
turbo build --filter=...@local/core

# Build affected packages (since last commit)
turbo build --filter=[HEAD^1]

# Force rebuild (bypass cache)
turbo build --force

# See what would run (dry run)
turbo build --dry-run
```

### Performance Tips

- ✅ Use `mise run sync` instead of manual `pnpm install` + `turbo build`
- ✅ Use `turbo build --filter` to build specific packages
- ✅ Let Turbo cache work - don't force rebuild unless necessary
- ✅ Run `mise run clean` periodically (not `clean:full` unless needed)
- ✅ Keep `mise.toml` tool versions pinned
- ❌ Avoid `mise run reset` unless things are broken
- ❌ Don't commit `.turbo/` or `dist/` directories

### Package Dependencies

When one package depends on another:

```json
// packages/ui/package.json
{
  "dependencies": {
    "@local/shared-config": "workspace:*" // ← Use workspace protocol
  }
}
```

Turborepo automatically builds `@local/shared-config` before `@local/ui`.

### Python Package Structure

```
packages/my-package/
├── src/
│   └── my_package/
│       ├── __init__.py
│       ├── main.py
│       └── utils.py
├── test/
│   ├── __init__.py
│   └── test_main.py
├── pyproject.toml
└── package.json
```

### TypeScript Package Structure

```
packages/my-package/
├── src/
│   ├── index.ts
│   ├── types.ts
│   └── utils.ts
├── test/
│   └── index.test.ts
├── dist/              # Generated by build
├── tsconfig.json
├── package.json
└── turbo.json         # Only if needed
```

## Resources

### Documentation

- [mise documentation](https://mise.jdx.dev/)
- [Turborepo documentation](https://turbo.build/repo/docs)
- [pnpm documentation](https://pnpm.io/)
- [uv documentation](https://docs.astral.sh/uv/)
- [AWS CDK documentation](https://docs.aws.amazon.com/cdk/)
- [Astro documentation](https://docs.astro.build/)
- [Ruff documentation](https://docs.astral.sh/ruff/)
- [FastAPI documentation](https://fastapi.tiangolo.com/)

### Internal Resources

- **Bitbucket Repository**: [bitbucket.org/finlife/lumiant](https://bitbucket.org/finlife/lumiant)
- **Pipeline History**: Bitbucket → Pipelines
- **AWS Console**: [AWS Management Console](https://console.aws.amazon.com/)
- **Sanity Studio**: Production CMS for content management

### Team Contacts

- **DevOps**: For pipeline/infrastructure issues
- **Backend Team**: For Python/API questions
- **Frontend Team**: For Astro/UI questions

## License

Proprietary - All rights reserved by Finlife/Lumiant
