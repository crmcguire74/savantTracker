# Mise Workflow Guide

This guide explains how we use [mise](https://mise.jdx.dev/) to manage tools and run tasks in the Lumiant monorepo.

## What is mise?

**mise** handles two responsibilities:

1. **Tool version management**: installs and pins Python, Node.js, pnpm, uv, ruff, biome, etc.
2. **Task runner**: provides a single command surface for common repo workflows.

Think of it as a practical combination of runtime manager + task runner.

## Why mise?

Without mise:

- Tool versions drift across machines
- Setup is manual and inconsistent
- CI and local workflows diverge

With mise:

- Consistent toolchain versions
- Single setup path for all developers
- Reproducible local and CI behavior
- Auto-activation when entering the repo

## Initial Setup

### 1) Install mise

On macOS:

```bash
brew install mise
```

### 2) Activate mise in your shell

Add to `~/.zshrc` (or equivalent):

```bash
eval "$(mise activate zsh)"
```

Reload your shell:

```bash
source ~/.zshrc
```

### 3) Install tools and dependencies

```bash
git clone git@bitbucket.org:finlife/lumiant.git
cd lumiant
mise run setup
```

## Tool Versions

Source of truth: `mise.toml`.

Current pinned toolchain includes:

- `node = "24.14.1"`
- `pnpm = "10.33.0"`
- `python = "3.12"`
- `uv = "0.8.11"`
- `ruff = "0.12.9"`
- `biome = "2.4.9"`

## Available Tasks (Workspace Level)

Run these from repo root.

### Core workflow

```bash
mise run setup            # Full setup (clean + install + build)
mise run sync             # Sync deps and build
mise run sync:unfrozen    # Sync deps without frozen lockfile
mise run build            # Build all packages via turbo
mise run test             # Run tests via turbo
mise run dev              # Start dev in parallel
mise run start            # Start via turbo start
```

### Quality and checks

```bash
mise run lint
mise run lint:fix
mise run format
mise run format:check
mise run typecheck
mise run typecheck:python
mise run typecheck:ts
mise run typecheck:mypy
mise run check            # lint + format:check + typecheck
mise run check:cicd       # lint + format:check + typecheck:ts + typecheck:mypy
```

### Cleaning and maintenance

```bash
mise run clean
mise run clean:deps
mise run clean:full
mise run reset            # Alias flow that resolves to setup
mise run doctor
mise run check-versions
mise run check:mise
```

### API-focused test helpers

```bash
mise run test:unit_test
mise run test:unit_test_detailed
```

### Deployment tasks

```bash
mise run deploy:list
mise run deploy:dev
mise run deploy:qa:au
mise run deploy:qa:us
mise run deploy:staging:au
mise run deploy:staging:us
mise run deploy:prod:au
mise run deploy:prod:us
mise run deploy:website:dev
mise run deploy:website:prod:au
```

## Package-Level Workflows

There are currently **no `pkg:*` mise tasks** in `mise.toml`.

Use one of these patterns when working in a specific package:

### TypeScript/Node packages

Run scripts from that package directory:

```bash
cd packages/ui
pnpm build
pnpm test
pnpm lint
pnpm format
```

### Python packages

Use uv in the package directory:

```bash
cd packages/api
uv sync
uv run pytest
```

## How mise Fits with Turbo and Package Scripts

Typical execution chain:

```text
mise task
  -> turbo (workspace orchestration/caching)
    -> package scripts
      -> lumina (for many package scripts)
        -> underlying tools (ruff, biome, pytest, tsc, etc.)
```

### About `lumina`

- `lumina` exists at `tools/bin/lumina`.
- `mise.toml` adds `tools/bin` to PATH via `_.path`, so `lumina` is available inside mise-managed shells.
- In practice, most developers run `pnpm <script>` in a package (which then calls `lumina`), or run workspace tasks via `mise run <task>`.

## Environment and Venv Layout

`mise.toml` exports:

```toml
[env]
_.path = [
  "{{config_root}}/tools/bin",
  "{{config_root}}/node_modules/.bin",
]
PNPM_HOME = "{{config_root}}/.pnpm-store"
WORKSPACE_ROOT = "{{config_root}}"
REQUIRED_MISE_VERSION = "2026.4.0"
```

Python environments used in this repo typically include:

- Root venv: `.venv`
- Package venvs: `packages/core/.venv`, `packages/api/.venv`, `packages/lumiant-legacy/.venv`

## Task Composition Example

`setup` currently depends on `check:mise` and `clean:full`, then performs:

1. `mise install`
2. `pnpm install --no-frozen-lockfile`
3. Package venv creation + `uv sync --all-groups` for selected Python packages
4. Editable workspace dependency installs for API/legacy packages
5. `pnpm exec turbo build --output-logs=new-only`
6. `lefthook install`

## Common Workflows

### Daily development

```bash
mise run sync
mise run dev
```

### Before pushing

```bash
mise run build
mise run test
mise run lint
mise run typecheck
```

### If things break

```bash
mise run doctor
mise run clean:full
mise run setup
```

## Troubleshooting

### mise version mismatch error

Run:

```bash
mise run check:mise
```

If it fails, update mise:

```bash
brew upgrade mise
```

### Missing dependencies after branch switch

Run:

```bash
mise run sync
```

### Python imports not resolving in a package

From the package folder:

```bash
uv sync
```

For API/legacy workspace deps, `mise run sync` also reinstalls editable links.

### Turbo cache oddities

```bash
pnpm exec turbo build --force
```

Or clear turbo cache:

```bash
rm -rf .turbo
mise run build
```

## Useful Commands

```bash
mise tasks            # list tasks
mise task info build  # task details
mise current          # current selected tool versions
mise list             # installed tool versions
mise doctor           # environment diagnostics
```

## Best Practices

1. Run `mise run sync` after pulling changes.
2. Use workspace-level `mise run ...` tasks for cross-package operations.
3. Use package-local `pnpm ...` or `uv ...` when iterating on one package.
4. Prefer `mise run clean` before reaching for `clean:full`.
5. Keep tool versions pinned in `mise.toml` and aligned with `package.json` where applicable.

## Additional Resources

- [mise Documentation](https://mise.jdx.dev/)
- [Turborepo Documentation](https://turbo.build/repo/docs)
- [pnpm Workspaces](https://pnpm.io/workspaces)
- [uv Documentation](https://docs.astral.sh/uv/)
- [Ruff Documentation](https://docs.astral.sh/ruff/)
