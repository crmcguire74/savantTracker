# Deployment Planner

> **Relevant files**
> - [`scripts/deployment-plan.mjs`](../scripts/deployment-plan.mjs) — change detection and classification
> - [`scripts/pipeline-helpers.sh`](../scripts/pipeline-helpers.sh) — deploy orchestration (`deploy_environment`, `deploy_website_only`)
> - [`packages/lumiant-cdk/lib/app.ts`](../packages/lumiant-cdk/lib/app.ts) — CDK stack filter

## Why this exists

The monorepo contains three independently deployable components — the **API** (Lambda + API Gateway), the **website** (Astro on S3/CloudFront), and **Sanity Studio** — that share a common build graph. Previously, every push to mainline rebuilt and redeployed all components, causing:

- CloudFront invalidations on unchanged website builds
- CDK stack updates when only unrelated packages changed
- Slower pipelines as more apps are added

The planner replaces that blanket approach with **explicit, file-based change detection**. It decides what to build and what to deploy before touching AWS, rather than leaving it to Turbo cache heuristics or CDK drift detection.

---

## Full flow

### 1. Entry point

```
Bitbucket step
  └─ mise run deploy:dev
       └─ sets DEPLOY_ENV=dev DEPLOY_REGION=au
            └─ mise run _deploy
                 └─ deploy_environment() in pipeline-helpers.sh
```

All environment-specific tasks (`deploy:dev`, `deploy:qa:au`, etc.) are thin wrappers that set `DEPLOY_ENV` and `DEPLOY_REGION`, then delegate to the single `deploy_environment` function.

### 2. AWS auth

`deploy_environment` authenticates with AWS via OIDC before doing anything else, so all subsequent AWS calls have valid credentials.

### 3. Git unshallow

```bash
git rev-parse --is-shallow-repository
# if true:
git fetch --unshallow
```

Bitbucket clones are always shallow (only the tip commit). Without this step, the diff base refs — `BITBUCKET_PREVIOUS_SUCCESSFUL_COMMIT` and `HEAD^` — would be unknown and the planner would fall back to a full deploy on every run.

### 4. Run the planner

```bash
eval "$(node ./scripts/deployment-plan.mjs)"
```

`eval` is intentional: the planner writes only `export VAR='value'` lines to stdout, and `eval` executes them in the current shell. This injects the deployment plan as shell environment variables without any temp files or subshell scope issues.

#### 4a. Resolve diff base

The planner selects a git ref to diff against using this priority order:

| Priority | Source | When it applies |
|---|---|---|
| 1 | `DEPLOY_DIFF_BASE` env var | Manual override — set as a Bitbucket repository or deployment variable for hotfixes, rollbacks, or ad-hoc re-deploys |
| 2 | `BITBUCKET_PREVIOUS_SUCCESSFUL_COMMIT` | Normal CI path — Bitbucket automatically provides the SHA of the last successful build on this branch. Correctly spans batch merges (multiple commits merged at once) |
| 3 | `HEAD^` | Local dev fallback for single-commit runs |
| — | `null` | No base found — forces a full deploy of all components |

#### 4b. Get changed files

```bash
git diff --name-only --diff-filter=ACDMRTUXB <base>..HEAD
```

`--diff-filter=ACDMRTUXB` includes `D` (deleted files). Deleting a source file from a tracked package is itself a code change — the deletion must be built and deployed so it takes effect in the environment.

#### 4c. Classify each file

Every changed file is mapped to one or more deployment components:

| File path pattern | Component(s) |
|---|---|
| `packages/api/`, `packages/core/`, `packages/lumiant-legacy/`, `tools/cli/` | `api` |
| `apps/astro/`, `packages/ui/`, `packages/shared-config/` | `website` |
| `apps/sanity-studio/` | `sanity` |
| `packages/momentum-cdk-constructs/`, root config files (`mise.toml`, `pnpm-lock.yaml`, etc.), `scripts/` | `api` + `website` |
| `packages/lumiant-cdk/lib/api-stack.ts` | `api` |
| `packages/lumiant-cdk/lib/website-stack.ts`, `packages/lumiant-cdk/src/lambdas/` | `website` |
| Unrecognised paths | ignored (no component flagged) |

#### 4d. Emit shell variables

To avoid oversized environment variables on large merges, the planner applies a threshold when emitting file lists:

- `MATCH_LIST_SIZE_THRESHOLD` is currently `10` in `scripts/deployment-plan.mjs`
- If a match list exceeds the threshold, the planner emits a count string (for example, `"37 files"`) instead of a comma-separated path list
- This applies to `DEPLOY_PLAN_API_MATCHES`, `DEPLOY_PLAN_WEBSITE_MATCHES`, `DEPLOY_PLAN_SANITY_MATCHES`, and `DEPLOY_PLAN_CHANGED_FILES`

```bash
export DEPLOY_PLAN_API_CHANGED='true'
export DEPLOY_PLAN_WEBSITE_CHANGED='false'
export DEPLOY_PLAN_SANITY_CHANGED='false'
export DEPLOY_PLAN_API_MATCHES='37 files'
export DEPLOY_PLAN_DIFF_BASE='a3f9b12c...'
export DEPLOY_PLAN_CHANGED_FILES='37 files'
```

When the number of matches is within the threshold, these variables still emit the full comma-separated file paths.

### 5. Log and early exit

The helper logs which components were flagged and which files triggered them. If nothing is flagged, the step exits cleanly with no build and no CDK invocation — the Bitbucket step succeeds in seconds.

### 6. Selective build

Only the packages needed to produce deployment artifacts for flagged components are built:

```bash
# API-only change:
pnpm exec turbo build \
  --filter=@local/momentum-cdk-constructs \
  --filter=@local/api

# Website-only change:
pnpm exec turbo build \
  --filter=@local/momentum-cdk-constructs \
  --filter=@local/website

# Both changed: all three filters are combined
```

`@local/momentum-cdk-constructs` is always included because CDK depends on it regardless of which stack is being deployed.

Turbo's own caching then applies within the filtered set, so unchanged packages within the selected component are also skipped.

> **Sanity exception**: `deploy:website:*` (content-triggered rebuilds) sets `TURBO_FORCE_BUILD=true` to bypass Turbo cache entirely. Sanity content changes are invisible to file hashing, so a cached Astro build could serve stale content.

### 7. Deploy each flagged component

For each flagged component, `deploy_cdk` is called with an explicit stack name:

```bash
# API changed:
LUMIANT_STACKS=Api  cdk deploy Dev-*-ap-southeast-2-Api

# Website changed (dev only in the full deploy path):
LUMIANT_STACKS=Website  cdk deploy Dev-*-ap-southeast-2-Website
```

`LUMIANT_STACKS` is read by `packages/lumiant-cdk/lib/app.ts` at synth time. The `filterStacks()` function removes all stacks not in the set before CDK constructs the app, so it never synthesises the Website CloudFormation template during an API-only deploy, and vice versa. This prevents CDK from computing a diff it has no reason to act on.

---

## Override variables

Set these as Bitbucket **repository variables** (applies to all branches) or **deployment variables** (applies to a specific environment):

| Variable | Effect |
|---|---|
| `FORCE_DEPLOY_ALL=true` | Skips the planner entirely and deploys all components unconditionally. Use to recover from a failed partial deploy. |
| `DEPLOY_DIFF_BASE=<ref>` | Compares against a specific SHA, tag, or branch instead of the last successful build. Use for hotfixes targeting a known good state or when `BITBUCKET_PREVIOUS_SUCCESSFUL_COMMIT` is not set. |

---

## Adding a new web app

When a second (B2B or B2C) web app is added the planner needs to be updated in three places:

### 1. `scripts/deployment-plan.mjs` — file classification

Add a new component key and classify the app's source paths:

```js
const componentMatches = {
  api: [],
  website: [],
  sanity: [],
  b2b: [],       // ← add new component
};

// In classifyFile():
if (file.startsWith('apps/b2b/') || /* any app-specific packages */) {
  addMatch('b2b', file);
  return;
}
```

If the new app shares `packages/ui/`, that path currently maps to `website`. If a UI change should also trigger the new app, change `addMatch('website', file)` to flag both components:

```js
if (file.startsWith('packages/ui/') || file.startsWith('packages/shared-config/')) {
  addMatch('website', file);
  addMatch('b2b', file);   // ← also flag the new app
  return;
}
```

### 2. `scripts/pipeline-helpers.sh` — selective build and deploy

Add the new component to `build_selected_artifacts` and the deploy phase of `deploy_environment`:

```bash
# In build_selected_artifacts():
"b2b")
    HAS_B2B=true
    ;;

# Build filter:
if [[ "$HAS_B2B" == "true" ]]; then
    TURBO_FILTERS+=("--filter=@local/b2b")
fi

# In deploy_environment(), after the existing website deploy block:
if [[ "$DEPLOY_PLAN_B2B_CHANGED" == "true" ]]; then
    deploy_cdk "$ENV_PREFIX" "$ACCOUNT_ID" "$REGION" "B2B" || return 1
fi
```

### 3. `packages/lumiant-cdk/lib/app.ts` — CDK stack filter

Add the new stack to the `filterStacks` call for each stage that hosts it:

```ts
stacks: filterStacks([ApiStack, WebsiteStack, B2BStack]),
```

The `LUMIANT_STACKS=B2B` env var will then correctly scope CDK to only synthesise and deploy the new stack.
