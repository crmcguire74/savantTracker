# Contributing to Lumiant Platform Monorepo

## Commit Message Standardisation

All commit messages **must** follow the [Conventional Commits](https://www.conventionalcommits.org/) standard. This is enforced by automated commit hooks (Lefthook + commitlint). If your commit message does not comply, the commit will be rejected.

### Format
```
<type>(<scope>): <subject>

[optional body]

[optional footer(s)]
```
- **type**: feat, fix, chore, docs, refactor, test, build, ci, etc.
- **scope**: (optional) the package or area affected, e.g., api, core, cdk.
- **subject**: concise summary, imperative mood, no period.
- **body**: (optional) more detail, wrapped at 100 chars.
- **footer**: (optional) BREAKING CHANGE: or issue references.

### Examples
- `feat(api): add v2 endpoint for client search`
- `fix(core): correct date parsing for AU region`
- `chore: update dependencies`
- `docs(readme): clarify setup instructions`
- `refactor(api): simplify user validation logic`
- `test(core): add coverage for new utils`
- `feat!: remove deprecated v1 endpoints`
- `fix(api): handle null values in client import\n\nCloses #1234`

### Breaking Changes
To indicate a breaking change, add `!` after the type or include a `BREAKING CHANGE:` footer:
- `feat!: migrate all endpoints to v2`
- `fix(api)!: change response format for /clients`
- Footer example:
  ```
  BREAKING CHANGE: The /clients endpoint now returns a paginated response.
  ```

### Why Standardise?
- Enables automated changelogs and semantic versioning
- Improves code review and history readability
- Required for release automation and version bumping

### Enforcement
- The `lefthook => commit-msg` hook runs `commitlint` on every commit.
- Non-compliant messages are rejected with an error.

---