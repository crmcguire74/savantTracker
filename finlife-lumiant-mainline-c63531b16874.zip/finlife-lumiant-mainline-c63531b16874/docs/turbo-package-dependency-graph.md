# How Turbo Constructs the Package Dependency Graph

Turbo builds the package dependency graph by analyzing your workspace configuration and package dependencies. This document explains the step-by-step process.

## 1. Workspace Discovery

Turbo reads your workspace configuration to find all packages:

```yaml
# pnpm-workspace.yaml
packages:
  - 'packages/*'
  - 'apps/*'
```

This tells Turbo to look for packages in:

- `packages/api`
- `packages/core`
- `packages/ui`
- `apps/astro`
- etc.

## 2. Package Dependency Analysis

For each package, Turbo reads `package.json` to find dependencies:

### Example: `packages/api/package.json`

```json
{
  "name": "@local/api",
  "dependencies": {
    "@local/core": "workspace:*", // Internal dependency
    "@local/lumiant-legacy": "workspace:*", // Internal dependency
    "fastapi": "^0.100.0" // External (ignored for graph)
  }
}
```

Turbo notes: **"@local/api depends on @local/core and @local/lumiant-legacy"**

### Example: `packages/shared-config/package.json`

```json
{
  "name": "@local/shared-config",
  "devDependencies": {
    "tailwindcss": "catalog:" // External only (no internal deps)
  }
}
```

Turbo notes: **"@local/shared-config has no internal dependencies"**

## 3. Build the Graph

Turbo constructs a directed acyclic graph (DAG):

```
┌─────────────────┐
│  @local/core    │ (no dependencies)
└────────┬────────┘
         │
         ├──────────┐
         │          │
┌────────▼────────┐ │
│ @local/legacy   │ │ (depends on core)
└────────┬────────┘ │
         │          │
         ├──────────┘
         │
┌────────▼────────┐
│  @local/api     │ (depends on core + legacy)
└─────────────────┘

┌─────────────────┐
│  @local/shared- │ (no dependencies - can build in parallel)
│     config      │
└────────┬────────┘
         │
         ├──────────┐
         │          │
┌────────▼────────┐ │
│  @local/ui      │ │ (depends on shared-config)
└────────┬────────┘ │
         │          │
         │──────────┘
         │
┌────────▼────────┐
│  @local/astro   │ (depends on ui + shared-config)
└─────────────────┘
```

## 4. Task Dependency Resolution

When you run `turbo build`, Turbo consults `turbo.json`:

```json
{
  "tasks": {
    "build": {
      "dependsOn": ["^build"] // "^" means "dependencies' build tasks first"
    }
  }
}
```

### The `dependsOn` Syntax

- **`"dependsOn": ["^build"]`** = "Run `build` on all my dependencies first"
- **`"dependsOn": ["build"]`** = "Run my own `build` first" (self-dependency)
- **`"dependsOn": ["lint", "test"]`** = "Run `lint` and `test` tasks first (in this package)"
- **`"dependsOn": ["^build", "lint"]`** = "Run dependencies' `build` first, then my `lint`"

## 5. Execution Order

Given the graph above, when you run `turbo build`:

```bash
turbo build
```

**Turbo's execution plan:**

```
Phase 1 (parallel):
  - @local/core build
  - @local/shared-config build        # No deps, can run in parallel

Phase 2 (parallel):
  - @local/legacy build    # Waits for core
  - @local/ui              # Waits for shared-config

Phase 3:
  - @local/api build       # Waits for core + legacy
  - @local/astro build     # Waits for ui (runs in parallel with api)
```

## 6. Workspace Protocol

The `workspace:*` protocol in package.json is key:

```json
{
  "dependencies": {
    "@local/core": "workspace:*" // Tells both pnpm and Turbo: internal dependency
  }
}
```

**What Turbo does:**

- Sees `workspace:*` → marks as internal dependency
- Adds edge to dependency graph
- Ensures build order respects this relationship

**What pnpm does:**

- Sees `workspace:*` → symlinks to `packages/core` instead of npm registry
- Makes TypeScript imports work: `import { something } from '@local/core'`

## 7. Example: Real Execution

```bash
# You run:
turbo build --filter=@local/api

# Turbo analyzes:
1. @local/api depends on @local/core, @local/lumiant-legacy
2. @local/lumiant-legacy depends on @local/core
3. @local/core has no dependencies

# Turbo executes:
Step 1: cd packages/core && pnpm run build
Step 2: cd packages/lumiant-legacy && pnpm run build
Step 3: cd packages/api && pnpm run build

# With caching:
Step 1: ✓ @local/core:build (CACHED)          # Hash matched, skip
Step 2: ✓ @local/lumiant-legacy:build (CACHED)
Step 3: → @local/api:build (RUNNING)          # No cache, must run
```

## 8. How Turbo Detects Changes

Turbo hashes inputs to determine if rebuild is needed:

```json
{
  "tasks": {
    "build": {
      "inputs": ["src/**", "package.json", "tsconfig.json", "pyproject.toml"],
      "outputs": ["dist/**", "build/**"]
    }
  }
}
```

### Hash Calculation

```
hash = sha256(
  file_contents(src/**) +
  file_contents(package.json) +
  file_contents(tsconfig.json) +
  file_contents(pyproject.toml) +
  hash_of_dependency_outputs
)
```

**Cache decision:**

- If `hash` matches cached hash → use cached output
- If `hash` differs → rebuild

### Global Dependencies

Files in `globalDependencies` invalidate ALL caches when changed:

```json
{
  "globalDependencies": ["tsconfig.json", "biome.js", "mise.toml", "pnpm-workspace.yaml"]
}
```

If any of these files change, all packages must rebuild.

## 9. Tool Hierarchy & Responsibilities

```
mise (tool version manager + task runner)
  ├── manages: node, pnpm, python, uv, ruff versions
  ├── provides: workspace-level task commands (mise sync, mise build, etc.)
  └── delegates to:
      │
      ├── pnpm (package manager)
      │   ├── installs: node_modules dependencies
      │   ├── manages: workspace packages (via pnpm-workspace.yaml)
      │   └── runs: package.json scripts
      │
      ├── turbo (build orchestrator)
      │   ├── reads: turbo.json configuration
      │   ├── orchestrates: build/test/lint tasks across packages
      │   ├── provides: intelligent caching, parallel execution
      │   └── calls: package.json scripts (which use pnpm/tools)
      │
      └── uv (Python package manager)
          ├── installs: Python dependencies
          ├── manages: virtual environments
          └── runs: Python packages/scripts
```

### Execution Flow

```bash
mise build
  ↓
turbo build --output-logs=new-only
  ↓
reads turbo.json (task configuration)
  ↓
determines package dependency graph
  ↓
executes "build" script from each package.json in order
  ↓
pnpm run build (in each package)
  ↓
runs the actual build command (tsup, astro build, uv build, etc.)
```

## 10. Why You Need Both pnpm AND Turbo

### pnpm alone:

- ✅ Can install dependencies
- ✅ Can run scripts
- ❌ No build caching
- ❌ No incremental builds
- ❌ No dependency graph awareness
- ❌ Must run scripts manually in order

### Turbo alone:

- ❌ Can't install dependencies
- ❌ Can't run scripts directly
- ✅ Build caching
- ✅ Incremental builds
- ✅ Dependency graph orchestration
- ✅ Parallel execution

### pnpm + Turbo together:

- ✅ pnpm installs deps and provides script runner
- ✅ Turbo orchestrates builds with caching
- ✅ Best of both worlds

## 11. Verification Commands

```bash
# See the dependency graph visually
turbo run build --graph=graph.html  # Opens in browser

# See execution plan without running
turbo run build --dry-run

# See detailed summary after execution
turbo run build --summarize

# See what would run for a specific package
turbo run build --filter=@local/api --dry-run

# Force rebuild (ignore cache)
turbo run build --force

# Only build packages that changed
turbo run build --filter=[HEAD^1]
```

## 12. Common Patterns

### Pattern 1: Build depends on dependency builds

```json
{
  "tasks": {
    "build": {
      "dependsOn": ["^build"]
    }
  }
}
```

This is the most common pattern - ensures dependencies are built before dependents.

### Pattern 2: Test depends on build

```json
{
  "tasks": {
    "test": {
      "dependsOn": ["build"]
    }
  }
}
```

Tests need the built code to run against.

### Pattern 3: Lint is independent

```json
{
  "tasks": {
    "lint": {
      "dependsOn": []
    }
  }
}
```

Linting can run on source code without needing builds.

### Pattern 4: Deploy depends on everything

```json
{
  "tasks": {
    "deploy": {
      "dependsOn": ["build", "test", "lint"],
      "cache": false
    }
  }
}
```

Deployment needs everything to pass first, and shouldn't be cached.

## 13. Example: Lumiant Monorepo Graph

Based on the Lumiant workspace structure, the dependency graph is:

### Python Packages

```
┌─────────────────┐
│  @local/core    │
└────────┬────────┘
         │
┌────────▼────────┐
│  @local/legacy  │
└────────┬────────┘
         │
┌────────▼────────┐
│  @local/api     │
└─────────────────┘
```

### TypeScript Packages

```
┌─────────────────┐
│ @local/shared-  │
│     config      │
└────────┬────────┘
         │
┌────────▼────────┐
│  @local/ui      │
└────────┬────────┘
         │
┌────────▼────────┐
│ @local/astro    │
└─────────────────┘
```

### CDK Packages

```
┌─────────────────┐
│ @local/momentum-│
│ cdk-constructs  │
└────────┬────────┘
         │
┌────────▼────────┐
│ @local/lumiant- │
│      cdk        │
└─────────────────┘
```

These three sub-graphs can build **completely in parallel** since they don't depend on each other.

## Key Takeaways

1. **Turbo reads `package.json` dependencies** to build the graph automatically
2. **`workspace:*` protocol** marks internal dependencies for both pnpm and Turbo
3. **`dependsOn: ["^build"]`** in turbo.json controls task ordering
4. **Parallel execution** happens when packages have no dependency relationship
5. **Caching** uses input hashes + dependency output hashes for intelligent cache invalidation
6. **The graph is automatic** - you don't configure it manually, just declare package dependencies
7. **Turbo orchestrates, pnpm executes** - they work together, not separately
8. **Hash-based caching** ensures correctness while maximizing speed

This architecture is why monorepos with Turbo scale so well - the dependency graph ensures correctness while maximizing parallelism and caching efficiency.

## Further Reading

- [Turbo Documentation - Task Dependencies](https://turbo.build/repo/docs/core-concepts/monorepos/task-dependencies)
- [Turbo Documentation - Caching](https://turbo.build/repo/docs/core-concepts/caching)
- [pnpm Workspace Protocol](https://pnpm.io/workspaces#workspace-protocol-workspace)
- [Understanding Directed Acyclic Graphs](https://en.wikipedia.org/wiki/Directed_acyclic_graph)
