# Linting and Type Checking

This document describes the current linting and type-checking workflow for the Lumiant monorepo.

## Overview

Code quality checks run at three layers:

1. IDE feedback while coding (Pylance, Ruff, Biome)
2. Package-local scripts (`pnpm ...` in package folders, `uv ...` in Python packages)
3. Workspace-level checks via `mise run ...` and Turborepo caching

## Tooling

### Python

| Tool | Purpose | Typical Use |
|------|---------|-------------|
| Ruff | Lint + format | Dev + CI |
| Pyright | Fast type checking | Dev + pre-commit + CI |
| Mypy | Stricter type checking | CI-focused |

### TypeScript/Astro

| Tool | Purpose | Typical Use |
|------|---------|-------------|
| Biome | Lint + format | Dev + CI |
| tsc | Type checking | Dev + CI |

## Source of Truth

Primary task definitions are in `mise.toml`.

Key workspace tasks:

- `mise run lint`
- `mise run lint:fix`
- `mise run format`
- `mise run format:check`
- `mise run typecheck`
- `mise run typecheck:python`
- `mise run typecheck:ts`
- `mise run typecheck:mypy`
- `mise run check`
- `mise run check:cicd`

There are currently no `pkg:*` mise tasks.

## Package-Level Usage

### TypeScript/Astro packages and apps

From the package/app directory:

```bash
pnpm lint
pnpm lint:fix
pnpm typecheck
pnpm format
pnpm format:check
```

Many package scripts call `lumina` internally, but developers should use package scripts (`pnpm ...`) or workspace tasks (`mise run ...`).

### Python packages

From the package directory:

```bash
uv sync
uv run pytest
pnpm lint
pnpm format
pnpm typecheck
```

Note: in this monorepo, Python package lint/typecheck commands are commonly exposed through package scripts and can be run via `pnpm ...` as above.

## Recommended Workflow

### Fast local iteration (single package)

```bash
cd packages/api
pnpm lint
pnpm typecheck
```

### Full repo verification

```bash
mise run check
```

### CI-style checks

```bash
mise run check:cicd
```

## Task Behavior

### `mise run typecheck`

Runs Turborepo typecheck tasks across packages. This is the default broad type-check command.

### `mise run typecheck:python`

Runs type-check for selected Python packages via Turbo filters.

### `mise run typecheck:ts`

Runs TypeScript checks via Turbo filters for TS packages/apps.

### `mise run typecheck:mypy`

Runs stricter mypy checks (currently targeted at API package sources/tests).

## Caching and Performance

- Turborepo caches lint/typecheck tasks where configured.
- Re-running checks is significantly faster when inputs are unchanged.
- Use `pnpm exec turbo <task> --force` to bypass cache when needed.

Examples:

```bash
pnpm exec turbo lint --force
pnpm exec turbo typecheck --force
```

## Common Workflows

### Before committing

```bash
mise run check
```

### Auto-fix style issues

```bash
mise run lint:fix
mise run format
```

### Full clean and rebuild when environment is inconsistent

```bash
mise run clean:full
mise run setup
```

## IDE Integration

### VS Code

Recommended extensions:

- ms-python.python
- ms-python.vscode-pylance
- charliermarsh.ruff
- biomejs.biome

The workspace already includes recommendations in the workspace file.

## Troubleshooting

### I switched branches and checks started failing unexpectedly

```bash
mise run sync
```

### Typecheck result seems stale

```bash
pnpm exec turbo typecheck --force
```

### Python import/type resolution is broken in a package

```bash
cd packages/api
uv sync
```

## Notes on lumina

`tools/bin/lumina` is used by many package scripts. `mise.toml` adds `tools/bin` to PATH via `_.path`, so lumina is available inside mise-managed shells.

For day-to-day usage:

- Use `mise run ...` for workspace-wide workflows
- Use `pnpm ...` and `uv ...` inside specific packages
